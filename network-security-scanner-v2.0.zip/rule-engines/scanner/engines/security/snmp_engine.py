"""SNMP Security Analysis Engine."""

import re
from typing import List, Dict, Any, Optional
from ..base_engine import BaseSecurityEngine, EngineCategory, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector
from ..utils import safe_get_content, create_mock_config_line


class SNMPSecurityEngine(BaseSecurityEngine):
    """Comprehensive SNMP security analysis engine."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 15
    
    def get_category(self) -> EngineCategory:
        return EngineCategory.SECURITY
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.HIGH
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS, VendorType.JUNIPER_JUNOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze SNMP configuration for security issues."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_snmp(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._analyze_juniper_snmp(parsed_config))
        
        return findings
    
    def _analyze_cisco_snmp(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco SNMP configuration."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Extract SNMP configuration
        snmp_config = self._extract_snmp_config(config_lines)
        
        # Run SNMP security checks
        findings.extend(self._check_snmp_communities(snmp_config))
        findings.extend(self._check_snmp_versions(snmp_config))
        findings.extend(self._check_snmp_access_lists(snmp_config))
        findings.extend(self._check_snmp_traps(snmp_config))
        findings.extend(self._check_snmp_users(snmp_config))
        
        return findings
    
    def _extract_snmp_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract SNMP configuration from config lines."""
        snmp_config = {
            "communities": [],
            "users": [],
            "groups": [],
            "views": [],
            "trap_hosts": [],
            "engine_id": None,
            "contact": None,
            "location": None
        }
        
        for line in config_lines:
            content = safe_get_content(line)
            if not hasattr(line, 'content'):
                line = create_mock_config_line(content)
            
            # SNMP community strings
            community_match = re.match(r'snmp-server community (\S+)(?:\s+(RO|RW))(?:\s+(\d+))?', content)
            if community_match:
                community = {
                    "string": community_match.group(1),
                    "access": community_match.group(2),
                    "acl": community_match.group(3),
                    "config_line": line
                }
                snmp_config["communities"].append(community)
                continue
            
            # SNMP users (v3)
            user_match = re.match(r'snmp-server user (\S+)', content)
            if user_match:
                snmp_config["users"].append({
                    "username": user_match.group(1),
                    "config_line": line
                })
                continue
            
            # SNMP trap hosts
            trap_match = re.match(r'snmp-server host (\S+)(?:\s+(\S+))?', content)
            if trap_match:
                snmp_config["trap_hosts"].append({
                    "host": trap_match.group(1),
                    "community": trap_match.group(2),
                    "config_line": line
                })
                continue
            
            # SNMP engine ID
            if "snmp-server engineID" in content:
                snmp_config["engine_id"] = {
                    "config_line": line,
                    "command": content
                }
            
            # SNMP contact/location
            if "snmp-server contact" in content:
                snmp_config["contact"] = line
            elif "snmp-server location" in content:
                snmp_config["location"] = line
        
        return snmp_config
    
    def _check_snmp_communities(self, snmp_config: Dict) -> List[Finding]:
        """Check SNMP community string security."""
        findings = []
        
        communities = snmp_config.get("communities", [])
        
        # Check for default/weak community strings
        weak_communities = []
        for community in communities:
            community_string = community["string"].lower()
            if community_string in ["public", "private", "community", "cisco", "admin"]:
                weak_communities.append(community)
        
        if weak_communities:
            findings.append(self.create_finding(
                rule_id="SNMP-001",
                title="SNMP Default/Weak Community Strings",
                description=f"Default or weak SNMP community strings detected: {', '.join(c['string'] for c in weak_communities)}. "
                           f"These are easily guessable and pose significant security risks.",
                severity=Severity.CRITICAL,
                category="SNMP Security",
                config_line=weak_communities[0]["config_line"],
                recommendation="Use strong, unique SNMP community strings",
                fix_commands=["snmp-server community <STRONG_COMMUNITY> RO 99"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-3", "IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for RW communities
        rw_communities = [c for c in communities if c["access"] == "RW"]
        if rw_communities:
            findings.append(self.create_finding(
                rule_id="SNMP-002",
                title="SNMP Read-Write Communities Configured",
                description=f"SNMP read-write communities detected: {', '.join(c['string'] for c in rw_communities)}. "
                           f"RW access allows configuration changes via SNMP.",
                severity=Severity.HIGH,
                category="SNMP Security",
                config_line=rw_communities[0]["config_line"],
                recommendation="Disable RW access or restrict to management networks only",
                fix_commands=["snmp-server community <COMMUNITY> RO 99"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["AC-3", "CM-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for communities without ACL restrictions
        unrestricted_communities = [c for c in communities if not c["acl"]]
        if unrestricted_communities:
            findings.append(self.create_finding(
                rule_id="SNMP-003",
                title="SNMP Communities Without Access Restrictions",
                description=f"SNMP communities without ACL restrictions: {', '.join(c['string'] for c in unrestricted_communities)}. "
                           f"Should be restricted to management networks.",
                severity=Severity.MEDIUM,
                category="SNMP Security",
                config_line=unrestricted_communities[0]["config_line"],
                recommendation="Apply access lists to restrict SNMP access to management networks",
                fix_commands=["snmp-server community <COMMUNITY> RO 99"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["AC-3", "SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_snmp_versions(self, snmp_config: Dict) -> List[Finding]:
        """Check SNMP version usage."""
        findings = []
        
        communities = snmp_config.get("communities", [])
        users = snmp_config.get("users", [])
        
        # If communities exist but no SNMPv3 users, assume v1/v2c usage
        if communities and not users:
            findings.append(self.create_finding(
                rule_id="SNMP-004",
                title="SNMP v1/v2c in Use",
                description="SNMP v1/v2c detected (community strings present without v3 users). "
                           "These versions transmit community strings in clear text.",
                severity=Severity.HIGH,
                category="SNMP Security",
                config_line=communities[0]["config_line"],
                recommendation="Migrate to SNMPv3 with authentication and encryption",
                fix_commands=[
                    "snmp-server user <USER> <GROUP> v3 auth sha <AUTHKEY> priv aes 128 <PRIVKEY>",
                    "no snmp-server community <OLD_COMMUNITY>"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-8", "SC-13"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_snmp_access_lists(self, snmp_config: Dict) -> List[Finding]:
        """Check SNMP access list configuration."""
        # This would be enhanced with actual ACL analysis
        # For now, basic check is done in _check_snmp_communities
        return []
    
    def _check_snmp_traps(self, snmp_config: Dict) -> List[Finding]:
        """Check SNMP trap configuration."""
        findings = []
        
        trap_hosts = snmp_config.get("trap_hosts", [])
        
        # Check for trap hosts with weak communities
        weak_trap_communities = []
        for trap in trap_hosts:
            if trap.get("community") and trap["community"].lower() in ["public", "private"]:
                weak_trap_communities.append(trap)
        
        if weak_trap_communities:
            findings.append(self.create_finding(
                rule_id="SNMP-005",
                title="SNMP Traps Using Default Communities",
                description=f"SNMP trap hosts using default communities detected. "
                           f"Trap authentication may be compromised.",
                severity=Severity.MEDIUM,
                category="SNMP Security",
                config_line=weak_trap_communities[0]["config_line"],
                recommendation="Use strong community strings for SNMP traps",
                fix_commands=["snmp-server host <HOST> <STRONG_COMMUNITY>"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-3", "AU-9"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_snmp_users(self, snmp_config: Dict) -> List[Finding]:
        """Check SNMPv3 user configuration."""
        findings = []
        
        users = snmp_config.get("users", [])
        
        # This is a basic check - in reality would need to parse user details
        if not users and snmp_config.get("communities"):
            # Already covered in version check
            pass
        
        return findings
    
    def _analyze_juniper_snmp(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Juniper SNMP configuration (placeholder)."""
        # TODO: Implement Juniper SNMP analysis
        return []