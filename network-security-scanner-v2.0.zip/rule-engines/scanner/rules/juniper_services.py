"""Network services rules for Juniper JunOS.

Detects insecure or unnecessary network services including:
- HTTP/HTTPS services
- FTP server
- Finger service
- LLDP/LLDP-MED
- NTP configuration
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class JuniperServicesRules(BaseRuleEngine):
    """Network services security rules for Juniper JunOS."""

    def __init__(self):
        super().__init__()
        self.category = "Network Services"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check network services security rules."""
        findings = []

        if vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._check_juniper_services(parsed_config))

        return findings

    def _check_juniper_services(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Juniper network services configuration."""
        findings = []

        # Get system configuration
        system = config.get('system', {})
        services = system.get('services', {})

        # Check for HTTP service
        if 'web-management' in services and 'http' in services.get('web-management', {}):
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-001",
                title="Insecure HTTP Management Interface Enabled",
                description="HTTP web management interface is enabled on the device. HTTP transmits all data "
                          "in cleartext, including authentication credentials. An attacker with network access "
                          "can intercept administrative credentials and session cookies using packet sniffing.",
                severity="CRITICAL",
                recommendation="Disable HTTP and use HTTPS only for web management",
                fix_commands=[
                    "delete system services web-management http",
                    "set system services web-management https system-generated-certificate"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["SC-8", "AC-17", "IA-2(8)"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check for FTP service
        if 'ftp' in services:
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-002",
                title="Insecure FTP Service Enabled",
                description="FTP service is enabled on the device. FTP transmits credentials and data in "
                          "cleartext, making it vulnerable to interception. FTP also has known vulnerabilities "
                          "and should not be used for secure file transfers.",
                severity="HIGH",
                recommendation="Disable FTP service and use SCP or SFTP instead",
                fix_commands=[
                    "delete system services ftp"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-8", "AC-17"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check for Finger service
        if 'finger' in services:
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-003",
                title="Finger Service Enabled",
                description="Finger service is enabled on the device. Finger provides user information to "
                          "anonymous network users, which can be used for reconnaissance. This information "
                          "helps attackers identify valid usernames for brute-force attacks.",
                severity="MEDIUM",
                recommendation="Disable Finger service",
                fix_commands=[
                    "delete system services finger"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["SC-7", "CM-7"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check NTP configuration
        ntp_config = system.get('ntp', {})
        if not ntp_config.get('servers'):
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-004",
                title="NTP Server Not Configured",
                description="No NTP servers are configured on the device. Without accurate time synchronization, "
                          "log correlation becomes impossible, certificate validation may fail, and time-based "
                          "security policies cannot be enforced. This severely impacts forensic investigations "
                          "and security event correlation.",
                severity="HIGH",
                recommendation="Configure NTP servers with authentication",
                fix_commands=[
                    "set system ntp server <ntp_server_ip>",
                    "set system ntp authentication-key 1 type md5 value <key>",
                    "set system ntp server <ntp_server_ip> key 1",
                    "set system ntp trusted-key 1"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AU-8", "AU-12"],
                vendor=VendorType.JUNIPER_JUNOS
            ))
        elif not ntp_config.get('authentication'):
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-005",
                title="NTP Authentication Not Configured",
                description="NTP servers are configured but authentication is not enabled. Without authentication, "
                          "an attacker can spoof NTP responses and manipulate the device's system time. This can "
                          "be used to bypass time-based access controls, invalidate certificates, or hide attack "
                          "activities in logs.",
                severity="MEDIUM",
                recommendation="Enable NTP authentication",
                fix_commands=[
                    "set system ntp authentication-key 1 type md5 value <key>",
                    "set system ntp server <ntp_server_ip> key 1",
                    "set system ntp trusted-key 1"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AU-8(1)", "SC-8"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check for LLDP
        protocols = config.get('protocols', {})
        if 'lldp' in protocols:
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-006",
                title="LLDP Protocol Enabled",
                description="LLDP (Link Layer Discovery Protocol) is enabled on the device. LLDP broadcasts "
                          "detailed device information including hostname, interface names, IP addresses, and "
                          "capabilities to all connected devices. This information can be used by attackers for "
                          "network reconnaissance and mapping.",
                severity="LOW",
                recommendation="Disable LLDP if not required for network management",
                fix_commands=[
                    "delete protocols lldp",
                    "# Or disable on specific interfaces:",
                    "set protocols lldp interface <interface> disable"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["SC-7", "CM-7"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        if 'lldp-med' in protocols:
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-007",
                title="LLDP-MED Protocol Enabled",
                description="LLDP-MED (LLDP for Media Endpoint Devices) is enabled. Like LLDP, this protocol "
                          "broadcasts device information to connected devices, which can be used for network "
                          "reconnaissance. Unless specifically required for VoIP endpoint management, this "
                          "should be disabled.",
                severity="LOW",
                recommendation="Disable LLDP-MED if not required",
                fix_commands=[
                    "delete protocols lldp-med"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["SC-7", "CM-7"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check for syslog configuration
        syslog = system.get('syslog', {})
        if not syslog.get('hosts') and not syslog.get('files'):
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-008",
                title="Syslog Not Configured",
                description="No syslog configuration is present on the device. Without logging, security events "
                          "and system activities are not recorded, making forensic investigation impossible and "
                          "preventing detection of security incidents or configuration changes.",
                severity="HIGH",
                recommendation="Configure syslog to remote server and/or local files",
                fix_commands=[
                    "set system syslog host <syslog_server> any any",
                    "set system syslog file messages any any",
                    "set system syslog file interactive-commands interactive-commands any"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AU-2", "AU-3", "AU-4", "AU-9"],
                vendor=VendorType.JUNIPER_JUNOS
            ))
        elif not syslog.get('hosts'):
            findings.append(self.create_finding(
                rule_id="JUNOS-SVC-009",
                title="Remote Syslog Server Not Configured",
                description="Syslog is configured for local files only, without a remote syslog server. If the "
                          "device is compromised, an attacker can delete local logs to hide their activities. "
                          "Remote logging to a secure server prevents log tampering.",
                severity="MEDIUM",
                recommendation="Configure remote syslog server",
                fix_commands=[
                    "set system syslog host <syslog_server> any any",
                    "set system syslog host <syslog_server> authorization any"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AU-4(1)", "AU-9(2)"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        return findings
