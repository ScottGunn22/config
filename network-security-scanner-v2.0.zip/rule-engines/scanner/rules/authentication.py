"""Authentication security rules."""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class AuthenticationRules(BaseRuleEngine):
    """Security rules for authentication configurations."""
    
    def __init__(self):
        super().__init__()
        self.category = "Authentication"
    
    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check authentication-related security rules."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._check_cisco_authentication(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._check_juniper_authentication(parsed_config))
        
        return findings
    
    def _check_cisco_authentication(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Cisco IOS authentication rules."""
        findings = []
        auth = config.get("authentication", {})
        
        # Rule: Enable secret not configured
        if not auth.get("enable_secret", False):
            findings.append(self.create_finding(
                rule_id="AUTH-001",
                title="Enable Secret Not Configured",
                description="The 'enable secret' command is not configured. This means there is no strongly hashed password for privileged EXEC mode, posing a critical security risk.",
                severity="CRITICAL",
                recommendation="Configure a strong enable secret password",
                fix_commands=["enable secret <STRONG_PASSWORD>"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L", 
                    privileges_required="L",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-5", "AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: AAA new-model not configured
        if not auth.get("aaa_new_model", False):
            findings.append(self.create_finding(
                rule_id="AUTH-002",
                title="AAA New-Model Not Configured",
                description="AAA new-model is not configured, indicating a lack of centralized authentication, authorization, and accounting enforcement.",
                severity="HIGH",
                recommendation="Enable AAA new-model for centralized access control",
                fix_commands=["aaa new-model"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-2", "AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Enable password with enable secret
        if auth.get("enable_secret", False) and auth.get("enable_password", False):
            findings.append(self.create_finding(
                rule_id="AUTH-003", 
                title="Both Enable Secret and Enable Password Configured",
                description="Both enable secret and enable password are configured. The enable password provides a fallback that uses weaker encryption.",
                severity="MEDIUM",
                recommendation="Remove the enable password command",
                fix_commands=["no enable password"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="H",
                    privileges_required="L",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Check line authentication
        line_configs = config.get("line_configs", {})
        for line_name, line_config in line_configs.items():
            # Check for missing authentication on VTY lines
            if "vty" in line_name.lower():
                auth_configured = False
                for config_line in line_config.get("config_lines", []):
                    if "login authentication" in config_line.content or "login local" in config_line.content:
                        auth_configured = True
                        break
                
                if not auth_configured:
                    # Find the line declaration for context
                    line_decl = line_config.get("config_lines", [None])[0]
                    findings.append(self.create_finding(
                        rule_id="AUTH-004",
                        title="Missing Login Authentication on VTY Lines",
                        description=f"No explicit login authentication configured for {line_name}. This could allow unauthenticated access to the device.",
                        severity="HIGH",
                        config_line=line_decl,
                        recommendation="Configure login authentication on all VTY lines",
                        fix_commands=["login authentication default", "login local"],
                        cvss_vector=CVSSVector(
                            attack_vector="N",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H", 
                            availability="H"
                        ),
                        nist_controls=["IA-2"],
                        vendor=VendorType.CISCO_IOS
                    ))
        
        return findings
    
    def _check_juniper_authentication(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Juniper JUNOS authentication rules."""
        findings = []
        system = config.get("system", {})
        
        # Rule: Direct root login via SSH
        ssh_config = system.get("services", {}).get("ssh", {})
        if ssh_config.get("root_login", False):
            # Find the config line for context
            root_login_line = None
            for line in ssh_config.get("config_lines", []):
                if "root-login" in line.content:
                    root_login_line = line
                    break
            
            findings.append(self.create_finding(
                rule_id="AUTH-J001",
                title="Direct Root Login via SSH Allowed",
                description="Direct root login via SSH is allowed, which is insecure and hinders accountability.",
                severity="HIGH",
                config_line=root_login_line,
                recommendation="Disable direct root login via SSH",
                fix_commands=["delete system services ssh root-login"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["AC-2"],
                vendor=VendorType.JUNIPER_JUNOS
            ))
        
        return findings