#!/usr/bin/env python3
"""
Compare findings between two scanner runs or different tools.
Useful for identifying false positives by comparison.
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Set


def load_findings(file_path: Path) -> Dict[str, Set[int]]:
    """Load findings from JSON report."""
    with open(file_path, 'r') as f:
        data = json.load(f)

    findings = {}
    for finding in data.get('security_findings', []):
        title = finding['title']
        line_num = finding.get('line_number', 0)

        if title not in findings:
            findings[title] = set()
        findings[title].add(line_num)

    return findings


def compare_findings(baseline: Dict[str, Set[int]], current: Dict[str, Set[int]]):
    """Compare two sets of findings."""

    # New findings (potentially false positives if baseline is trusted)
    new_findings = {}
    for title, lines in current.items():
        if title not in baseline:
            new_findings[title] = lines
        else:
            new_lines = lines - baseline[title]
            if new_lines:
                new_findings[title] = new_lines

    # Missing findings (potentially false negatives)
    missing_findings = {}
    for title, lines in baseline.items():
        if title not in current:
            missing_findings[title] = lines
        else:
            missing_lines = baseline[title] - current[title]
            if missing_lines:
                missing_findings[title] = missing_lines

    # Common findings (likely correct)
    common_findings = {}
    for title, lines in baseline.items():
        if title in current:
            common_lines = lines & current[title]
            if common_lines:
                common_findings[title] = common_lines

    return new_findings, missing_findings, common_findings


def generate_report(new_findings, missing_findings, common_findings,
                   baseline_name, current_name):
    """Generate comparison report."""

    print("=" * 80)
    print("FINDING COMPARISON REPORT")
    print("=" * 80)
    print(f"Baseline: {baseline_name}")
    print(f"Current:  {current_name}")
    print()

    # Summary
    total_new = sum(len(lines) for lines in new_findings.values())
    total_missing = sum(len(lines) for lines in missing_findings.values())
    total_common = sum(len(lines) for lines in common_findings.values())

    print("SUMMARY")
    print("-" * 80)
    print(f"Common Findings:  {len(common_findings)} rules ({total_common} instances)")
    print(f"New Findings:     {len(new_findings)} rules ({total_new} instances)")
    print(f"Missing Findings: {len(missing_findings)} rules ({total_missing} instances)")
    print()

    # New findings - could be false positives
    if new_findings:
        print("NEW FINDINGS (in Current, not in Baseline)")
        print("-" * 80)
        print("⚠️  These could be false positives if baseline is trusted")
        print("✓  Or these could be improvements in detection")
        print()

        for title, lines in sorted(new_findings.items()):
            print(f"  • {title}")
            print(f"    Lines: {sorted(lines)}")
        print()

    # Missing findings - could be false negatives
    if missing_findings:
        print("MISSING FINDINGS (in Baseline, not in Current)")
        print("-" * 80)
        print("⚠️  These could be false negatives (detection failures)")
        print("✓  Or baseline tool may have had false positives")
        print()

        for title, lines in sorted(missing_findings.items()):
            print(f"  • {title}")
            print(f"    Lines: {sorted(lines)}")
        print()

    # Common findings - likely correct
    if common_findings:
        print("COMMON FINDINGS (in Both)")
        print("-" * 80)
        print("✓  High confidence - both tools agree")
        print()

        for title, lines in sorted(common_findings.items()):
            print(f"  • {title}")
            print(f"    Lines: {sorted(lines)}")
        print()

    print("=" * 80)

    # Recommendations
    print("\nRECOMMENDATIONS:")
    print("-" * 80)

    if new_findings:
        print("1. Review NEW findings manually:")
        print("   - Check if they're legitimate issues")
        print("   - Verify line numbers are correct")
        print("   - Look for pattern in false positives")

    if missing_findings:
        print("2. Investigate MISSING findings:")
        print("   - Why didn't current scanner detect these?")
        print("   - Are they real issues that were missed?")
        print("   - Update detection rules if needed")

    if not new_findings and not missing_findings:
        print("✓ Perfect match! Both scanners produce identical results.")

    print()


def main():
    """Main comparison entry point."""

    if len(sys.argv) != 3:
        print("Usage: python3 compare_results.py <baseline.json> <current.json>")
        print()
        print("Example:")
        print("  python3 compare_results.py nipper_results.json our_results.json")
        print("  python3 compare_results.py previous_scan.json new_scan.json")
        sys.exit(1)

    baseline_file = Path(sys.argv[1])
    current_file = Path(sys.argv[2])

    if not baseline_file.exists():
        print(f"Error: Baseline file not found: {baseline_file}")
        sys.exit(1)

    if not current_file.exists():
        print(f"Error: Current file not found: {current_file}")
        sys.exit(1)

    try:
        baseline = load_findings(baseline_file)
        current = load_findings(current_file)

        new_findings, missing_findings, common_findings = compare_findings(
            baseline, current
        )

        generate_report(
            new_findings,
            missing_findings,
            common_findings,
            baseline_file.name,
            current_file.name
        )

    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
