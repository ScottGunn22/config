"""Benchmark validation engine for CIS, DISA STIG, and vendor hardening guides."""

import re
from typing import List, Dict, Any, Optional
from benchmark_rules import CISBenchmarkRules, DISTIGRules, VendorHardeningGuideRules, BenchmarkRule


class BenchmarkValidator:
    """Validates network configurations against security benchmarks."""

    def __init__(self):
        """Initialize benchmark validator with all rule sets."""
        self.cis_cisco_rules = CISBenchmarkRules.get_cisco_ios_rules()
        self.stig_cisco_rules = DISTIGRules.get_cisco_ios_rules()
        self.cisco_hardening_rules = VendorHardeningGuideRules.get_cisco_hardening_rules()

        # ASA and NX-OS specific rules
        self.cis_asa_rules = CISBenchmarkRules.get_cisco_asa_rules()
        self.cis_nxos_rules = CISBenchmarkRules.get_cisco_nxos_rules()

    def validate_cisco_ios(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco IOS configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_cisco_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def validate_cisco_asa(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco ASA configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS ASA Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_asa_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks (many apply to ASA as well)
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks (many apply to ASA)
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def validate_cisco_nxos(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco NX-OS configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS NX-OS Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_nxos_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks (many apply to NX-OS as well)
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks (many apply to NX-OS)
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def _run_benchmark_checks(self, rules: List[BenchmarkRule],
                              config_lines: List,
                              parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Run benchmark checks and return findings."""
        findings = []

        for rule in rules:
            check_func = getattr(self, rule.check_function, None)
            if check_func:
                result = check_func(config_lines, parsed_config)
                if result:
                    finding = {
                        "rule_id": rule.rule_id,
                        "title": rule.title,
                        "description": rule.description,
                        "severity": rule.severity,
                        "category": "Benchmark Compliance",
                        "benchmark_id": rule.benchmark_id,
                        "benchmark_name": rule.benchmark_name,
                        "recommendation": rule.recommendation,
                        "fix_commands": rule.fix_commands,
                        "nist_controls": rule.nist_controls,
                        "compliant": result["compliant"],
                        "details": result.get("details", "")
                    }

                    if not result["compliant"]:
                        findings.append(finding)

        return findings

    # CIS Benchmark check functions

    def check_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.1: Check hostname is configured."""
        has_hostname = any(
            self._safe_content(line).startswith("hostname ")
            for line in config_lines
        )

        # Check if hostname is default
        default_hostnames = ["Router", "Switch", "router", "switch"]
        hostname_value = None
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("hostname "):
                hostname_value = content.split()[1] if len(content.split()) > 1 else None

        is_default = hostname_value in default_hostnames if hostname_value else True

        return {
            "compliant": has_hostname and not is_default,
            "details": f"Hostname: {hostname_value}" if hostname_value else "No hostname configured"
        }

    def check_enable_secret(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.2: Check enable secret is configured."""
        has_enable_secret = any(
            self._safe_content(line).startswith("enable secret")
            for line in config_lines
        )

        return {
            "compliant": has_enable_secret,
            "details": "Enable secret configured" if has_enable_secret else "Enable secret not found"
        }

    def check_password_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.3: Check password encryption is enabled."""
        has_encryption = any(
            "service password-encryption" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_encryption,
            "details": "Password encryption enabled" if has_encryption else "Password encryption not enabled"
        }

    def check_login_banner(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.4: Check login banner is configured."""
        has_banner = any(
            re.search(r'banner (login|motd)', self._safe_content(line), re.I)
            for line in config_lines
        )

        return {
            "compliant": has_banner,
            "details": "Login banner configured" if has_banner else "No login banner found"
        }

    def check_no_http_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.1: Check HTTP server is disabled."""
        http_enabled = any(
            self._safe_content(line) == "ip http server"
            for line in config_lines
        )

        http_disabled = any(
            self._safe_content(line) == "no ip http server"
            for line in config_lines
        )

        return {
            "compliant": not http_enabled or http_disabled,
            "details": "HTTP server properly disabled" if not http_enabled or http_disabled else "HTTP server is enabled"
        }

    def check_https_secure(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.2: Check HTTPS is properly configured if enabled."""
        https_enabled = any(
            "ip http secure-server" in self._safe_content(line)
            for line in config_lines
        )

        if not https_enabled:
            return {"compliant": True, "details": "HTTPS not enabled (acceptable)"}

        # If HTTPS is enabled, check for proper TLS version
        has_tls_12 = any(
            "tlsv1.2" in self._safe_content(line).lower()
            for line in config_lines
        )

        return {
            "compliant": has_tls_12,
            "details": "HTTPS with TLS 1.2+" if has_tls_12 else "HTTPS enabled but TLS version not configured"
        }

    def check_ssh_version_2(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.3: Check SSH version 2 is configured."""
        has_ssh_v2 = any(
            "ip ssh version 2" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_ssh_v2,
            "details": "SSH version 2 configured" if has_ssh_v2 else "SSH version not explicitly set to 2"
        }

    def check_vty_transport_ssh(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.4: Check VTY lines use SSH only."""
        in_vty_block = False
        vty_ssh_only = True
        vty_found = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'line vty', content):
                in_vty_block = True
                vty_found = True
            elif in_vty_block and content.startswith("line "):
                in_vty_block = False
            elif in_vty_block and "transport input" in content:
                if "ssh" not in content or ("telnet" in content or "all" in content):
                    vty_ssh_only = False

        if not vty_found:
            return {"compliant": False, "details": "No VTY lines configured"}

        return {
            "compliant": vty_ssh_only,
            "details": "VTY lines use SSH only" if vty_ssh_only else "VTY lines allow insecure protocols"
        }

    def check_exec_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.5: Check exec-timeout is configured appropriately."""
        timeout_issues = []
        in_line_block = False
        current_line = None

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'line (console|aux|vty)', content):
                in_line_block = True
                current_line = content.split()[1]
            elif in_line_block and content.startswith("line "):
                in_line_block = False
                current_line = None
            elif in_line_block and "exec-timeout" in content:
                # Parse timeout value (minutes seconds)
                match = re.search(r'exec-timeout (\d+)(?: (\d+))?', content)
                if match:
                    minutes = int(match.group(1))
                    if minutes > 10 or minutes == 0:
                        timeout_issues.append(current_line)

        return {
            "compliant": len(timeout_issues) == 0,
            "details": f"Timeout issues on: {', '.join(timeout_issues)}" if timeout_issues else "All timeouts properly configured"
        }

    def check_no_source_route(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.3.1: Check IP source routing is disabled."""
        has_no_source_route = any(
            "no ip source-route" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_no_source_route,
            "details": "IP source routing disabled" if has_no_source_route else "IP source routing not disabled"
        }

    def check_no_proxy_arp(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.3.2: Check proxy ARP is disabled."""
        has_no_proxy_arp = any(
            "no ip proxy-arp" in self._safe_content(line)
            for line in config_lines
        )

        # This is a recommendation, not always required
        return {
            "compliant": has_no_proxy_arp,
            "details": "Proxy ARP disabled" if has_no_proxy_arp else "Proxy ARP not explicitly disabled"
        }

    def check_aaa_new_model(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.4.1: Check AAA new-model is enabled."""
        has_aaa = any(
            "aaa new-model" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa,
            "details": "AAA new-model enabled" if has_aaa else "AAA new-model not configured"
        }

    def check_aaa_authentication_login(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.4.2: Check AAA authentication login is configured."""
        has_auth_login = any(
            "aaa authentication login" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_auth_login,
            "details": "AAA authentication login configured" if has_auth_login else "AAA authentication login not configured"
        }

    def check_logging_buffered(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.5.1: Check logging buffered is configured."""
        has_logging_buffered = any(
            "logging buffered" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_logging_buffered,
            "details": "Logging buffered configured" if has_logging_buffered else "Logging buffered not configured"
        }

    def check_logging_host(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.5.2: Check remote logging is configured."""
        has_logging_host = any(
            re.match(r'logging (host|\d+\.\d+\.\d+\.\d+)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_logging_host,
            "details": "Remote logging configured" if has_logging_host else "No remote logging server configured"
        }

    # DISA STIG check functions

    def check_console_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3056: Check console authentication."""
        in_console = False
        has_auth = False

        for line in config_lines:
            content = self._safe_content(line)
            if "line console" in content:
                in_console = True
            elif in_console and content.startswith("line "):
                break
            elif in_console and ("login authentication" in content or "login local" in content):
                has_auth = True

        return {
            "compliant": has_auth,
            "details": "Console authentication configured" if has_auth else "Console lacks authentication"
        }

    def check_fips_mode(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3057: Check FIPS mode or approved algorithms."""
        # Check for SSH v2 and strong key size as proxy
        has_ssh_v2 = any("ip ssh version 2" in self._safe_content(line) for line in config_lines)
        has_strong_rsa = any(re.search(r'crypto key generate rsa.*(?:2048|4096)', self._safe_content(line)) for line in config_lines)

        return {
            "compliant": has_ssh_v2 and has_strong_rsa,
            "details": "FIPS-approved algorithms in use" if (has_ssh_v2 and has_strong_rsa) else "FIPS compliance not verified"
        }

    def check_dod_banner(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3058: Check DoD banner."""
        has_banner = any(re.search(r'banner login', self._safe_content(line), re.I) for line in config_lines)

        return {
            "compliant": has_banner,
            "details": "Login banner configured" if has_banner else "No login banner"
        }

    def check_logging_protection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3059: Check logging protection."""
        has_logging_host = any(re.match(r'logging (host|\d+\.\d+\.\d+\.\d+)', self._safe_content(line)) for line in config_lines)

        return {
            "compliant": has_logging_host,
            "details": "Logging to secure server" if has_logging_host else "No secure logging configured"
        }

    def check_password_length(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3210: Check minimum password length."""
        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'security passwords min-length (\d+)', content)
            if match:
                length = int(match.group(1))
                return {
                    "compliant": length >= 15,
                    "details": f"Password min-length: {length}"
                }

        return {
            "compliant": False,
            "details": "Password min-length not configured"
        }

    def check_session_timeout_stig(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3058: Check session timeout."""
        return self.check_exec_timeout(config_lines, parsed_config)

    def check_pki_certificates(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3069: Check PKI certificates."""
        has_pki = any("crypto pki" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_pki,
            "details": "PKI configured" if has_pki else "No PKI configuration"
        }

    def check_snmp_version(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3143: Check SNMP version."""
        has_snmpv1v2 = any(
            re.search(r'snmp-server community \S+ (RO|RW)', self._safe_content(line))
            for line in config_lines
        )

        has_snmpv3 = any(
            "snmp-server group" in self._safe_content(line) and "v3" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": not has_snmpv1v2 or has_snmpv3,
            "details": "SNMPv3 configured" if has_snmpv3 else "SNMPv1/v2c detected" if has_snmpv1v2 else "No SNMP configured"
        }

    def check_control_plane_policing(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3175: Check control plane policing."""
        has_copp = any(
            re.search(r'control-plane|service-policy.*control-plane', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_copp,
            "details": "Control plane policing configured" if has_copp else "No CoPP configured"
        }

    def check_management_acl(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3057: Check management ACL."""
        in_vty = False
        has_acl = False

        for line in config_lines:
            content = self._safe_content(line)
            if "line vty" in content:
                in_vty = True
            elif in_vty and content.startswith("line "):
                break
            elif in_vty and "access-class" in content:
                has_acl = True

        return {
            "compliant": has_acl,
            "details": "Management ACL configured" if has_acl else "No VTY access control"
        }

    # Vendor Hardening Guide check functions

    def check_unnecessary_services(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check unnecessary services are disabled."""
        unnecessary_services = ["cdp run", "ip finger", "service pad"]
        issues = []

        for service in unnecessary_services:
            if any(service in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines):
                issues.append(service)

        return {
            "compliant": len(issues) == 0,
            "details": f"Unnecessary services enabled: {', '.join(issues)}" if issues else "Unnecessary services disabled"
        }

    def check_tcp_keepalives(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check TCP keepalives."""
        has_keepalives_in = any("service tcp-keepalives-in" in self._safe_content(line) for line in config_lines)
        has_keepalives_out = any("service tcp-keepalives-out" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_keepalives_in and has_keepalives_out,
            "details": "TCP keepalives configured" if (has_keepalives_in and has_keepalives_out) else "TCP keepalives not fully configured"
        }

    def check_no_icmp_redirects(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check ICMP redirects disabled."""
        has_no_redirects = any("no ip redirects" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_no_redirects,
            "details": "ICMP redirects disabled" if has_no_redirects else "ICMP redirects not disabled"
        }

    def check_urpf_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check uRPF enabled."""
        has_urpf = any("ip verify unicast source reachable-via" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_urpf,
            "details": "uRPF enabled" if has_urpf else "uRPF not configured"
        }

    def check_ntp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check NTP authentication."""
        has_ntp_auth = any("ntp authenticate" in self._safe_content(line) for line in config_lines)
        has_ntp_key = any("ntp authentication-key" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_ntp_auth and has_ntp_key,
            "details": "NTP authentication configured" if (has_ntp_auth and has_ntp_key) else "NTP authentication not configured"
        }

    # ASA-specific check functions

    def check_asa_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check hostname is configured."""
        has_hostname = any(
            self._safe_content(line).startswith("hostname ")
            for line in config_lines
        )

        # Check if hostname is default
        default_hostnames = ["ciscoasa", "asa", "firewall"]
        hostname_value = None
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("hostname "):
                hostname_value = content.split()[1] if len(content.split()) > 1 else None

        is_default = hostname_value.lower() in default_hostnames if hostname_value else True

        return {
            "compliant": has_hostname and not is_default,
            "details": f"Hostname: {hostname_value}" if hostname_value else "No hostname configured"
        }

    def check_asa_enable_password(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check enable password is configured with encryption."""
        has_enable_password = any(
            self._safe_content(line).startswith("enable password")
            for line in config_lines
        )

        # Check if encrypted (ASA uses 'encrypted' keyword or shows hash)
        has_encrypted = False
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("enable password"):
                # ASA shows encrypted passwords with 'encrypted' keyword or hash
                if "encrypted" in content or len(content.split()) >= 3:
                    has_encrypted = True

        return {
            "compliant": has_enable_password and has_encrypted,
            "details": "Enable password configured with encryption" if (has_enable_password and has_encrypted) else "Enable password not properly configured"
        }

    def check_asa_no_http_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check HTTP server is disabled."""
        http_enabled = any(
            "http server enable" in self._safe_content(line)
            for line in config_lines
        )

        http_disabled = any(
            "no http server enable" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": not http_enabled or http_disabled,
            "details": "HTTP server properly disabled" if not http_enabled or http_disabled else "HTTP server is enabled"
        }

    def check_asa_ssh_version(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check SSH version 2 is configured."""
        has_ssh_v2 = any(
            "ssh version 2" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_ssh_v2,
            "details": "SSH version 2 configured" if has_ssh_v2 else "SSH version not explicitly set to 2"
        }

    def check_asa_management_access(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check management access restrictions are configured."""
        has_ssh_restriction = any(
            re.match(r'ssh\s+\d+\.\d+\.\d+\.\d+', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_ssh_restriction,
            "details": "SSH access restricted by IP" if has_ssh_restriction else "No SSH access restrictions configured"
        }

    def check_asa_aaa_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check AAA authentication is configured."""
        has_aaa_auth = any(
            "aaa authentication" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa_auth,
            "details": "AAA authentication configured" if has_aaa_auth else "AAA authentication not configured"
        }

    def check_asa_logging_host(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check logging to remote host is configured."""
        has_logging_host = any(
            re.match(r'logging host\s+', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_logging_host,
            "details": "Remote logging configured" if has_logging_host else "No remote logging server configured"
        }

    def check_asa_logging_trap(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check logging trap level is configured."""
        has_logging_trap = any(
            "logging trap" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_logging_trap,
            "details": "Logging trap level configured" if has_logging_trap else "Logging trap level not configured"
        }

    def check_asa_icmp_unreachable(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check ICMP unreachable is disabled."""
        has_no_icmp_unreachable = any(
            "no icmp unreachable" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_no_icmp_unreachable,
            "details": "ICMP unreachable disabled" if has_no_icmp_unreachable else "ICMP unreachable not disabled"
        }

    # NX-OS-specific check functions

    def check_nxos_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check switchname/hostname is configured."""
        has_switchname = any(
            self._safe_content(line).startswith("switchname ") or self._safe_content(line).startswith("hostname ")
            for line in config_lines
        )

        # Check if hostname is default
        default_hostnames = ["switch", "nexus", "nxos"]
        hostname_value = None
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("switchname ") or content.startswith("hostname "):
                hostname_value = content.split()[1] if len(content.split()) > 1 else None

        is_default = hostname_value.lower() in default_hostnames if hostname_value else True

        return {
            "compliant": has_switchname and not is_default,
            "details": f"Switchname: {hostname_value}" if hostname_value else "No switchname configured"
        }

    def check_nxos_password_strength(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check password strength checking is enabled."""
        has_strength_check = any(
            "password strength-check" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_strength_check,
            "details": "Password strength checking enabled" if has_strength_check else "Password strength checking not enabled"
        }

    def check_nxos_ssh_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check SSH feature is enabled and Telnet is disabled."""
        has_ssh = any(
            "feature ssh" in self._safe_content(line)
            for line in config_lines
        )

        has_telnet = any(
            "feature telnet" in self._safe_content(line) and not self._safe_content(line).startswith("no ")
            for line in config_lines
        )

        return {
            "compliant": has_ssh and not has_telnet,
            "details": "SSH enabled, Telnet disabled" if (has_ssh and not has_telnet) else "SSH not properly configured"
        }

    def check_nxos_ssh_key_strength(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check SSH key strength is sufficient."""
        has_strong_key = any(
            re.search(r'ssh key rsa (2048|4096)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_strong_key,
            "details": "Strong SSH key configured" if has_strong_key else "Strong SSH key not configured"
        }

    def check_nxos_exec_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check exec-timeout is configured on VTY lines."""
        timeout_issues = []
        in_line_block = False
        current_line = None

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'line (console|vty)', content):
                in_line_block = True
                current_line = content.split()[1]
            elif in_line_block and content.startswith("line "):
                in_line_block = False
                current_line = None
            elif in_line_block and "exec-timeout" in content:
                # Parse timeout value (minutes)
                match = re.search(r'exec-timeout (\d+)', content)
                if match:
                    minutes = int(match.group(1))
                    if minutes > 10 or minutes == 0:
                        timeout_issues.append(current_line)

        return {
            "compliant": len(timeout_issues) == 0,
            "details": f"Timeout issues on: {', '.join(timeout_issues)}" if timeout_issues else "All timeouts properly configured"
        }

    def check_nxos_aaa_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check AAA authentication is configured."""
        has_aaa_auth = any(
            "aaa authentication login" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa_auth,
            "details": "AAA authentication configured" if has_aaa_auth else "AAA authentication not configured"
        }

    def check_nxos_logging_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check logging server is configured."""
        has_logging_server = any(
            re.match(r'logging server', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_logging_server,
            "details": "Remote logging server configured" if has_logging_server else "No remote logging server configured"
        }

    def check_nxos_logging_level(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check logging level is configured."""
        has_logging_level = any(
            re.match(r'logging level', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_logging_level,
            "details": "Logging level configured" if has_logging_level else "Logging level not configured"
        }

    def check_nxos_unnecessary_features(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check unnecessary features are disabled."""
        unnecessary_features = ["feature dhcp", "feature dns"]
        issues = []

        for feature in unnecessary_features:
            if any(feature in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines):
                issues.append(feature)

        return {
            "compliant": len(issues) == 0,
            "details": f"Unnecessary features enabled: {', '.join(issues)}" if issues else "Unnecessary features disabled"
        }

    # New ASA Check Functions (25 functions)

    def check_asa_security_levels(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check security levels configured on interfaces."""
        has_nameif = any("nameif" in self._safe_content(line) for line in config_lines)
        has_security_level = any("security-level" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_security_level if has_nameif else True, "details": "Security levels configured" if has_security_level else "Missing security-level configuration"}

    def check_asa_same_security_traffic(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check same-security-traffic configuration."""
        has_same_security = any("same-security-traffic permit" in self._safe_content(line) for line in config_lines)
        return {"compliant": not has_same_security, "details": "Same-security-traffic disabled" if not has_same_security else "Same-security-traffic enabled (review)"}

    def check_asa_object_groups(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check use of object groups."""
        has_object_groups = any("object-group" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_object_groups, "details": "Object groups configured" if has_object_groups else "No object groups found"}

    def check_asa_threat_detection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check threat detection enabled."""
        has_threat_detection = any("threat-detection" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_threat_detection, "details": "Threat detection enabled" if has_threat_detection else "Threat detection not configured"}

    def check_asa_inspection_policies(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check inspection policies configured."""
        has_inspect = any(re.search(r'inspect (dns|http|ftp|icmp)', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_inspect, "details": "Inspection policies configured" if has_inspect else "No inspection policies found"}

    def check_asa_connection_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check connection limits configured."""
        has_conn_limit = any("set connection conn-max" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_conn_limit, "details": "Connection limits configured" if has_conn_limit else "No connection limits found"}

    def check_asa_tcp_normalization(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check TCP normalization/map configured."""
        has_tcp_map = any("tcp-map" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_tcp_map, "details": "TCP normalization configured" if has_tcp_map else "TCP normalization not configured"}

    def check_asa_timeout_values(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check timeout values configured."""
        has_timeout = any(re.search(r'timeout (xlate|conn)', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_timeout, "details": "Timeout values configured" if has_timeout else "Default timeout values in use"}

    def check_asa_dns_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check DNS inspection enabled."""
        has_dns_inspect = any("inspect dns" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_dns_inspect, "details": "DNS inspection enabled" if has_dns_inspect else "DNS inspection not enabled"}

    def check_asa_http_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check HTTP inspection enabled."""
        has_http_inspect = any("inspect http" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_http_inspect, "details": "HTTP inspection enabled" if has_http_inspect else "HTTP inspection not enabled"}

    def check_asa_ftp_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check FTP inspection enabled."""
        has_ftp_inspect = any("inspect ftp" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ftp_inspect, "details": "FTP inspection enabled" if has_ftp_inspect else "FTP inspection not enabled"}

    def check_asa_ikev2_vpn(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check IKEv2 configured for VPN."""
        has_ikev2 = any("crypto ikev2" in self._safe_content(line) for line in config_lines)
        has_ikev1 = any("crypto isakmp" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ikev2 or not has_ikev1, "details": "IKEv2 configured" if has_ikev2 else ("No VPN configured" if not has_ikev1 else "Only IKEv1 configured")}

    def check_asa_ipsec_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check strong IPsec encryption (AES-256)."""
        has_crypto = any(re.search(r'crypto ipsec', self._safe_content(line)) for line in config_lines)
        if not has_crypto:
            return {"compliant": True, "details": "No IPsec configured"}
        has_aes256 = any("aes-256" in self._safe_content(line) for line in config_lines)
        has_weak = any(re.search(r'(des|3des)\s', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_aes256 and not has_weak, "details": "Strong encryption (AES-256)" if has_aes256 else "Weak or no encryption configured"}

    def check_asa_vpn_pfs(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check VPN PFS configured."""
        has_crypto_map = any("crypto map" in self._safe_content(line) for line in config_lines)
        if not has_crypto_map:
            return {"compliant": True, "details": "No crypto map configured"}
        has_pfs = any("set pfs" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_pfs, "details": "PFS configured" if has_pfs else "PFS not configured"}

    def check_asa_anyconnect_auth(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check AnyConnect authentication configured."""
        has_anyconnect = any("anyconnect" in self._safe_content(line) or "webvpn" in self._safe_content(line) for line in config_lines)
        if not has_anyconnect:
            return {"compliant": True, "details": "AnyConnect not configured"}
        has_auth = any("authentication-server-group" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_auth, "details": "AnyConnect authentication configured" if has_auth else "AnyConnect lacks AAA authentication"}

    def check_asa_ssl_vpn_ciphers(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check SSL VPN cipher configuration."""
        has_ssl_cipher = any(re.search(r'ssl cipher', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_ssl_cipher, "details": "SSL ciphers configured" if has_ssl_cipher else "Default SSL ciphers in use"}

    def check_asa_no_weak_vpn(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check weak VPN protocols disabled."""
        has_vpdn = any("vpdn enable" in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines)
        return {"compliant": not has_vpdn, "details": "Weak VPN protocols disabled" if not has_vpdn else "VPDN (PPTP/L2TP) enabled"}

    def check_asa_twice_nat(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check network object NAT usage."""
        has_object_nat = any("object network" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_object_nat, "details": "Object NAT configured" if has_object_nat else "Traditional NAT in use"}

    def check_asa_outbound_acls(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check outbound ACLs configured."""
        has_outbound_acl = any(re.search(r'access-group.*out', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_outbound_acl, "details": "Outbound ACLs configured" if has_outbound_acl else "No outbound ACL filtering"}

    def check_asa_acl_logging(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check ACL logging configured."""
        has_acl = any("access-list" in self._safe_content(line) for line in config_lines)
        if not has_acl:
            return {"compliant": True, "details": "No ACLs configured"}
        has_log = any("access-list" in self._safe_content(line) and "log" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_log, "details": "ACL logging configured" if has_log else "ACLs lack logging"}

    def check_asa_failover_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check failover encryption configured."""
        has_failover = any("failover" in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines)
        if not has_failover:
            return {"compliant": True, "details": "Failover not configured"}
        has_key = any("failover key" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_key, "details": "Failover encryption configured" if has_key else "Failover lacks encryption"}

    def check_asa_botnet_filter(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check Botnet Traffic Filter enabled."""
        has_botnet = any("dynamic-filter" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_botnet, "details": "Botnet Traffic Filter enabled" if has_botnet else "Botnet Traffic Filter not enabled"}

    def check_asa_vpn_accounting(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check VPN accounting configured."""
        has_vpn_acct = any("aaa accounting" in self._safe_content(line) and "vpn" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_vpn_acct, "details": "VPN accounting configured" if has_vpn_acct else "VPN accounting not configured"}

    def check_asa_unnecessary_services(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check unnecessary services disabled."""
        has_ftp = any("ftp mode" in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines)
        return {"compliant": not has_ftp, "details": "Unnecessary services disabled" if not has_ftp else "FTP service enabled"}

    def check_asa_ntp_timezone(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check NTP and timezone configured."""
        has_ntp = any("ntp server" in self._safe_content(line) for line in config_lines)
        has_timezone = any("clock timezone" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ntp and has_timezone, "details": f"NTP: {has_ntp}, Timezone: {has_timezone}"}

    # ASA-Specific DISA STIG Check Functions (10 functions)

    def check_asa_stig_management_interface(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check management access restricted by interface."""
        http_lines = [line for line in config_lines if "http " in self._safe_content(line) and " " in self._safe_content(line).split("http ", 1)[1]]
        ssh_lines = [line for line in config_lines if "ssh " in self._safe_content(line) and " " in self._safe_content(line).split("ssh ", 1)[1]]

        # Check if management commands specify interface (not "any" or missing)
        http_has_interface = any(
            len(self._safe_content(line).split()) >= 4
            for line in http_lines
        )
        ssh_has_interface = any(
            len(self._safe_content(line).split()) >= 4
            for line in ssh_lines
        )

        compliant = (len(http_lines) == 0 or http_has_interface) and (len(ssh_lines) == 0 or ssh_has_interface)
        return {
            "compliant": compliant,
            "details": "Management access restricted by interface" if compliant else "Management access not restricted by interface"
        }

    def check_asa_stig_aaa_management(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check AAA configured for device management."""
        has_aaa_http = any(
            "aaa authentication http console" in self._safe_content(line)
            for line in config_lines
        )
        has_aaa_ssh = any(
            "aaa authentication ssh console" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_aaa_http or has_aaa_ssh
        return {
            "compliant": compliant,
            "details": "AAA configured for management" if compliant else "AAA not configured for management"
        }

    def check_asa_stig_session_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check session timeout does not exceed 10 minutes."""
        ssh_timeout = None
        http_timeout = None

        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("ssh timeout "):
                try:
                    ssh_timeout = int(content.split()[2])
                except (IndexError, ValueError):
                    pass
            elif content.startswith("http timeout "):
                try:
                    http_timeout = int(content.split()[2])
                except (IndexError, ValueError):
                    pass

        # STIG requires 10 minutes or less
        ssh_compliant = ssh_timeout is None or ssh_timeout <= 10
        http_compliant = http_timeout is None or http_timeout <= 10

        compliant = ssh_compliant and http_compliant
        return {
            "compliant": compliant,
            "details": f"SSH timeout: {ssh_timeout or 'not set'}, HTTP timeout: {http_timeout or 'not set'}" +
                      (" (exceeds 10 min)" if not compliant else "")
        }

    def check_asa_stig_acl_logging(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check access-lists log denied traffic."""
        acl_lines = [line for line in config_lines if "access-list " in self._safe_content(line) and " deny " in self._safe_content(line)]

        if not acl_lines:
            return {"compliant": True, "details": "No deny ACLs configured"}

        acls_with_logging = sum(1 for line in acl_lines if " log" in self._safe_content(line))
        compliant = acls_with_logging == len(acl_lines)

        return {
            "compliant": compliant,
            "details": f"{acls_with_logging}/{len(acl_lines)} deny ACLs have logging enabled"
        }

    def check_asa_stig_privilege_levels(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check privilege levels properly separated."""
        privilege_lines = [line for line in config_lines if "privilege " in self._safe_content(line) and " level " in self._safe_content(line)]

        # Check if custom privilege levels are defined (not just 0, 1, 15)
        custom_levels = set()
        for line in privilege_lines:
            content = self._safe_content(line)
            match = re.search(r'level\s+(\d+)', content)
            if match:
                level = int(match.group(1))
                if level not in [0, 1, 15]:
                    custom_levels.add(level)

        compliant = len(custom_levels) > 0
        return {
            "compliant": compliant,
            "details": f"{len(custom_levels)} custom privilege level(s) configured" if compliant else "No privilege level separation configured"
        }

    def check_asa_stig_connection_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check connection timeouts configured."""
        has_conn_timeout = any("timeout conn" in self._safe_content(line) for line in config_lines)
        has_xlate_timeout = any("timeout xlate" in self._safe_content(line) for line in config_lines)

        compliant = has_conn_timeout and has_xlate_timeout
        return {
            "compliant": compliant,
            "details": "Connection timeouts configured" if compliant else "Missing connection timeout configuration"
        }

    def check_asa_stig_snmp_default_community(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check no default SNMP community strings."""
        has_public = any(
            "snmp-server community public" in self._safe_content(line)
            for line in config_lines
        )
        has_private = any(
            "snmp-server community private" in self._safe_content(line)
            for line in config_lines
        )

        compliant = not has_public and not has_private
        return {
            "compliant": compliant,
            "details": "No default SNMP communities" if compliant else "Default SNMP community strings detected (public/private)"
        }

    def check_asa_stig_encrypted_management(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check management uses encrypted protocols only."""
        has_ssh = any("ssh " in self._safe_content(line) and "ssh " == self._safe_content(line)[:4] for line in config_lines)
        has_https = any("http server enable" in self._safe_content(line) for line in config_lines)
        has_telnet = any("telnet " in self._safe_content(line) and "telnet " == self._safe_content(line)[:7] for line in config_lines)

        # Compliant if SSH or HTTPS enabled, and no telnet
        compliant = (has_ssh or has_https) and not has_telnet
        return {
            "compliant": compliant,
            "details": f"SSH: {has_ssh}, HTTPS: {has_https}, Telnet: {has_telnet}" +
                      (" - Uses encrypted management" if compliant else " - Insecure protocols detected or no encrypted management")
        }

    def check_asa_stig_context_admin(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check security context admin restricted."""
        has_mode_multiple = any("mode multiple" in self._safe_content(line) for line in config_lines)

        if not has_mode_multiple:
            return {"compliant": True, "details": "Not in multiple context mode"}

        # In multiple context mode, check for admin context restrictions
        has_admin_context = any("context admin" in self._safe_content(line) for line in config_lines)
        has_allocate_interface = any("allocate-interface" in self._safe_content(line) for line in config_lines)

        compliant = has_admin_context and has_allocate_interface
        return {
            "compliant": compliant,
            "details": "Admin context restricted" if compliant else "Admin context not properly restricted"
        }

    def check_asa_stig_traffic_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check traffic inspection configured."""
        has_policy_map = any("policy-map" in self._safe_content(line) for line in config_lines)
        has_inspect = any("inspect " in self._safe_content(line) for line in config_lines)

        # Check for common inspection protocols
        inspect_protocols = ["inspect http", "inspect ftp", "inspect dns"]
        protocols_configured = sum(
            1 for protocol in inspect_protocols
            if any(protocol in self._safe_content(line) for line in config_lines)
        )

        compliant = has_policy_map and has_inspect and protocols_configured >= 2
        return {
            "compliant": compliant,
            "details": f"Traffic inspection: {protocols_configured} protocol(s) configured" if compliant else "Insufficient traffic inspection configured"
        }

    # New NXOS Check Functions (25 functions)

    def check_nxos_vdc_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VDC resource limits configured."""
        has_vdc = any(re.match(r'^vdc\s+', self._safe_content(line)) for line in config_lines)
        if not has_vdc:
            return {"compliant": True, "details": "VDC not in use"}
        has_limits = any("limit-resource" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_limits, "details": "VDC resource limits configured" if has_limits else "VDC lacks resource limits"}

    def check_nxos_vdc_separation(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VDC separation configured."""
        vdc_count = len([line for line in config_lines if re.match(r'^vdc\s+', self._safe_content(line))])
        return {"compliant": vdc_count > 1 or vdc_count == 0, "details": f"{vdc_count} VDCs configured" if vdc_count > 0 else "VDC not in use"}

    def check_nxos_vdc_ha(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VDC HA policy configured."""
        has_vdc = any(re.match(r'^vdc\s+', self._safe_content(line)) for line in config_lines)
        if not has_vdc:
            return {"compliant": True, "details": "VDC not in use"}
        has_ha_policy = any("ha-policy" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ha_policy, "details": "VDC HA policy configured" if has_ha_policy else "VDC lacks HA policy"}

    def check_nxos_vpc_keepalive(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC peer-keepalive configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_keepalive = any("peer-keepalive" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_keepalive, "details": "vPC peer-keepalive configured" if has_keepalive else "vPC lacks peer-keepalive"}

    def check_nxos_vpc_peerlink(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC peer-link configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_peerlink = any("vpc peer-link" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_peerlink, "details": "vPC peer-link configured" if has_peerlink else "vPC lacks peer-link"}

    def check_nxos_vpc_autorecovery(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC auto-recovery configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_autorecovery = any("auto-recovery" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_autorecovery, "details": "vPC auto-recovery configured" if has_autorecovery else "vPC lacks auto-recovery"}

    def check_nxos_vpc_priority(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC role priority configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_priority = any("role priority" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_priority, "details": "vPC role priority configured" if has_priority else "vPC using default priority"}

    def check_nxos_fex_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check FEX authentication configured."""
        has_fex = any(re.match(r'^fex\s+', self._safe_content(line)) for line in config_lines)
        if not has_fex:
            return {"compliant": True, "details": "FEX not configured"}
        has_pinning = any("pinning" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_pinning, "details": "FEX pinning configured" if has_pinning else "FEX lacks pinning/authentication"}

    def check_nxos_fex_maxlinks(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check FEX max-links configured."""
        has_fex = any(re.match(r'^fex\s+', self._safe_content(line)) for line in config_lines)
        if not has_fex:
            return {"compliant": True, "details": "FEX not configured"}
        has_maxlinks = any("max-links" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_maxlinks, "details": "FEX max-links configured" if has_maxlinks else "FEX using default max-links"}

    def check_nxos_custom_roles(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check custom RBAC roles configured."""
        custom_roles = [line for line in config_lines if re.match(r'^role name\s+(?!network-admin|network-operator)', self._safe_content(line))]
        return {"compliant": len(custom_roles) > 0, "details": f"{len(custom_roles)} custom roles configured" if custom_roles else "No custom roles configured"}

    def check_nxos_session_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check session limits configured."""
        has_session_limit = any("limit-max-sessions" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_session_limit, "details": "Session limits configured" if has_session_limit else "No session limits configured"}

    def check_nxos_command_authorization(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check command authorization enabled."""
        has_cmd_authz = any("aaa authorization commands" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_cmd_authz, "details": "Command authorization configured" if has_cmd_authz else "Command authorization not configured"}

    def check_nxos_admin_role_count(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check network-admin role usage."""
        admin_users = [line for line in config_lines if "role network-admin" in self._safe_content(line)]
        return {"compliant": len(admin_users) <= 3, "details": f"{len(admin_users)} users with network-admin role" if admin_users else "No network-admin users found"}

    def check_nxos_ra_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 RA Guard configured."""
        has_ra_guard = any("ipv6 nd raguard" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ra_guard, "details": "IPv6 RA Guard configured" if has_ra_guard else "IPv6 RA Guard not configured"}

    def check_nxos_nd_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 ND Inspection configured."""
        has_nd_inspection = any("ipv6 nd inspection" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_nd_inspection, "details": "IPv6 ND Inspection configured" if has_nd_inspection else "IPv6 ND Inspection not configured"}

    def check_nxos_dhcpv6_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 DHCP Guard configured."""
        has_dhcpv6_guard = any("ipv6 dhcp guard" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_dhcpv6_guard, "details": "IPv6 DHCP Guard configured" if has_dhcpv6_guard else "IPv6 DHCP Guard not configured"}

    def check_nxos_ipv6_source_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 Source Guard configured."""
        has_ipv6_sg = any("ipv6 source-guard" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ipv6_sg, "details": "IPv6 Source Guard configured" if has_ipv6_sg else "IPv6 Source Guard not configured"}

    def check_nxos_bfd(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check BFD configured."""
        has_bfd = any("feature bfd" in self._safe_content(line) or "bfd interval" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_bfd, "details": "BFD configured" if has_bfd else "BFD not configured"}

    def check_nxos_graceful_restart(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check graceful restart configured."""
        has_gr = any("graceful-restart" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_gr, "details": "Graceful restart configured" if has_gr else "Graceful restart not configured"}

    def check_nxos_cfs_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check CFS authentication enabled."""
        has_cfs = any("cfs distribute" in self._safe_content(line) for line in config_lines)
        if not has_cfs:
            return {"compliant": True, "details": "CFS not enabled"}
        has_auth = any("enable-authentication" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_auth, "details": "CFS authentication enabled" if has_auth else "CFS lacks authentication"}

    def check_nxos_vxlan_security(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VXLAN security configured."""
        has_vxlan = any("feature nv overlay" in self._safe_content(line) for line in config_lines)
        if not has_vxlan:
            return {"compliant": True, "details": "VXLAN not configured"}
        has_evpn = any("evpn" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_evpn, "details": "VXLAN with EVPN configured" if has_evpn else "VXLAN without EVPN"}

    def check_nxos_port_tracking(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check port tracking configured."""
        has_tracking = any(re.match(r'^track\s+', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_tracking, "details": "Port tracking configured" if has_tracking else "Port tracking not configured"}

    def check_nxos_qos_policies(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check QoS policies configured."""
        has_qos = any("class-map type qos" in self._safe_content(line) or "policy-map type qos" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_qos, "details": "QoS policies configured" if has_qos else "QoS policies not configured"}

    def check_nxos_snmpv3_only(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check SNMPv3 only configured."""
        has_snmpv3 = any("snmp-server user" in self._safe_content(line) for line in config_lines)
        has_community = any(re.search(r'snmp-server community\s+\w+', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_snmpv3 and not has_community, "details": "SNMPv3 only configured" if (has_snmpv3 and not has_community) else "SNMPv1/v2c or no SNMP configured"}

    def check_nxos_checkpoint_auto(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check automatic checkpoint configured."""
        has_checkpoint_auto = any("checkpoint auto" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_checkpoint_auto, "details": "Automatic checkpoint configured" if has_checkpoint_auto else "Automatic checkpoint not configured"}

    # NXOS-Specific DISA STIG Check Functions (10 functions)

    def check_nxos_stig_password_complexity(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check password complexity enforced."""
        has_strength_check = any(
            "password strength-check" in self._safe_content(line)
            for line in config_lines
        )

        # Check if default strength-check is disabled (good - means custom rules)
        has_no_default = any(
            "no password strength-check default" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_strength_check
        return {
            "compliant": compliant,
            "details": "Password strength checking enabled" + (" with custom rules" if has_no_default else "") if compliant else "Password strength checking not enabled"
        }

    def check_nxos_stig_aaa_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check AAA authentication configured."""
        has_aaa_console = any(
            "aaa authentication login console" in self._safe_content(line)
            for line in config_lines
        )
        has_aaa_default = any(
            "aaa authentication login default" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_aaa_console or has_aaa_default
        return {
            "compliant": compliant,
            "details": "AAA authentication configured" if compliant else "AAA authentication not configured"
        }

    def check_nxos_stig_session_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check session timeout does not exceed 10 minutes."""
        timeout_values = []

        for line in config_lines:
            content = self._safe_content(line)
            if "exec-timeout" in content:
                # Parse timeout value (format: exec-timeout <minutes>)
                match = re.search(r'exec-timeout\s+(\d+)', content)
                if match:
                    timeout_values.append(int(match.group(1)))

        if not timeout_values:
            return {"compliant": False, "details": "No exec-timeout configured"}

        # Check all timeouts are 10 minutes or less
        max_timeout = max(timeout_values)
        compliant = max_timeout <= 10

        return {
            "compliant": compliant,
            "details": f"Max timeout: {max_timeout} minutes" + (" - compliant" if compliant else " - exceeds 10 minutes")
        }

    def check_nxos_stig_fips_mode(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check FIPS mode enabled."""
        has_fips = any(
            "fips mode enable" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_fips,
            "details": "FIPS mode enabled" if has_fips else "FIPS mode not enabled"
        }

    def check_nxos_stig_command_accounting(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check command accounting configured."""
        has_accounting = any(
            "aaa accounting default" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_accounting,
            "details": "AAA accounting configured" if has_accounting else "AAA accounting not configured"
        }

    def check_nxos_stig_tcp_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check TCP protection configured."""
        has_tcp_mtu = any(
            "ip tcp path-mtu-discovery" in self._safe_content(line)
            for line in config_lines
        )

        # Additional TCP hardening checks
        has_tcp_synwait = any(
            "ip tcp synwait-time" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_tcp_mtu or has_tcp_synwait
        return {
            "compliant": compliant,
            "details": "TCP protection configured" if compliant else "TCP protection not configured"
        }

    def check_nxos_stig_snmp_default_community(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check no default SNMP community strings."""
        has_public = any(
            "snmp-server community public" in self._safe_content(line)
            for line in config_lines
        )
        has_private = any(
            "snmp-server community private" in self._safe_content(line)
            for line in config_lines
        )

        compliant = not has_public and not has_private
        return {
            "compliant": compliant,
            "details": "No default SNMP communities" if compliant else "Default SNMP community strings detected (public/private)"
        }

    def check_nxos_stig_snmpv3_security(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check SNMPv3 with auth and priv configured."""
        snmpv3_users = []

        for line in config_lines:
            content = self._safe_content(line)
            if "snmp-server user" in content:
                # Check if it has auth and priv
                if " auth " in content and " priv " in content:
                    snmpv3_users.append(content)

        compliant = len(snmpv3_users) > 0
        return {
            "compliant": compliant,
            "details": f"SNMPv3 with auth and priv: {len(snmpv3_users)} user(s)" if compliant else "No SNMPv3 users with auth and priv"
        }

    def check_nxos_stig_management_acl(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check management interface ACL configured."""
        has_mgmt_interface = any(
            "interface mgmt" in self._safe_content(line)
            for line in config_lines
        )

        if not has_mgmt_interface:
            return {"compliant": True, "details": "No mgmt interface configured"}

        # Check for ACL on management interface
        in_mgmt_interface = False
        has_acl = False

        for line in config_lines:
            content = self._safe_content(line)
            if "interface mgmt" in content:
                in_mgmt_interface = True
            elif in_mgmt_interface and content.startswith("interface "):
                in_mgmt_interface = False
            elif in_mgmt_interface and "ip access-group" in content:
                has_acl = True
                break

        return {
            "compliant": has_acl,
            "details": "Management ACL configured" if has_acl else "No ACL on management interface"
        }

    def check_nxos_stig_management_vlan(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check management traffic segregation."""
        has_mgmt_interface = any(
            "interface mgmt" in self._safe_content(line)
            for line in config_lines
        )
        has_mgmt_ip = False

        in_mgmt_interface = False
        for line in config_lines:
            content = self._safe_content(line)
            if "interface mgmt" in content:
                in_mgmt_interface = True
            elif in_mgmt_interface and content.startswith("interface "):
                in_mgmt_interface = False
            elif in_mgmt_interface and "ip address" in content:
                has_mgmt_ip = True
                break

        compliant = has_mgmt_interface and has_mgmt_ip
        return {
            "compliant": compliant,
            "details": "Dedicated management interface configured" if compliant else "No dedicated management interface"
        }

    # New IOS Check Functions - Interface Security

    def check_dtp_disabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that DTP is disabled on access ports."""
        dtp_issues = []
        in_interface = False
        current_interface = None
        is_access_port = False
        has_nonegotiate = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'interface\s+(gigabitethernet|fastethernet|ethernet)', content, re.I):
                # Save previous interface state
                if in_interface and is_access_port and not has_nonegotiate:
                    dtp_issues.append(current_interface)

                in_interface = True
                current_interface = content
                is_access_port = False
                has_nonegotiate = False
            elif in_interface and content.startswith("interface "):
                in_interface = False
            elif in_interface:
                if "switchport mode access" in content:
                    is_access_port = True
                if "switchport nonegotiate" in content:
                    has_nonegotiate = True

        # Check last interface
        if in_interface and is_access_port and not has_nonegotiate:
            dtp_issues.append(current_interface)

        return {
            "compliant": len(dtp_issues) == 0,
            "details": f"DTP not disabled on: {', '.join(dtp_issues) if dtp_issues else 'All access ports compliant'}"
        }

    def check_unused_interfaces_shutdown(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that unused interfaces are shutdown."""
        # This is a best-effort check - we look for interfaces without IP or VLAN config that aren't shutdown
        unshutdown_unused = []
        in_interface = False
        current_interface = None
        has_config = False
        is_shutdown = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'interface\s+', content, re.I):
                if in_interface and not has_config and not is_shutdown:
                    unshutdown_unused.append(current_interface)

                in_interface = True
                current_interface = content
                has_config = False
                is_shutdown = False
            elif in_interface and content.startswith("interface "):
                in_interface = False
            elif in_interface:
                if re.search(r'(ip address|switchport|description|channel-group)', content, re.I):
                    has_config = True
                if content == "shutdown":
                    is_shutdown = True

        return {
            "compliant": len(unshutdown_unused) == 0,
            "details": f"Unused interfaces not shutdown: {len(unshutdown_unused)}" if unshutdown_unused else "Check passed"
        }

    def check_native_vlan_trunk(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that native VLAN is configured on trunk ports."""
        trunk_without_native_vlan = []
        in_interface = False
        current_interface = None
        is_trunk = False
        has_native_vlan = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'interface\s+', content, re.I):
                if in_interface and is_trunk and not has_native_vlan:
                    trunk_without_native_vlan.append(current_interface)

                in_interface = True
                current_interface = content
                is_trunk = False
                has_native_vlan = False
            elif in_interface and content.startswith("interface "):
                in_interface = False
            elif in_interface:
                if "switchport mode trunk" in content:
                    is_trunk = True
                if "switchport trunk native vlan" in content:
                    has_native_vlan = True

        return {
            "compliant": len(trunk_without_native_vlan) == 0,
            "details": f"Trunks without native VLAN: {len(trunk_without_native_vlan)}" if trunk_without_native_vlan else "All trunks have native VLAN configured"
        }

    def check_port_security(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that port security is enabled on access ports."""
        has_port_security = any(
            "switchport port-security" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_port_security,
            "details": "Port security configured" if has_port_security else "No port security found"
        }

    def check_storm_control(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that storm control is configured."""
        has_storm_control = any(
            "storm-control" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_storm_control,
            "details": "Storm control configured" if has_storm_control else "No storm control found"
        }

    def check_dhcp_snooping(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that DHCP snooping is enabled."""
        has_dhcp_snooping = any(
            "ip dhcp snooping" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_dhcp_snooping,
            "details": "DHCP snooping enabled" if has_dhcp_snooping else "DHCP snooping not configured"
        }

    def check_dynamic_arp_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Dynamic ARP Inspection is enabled."""
        has_dai = any(
            "ip arp inspection" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_dai,
            "details": "Dynamic ARP Inspection enabled" if has_dai else "DAI not configured"
        }

    def check_ip_source_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that IP Source Guard is enabled."""
        has_ipsg = any(
            "ip verify source" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_ipsg,
            "details": "IP Source Guard enabled" if has_ipsg else "IP Source Guard not configured"
        }

    def check_bpdu_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that BPDU Guard is enabled."""
        has_bpdu_guard = any(
            re.search(r'spanning-tree (bpduguard|portfast bpduguard)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_bpdu_guard,
            "details": "BPDU Guard enabled" if has_bpdu_guard else "BPDU Guard not configured"
        }

    def check_root_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Root Guard is enabled."""
        has_root_guard = any(
            "spanning-tree guard root" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_root_guard,
            "details": "Root Guard enabled" if has_root_guard else "Root Guard not configured"
        }

    # New IOS Check Functions - Advanced AAA

    def check_aaa_authorization_exec(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA authorization for exec."""
        has_aaa_authz_exec = any(
            "aaa authorization exec" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa_authz_exec,
            "details": "AAA authorization exec configured" if has_aaa_authz_exec else "AAA authorization exec not configured"
        }

    def check_aaa_authorization_commands(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA authorization for commands."""
        has_aaa_authz_commands = any(
            "aaa authorization commands" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa_authz_commands,
            "details": "AAA authorization commands configured" if has_aaa_authz_commands else "AAA authorization commands not configured"
        }

    def check_aaa_accounting_exec(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA accounting for exec sessions."""
        has_aaa_acct_exec = any(
            "aaa accounting exec" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa_acct_exec,
            "details": "AAA accounting exec configured" if has_aaa_acct_exec else "AAA accounting exec not configured"
        }

    def check_aaa_accounting_commands(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA accounting for commands."""
        has_aaa_acct_commands = any(
            "aaa accounting commands" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa_acct_commands,
            "details": "AAA accounting commands configured" if has_aaa_acct_commands else "AAA accounting commands not configured"
        }

    def check_login_block_for(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check login failure rate limiting."""
        has_login_block = any(
            "login block-for" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_login_block,
            "details": "Login failure rate limiting configured" if has_login_block else "Login block-for not configured"
        }

    def check_password_complexity(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check password complexity requirements."""
        has_complexity = any(
            "password strength-check" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_complexity,
            "details": "Password complexity enabled" if has_complexity else "Password strength-check not configured"
        }

    def check_no_type7_passwords(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for weak Type 7 passwords in configuration."""
        type7_found = []

        for line in config_lines:
            content = self._safe_content(line)
            # Type 7 passwords start with "password 7" or "username X password 7"
            if re.search(r'password\s+7\s+\w+', content, re.I):
                type7_found.append(content)

        return {
            "compliant": len(type7_found) == 0,
            "details": f"Type 7 passwords found: {len(type7_found)}" if type7_found else "No Type 7 passwords detected"
        }

    # New IOS Check Functions - Routing Security

    def check_bgp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check BGP neighbor authentication."""
        has_bgp = any(
            "router bgp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_bgp:
            return {"compliant": True, "details": "BGP not configured"}

        has_bgp_password = any(
            re.search(r'neighbor\s+\S+\s+password', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_bgp_password,
            "details": "BGP authentication configured" if has_bgp_password else "BGP neighbors lack authentication"
        }

    def check_bgp_prefix_filtering(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check BGP prefix filtering."""
        has_bgp = any(
            "router bgp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_bgp:
            return {"compliant": True, "details": "BGP not configured"}

        has_prefix_filtering = any(
            re.search(r'neighbor\s+\S+\s+(prefix-list|route-map|filter-list)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_prefix_filtering,
            "details": "BGP prefix filtering configured" if has_prefix_filtering else "BGP lacks prefix filtering"
        }

    def check_bgp_max_prefix(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check BGP maximum-prefix limits."""
        has_bgp = any(
            "router bgp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_bgp:
            return {"compliant": True, "details": "BGP not configured"}

        has_max_prefix = any(
            "neighbor" in self._safe_content(line) and "maximum-prefix" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_max_prefix,
            "details": "BGP maximum-prefix configured" if has_max_prefix else "BGP lacks maximum-prefix limits"
        }

    def check_ospf_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check OSPF authentication."""
        has_ospf = any(
            "router ospf" in self._safe_content(line)
            for line in config_lines
        )

        if not has_ospf:
            return {"compliant": True, "details": "OSPF not configured"}

        has_ospf_auth = any(
            re.search(r'ip ospf (authentication|message-digest)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_ospf_auth,
            "details": "OSPF authentication configured" if has_ospf_auth else "OSPF lacks authentication"
        }

    def check_ospf_passive_interface(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check OSPF passive interface configuration."""
        has_ospf = any(
            "router ospf" in self._safe_content(line)
            for line in config_lines
        )

        if not has_ospf:
            return {"compliant": True, "details": "OSPF not configured"}

        has_passive = any(
            "passive-interface" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_passive,
            "details": "OSPF passive-interface configured" if has_passive else "OSPF lacks passive-interface configuration"
        }

    def check_eigrp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check EIGRP authentication."""
        has_eigrp = any(
            "router eigrp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_eigrp:
            return {"compliant": True, "details": "EIGRP not configured"}

        has_eigrp_auth = any(
            re.search(r'ip authentication (mode eigrp|key-chain eigrp)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_eigrp_auth,
            "details": "EIGRP authentication configured" if has_eigrp_auth else "EIGRP lacks authentication"
        }

    # New IOS Check Functions - Advanced Cryptography

    def check_strong_rsa_keys(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for strong RSA keys (2048-bit minimum)."""
        rsa_key_lines = [line for line in config_lines if "crypto key generate rsa" in self._safe_content(line)]

        if not rsa_key_lines:
            return {"compliant": False, "details": "No RSA key generation found"}

        has_strong_keys = any(
            re.search(r'modulus (2048|4096)', self._safe_content(line))
            for line in rsa_key_lines
        )

        return {
            "compliant": has_strong_keys,
            "details": "Strong RSA keys (2048-bit+) configured" if has_strong_keys else "Weak RSA keys detected"
        }

    def check_ssh_strong_algorithms(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for strong SSH algorithms."""
        has_ssh_algo = any(
            "ip ssh server algorithm" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_ssh_algo,
            "details": "SSH algorithm restrictions configured" if has_ssh_algo else "SSH algorithms not restricted"
        }

    def check_no_weak_ipsec_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for weak IPsec encryption (DES, 3DES)."""
        weak_ipsec = []

        for line in config_lines:
            content = self._safe_content(line)
            if re.search(r'(esp-des|esp-3des)', content, re.I):
                weak_ipsec.append(content)

        return {
            "compliant": len(weak_ipsec) == 0,
            "details": f"Weak IPsec encryption found: {len(weak_ipsec)}" if weak_ipsec else "No weak IPsec encryption detected"
        }

    def check_ikev2_preferred(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that IKEv2 is preferred over IKEv1."""
        has_ikev2 = any(
            "crypto ikev2" in self._safe_content(line)
            for line in config_lines
        )

        has_isakmp = any(
            "crypto isakmp" in self._safe_content(line)
            for line in config_lines
        )

        # If IPsec is configured, prefer IKEv2
        if has_isakmp and not has_ikev2:
            return {"compliant": False, "details": "IKEv1 configured without IKEv2"}

        return {
            "compliant": True,
            "details": "IKEv2 configured" if has_ikev2 else "No IKE configuration found"
        }

    def check_strong_dh_groups(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for strong Diffie-Hellman groups (14+)."""
        dh_groups = []

        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'group\s+(\d+)', content)
            if match:
                group_num = int(match.group(1))
                if group_num < 14:
                    dh_groups.append(group_num)

        return {
            "compliant": len(dh_groups) == 0,
            "details": f"Weak DH groups found: {dh_groups}" if dh_groups else "Strong DH groups (14+) configured"
        }

    def check_ipsec_pfs(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Perfect Forward Secrecy is enabled for IPsec."""
        has_crypto_map = any(
            "crypto map" in self._safe_content(line)
            for line in config_lines
        )

        if not has_crypto_map:
            return {"compliant": True, "details": "No crypto map configured"}

        has_pfs = any(
            re.search(r'set pfs\s+group', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_pfs,
            "details": "IPsec PFS enabled" if has_pfs else "IPsec lacks PFS configuration"
        }

    # New IOS Check Functions - Management Plane Security

    def check_ssh_ciphersuite_restrictions(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check SSH ciphersuite restrictions."""
        has_ssh_cipher = any(
            "ip ssh server algorithm encryption" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_ssh_cipher,
            "details": "SSH cipher restrictions configured" if has_ssh_cipher else "SSH ciphers not restricted"
        }

    def check_ssh_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check SSH authentication timeout."""
        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'ip ssh time-out (\d+)', content)
            if match:
                timeout = int(match.group(1))
                return {
                    "compliant": timeout <= 60,
                    "details": f"SSH timeout: {timeout} seconds"
                }

        return {
            "compliant": False,
            "details": "SSH timeout not configured"
        }

    def check_ssh_auth_retries(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check SSH authentication retries."""
        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'ip ssh authentication-retries (\d+)', content)
            if match:
                retries = int(match.group(1))
                return {
                    "compliant": retries <= 3,
                    "details": f"SSH auth retries: {retries}"
                }

        return {
            "compliant": False,
            "details": "SSH authentication-retries not configured"
        }

    def check_no_telnet(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Telnet is disabled."""
        has_telnet = any(
            "transport input telnet" in self._safe_content(line) or
            "transport input all" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": not has_telnet,
            "details": "Telnet disabled" if not has_telnet else "Telnet is enabled on VTY lines"
        }

    def check_no_tftp_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that TFTP server is disabled."""
        has_tftp = any(
            re.match(r'tftp-server\s+', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": not has_tftp,
            "details": "TFTP server disabled" if not has_tftp else "TFTP server is enabled"
        }

    def check_scp_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that SCP server is enabled."""
        has_scp = any(
            "ip scp server enable" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_scp,
            "details": "SCP server enabled" if has_scp else "SCP server not enabled"
        }

    # New IOS Check Functions - Logging & Monitoring

    def check_logging_source_interface(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging source-interface configuration."""
        has_logging_source = any(
            "logging source-interface" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_logging_source,
            "details": "Logging source-interface configured" if has_logging_source else "Logging source-interface not configured"
        }

    def check_logging_timestamps(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging timestamps with datetime."""
        has_timestamps = any(
            re.search(r'service timestamps log datetime', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_timestamps,
            "details": "Logging timestamps with datetime configured" if has_timestamps else "Logging timestamps not properly configured"
        }

    def check_logging_facility(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging facility configuration."""
        has_facility = any(
            "logging facility" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_facility,
            "details": "Logging facility configured" if has_facility else "Logging facility not configured"
        }

    def check_logging_synchronous(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging synchronous on lines."""
        has_logging_sync = any(
            "logging synchronous" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_logging_sync,
            "details": "Logging synchronous configured" if has_logging_sync else "Logging synchronous not configured"
        }

    # Additional CIS Controls (56-61) - Final 6 check functions for 100% coverage

    def check_tcp_sequence_randomization(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check TCP sequence number randomization (TCP keepalives)."""
        has_tcp_keepalive_in = any(
            "service tcp-keepalives-in" in self._safe_content(line)
            for line in config_lines
        )
        has_tcp_keepalive_out = any(
            "service tcp-keepalives-out" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_tcp_keepalive_in and has_tcp_keepalive_out
        return {
            "compliant": compliant,
            "details": "TCP keepalives enabled for both directions" if compliant else "TCP keepalives not fully configured"
        }

    def check_interface_descriptions(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that all active interfaces have descriptions."""
        interfaces_without_desc = []
        current_interface = None
        interface_has_description = False
        interface_is_shutdown = False

        for line in config_lines:
            content = self._safe_content(line)

            # New interface found
            if content.startswith("interface "):
                # Save previous interface if it was missing description
                if current_interface and not interface_has_description and not interface_is_shutdown:
                    interfaces_without_desc.append(current_interface)

                current_interface = content.replace("interface ", "").strip()
                interface_has_description = False
                interface_is_shutdown = False

            # Check for description
            elif current_interface and content.startswith("description "):
                interface_has_description = True

            # Check if interface is shutdown
            elif current_interface and content.strip() == "shutdown":
                interface_is_shutdown = True

        # Check last interface
        if current_interface and not interface_has_description and not interface_is_shutdown:
            interfaces_without_desc.append(current_interface)

        compliant = len(interfaces_without_desc) == 0
        return {
            "compliant": compliant,
            "details": "All active interfaces have descriptions" if compliant else f"{len(interfaces_without_desc)} active interface(s) lack descriptions: {', '.join(interfaces_without_desc[:5])}"
        }

    def check_switchport_mode_explicit(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check switchport mode explicitly set without negotiation."""
        interfaces_with_auto_negotiation = []
        current_interface = None
        has_switchport_mode = False
        has_nonegotiate = False

        for line in config_lines:
            content = self._safe_content(line)

            # New interface found
            if content.startswith("interface "):
                # Check previous interface
                if current_interface and has_switchport_mode and not has_nonegotiate:
                    if "GigabitEthernet" in current_interface or "FastEthernet" in current_interface or "Ethernet" in current_interface:
                        interfaces_with_auto_negotiation.append(current_interface)

                current_interface = content.replace("interface ", "").strip()
                has_switchport_mode = False
                has_nonegotiate = False

            # Check for switchport mode
            elif current_interface and "switchport mode" in content:
                has_switchport_mode = True

            # Check for nonegotiate
            elif current_interface and "switchport nonegotiate" in content:
                has_nonegotiate = True

        # Check last interface
        if current_interface and has_switchport_mode and not has_nonegotiate:
            if "GigabitEthernet" in current_interface or "FastEthernet" in current_interface or "Ethernet" in current_interface:
                interfaces_with_auto_negotiation.append(current_interface)

        compliant = len(interfaces_with_auto_negotiation) == 0
        return {
            "compliant": compliant,
            "details": "All switchports have nonegotiate configured" if compliant else f"{len(interfaces_with_auto_negotiation)} switchport(s) allow DTP negotiation: {', '.join(interfaces_with_auto_negotiation[:5])}"
        }

    def check_loop_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check Loop Guard enabled globally or on trunk ports."""
        has_global_loopguard = any(
            "spanning-tree loopguard default" in self._safe_content(line)
            for line in config_lines
        )

        # Check for per-interface loop guard on trunks
        trunk_interfaces = []
        trunk_with_loopguard = []
        current_interface = None
        is_trunk = False
        has_loopguard = False

        for line in config_lines:
            content = self._safe_content(line)

            if content.startswith("interface "):
                # Process previous interface
                if current_interface and is_trunk:
                    trunk_interfaces.append(current_interface)
                    if has_loopguard:
                        trunk_with_loopguard.append(current_interface)

                current_interface = content.replace("interface ", "").strip()
                is_trunk = False
                has_loopguard = False

            elif current_interface and "switchport mode trunk" in content:
                is_trunk = True

            elif current_interface and "spanning-tree guard loop" in content:
                has_loopguard = True

        # Check last interface
        if current_interface and is_trunk:
            trunk_interfaces.append(current_interface)
            if has_loopguard:
                trunk_with_loopguard.append(current_interface)

        # Compliant if global loopguard OR all trunks have it configured
        compliant = has_global_loopguard or (len(trunk_interfaces) > 0 and len(trunk_interfaces) == len(trunk_with_loopguard))

        if has_global_loopguard:
            detail = "Loop Guard enabled globally"
        elif len(trunk_interfaces) == 0:
            detail = "No trunk interfaces configured"
            compliant = True
        elif compliant:
            detail = f"All {len(trunk_interfaces)} trunk interface(s) have Loop Guard"
        else:
            detail = f"Loop Guard missing on {len(trunk_interfaces) - len(trunk_with_loopguard)} trunk interface(s)"

        return {
            "compliant": compliant,
            "details": detail
        }

    def check_netflow_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check NetFlow or sFlow enabled for traffic monitoring."""
        has_netflow_export = any(
            "ip flow-export" in self._safe_content(line) or "flow exporter" in self._safe_content(line)
            for line in config_lines
        )

        has_sflow = any(
            "sflow" in self._safe_content(line)
            for line in config_lines
        )

        has_flexible_netflow = any(
            "flow monitor" in self._safe_content(line) or "flow record" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_netflow_export or has_sflow or has_flexible_netflow

        if has_flexible_netflow:
            detail = "Flexible NetFlow configured"
        elif has_netflow_export:
            detail = "NetFlow export configured"
        elif has_sflow:
            detail = "sFlow configured"
        else:
            detail = "No flow monitoring configured"

        return {
            "compliant": compliant,
            "details": detail
        }

    def check_config_change_notifications(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check configuration change notifications enabled."""
        has_archive = any("archive" in self._safe_content(line) for line in config_lines)
        has_log_config = any("log config" in self._safe_content(line) for line in config_lines)
        has_logging_enable = any(
            "logging enable" in self._safe_content(line)
            for line in config_lines
        )
        has_notify = any(
            "notify syslog" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_archive and has_log_config and (has_logging_enable or has_notify)

        if compliant:
            detail = "Configuration change notifications enabled"
        elif not has_archive:
            detail = "Archive not configured"
        elif not has_log_config:
            detail = "Log config not enabled in archive"
        else:
            detail = "Configuration change logging/notification not fully enabled"

        return {
            "compliant": compliant,
            "details": detail
        }

    # Helper methods

    def _safe_content(self, line) -> str:
        """Safely extract content from line object or string."""
        if hasattr(line, 'content'):
            return line.content.strip()
        return str(line).strip()
