"""Comprehensive security rules for Juniper JunOS.

Covers SNMP, routing protocol authentication, VRRP, and other security features.
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class JuniperComprehensiveRules(BaseRuleEngine):
    """Comprehensive security rules for Juniper JunOS."""

    def __init__(self):
        super().__init__()
        self.category = "Comprehensive Security"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check comprehensive security rules."""
        findings = []

        if vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._check_juniper_security(parsed_config))

        return findings

    def _check_juniper_security(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Juniper comprehensive security configuration."""
        findings = []

        # Check SNMP configuration
        findings.extend(self._check_snmp(config))

        # Check routing protocol authentication
        findings.extend(self._check_routing_auth(config))

        # Check VRRP configuration
        findings.extend(self._check_vrrp(config))

        return findings

    def _check_snmp(self, config: Dict[str, Any]) -> List[Finding]:
        """Check SNMP security configuration."""
        findings = []

        snmp_config = config.get('snmp', {})
        communities = snmp_config.get('communities', {})

        if not communities and not snmp_config.get('v3'):
            # No SNMP configured - this is actually good, but only note if other SNMP indicators exist
            return findings

        # Check for SNMPv1/v2c communities
        for community_name, community_config in communities.items():
            # Check for well-known community strings
            if community_name.lower() in ['public', 'private']:
                findings.append(self.create_finding(
                    rule_id="JUNOS-SNMP-001",
                    title=f"Default SNMP Community String '{community_name}' Detected",
                    description=f"SNMP community string '{community_name}' is configured. Default community "
                              f"strings are widely known and allow unauthorized access to device information. "
                              f"Attackers can use SNMP to gather detailed network topology, configuration, "
                              f"and operational data.",
                    severity="CRITICAL",
                    recommendation=f"Change community string to a strong, unique value or migrate to SNMPv3",
                    fix_commands=[
                        f"delete snmp community {community_name}",
                        "set snmp community <strong_community> authorization read-only",
                        "set snmp community <strong_community> clients <management_subnet>"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="L",
                        availability="L"
                    ),
                    nist_controls=["IA-5(1)", "SC-8", "CM-7"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

            # Check for read-write access
            if community_config.get('authorization') == 'read-write':
                findings.append(self.create_finding(
                    rule_id="JUNOS-SNMP-002",
                    title=f"SNMP Community '{community_name}' Has Read-Write Access",
                    description=f"SNMP community '{community_name}' is configured with read-write access. "
                              f"SNMPv1/v2c communities with write access allow unauthenticated configuration "
                              f"changes. An attacker can modify device configuration, disable security features, "
                              f"or cause a denial of service.",
                    severity="CRITICAL",
                    recommendation=f"Change to read-only access or use SNMPv3 with strong authentication",
                    fix_commands=[
                        f"set snmp community {community_name} authorization read-only",
                        "# Or migrate to SNMPv3:",
                        "delete snmp community {community_name}",
                        "set snmp v3 usm local-engine user <username> authentication-md5 authentication-password <password>",
                        "set snmp v3 usm local-engine user <username> privacy-des privacy-password <password>"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="H"
                    ),
                    nist_controls=["CM-3", "CM-5", "SC-8"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

            # Check for unrestricted clients
            if not community_config.get('clients'):
                findings.append(self.create_finding(
                    rule_id="JUNOS-SNMP-003",
                    title=f"SNMP Community '{community_name}' Not Restricted by Client IP",
                    description=f"SNMP community '{community_name}' does not restrict access by client IP address. "
                              f"This allows any network device to query or modify (if read-write) the device "
                              f"configuration. SNMP access should be limited to authorized management systems only.",
                    severity="HIGH",
                    recommendation=f"Restrict SNMP access to authorized management networks",
                    fix_commands=[
                        f"set snmp community {community_name} clients <management_subnet>",
                        f"set snmp community {community_name} clients restrict"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="L",
                        availability="L"
                    ),
                    nist_controls=["AC-3", "SC-7"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

        # Recommend SNMPv3 if using v1/v2c
        if communities and not snmp_config.get('v3'):
            findings.append(self.create_finding(
                rule_id="JUNOS-SNMP-004",
                title="SNMPv3 Not Configured",
                description="The device is using SNMPv1 or SNMPv2c instead of SNMPv3. SNMPv1 and v2c transmit "
                          "community strings in cleartext and provide no encryption for SNMP data. SNMPv3 provides "
                          "authentication, encryption, and access control, significantly improving security.",
                severity="HIGH",
                recommendation="Migrate to SNMPv3 with authentication and encryption",
                fix_commands=[
                    "set snmp v3 usm local-engine user <username> authentication-md5 authentication-password <password>",
                    "set snmp v3 usm local-engine user <username> privacy-des privacy-password <password>",
                    "set snmp v3 vacm security-to-group security-model usm security-name <username> group <group>",
                    "set snmp v3 vacm access group <group> default-context-prefix security-model usm security-level privacy read-view <view>",
                    "# Then remove v1/v2c communities:",
                    "delete snmp community"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-8", "IA-2", "IA-5"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        return findings

    def _check_routing_auth(self, config: Dict[str, Any]) -> List[Finding]:
        """Check routing protocol authentication."""
        findings = []

        protocols = config.get('protocols', {})

        # Check OSPF authentication
        ospf_config = protocols.get('ospf', {})
        if ospf_config:
            areas = ospf_config.get('areas', {})
            for area_id, area_config in areas.items():
                # Check area-level authentication
                if not area_config.get('authentication'):
                    area_interfaces = area_config.get('interfaces', {})

                    # Check if any interface lacks authentication
                    unauthenticated_interfaces = []
                    for if_name, if_config in area_interfaces.items():
                        if not if_config.get('authentication'):
                            unauthenticated_interfaces.append(if_name)

                    if unauthenticated_interfaces:
                        findings.append(self.create_finding(
                            rule_id="JUNOS-OSPF-001",
                            title=f"OSPF Area {area_id} Missing Authentication",
                            description=f"OSPF area {area_id} does not have authentication configured. Without "
                                      f"authentication, an attacker can inject false routing information, redirect "
                                      f"traffic, or cause a denial of service by forming unauthorized OSPF adjacencies. "
                                      f"This affects interfaces: {', '.join(unauthenticated_interfaces)}",
                            severity="HIGH",
                            recommendation=f"Enable MD5 authentication for OSPF area {area_id}",
                            fix_commands=[
                                f"set protocols ospf area {area_id} authentication-type md5",
                                f"set protocols ospf area {area_id} interface <interface> authentication md5 1 key <key>"
                            ],
                            cvss_vector=CVSSVector(
                                attack_vector="A",
                                attack_complexity="L",
                                privileges_required="N",
                                confidentiality="N",
                                integrity="H",
                                availability="H"
                            ),
                            nist_controls=["SC-8", "IA-3", "SC-5"],
                            vendor=VendorType.JUNIPER_JUNOS
                        ))

        # Check BGP authentication
        bgp_config = protocols.get('bgp', {})
        if bgp_config and not bgp_config.get('authentication'):
            findings.append(self.create_finding(
                rule_id="JUNOS-BGP-001",
                title="BGP Authentication Not Configured",
                description="BGP does not have MD5 authentication configured. Without authentication, an attacker "
                          "can inject false routing information, hijack IP prefixes, or cause routing instability. "
                          "BGP is a critical protocol for Internet routing and must be protected.",
                severity="CRITICAL",
                recommendation="Enable MD5 authentication for all BGP neighbors",
                fix_commands=[
                    "set protocols bgp group <group> authentication-key <key>",
                    "# Or use keychain for key rotation:",
                    "set security authentication-key-chains key-chain bgp-auth key 1 secret <key>",
                    "set protocols bgp group <group> authentication-key-chain bgp-auth"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["SC-8", "IA-3", "SC-5"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        return findings

    def _check_vrrp(self, config: Dict[str, Any]) -> List[Finding]:
        """Check VRRP security configuration."""
        findings = []

        interfaces = config.get('interfaces', {})

        for if_name, if_config in interfaces.items():
            units = if_config.get('units', {})

            for unit_num, unit_config in units.items():
                vrrp_groups = unit_config.get('vrrp', [])

                for vrrp in vrrp_groups:
                    group_num = vrrp.get('group')
                    priority = vrrp.get('priority', 100)

                    # Check for missing authentication
                    if not vrrp.get('authentication'):
                        findings.append(self.create_finding(
                            rule_id="JUNOS-VRRP-001",
                            title=f"VRRP Group {group_num} on {if_name}.{unit_num} Missing Authentication",
                            description=f"VRRP group {group_num} on interface {if_name}.{unit_num} does not have "
                                      f"authentication configured. Without authentication, an attacker on the local "
                                      f"network can inject VRRP advertisements with higher priority, hijack the virtual "
                                      f"IP address, and intercept traffic destined for the default gateway. This enables "
                                      f"man-in-the-middle attacks.",
                            severity="CRITICAL",
                            recommendation=f"Enable authentication for VRRP group {group_num}",
                            fix_commands=[
                                f"set interfaces {if_name} unit {unit_num} family inet address <address> vrrp-group {group_num} authentication-type md5",
                                f"set interfaces {if_name} unit {unit_num} family inet address <address> vrrp-group {group_num} authentication-key <key>"
                            ],
                            cvss_vector=CVSSVector(
                                attack_vector="A",
                                attack_complexity="L",
                                privileges_required="N",
                                confidentiality="H",
                                integrity="H",
                                availability="H"
                            ),
                            nist_controls=["SC-23", "SC-8", "IA-3"],
                            vendor=VendorType.JUNIPER_JUNOS
                        ))

                    # Check for missing interface tracking
                    if priority > 100 and not vrrp.get('track'):
                        findings.append(self.create_finding(
                            rule_id="JUNOS-VRRP-002",
                            title=f"VRRP Group {group_num} on {if_name}.{unit_num} Missing Interface Tracking",
                            description=f"VRRP group {group_num} on interface {if_name}.{unit_num} is configured as "
                                      f"master (priority {priority}) but does not track any uplink interfaces. If the "
                                      f"uplink fails while the VRRP interface remains up, this router will continue as "
                                      f"master even though it cannot forward traffic, causing a complete outage.",
                            severity="MEDIUM",
                            recommendation=f"Configure interface tracking for VRRP group {group_num}",
                            fix_commands=[
                                f"set interfaces {if_name} unit {unit_num} family inet address <address> vrrp-group {group_num} track interface <uplink_interface> priority-cost 50"
                            ],
                            cvss_vector=CVSSVector(
                                attack_vector="L",
                                attack_complexity="L",
                                privileges_required="N",
                                confidentiality="N",
                                integrity="N",
                                availability="H"
                            ),
                            nist_controls=["SC-5", "SC-6"],
                            vendor=VendorType.JUNIPER_JUNOS
                        ))

        return findings
