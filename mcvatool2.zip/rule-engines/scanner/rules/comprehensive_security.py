"""Comprehensive security rules to catch all misconfigurations."""

import re
from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class ComprehensiveSecurityRules(BaseRuleEngine):
    """Comprehensive security rules to ensure complete coverage."""
    
    def __init__(self):
        super().__init__()
        self.category = "Comprehensive Security"
    
    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check comprehensive security rules to catch all misconfigurations."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._check_cisco_comprehensive(parsed_config))
        
        return findings
    
    def _check_cisco_comprehensive(self, config: Dict[str, Any]) -> List[Finding]:
        """Comprehensive Cisco IOS security checks."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Password Security Checks
        findings.extend(self._check_password_security(config_lines))
        
        # Line Security Comprehensive
        findings.extend(self._check_line_security_comprehensive(config))
        
        # Service Security
        findings.extend(self._check_service_security(config_lines))
        
        # Protocol Security
        findings.extend(self._check_protocol_security(config))
        
        # Missing Configuration Checks
        findings.extend(self._check_missing_configurations(config_lines))
        
        return findings
    
    def _check_password_security(self, config_lines: List) -> List[Finding]:
        """Check for password-related security issues."""
        findings = []
        
        # Type 7 password detection
        type7_lines = []
        plaintext_lines = []
        
        for line in config_lines:
            content = line.content.strip()

            # Type 7 passwords (reversible Cisco encryption)
            if re.search(r'password 7 [A-F0-9]+', content, re.I):
                type7_lines.append(line)

            # Plain text passwords - only match actual password configuration commands
            # Match patterns like: "password <plaintext>", "username foo password <plaintext>", "enable password <plaintext>"
            # Exclude: password 5/7/0, "password encryption", "password configuration", "password rollover", etc.
            password_match = re.search(r'\b(enable\s+password|username\s+\S+\s+password|^\s*password)\s+(\S+)', content, re.I)
            if password_match:
                pwd_value = password_match.group(2)
                # Exclude if it's encrypted (starts with type 0, 5, or 7) or is a keyword
                excluded_keywords = ['encryption', 'configuration', 'rollover', 'management', 'threshold', 'policy']
                if not re.match(r'^[0-9]+$', pwd_value) and pwd_value.lower() not in excluded_keywords:
                    # This looks like a plaintext password
                    plaintext_lines.append(line)
        
        # Report Type 7 passwords
        for line in type7_lines:
            findings.append(self.create_finding(
                rule_id="COMP-001",
                title="Type 7 Password Detected",
                description="Cisco Type 7 passwords use reversible encryption and can be easily cracked.",
                severity="HIGH",
                config_line=line,
                recommendation="Replace with Type 5 (MD5) or stronger hashing",
                fix_commands=["username <USER> secret <PASSWORD>"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="L",
                    confidentiality="H",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Report plain text passwords
        for line in plaintext_lines:
            findings.append(self.create_finding(
                rule_id="COMP-002",
                title="Plain Text Password Detected",
                description="Plain text passwords are stored without encryption and are visible in configuration.",
                severity="CRITICAL",
                config_line=line,
                recommendation="Use encrypted password storage",
                fix_commands=["service password-encryption", "username <USER> secret <PASSWORD>"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="L",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_line_security_comprehensive(self, config: Dict[str, Any]) -> List[Finding]:
        """Comprehensive line security checks."""
        findings = []
        line_configs = config.get("line_configs", {})
        
        # Transport security
        insecure_transport_lines = []
        timeout_issues = []
        missing_banners = []
        
        for line_name, line_config in line_configs.items():
            line_obj = line_config.get("config_lines", [None])[0]
            
            # Check transport input
            transport_input = line_config.get("transport", {}).get("input", [])
            if not transport_input or "telnet" in transport_input or "all" in transport_input:
                insecure_transport_lines.append((line_name, line_obj))
            
            # Check exec timeout (should be <= 10 minutes)
            exec_timeout = line_config.get("timeouts", {}).get("exec", 0)
            if exec_timeout == 0 or exec_timeout > 600:  # 10 minutes
                timeout_issues.append((line_name, exec_timeout, line_obj))
        
        # Generate transport findings
        for line_name, line_obj in insecure_transport_lines:
            findings.append(self.create_finding(
                rule_id="COMP-003",
                title="Insecure Transport Protocol on Terminal Lines",
                description=f"Terminal line {line_name} allows insecure transport (Telnet), exposing credentials.",
                severity="HIGH",
                config_line=line_obj,
                recommendation="Restrict to SSH only",
                fix_commands=["transport input ssh"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="N"
                ),
                nist_controls=["SC-8", "AC-17"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Generate timeout findings
        for line_name, timeout_val, line_obj in timeout_issues:
            timeout_desc = f"{timeout_val//60} minutes" if timeout_val > 0 else "disabled"
            findings.append(self.create_finding(
                rule_id="COMP-004",
                title="Excessive or Missing Session Timeout",
                description=f"Terminal line {line_name} has session timeout {timeout_desc}, increasing unauthorized access risk.",
                severity="MEDIUM",
                config_line=line_obj,
                recommendation="Set appropriate session timeout (10 minutes or less)",
                fix_commands=["exec-timeout 10 0"],
                cvss_vector=CVSSVector(
                    attack_vector="P",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-12"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_service_security(self, config_lines: List) -> List[Finding]:
        """Check for insecure service configurations."""
        findings = []
        
        # Check for dangerous services
        dangerous_services = [
            ("ip finger", "Finger Service", "Finger service exposes user information"),
            ("ip bootp server", "BOOTP Server", "BOOTP server can be used for network reconnaissance"),
            ("service tcp-small-servers", "TCP Small Servers", "TCP small servers provide unnecessary attack vectors"),
            ("service udp-small-servers", "UDP Small Servers", "UDP small servers provide unnecessary attack vectors"),
        ]
        
        for pattern, service_name, description in dangerous_services:
            for line in config_lines:
                if re.search(pattern, line.content, re.I) and not re.search(f"no {pattern}", line.content, re.I):
                    findings.append(self.create_finding(
                        rule_id=f"COMP-SVC-{hash(pattern) % 1000}",
                        title=f"{service_name} Enabled",
                        description=description,
                        severity="MEDIUM",
                        config_line=line,
                        recommendation=f"Disable {service_name.lower()}",
                        fix_commands=[f"no {pattern}"],
                        cvss_vector=CVSSVector(
                            attack_vector="N",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="L",
                            integrity="N",
                            availability="N"
                        ),
                        nist_controls=["CM-7"],
                        vendor=VendorType.CISCO_IOS
                    ))
        
        return findings
    
    def _check_protocol_security(self, config: Dict[str, Any]) -> List[Finding]:
        """Check routing and network protocol security."""
        findings = []
        
        # BGP Authentication check
        bgp_neighbors = []
        for line in config.get("config_lines", []):
            if re.search(r'neighbor\s+\d+\.\d+\.\d+\.\d+', line.content):
                neighbor_ip = re.search(r'neighbor\s+(\d+\.\d+\.\d+\.\d+)', line.content).group(1)
                bgp_neighbors.append((neighbor_ip, line))
        
        # Check if BGP neighbors have authentication
        unauthenticated_neighbors = []
        for neighbor_ip, line in bgp_neighbors:
            # Look for password command for this neighbor
            has_auth = False
            for config_line in config.get("config_lines", []):
                if f"neighbor {neighbor_ip} password" in config_line.content:
                    has_auth = True
                    break
            
            if not has_auth:
                unauthenticated_neighbors.append((neighbor_ip, line))
        
        if unauthenticated_neighbors:
            first_neighbor = unauthenticated_neighbors[0][1]
            neighbor_list = [neighbor[0] for neighbor in unauthenticated_neighbors]
            
            findings.append(self.create_finding(
                rule_id="COMP-005",
                title="Unauthenticated BGP Neighbors",
                description=f"BGP neighbors without authentication: {', '.join(neighbor_list)}. This makes routing vulnerable to hijacking.",
                severity="HIGH",
                config_line=first_neighbor,
                recommendation="Configure MD5 authentication for all BGP neighbors",
                fix_commands=[f"neighbor {neighbor_list[0]} password <MD5_PASSWORD>"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["SC-45", "AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_missing_configurations(self, config_lines: List) -> List[Finding]:
        """Check for missing security configurations."""
        findings = []
        
        # Check for missing login banner
        has_banner = any(re.search(r'banner (login|motd)', line.content, re.I) for line in config_lines)
        if not has_banner:
            findings.append(self.create_finding(
                rule_id="COMP-006",
                title="Missing Login Banner",
                description="No login banner configured to warn unauthorized users, which may impact legal proceedings.",
                severity="LOW",
                recommendation="Configure warning banner for legal protection",
                fix_commands=["banner login ^C Unauthorized access prohibited ^C"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-8"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for service password-encryption
        has_password_encryption = any(re.search(r'service password-encryption', line.content, re.I) for line in config_lines)
        if not has_password_encryption:
            findings.append(self.create_finding(
                rule_id="COMP-007",
                title="Password Encryption Service Disabled",
                description="Service password-encryption is not enabled, leaving passwords in plain text in memory and configuration.",
                severity="MEDIUM",
                recommendation="Enable password encryption service",
                fix_commands=["service password-encryption"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="H",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for IP redirects disabled
        has_no_redirects = any(re.search(r'no ip redirects', line.content, re.I) for line in config_lines)
        if not has_no_redirects:
            findings.append(self.create_finding(
                rule_id="COMP-008",
                title="IP Redirects Not Globally Disabled",
                description="IP redirects are not globally disabled, which can be used for man-in-the-middle attacks.",
                severity="MEDIUM",
                recommendation="Disable IP redirects globally or per interface",
                fix_commands=["no ip redirects"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings