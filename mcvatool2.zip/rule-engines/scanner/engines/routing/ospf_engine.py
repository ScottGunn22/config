"""OSPF Security Analysis Engine."""

import re
from typing import List, Dict, Any, Optional
from ..base_engine import ProtocolSecurityEngine, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector
from ..utils import safe_get_content, create_mock_config_line


class OSPFSecurityEngine(ProtocolSecurityEngine):
    """Comprehensive OSPF security analysis engine."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 18
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS, VendorType.JUNIPER_JUNOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze OSPF configuration for security issues."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_ospf(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._analyze_juniper_ospf(parsed_config))
        
        return findings
    
    def _analyze_cisco_ospf(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco OSPF configuration."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Extract OSPF configuration
        ospf_config = self._extract_ospf_config(config_lines)
        
        if not ospf_config:
            return findings  # No OSPF configured
        
        # Run OSPF security checks
        findings.extend(self.check_authentication(ospf_config))
        findings.extend(self.check_filtering(ospf_config))
        findings.extend(self.check_hardening(ospf_config))
        
        return findings
    
    def _extract_ospf_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract OSPF configuration from config lines."""
        ospf_config = {
            "router_ospf": None,
            "process_id": None,
            "router_id": None,
            "areas": {},
            "networks": [],
            "interfaces": {},
            "passive_interfaces": [],
            "default_routes": [],
            "ospf_section_lines": []
        }
        
        in_ospf_section = False
        current_area = None
        
        # First pass: Extract router OSPF section
        for line in config_lines:
            content = safe_get_content(line)
            if not hasattr(line, 'content'):
                line = create_mock_config_line(content)
            
            # Start of OSPF section
            if re.match(r'router ospf (\d+)', content):
                in_ospf_section = True
                match = re.match(r'router ospf (\d+)', content)
                ospf_config["router_ospf"] = line
                ospf_config["process_id"] = match.group(1)
                ospf_config["ospf_section_lines"].append(line)
                continue
            
            # End of OSPF section
            if in_ospf_section and (content.startswith('router ') or 
                                  content.startswith('interface ') or
                                  content.startswith('line ')) and not content.startswith('router ospf'):
                in_ospf_section = False
                continue
            
            if in_ospf_section:
                ospf_config["ospf_section_lines"].append(line)
                
                # Router ID
                if content.startswith('router-id'):
                    ospf_config["router_id"] = {
                        "id": content.split()[1],
                        "config_line": line
                    }
                
                # Area configuration
                elif content.startswith('area'):
                    area_match = re.match(r'area ([\d.]+) (.+)', content)
                    if area_match:
                        area_id = area_match.group(1)
                        area_cmd = area_match.group(2)
                        
                        if area_id not in ospf_config["areas"]:
                            ospf_config["areas"][area_id] = {
                                "id": area_id,
                                "authentication": None,
                                "nssa": False,
                                "stub": False,
                                "default_cost": None,
                                "range": [],
                                "config_lines": []
                            }
                        
                        area = ospf_config["areas"][area_id]
                        area["config_lines"].append(line)
                        
                        if "authentication" in area_cmd:
                            if "message-digest" in area_cmd:
                                area["authentication"] = "md5"
                            else:
                                area["authentication"] = "plaintext"
                        elif "nssa" in area_cmd:
                            area["nssa"] = True
                        elif "stub" in area_cmd:
                            area["stub"] = True
                            if "no-summary" in area_cmd:
                                area["stub_no_summary"] = True
                        elif "default-cost" in area_cmd:
                            area["default_cost"] = area_cmd.split()[-1]
                        elif "range" in area_cmd:
                            area["range"].append(area_cmd)
                
                # Network statements
                elif content.startswith('network'):
                    network_match = re.match(r'network ([\d.]+) ([\d.]+) area ([\d.]+)', content)
                    if network_match:
                        ospf_config["networks"].append({
                            "network": network_match.group(1),
                            "wildcard": network_match.group(2),
                            "area": network_match.group(3),
                            "config_line": line
                        })
                
                # Passive interfaces
                elif "passive-interface" in content:
                    if content.startswith('passive-interface'):
                        interface = content.split()[1] if len(content.split()) > 1 else "default"
                        ospf_config["passive_interfaces"].append({
                            "interface": interface,
                            "config_line": line
                        })
                
                # Default route origination
                elif "default-information originate" in content:
                    ospf_config["default_routes"].append({
                        "command": content,
                        "config_line": line
                    })
        
        # Second pass: Extract interface OSPF configuration
        current_interface = None
        for line in config_lines:
            content = safe_get_content(line)
            if not hasattr(line, 'content'):
                line = create_mock_config_line(content)
            
            # Interface definition
            if content.startswith('interface '):
                current_interface = content.split()[1]
                continue
            
            # End of interface section
            if current_interface and (content.startswith('interface ') or 
                                    content.startswith('router ') or
                                    content.startswith('line ')):
                current_interface = None
                continue
            
            if current_interface:
                # OSPF interface commands
                if "ip ospf" in content:
                    if current_interface not in ospf_config["interfaces"]:
                        ospf_config["interfaces"][current_interface] = {
                            "name": current_interface,
                            "authentication": None,
                            "authentication_key": None,
                            "message_digest": {},
                            "cost": None,
                            "priority": None,
                            "hello_interval": None,
                            "dead_interval": None,
                            "config_lines": []
                        }
                    
                    interface_ospf = ospf_config["interfaces"][current_interface]
                    interface_ospf["config_lines"].append(line)
                    
                    if "ip ospf authentication" in content:
                        if "message-digest" in content:
                            interface_ospf["authentication"] = "md5"
                        else:
                            interface_ospf["authentication"] = "plaintext"
                    elif "ip ospf authentication-key" in content:
                        interface_ospf["authentication_key"] = content
                    elif "ip ospf message-digest-key" in content:
                        key_match = re.match(r'ip ospf message-digest-key (\d+) md5 (.+)', content)
                        if key_match:
                            key_id = key_match.group(1)
                            interface_ospf["message_digest"][key_id] = content
                    elif "ip ospf cost" in content:
                        interface_ospf["cost"] = content.split()[-1]
                    elif "ip ospf priority" in content:
                        interface_ospf["priority"] = content.split()[-1]
                    elif "ip ospf hello-interval" in content:
                        interface_ospf["hello_interval"] = content.split()[-1]
                    elif "ip ospf dead-interval" in content:
                        interface_ospf["dead_interval"] = content.split()[-1]
        
        return ospf_config
    
    def check_authentication(self, ospf_config: Dict) -> List[Finding]:
        """Check OSPF authentication configuration."""
        findings = []
        
        # Check for areas without authentication
        unauthenticated_areas = []
        weak_auth_areas = []
        
        for area_id, area in ospf_config.get("areas", {}).items():
            auth_type = area.get("authentication")
            if not auth_type:
                unauthenticated_areas.append(area_id)
            elif auth_type == "plaintext":
                weak_auth_areas.append(area_id)
        
        # Report unauthenticated areas
        if unauthenticated_areas:
            findings.append(self.create_finding(
                rule_id="OSPF-001",
                title="OSPF Areas Without Authentication",
                description=f"OSPF areas without authentication: {', '.join(unauthenticated_areas)}. "
                           f"Vulnerable to LSA injection and routing manipulation attacks.",
                severity=Severity.HIGH,
                category="OSPF Security",
                config_line=ospf_config["router_ospf"],
                recommendation="Configure MD5 authentication for all OSPF areas",
                fix_commands=[f"area {unauthenticated_areas[0]} authentication message-digest"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["SC-45", "AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Report weak authentication
        if weak_auth_areas:
            findings.append(self.create_finding(
                rule_id="OSPF-002",
                title="OSPF Areas with Weak Authentication",
                description=f"OSPF areas using plaintext authentication: {', '.join(weak_auth_areas)}. "
                           f"Passwords transmitted in clear text.",
                severity=Severity.MEDIUM,
                category="OSPF Security",
                config_line=ospf_config["router_ospf"],
                recommendation="Use MD5 authentication instead of plaintext",
                fix_commands=[f"area {weak_auth_areas[0]} authentication message-digest"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["IA-5", "SC-8"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check interface authentication
        interfaces_without_keys = []
        for interface_name, interface_config in ospf_config.get("interfaces", {}).items():
            auth_type = interface_config.get("authentication")
            if auth_type == "md5" and not interface_config.get("message_digest"):
                interfaces_without_keys.append(interface_name)
            elif auth_type == "plaintext" and not interface_config.get("authentication_key"):
                interfaces_without_keys.append(interface_name)
        
        if interfaces_without_keys:
            findings.append(self.create_finding(
                rule_id="OSPF-003",
                title="OSPF Interfaces Missing Authentication Keys",
                description=f"OSPF interfaces with authentication enabled but missing keys: {', '.join(interfaces_without_keys)}.",
                severity=Severity.HIGH,
                category="OSPF Security",
                recommendation="Configure authentication keys on OSPF interfaces",
                fix_commands=["ip ospf message-digest-key 1 md5 <KEY>"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def check_filtering(self, ospf_config: Dict) -> List[Finding]:
        """Check OSPF filtering and LSA control."""
        findings = []
        
        # Check for missing passive interfaces
        networks = ospf_config.get("networks", [])
        passive_interfaces = [p["interface"] for p in ospf_config.get("passive_interfaces", [])]
        
        if networks and not passive_interfaces and "default" not in passive_interfaces:
            findings.append(self.create_finding(
                rule_id="OSPF-004",
                title="OSPF Missing Passive Interface Configuration",
                description="OSPF networks configured without passive interface settings. "
                           "May advertise unnecessary networks or establish unwanted adjacencies.",
                severity=Severity.MEDIUM,
                category="OSPF Security",
                config_line=ospf_config["router_ospf"],
                recommendation="Configure passive interfaces for networks that shouldn't form adjacencies",
                fix_commands=["passive-interface default", "no passive-interface <OSPF_INTERFACE>"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="H",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for area range summarization
        areas_without_summarization = []
        for area_id, area in ospf_config.get("areas", {}).items():
            if area_id != "0" and not area.get("range"):  # Non-backbone areas
                areas_without_summarization.append(area_id)
        
        if areas_without_summarization:
            findings.append(self.create_finding(
                rule_id="OSPF-005",
                title="OSPF Areas Without Route Summarization",
                description=f"OSPF areas without route summarization: {', '.join(areas_without_summarization)}. "
                           f"May cause routing table bloat and performance issues.",
                severity=Severity.LOW,
                category="OSPF Security",
                config_line=ospf_config["router_ospf"],
                recommendation="Configure area range summarization for better scalability",
                fix_commands=[f"area {areas_without_summarization[0]} range <NETWORK> <MASK>"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="H",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def check_hardening(self, ospf_config: Dict) -> List[Finding]:
        """Check OSPF hardening measures."""
        findings = []
        
        # Check for explicit router-id
        if not ospf_config.get("router_id"):
            findings.append(self.create_finding(
                rule_id="OSPF-006",
                title="OSPF Router ID Not Explicitly Configured",
                description="OSPF router-id not explicitly set. May cause instability during interface changes.",
                severity=Severity.MEDIUM,
                category="OSPF Security",
                config_line=ospf_config["router_ospf"],
                recommendation="Configure explicit OSPF router-id using loopback interface",
                fix_commands=["router-id <LOOPBACK_IP>"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="H",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for stub/NSSA area configuration
        backbone_only = len(ospf_config.get("areas", {})) == 1 and "0" in ospf_config.get("areas", {})
        if not backbone_only:
            non_special_areas = []
            for area_id, area in ospf_config.get("areas", {}).items():
                if area_id != "0" and not area.get("stub") and not area.get("nssa"):
                    non_special_areas.append(area_id)
            
            if non_special_areas:
                findings.append(self.create_finding(
                    rule_id="OSPF-007",
                    title="OSPF Non-Backbone Areas Not Configured as Stub/NSSA",
                    description=f"OSPF areas not configured as stub or NSSA: {', '.join(non_special_areas)}. "
                               f"May receive unnecessary external routes.",
                    severity=Severity.LOW,
                    category="OSPF Security",
                    config_line=ospf_config["router_ospf"],
                    recommendation="Configure non-backbone areas as stub or NSSA for better security",
                    fix_commands=[f"area {non_special_areas[0]} stub"],
                    cvss_vector=CVSSVector(
                        attack_vector="L",
                        attack_complexity="H",
                        privileges_required="H",
                        confidentiality="L",
                        integrity="L",
                        availability="N"
                    ),
                    nist_controls=["SC-7"],
                    vendor=VendorType.CISCO_IOS
                ))
        
        # Check for interface timer security
        interfaces_with_default_timers = []
        for interface_name, interface_config in ospf_config.get("interfaces", {}).items():
            hello_interval = interface_config.get("hello_interval")
            dead_interval = interface_config.get("dead_interval")
            
            # Default timers are hello=10s, dead=40s for broadcast networks
            if not hello_interval or not dead_interval:
                interfaces_with_default_timers.append(interface_name)
        
        if interfaces_with_default_timers:
            findings.append(self.create_finding(
                rule_id="OSPF-008",
                title="OSPF Interfaces Using Default Timers",
                description=f"OSPF interfaces using default hello/dead timers: {', '.join(interfaces_with_default_timers[:5])}. "
                           f"Consider tuning for faster convergence and security.",
                severity=Severity.INFO,
                category="OSPF Security",
                recommendation="Consider tuning OSPF timers for better convergence",
                fix_commands=[
                    "ip ospf hello-interval 5",
                    "ip ospf dead-interval 20"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="H",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="N",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for default route origination security
        default_routes = ospf_config.get("default_routes", [])
        for default_route in default_routes:
            command = default_route["command"]
            if "always" not in command:
                findings.append(self.create_finding(
                    rule_id="OSPF-009",
                    title="OSPF Default Route Injection Without 'Always' Keyword",
                    description="OSPF default route origination configured without 'always' keyword. "
                               "May cause routing instability if default route is withdrawn.",
                    severity=Severity.LOW,
                    category="OSPF Security",
                    config_line=default_route["config_line"],
                    recommendation="Consider using 'always' keyword for consistent default route advertisement",
                    fix_commands=["default-information originate always"],
                    cvss_vector=CVSSVector(
                        attack_vector="L",
                        attack_complexity="H",
                        privileges_required="H",
                        confidentiality="N",
                        integrity="L",
                        availability="L"
                    ),
                    nist_controls=["SC-7"],
                    vendor=VendorType.CISCO_IOS
                ))
        
        return findings
    
    def _analyze_juniper_ospf(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Juniper OSPF configuration (placeholder)."""
        # TODO: Implement Juniper OSPF analysis
        return []