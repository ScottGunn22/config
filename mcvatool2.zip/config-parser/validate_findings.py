#!/usr/bin/env python3
"""
Validation script to detect false positives and false negatives.
Tests scanner output against expected findings.
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Set


class FindingValidator:
    """Validates scanner findings against expected results."""

    def __init__(self):
        self.false_positives = []
        self.false_negatives = []
        self.correct_findings = []

    def load_expected_findings(self, expected_file: Path) -> Dict[str, List[str]]:
        """Load expected findings from JSON file."""
        with open(expected_file, 'r') as f:
            return json.load(f)

    def load_actual_findings(self, results_file: Path) -> Dict[str, List[str]]:
        """Load actual scanner results from JSON file."""
        with open(results_file, 'r') as f:
            data = json.load(f)
            # Extract finding titles and their line numbers
            findings = {}
            for finding in data.get('security_findings', []):
                title = finding['title']
                line_num = finding.get('line_number', 0)
                if title not in findings:
                    findings[title] = []
                findings[title].append(line_num)
            return findings

    def validate(self, expected: Dict, actual: Dict) -> Dict:
        """Compare expected vs actual findings."""

        # Check for false negatives (missed detections)
        for expected_title, expected_lines in expected.get('should_flag', {}).items():
            if expected_title not in actual:
                self.false_negatives.append({
                    'title': expected_title,
                    'expected_lines': expected_lines,
                    'reason': 'Not detected at all'
                })
            else:
                # Found the issue, check if it's on the right lines
                actual_lines = actual[expected_title]
                for exp_line in expected_lines:
                    if exp_line not in actual_lines:
                        self.false_negatives.append({
                            'title': expected_title,
                            'expected_lines': [exp_line],
                            'actual_lines': actual_lines,
                            'reason': f'Missed line {exp_line}'
                        })

        # Check for false positives (incorrect detections)
        for actual_title, actual_lines in actual.items():
            # Check if this finding matches something we expect to NOT flag
            for should_not_flag in expected.get('should_not_flag', {}).keys():
                if should_not_flag.lower() in actual_title.lower():
                    self.false_positives.append({
                        'title': actual_title,
                        'lines': actual_lines,
                        'reason': f'Should not flag: {should_not_flag}'
                    })

            # Check if this is an expected finding
            if actual_title in expected.get('should_flag', {}):
                self.correct_findings.append({
                    'title': actual_title,
                    'lines': actual_lines
                })

        return {
            'false_positives': self.false_positives,
            'false_negatives': self.false_negatives,
            'correct_findings': self.correct_findings
        }

    def generate_report(self) -> str:
        """Generate validation report."""
        report = []
        report.append("=" * 80)
        report.append("FINDING VALIDATION REPORT")
        report.append("=" * 80)
        report.append("")

        # Summary
        total = len(self.false_positives) + len(self.false_negatives) + len(self.correct_findings)
        fp_rate = (len(self.false_positives) / total * 100) if total > 0 else 0
        fn_rate = (len(self.false_negatives) / total * 100) if total > 0 else 0
        accuracy = (len(self.correct_findings) / total * 100) if total > 0 else 0

        report.append("SUMMARY")
        report.append("-" * 80)
        report.append(f"Total Findings: {total}")
        report.append(f"Correct: {len(self.correct_findings)} ({accuracy:.1f}%)")
        report.append(f"False Positives: {len(self.false_positives)} ({fp_rate:.1f}%)")
        report.append(f"False Negatives: {len(self.false_negatives)} ({fn_rate:.1f}%)")
        report.append("")

        # False Positives
        if self.false_positives:
            report.append("FALSE POSITIVES (Incorrect Detections)")
            report.append("-" * 80)
            for i, fp in enumerate(self.false_positives, 1):
                report.append(f"{i}. {fp['title']}")
                report.append(f"   Lines: {fp['lines']}")
                report.append(f"   Reason: {fp['reason']}")
                report.append("")

        # False Negatives
        if self.false_negatives:
            report.append("FALSE NEGATIVES (Missed Detections)")
            report.append("-" * 80)
            for i, fn in enumerate(self.false_negatives, 1):
                report.append(f"{i}. {fn['title']}")
                report.append(f"   Expected Lines: {fn['expected_lines']}")
                if 'actual_lines' in fn:
                    report.append(f"   Actual Lines: {fn['actual_lines']}")
                report.append(f"   Reason: {fn['reason']}")
                report.append("")

        # Correct Findings
        if self.correct_findings:
            report.append("CORRECT FINDINGS")
            report.append("-" * 80)
            for i, correct in enumerate(self.correct_findings, 1):
                report.append(f"{i}. {correct['title']} (Lines: {correct['lines']})")

        report.append("")
        report.append("=" * 80)

        return "\n".join(report)


def main():
    """Main validation entry point."""
    if len(sys.argv) != 3:
        print("Usage: python3 validate_findings.py <expected.json> <actual_results.json>")
        sys.exit(1)

    expected_file = Path(sys.argv[1])
    results_file = Path(sys.argv[2])

    if not expected_file.exists():
        print(f"Error: Expected findings file not found: {expected_file}")
        sys.exit(1)

    if not results_file.exists():
        print(f"Error: Results file not found: {results_file}")
        sys.exit(1)

    validator = FindingValidator()

    try:
        expected = validator.load_expected_findings(expected_file)
        actual = validator.load_actual_findings(results_file)
        validator.validate(expected, actual)

        report = validator.generate_report()
        print(report)

        # Exit with error code if false positives or negatives found
        if validator.false_positives or validator.false_negatives:
            sys.exit(1)

    except Exception as e:
        print(f"Validation error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
