# Enterprise Security Parser - Package

## What's Included

This package contains everything you need to run the Enterprise Security Parser, a comprehensive command-line tool for analyzing network device configurations for security vulnerabilities and compliance issues.

### Core Files

- **enterprise_security_parser.py** - Main CLI script
- **benchmark_validator.py** - CIS, STIG, and vendor hardening guide validation
- **benchmark_rules.py** - Benchmark rule definitions
- **genie_integration.py** - Cisco Genie parser integration
- **enhanced_parser.py** - Advanced Cisco configuration parsing
- **juniper_enhanced_parser.py** - Juniper JunOS configuration parsing
- **paloalto_enhanced_parser.py** - Palo Alto PAN-OS configuration parsing
- **cva_mapping.json** - CVA vulnerability ID mapping (customizable)

### Documentation

- **USER_GUIDE.md** - Complete user guide with examples and troubleshooting
- **ENTERPRISE_READINESS.md** - Gap analysis and enterprise feature assessment
- **IMPLEMENTATION_ROADMAP.md** - 18-month roadmap to enterprise-ready solution
- **README.md** - This file

### Complete Package

This package includes **everything needed** - both the parser scripts and the rule-engines directory with all security analysis engines.

**Extracted directory structure:**
```
enterprise-security-parser/
├── config-parser/           (parser scripts)
│   ├── enterprise_security_parser.py
│   ├── benchmark_validator.py
│   ├── README.md
│   └── ... (documentation and other files)
└── rule-engines/            (security engines - INCLUDED!)
    └── scanner/
        ├── core.py
        ├── engines/
        │   ├── security/
        │   ├── routing/
        │   ├── switching/
        │   └── compliance/
        └── rules/
```

---

## Quick Start

### Prerequisites

- Python 3.7 or higher
- All dependencies included in the package!

### Optional Dependencies

```bash
# For enhanced parsing (recommended)
pip install genie

# For better regex performance
pip install regex
```

### Basic Usage

```bash
# Extract the package
unzip shipit.zip
cd config-parser

# Make the script executable
chmod +x enterprise_security_parser.py

# Run analysis on a configuration file
python3 enterprise_security_parser.py router-config.txt --output report.html

# Generate JSON output
python3 enterprise_security_parser.py router-config.txt --output findings.json --format json --pretty

# Specify vendor explicitly
python3 enterprise_security_parser.py config.txt --output report.html --vendor cisco_ios
```

### Example Output

```
Parsing configuration...
✓ Parsed 856 lines
✓ Detected vendor: cisco_ios
Running security analysis...
✓ ACLSecurityEngine: 8 findings
✓ CryptographySecurityEngine: 3 findings
✓ SNMPSecurityEngine: 2 findings
✓ BenchmarkValidator: 18 findings
✓ HTML report written to: report.html

Security Analysis:
  Total Findings: 63
  Critical: 5
  High: 15
  Medium: 28
  Low: 12
  Info: 3
```

---

## Features

### Multi-Vendor Support
- Cisco IOS/IOS-XE
- Juniper JunOS
- Palo Alto PAN-OS
- Fortinet FortiOS

### Security Analysis
- Access Control Lists (ACLs)
- Cryptography & Encryption
- SNMP Security
- Routing Protocol Security (BGP, OSPF)
- Authentication & Authorization
- Network Services
- Tunnel & VPN Security
- Layer 2 Security (STP)

### Compliance Benchmarks
- CIS Benchmark v4.1.0
- DISA STIG
- Vendor Hardening Guides
- PCI-DSS Requirements

### Output Formats
- HTML Report (with Bootstrap styling)
- JSON (with --pretty option)

---

## Important Setup Notes

### 1. Complete Package - No Extra Setup Required!

Everything is included in this package. The `rule-engines` directory with all security analysis engines is already in the correct location. Just extract and run!

### 2. Customizing CVA Mapping

Edit `cva_mapping.json` to map findings to your internal vulnerability IDs:

```json
{
  "mappings": {
    "cdp": "CVA 0000",
    "http": "CVA 0001",
    "enable_secret": "CVA 0039"
  }
}
```

### 3. Vendor Auto-Detection

The parser automatically detects vendor from configuration content. To override:

```bash
python3 enterprise_security_parser.py config.txt --output report.html --vendor cisco_ios
```

Valid vendor codes:
- `cisco_ios`
- `juniper_junos`
- `paloalto_panos`
- `fortinet_fortios`
- `unknown`

---

## Documentation

### USER_GUIDE.md
Complete guide covering:
- Installation and setup
- Usage examples
- All command-line options
- Understanding results
- Troubleshooting
- Advanced usage scenarios

### ENTERPRISE_READINESS.md
Assessment document covering:
- Current capabilities
- Enterprise feature gaps
- Scalability concerns
- Security & compliance gaps
- Priority matrix for improvements

### IMPLEMENTATION_ROADMAP.md
18-month roadmap including:
- Quarterly milestones
- Technical architecture evolution
- Resource requirements
- Risk management
- Success metrics

---

## Command-Line Reference

```bash
python3 enterprise_security_parser.py <config_file> [OPTIONS]

Required Arguments:
  config_file          Path to configuration file

Options:
  -o, --output FILE    Output file path (required)
  -f, --format FORMAT  Output format: html or json (default: html)
  -v, --vendor VENDOR  Vendor type (auto-detect if not specified)
  -p, --pretty         Pretty-print JSON output
  -n, --no-security    Skip security analysis (parse only)
  -h, --help           Show help message
```

---

## Troubleshooting

### ImportError: No module named 'scanner'

**Problem:** The rule-engines directory is not found.

**Solution:** Make sure you extracted the complete shipit.zip and that you're running the script from the `config-parser` directory. The directory structure should be:

```
extracted-location/
├── config-parser/        <- Run script from here
│   └── enterprise_security_parser.py
└── rule-engines/         <- Should be at the same level
    └── scanner/
```

If you moved files around, the script expects rule-engines in the parent directory.

### Detected vendor: unknown

**Problem:** Configuration format not recognized.

**Solution:** Manually specify the vendor:
```bash
python3 enterprise_security_parser.py config.txt --output report.html --vendor cisco_ios
```

### Genie parser warnings

**Warning:** `⚠ Warning: Genie parser not installed. Falling back to regex parsing.`

**Solution (optional):** Install Genie for enhanced parsing:
```bash
pip install genie
```

**Note:** Regex parsing works well. Genie is optional but recommended for Cisco IOS.

---

## Examples

### Example 1: Basic Scan
```bash
python3 enterprise_security_parser.py router-config.txt -o report.html
```

### Example 2: JSON Output for Automation
```bash
python3 enterprise_security_parser.py config.txt \
  --output findings.json \
  --format json \
  --pretty
```

### Example 3: Juniper Device
```bash
python3 enterprise_security_parser.py juniper-set-config.txt \
  --output juniper-report.html \
  --vendor juniper_junos
```

### Example 4: Parse Only (No Security Analysis)
```bash
python3 enterprise_security_parser.py config.txt \
  --output parsed.json \
  --format json \
  --no-security
```

---

## Integration Examples

### CI/CD Pipeline

```bash
#!/bin/bash
# Fail build if critical findings detected

python3 enterprise_security_parser.py config.txt -o findings.json -f json

CRITICAL=$(jq '.security_summary.critical' findings.json)

if [ "$CRITICAL" -gt 0 ]; then
  echo "FAIL: $CRITICAL critical findings detected"
  exit 1
fi

echo "PASS: No critical findings"
```

### Batch Processing

```bash
#!/bin/bash
# Process all configs in a directory

for config in configs/*.txt; do
  filename=$(basename "$config" .txt)
  python3 enterprise_security_parser.py "$config" \
    --output "reports/${filename}-report.html"
done
```

---

## What's Next?

For enterprise deployment, see **ENTERPRISE_READINESS.md** and **IMPLEMENTATION_ROADMAP.md** for:
- Database integration
- REST API
- Multi-file processing
- User management & RBAC
- Alerting & notifications
- Scheduled scanning
- High availability
- Advanced reporting

---

## Support

### Getting Help

1. Read the **USER_GUIDE.md** for detailed documentation
2. Check the **Troubleshooting** section above
3. Review console output for specific error messages

### Reporting Issues

When reporting issues, include:
- Python version (`python3 --version`)
- Operating system
- Complete error message
- Sample configuration (sanitized)
- Command used

---

## License

See main project license.

---

## Version

**Package Version:** 1.0
**Created:** 2025-10-23

---

**Ready to Ship!** 🚀
