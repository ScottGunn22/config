"""Enhanced parser for Palo Alto PAN-OS configurations.

Provides structured parsing of PAN-OS configurations for security analysis.
Handles hierarchical 'show config' output format.
"""

from typing import Dict, Any, List, Optional
import re


class PaloAltoEnhancedParser:
    """Enhanced parser for Palo Alto PAN-OS configurations."""

    def __init__(self):
        self.config_data = {}

    def parse(self, config_lines: List[Any]) -> Dict[str, Any]:
        """Parse PAN-OS configuration into structured data.

        Args:
            config_lines: List of ConfigLine objects or strings

        Returns:
            Dictionary with structured configuration data
        """
        # Convert to list of strings
        lines = []
        for line in config_lines:
            if hasattr(line, 'content'):
                lines.append(line.content)
            else:
                lines.append(str(line))

        return self._parse_config(lines)

    def _parse_config(self, lines: List[str]) -> Dict[str, Any]:
        """Parse PAN-OS hierarchical configuration."""
        data = {
            'deviceconfig': {
                'system': {},
                'setting': {}
            },
            'mgt-config': {
                'users': {},
                'password_profile': {}
            },
            'network': {
                'interfaces': {},
                'zones': {},
                'virtual_routers': {}
            },
            'devices': {
                'vsys': {}
            },
            'high_availability': {
                'enabled': False,
                'encryption': None,
                'authentication': None
            },
            'shared': {
                'log_settings': {}
            }
        }

        # State tracking for hierarchical parsing
        context_stack = []
        current_obj = data

        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue

            # Calculate indentation
            indent = len(line) - len(line.lstrip())

            # Handle closing braces/semicolons
            if stripped == ';' or stripped == '}':
                if context_stack:
                    context_stack.pop()
                    current_obj = data
                    for ctx in context_stack:
                        current_obj = current_obj.get(ctx, {})
                continue

            # Remove trailing semicolon or opening brace
            if stripped.endswith(';'):
                stripped = stripped[:-1].strip()
            if stripped.endswith('{'):
                stripped = stripped[:-1].strip()

            # Parse line
            parts = stripped.split(maxsplit=1)
            if not parts:
                continue

            keyword = parts[0]
            value = parts[1] if len(parts) > 1 else None

            # Route to specific parsers based on context
            if not context_stack:
                # Top level
                if keyword == 'deviceconfig':
                    context_stack.append('deviceconfig')
                    current_obj = data['deviceconfig']
                elif keyword == 'mgt-config':
                    context_stack.append('mgt-config')
                    current_obj = data['mgt-config']
                elif keyword == 'network':
                    context_stack.append('network')
                    current_obj = data['network']
                elif keyword == 'devices':
                    context_stack.append('devices')
                    current_obj = data['devices']
                elif keyword == 'shared':
                    context_stack.append('shared')
                    current_obj = data['shared']
            else:
                # Within a context
                self._parse_context(context_stack, current_obj, keyword, value, data)

        return data

    def _parse_context(self, context_stack: List[str], current_obj: Dict, keyword: str, value: Optional[str], root_data: Dict):
        """Parse based on current context."""
        if not context_stack:
            return

        ctx = context_stack[0]

        # Device config parsing
        if ctx == 'deviceconfig':
            if keyword == 'system':
                if 'hostname' not in current_obj['system']:
                    current_obj['system']['hostname'] = None
                if 'dns-setting' not in current_obj['system']:
                    current_obj['system']['dns-setting'] = {}
                if 'ntp-servers' not in current_obj['system']:
                    current_obj['system']['ntp-servers'] = []

                if len(context_stack) > 1 and context_stack[1] == 'system':
                    if keyword == 'hostname':
                        current_obj['system']['hostname'] = value
                    elif keyword == 'ntp-servers':
                        context_stack.append('ntp-servers')
                    elif keyword == 'primary-ntp-server':
                        if 'server-address' in value or 'ntp-server-address' in value:
                            addr_match = re.search(r'[\d\.]+', value)
                            if addr_match:
                                current_obj['system']['ntp-servers'].append(addr_match.group())

            elif keyword == 'setting':
                if 'management' not in current_obj['setting']:
                    current_obj['setting']['management'] = {}
                if 'protocol' not in current_obj['setting']['management']:
                    current_obj['setting']['management']['protocol'] = {'http': False, 'https': True, 'ssh': True, 'telnet': False}

        # Management config parsing
        elif ctx == 'mgt-config':
            if keyword == 'users':
                if len(context_stack) > 1 and isinstance(value, str):
                    username = value.strip('"')
                    if username not in current_obj['users']:
                        current_obj['users'][username] = {
                            'password_profile': None,
                            'authentication': 'password'
                        }

            elif keyword == 'password-profile':
                if isinstance(value, str):
                    profile_name = value.strip('"')
                    if profile_name not in current_obj['password_profile']:
                        current_obj['password_profile'][profile_name] = {
                            'min_length': None,
                            'complexity': {}
                        }

        # Network parsing
        elif ctx == 'network':
            if keyword == 'interface':
                if 'ethernet' not in current_obj['interfaces']:
                    current_obj['interfaces']['ethernet'] = {}

                if value and 'ethernet' in value.lower():
                    if_match = re.search(r'ethernet(\d+/\d+)', value.lower())
                    if if_match:
                        if_name = f"ethernet{if_match.group(1)}"
                        if if_name not in current_obj['interfaces']['ethernet']:
                            current_obj['interfaces']['ethernet'][if_name] = {
                                'layer3': {},
                                'layer2': {},
                                'mode': None
                            }

            elif keyword == 'zone':
                if isinstance(value, str):
                    zone_name = value.strip('"')
                    if zone_name not in current_obj['zones']:
                        current_obj['zones'][zone_name] = {
                            'interfaces': [],
                            'type': None
                        }

            elif keyword == 'virtual-router':
                if isinstance(value, str):
                    vr_name = value.strip('"')
                    if vr_name not in current_obj['virtual_routers']:
                        current_obj['virtual_routers'][vr_name] = {
                            'interfaces': [],
                            'routing_table': {},
                            'protocol': {}
                        }

        # Devices/vsys parsing
        elif ctx == 'devices':
            if keyword == 'vsys':
                if isinstance(value, str):
                    vsys_name = value.strip('"')
                    if vsys_name not in current_obj['vsys']:
                        current_obj['vsys'][vsys_name] = {
                            'rulebase': {
                                'security': []
                            },
                            'service': {},
                            'service-group': {}
                        }

        # Shared config parsing
        elif ctx == 'shared':
            if keyword == 'log-settings':
                if 'syslog' not in current_obj['log_settings']:
                    current_obj['log_settings']['syslog'] = []
                if 'profiles' not in current_obj['log_settings']:
                    current_obj['log_settings']['profiles'] = {}

    def parse_security_policies(self, config_lines: List[str]) -> List[Dict[str, Any]]:
        """Extract security policies from configuration."""
        policies = []
        current_policy = None

        for line in config_lines:
            stripped = line.strip()

            if 'security rules' in stripped:
                # Start of security policy section
                continue

            # Look for rule definitions
            if stripped.startswith('entry name'):
                # New rule
                name_match = re.search(r'entry name\s+"([^"]+)"', stripped)
                if name_match:
                    if current_policy:
                        policies.append(current_policy)

                    current_policy = {
                        'name': name_match.group(1),
                        'from': [],
                        'to': [],
                        'source': [],
                        'destination': [],
                        'application': [],
                        'service': [],
                        'action': None,
                        'log_start': False,
                        'log_end': False,
                        'profile_setting': None
                    }

            elif current_policy:
                if 'from ' in stripped:
                    zone_match = re.search(r'from\s+\[?\s*"?([^"\]]+)"?\s*\]?', stripped)
                    if zone_match:
                        current_policy['from'].append(zone_match.group(1))

                elif 'to ' in stripped:
                    zone_match = re.search(r'to\s+\[?\s*"?([^"\]]+)"?\s*\]?', stripped)
                    if zone_match:
                        current_policy['to'].append(zone_match.group(1))

                elif 'source ' in stripped:
                    src_match = re.search(r'source\s+\[?\s*"?([^"\]]+)"?\s*\]?', stripped)
                    if src_match:
                        current_policy['source'].append(src_match.group(1))

                elif 'destination ' in stripped:
                    dst_match = re.search(r'destination\s+\[?\s*"?([^"\]]+)"?\s*\]?', stripped)
                    if dst_match:
                        current_policy['destination'].append(dst_match.group(1))

                elif 'action ' in stripped:
                    action_match = re.search(r'action\s+(\w+)', stripped)
                    if action_match:
                        current_policy['action'] = action_match.group(1)

                elif 'log-start' in stripped:
                    current_policy['log_start'] = 'yes' in stripped.lower()

                elif 'log-end' in stripped:
                    current_policy['log_end'] = 'yes' in stripped.lower()

        # Add last policy
        if current_policy:
            policies.append(current_policy)

        return policies

    def parse_vpn_config(self, config_lines: List[str]) -> Dict[str, Any]:
        """Extract VPN configuration."""
        vpn_data = {
            'ike_gateways': {},
            'ipsec_tunnels': {},
            'ike_crypto_profiles': {},
            'ipsec_crypto_profiles': {}
        }

        current_section = None
        current_name = None

        for line in config_lines:
            stripped = line.strip()

            if 'ike-crypto-profiles' in stripped:
                current_section = 'ike_crypto_profiles'
            elif 'ipsec-crypto-profiles' in stripped:
                current_section = 'ipsec_crypto_profiles'
            elif 'ike gateway' in stripped:
                current_section = 'ike_gateways'
            elif 'ipsec tunnel' in stripped:
                current_section = 'ipsec_tunnels'

            # Parse entries based on section
            if current_section and 'entry name' in stripped:
                name_match = re.search(r'entry name\s+"([^"]+)"', stripped)
                if name_match:
                    current_name = name_match.group(1)
                    if current_section == 'ike_gateways':
                        vpn_data['ike_gateways'][current_name] = {
                            'authentication': {},
                            'protocol': {},
                            'local_address': None,
                            'peer_address': None
                        }
                    elif current_section == 'ipsec_tunnels':
                        vpn_data['ipsec_tunnels'][current_name] = {
                            'auto_key': {
                                'ike_gateway': None,
                                'ipsec_crypto_profile': None
                            }
                        }
                    elif current_section == 'ike_crypto_profiles':
                        vpn_data['ike_crypto_profiles'][current_name] = {
                            'encryption': [],
                            'authentication': [],
                            'dh_group': []
                        }
                    elif current_section == 'ipsec_crypto_profiles':
                        vpn_data['ipsec_crypto_profiles'][current_name] = {
                            'esp_encryption': [],
                            'esp_authentication': [],
                            'dh_group': []
                        }

        return vpn_data

    def parse_high_availability(self, config_lines: List[str]) -> Dict[str, Any]:
        """Extract high availability configuration."""
        ha_data = {
            'enabled': False,
            'group_id': None,
            'mode': None,
            'encryption': False,
            'authentication': False,
            'peer_ip': None
        }

        in_ha_section = False

        for line in config_lines:
            stripped = line.strip()

            if 'high-availability' in stripped.lower():
                in_ha_section = True
                ha_data['enabled'] = True

            if in_ha_section:
                if 'group id' in stripped.lower():
                    id_match = re.search(r'(\d+)', stripped)
                    if id_match:
                        ha_data['group_id'] = int(id_match.group(1))

                elif 'mode' in stripped.lower():
                    if 'active-passive' in stripped.lower():
                        ha_data['mode'] = 'active-passive'
                    elif 'active-active' in stripped.lower():
                        ha_data['mode'] = 'active-active'

                elif 'encryption' in stripped.lower():
                    ha_data['encryption'] = 'enabled' in stripped.lower() or 'yes' in stripped.lower()

                elif 'authentication' in stripped.lower():
                    ha_data['authentication'] = 'enabled' in stripped.lower() or 'yes' in stripped.lower()

        return ha_data
