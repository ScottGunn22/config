"""Comprehensive security rules for Palo Alto PAN-OS.

Covers authentication, management access, security policies, VPN, high availability,
and logging configuration.
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class PaloAltoSecurityRules(BaseRuleEngine):
    """Security rules for Palo Alto PAN-OS."""

    def __init__(self):
        super().__init__()
        self.category = "Comprehensive Security"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check security rules."""
        findings = []

        if vendor == VendorType.PALOALTO_PANOS:
            findings.extend(self._check_paloalto_security(parsed_config))

        return findings

    def _check_paloalto_security(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Palo Alto security configuration."""
        findings = []

        # Check authentication and user management
        findings.extend(self._check_authentication(config))

        # Check management interface security
        findings.extend(self._check_management(config))

        # Check security policies
        findings.extend(self._check_security_policies(config))

        # Check VPN configuration
        findings.extend(self._check_vpn(config))

        # Check high availability
        findings.extend(self._check_high_availability(config))

        # Check logging
        findings.extend(self._check_logging(config))

        return findings

    def _check_authentication(self, config: Dict[str, Any]) -> List[Finding]:
        """Check authentication and password policies."""
        findings = []

        mgt_config = config.get('mgt-config', {})
        users = mgt_config.get('users', {})
        password_profiles = mgt_config.get('password_profile', {})

        # Check if admin users exist
        if not users:
            findings.append(self.create_finding(
                rule_id="PAN-AUTH-001",
                title="No Administrative Users Configured",
                description="No administrative users are configured on the device. This may indicate the device "
                          "is using only the default 'admin' account, which is not recommended for production "
                          "environments. Individual user accounts provide accountability and audit trails.",
                severity="HIGH",
                recommendation="Create individual administrative user accounts",
                fix_commands=[
                    "set mgt-config users <username> permissions role-based superuser yes",
                    "set mgt-config users <username> password"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-2", "AU-2", "IA-2"],
                vendor=VendorType.PALOALTO_PANOS
            ))

        # Check password profiles
        if not password_profiles:
            findings.append(self.create_finding(
                rule_id="PAN-AUTH-002",
                title="No Password Profile Configured",
                description="No password complexity profiles are configured. Without password profiles, "
                          "administrators can set weak passwords that are vulnerable to brute-force attacks. "
                          "Password profiles enforce minimum length, complexity, and expiration requirements.",
                severity="HIGH",
                recommendation="Create and enforce a strong password profile",
                fix_commands=[
                    "set mgt-config password-profile <profile_name> password-change on-first-login",
                    "set mgt-config password-profile <profile_name> password-complexity enabled yes",
                    "set mgt-config password-profile <profile_name> password-complexity minimum-length 15",
                    "set mgt-config password-profile <profile_name> password-complexity minimum-uppercase-letters 1",
                    "set mgt-config password-profile <profile_name> password-complexity minimum-lowercase-letters 1",
                    "set mgt-config password-profile <profile_name> password-complexity minimum-numeric-letters 1",
                    "set mgt-config password-profile <profile_name> password-complexity minimum-special-characters 1",
                    "set mgt-config users <username> password-profile <profile_name>"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-5(1)", "AC-2"],
                vendor=VendorType.PALOALTO_PANOS
            ))
        else:
            # Check password profile strength
            for profile_name, profile_config in password_profiles.items():
                min_length = profile_config.get('min_length', 0)
                if min_length < 12:
                    findings.append(self.create_finding(
                        rule_id="PAN-AUTH-003",
                        title=f"Weak Password Profile '{profile_name}'",
                        description=f"Password profile '{profile_name}' has minimum length of {min_length} characters. "
                                  f"NIST SP 800-63B recommends minimum password length of 12-15 characters for "
                                  f"administrative accounts. Short passwords are vulnerable to brute-force attacks.",
                        severity="MEDIUM",
                        recommendation=f"Increase minimum password length to at least 12 characters",
                        fix_commands=[
                            f"set mgt-config password-profile {profile_name} password-complexity minimum-length 15"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="N",
                            attack_complexity="H",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H",
                            availability="H"
                        ),
                        nist_controls=["IA-5(1)"],
                        vendor=VendorType.PALOALTO_PANOS
                    ))

        return findings

    def _check_management(self, config: Dict[str, Any]) -> List[Finding]:
        """Check management interface security."""
        findings = []

        deviceconfig = config.get('deviceconfig', {})
        system = deviceconfig.get('system', {})
        settings = deviceconfig.get('setting', {})

        # Check for HTTP management
        mgmt_protocol = settings.get('management', {}).get('protocol', {})
        if mgmt_protocol.get('http', False):
            findings.append(self.create_finding(
                rule_id="PAN-MGT-001",
                title="HTTP Management Interface Enabled",
                description="HTTP management interface is enabled on the device. HTTP transmits all data "
                          "including credentials in cleartext. An attacker with network access can intercept "
                          "administrative credentials and session data using packet sniffing.",
                severity="CRITICAL",
                recommendation="Disable HTTP and use HTTPS only",
                fix_commands=[
                    "set deviceconfig system service disable-http yes"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["SC-8", "AC-17", "IA-2(8)"],
                vendor=VendorType.PALOALTO_PANOS
            ))

        # Check for Telnet management
        if mgmt_protocol.get('telnet', False):
            findings.append(self.create_finding(
                rule_id="PAN-MGT-002",
                title="Telnet Management Interface Enabled",
                description="Telnet management interface is enabled. Telnet transmits all data including "
                          "credentials in cleartext. This is a critical security vulnerability that exposes "
                          "the device to credential theft.",
                severity="CRITICAL",
                recommendation="Disable Telnet and use SSH only",
                fix_commands=[
                    "set deviceconfig system service disable-telnet yes"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["SC-8", "AC-17", "IA-2(8)"],
                vendor=VendorType.PALOALTO_PANOS
            ))

        # Check NTP configuration
        ntp_servers = system.get('ntp-servers', [])
        if not ntp_servers:
            findings.append(self.create_finding(
                rule_id="PAN-MGT-003",
                title="NTP Server Not Configured",
                description="No NTP servers are configured. Without accurate time synchronization, log "
                          "correlation is impossible, certificate validation may fail, and time-based security "
                          "policies cannot be enforced. This severely impacts forensic investigations.",
                severity="HIGH",
                recommendation="Configure NTP servers",
                fix_commands=[
                    "set deviceconfig system ntp-servers primary-ntp-server ntp-server-address <ntp_server>",
                    "set deviceconfig system ntp-servers secondary-ntp-server ntp-server-address <ntp_server>"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AU-8", "AU-12"],
                vendor=VendorType.PALOALTO_PANOS
            ))

        return findings

    def _check_security_policies(self, config: Dict[str, Any]) -> List[Finding]:
        """Check security policy configuration."""
        findings = []

        # This would require parsing security policies from the config
        # For now, return basic checks
        devices = config.get('devices', {})
        vsys = devices.get('vsys', {})

        if not vsys:
            findings.append(self.create_finding(
                rule_id="PAN-POL-001",
                title="No Virtual Systems Configured",
                description="No virtual systems (vsys) are configured. Virtual systems are required to define "
                          "security policies, zones, and objects. Without vsys configuration, the firewall "
                          "cannot enforce security policies.",
                severity="HIGH",
                recommendation="Configure virtual system and security policies",
                fix_commands=[
                    "# Virtual systems are typically configured through the web UI",
                    "# Basic CLI commands:",
                    "set vsys vsys1 zone <zone_name>",
                    "set vsys vsys1 rulebase security rules <rule_name>"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["SC-7", "AC-4", "SC-2"],
                vendor=VendorType.PALOALTO_PANOS
            ))

        return findings

    def _check_vpn(self, config: Dict[str, Any]) -> List[Finding]:
        """Check VPN security configuration."""
        findings = []

        # VPN checks would go here
        # This would require parsing IKE gateways and IPsec tunnels

        return findings

    def _check_high_availability(self, config: Dict[str, Any]) -> List[Finding]:
        """Check high availability configuration."""
        findings = []

        ha_config = config.get('high_availability', {})

        if ha_config.get('enabled'):
            # Check for encryption
            if not ha_config.get('encryption'):
                findings.append(self.create_finding(
                    rule_id="PAN-HA-001",
                    title="High Availability Link Encryption Disabled",
                    description="High availability is enabled but link encryption is not configured. HA peers "
                              "exchange configuration, session, and state information over the HA links. Without "
                              "encryption, this sensitive data is transmitted in cleartext and can be intercepted.",
                    severity="HIGH",
                    recommendation="Enable HA link encryption",
                    fix_commands=[
                        "set deviceconfig high-availability interface ha1 encryption enabled yes",
                        "set deviceconfig high-availability interface ha2 encryption enabled yes"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="A",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="L",
                        availability="N"
                    ),
                    nist_controls=["SC-8", "SC-13"],
                    vendor=VendorType.PALOALTO_PANOS
                ))

            # Check for authentication
            if not ha_config.get('authentication'):
                findings.append(self.create_finding(
                    rule_id="PAN-HA-002",
                    title="High Availability Authentication Disabled",
                    description="High availability is enabled but authentication is not configured. Without "
                              "authentication, a rogue device can join the HA cluster, intercept traffic, steal "
                              "configurations, or cause a split-brain scenario leading to an outage.",
                    severity="CRITICAL",
                    recommendation="Enable HA authentication",
                    fix_commands=[
                        "set deviceconfig high-availability interface ha1 authentication enabled yes",
                        "set deviceconfig high-availability interface ha1 authentication password <strong_password>"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="A",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="H"
                    ),
                    nist_controls=["IA-3", "SC-23", "SC-8"],
                    vendor=VendorType.PALOALTO_PANOS
                ))

        return findings

    def _check_logging(self, config: Dict[str, Any]) -> List[Finding]:
        """Check logging configuration."""
        findings = []

        shared = config.get('shared', {})
        log_settings = shared.get('log_settings', {})

        if not log_settings.get('syslog') and not log_settings.get('profiles'):
            findings.append(self.create_finding(
                rule_id="PAN-LOG-001",
                title="No Syslog Servers Configured",
                description="No syslog servers are configured on the firewall. Without remote logging, "
                          "security events and audit logs exist only locally. If the device is compromised, "
                          "an attacker can delete logs to hide their activities. Remote logging to a secure "
                          "server is essential for forensic investigations.",
                severity="HIGH",
                recommendation="Configure remote syslog servers",
                fix_commands=[
                    "set shared log-settings syslog <profile_name> server <server_name> server <syslog_ip>",
                    "set shared log-settings syslog <profile_name> server <server_name> facility LOG_USER",
                    "set shared log-settings syslog <profile_name> server <server_name> format BSD",
                    "# Then apply to log forwarding profiles:",
                    "set shared log-settings syslog <profile_name>"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AU-2", "AU-3", "AU-4", "AU-9(2)"],
                vendor=VendorType.PALOALTO_PANOS
            ))

        return findings
