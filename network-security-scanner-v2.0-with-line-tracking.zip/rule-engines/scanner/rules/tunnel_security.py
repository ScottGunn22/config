"""Tunnel security rules for GRE and other tunneling protocols.

Detects insecure tunnel configurations, particularly GRE tunnels without
proper encryption and availability protections.
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class TunnelSecurityRules(BaseRuleEngine):
    """Security rules for tunnel interfaces (GRE, IPsec, etc.)."""

    def __init__(self):
        super().__init__()
        self.category = "Tunnel Security"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check tunnel security rules."""
        findings = []

        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._check_cisco_tunnels(parsed_config))

        return findings

    def _check_cisco_tunnels(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Cisco tunnel security."""
        findings = []

        # Check if we have detailed interface data from enhanced parser
        interfaces = config.get("interfaces_detailed", {})

        if not interfaces:
            # Fallback to basic parsing if enhanced data not available
            return self._check_tunnels_basic(config)

        for if_name, if_data in interfaces.items():
            # Only check tunnel interfaces
            tunnel_cfg = if_data.get('tunnel')
            if not tunnel_cfg:
                continue

            # Skip if interface is shutdown (not in use)
            if if_data.get('shutdown', False):
                continue

            # Check if this is a GRE tunnel
            tunnel_mode = tunnel_cfg.get('mode', '')
            is_gre = 'gre' in tunnel_mode.lower() if tunnel_mode else False

            if is_gre:
                # CRITICAL: GRE tunnel without IPsec protection
                has_protection = (
                    tunnel_cfg.get('protection') is not None or
                    tunnel_cfg.get('crypto_map') is not None
                )

                if not has_protection:
                    findings.append(self.create_finding(
                        rule_id="TUNNEL-001",
                        title=f"GRE Tunnel {if_name} Without IPsec Encryption",
                        description=f"GRE tunnel {if_name} is not protected with IPsec. GRE provides no encryption "
                                  f"by default, meaning all tunnel traffic (including routing protocols, management "
                                  f"traffic, and data) is transmitted in cleartext. Attackers can intercept, modify, "
                                  f"or inject traffic into the tunnel.",
                        severity="CRITICAL",
                        recommendation=f"Apply IPsec protection to GRE tunnel {if_name}",
                        fix_commands=[
                            "# Option 1: IPsec profile",
                            f"interface {if_name}",
                            " tunnel protection ipsec profile <PROFILE_NAME>",
                            "",
                            "# Option 2: Crypto map",
                            f"interface {if_name}",
                            " crypto map <MAP_NAME>"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="N",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H",
                            availability="L"
                        ),
                        nist_controls=["SC-8", "SC-13", "SC-7"],
                        vendor=VendorType.CISCO_IOS
                    ))

                # HIGH: Missing keepalives on GRE tunnel
                if not tunnel_cfg.get('keepalive', False):
                    findings.append(self.create_finding(
                        rule_id="TUNNEL-002",
                        title=f"GRE Tunnel {if_name} Missing Keepalives",
                        description=f"GRE tunnel {if_name} does not have keepalives configured. Without keepalives, "
                                  f"the tunnel interface will remain 'up' even if the remote endpoint is unreachable, "
                                  f"creating a black hole for traffic and causing an outage. Keepalives detect "
                                  f"tunnel failures and trigger routing protocol convergence.",
                        severity="HIGH",
                        recommendation=f"Configure keepalives on GRE tunnel {if_name}",
                        fix_commands=[
                            f"interface {if_name}",
                            " keepalive 10 3  ! Send keepalive every 10s, fail after 3 retries"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="L",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="N",
                            integrity="N",
                            availability="H"
                        ),
                        nist_controls=["SC-5", "SC-6"],
                        vendor=VendorType.CISCO_IOS
                    ))

                # MEDIUM: Missing tunnel key (authentication)
                if not tunnel_cfg.get('key'):
                    findings.append(self.create_finding(
                        rule_id="TUNNEL-003",
                        title=f"GRE Tunnel {if_name} Missing Tunnel Key",
                        description=f"GRE tunnel {if_name} does not have a tunnel key configured. The tunnel key "
                                  f"provides basic authentication between tunnel endpoints, preventing unauthorized "
                                  f"devices from injecting traffic into the tunnel. While not as strong as IPsec "
                                  f"authentication, it provides an additional layer of defense.",
                        severity="MEDIUM",
                        recommendation=f"Configure tunnel key on GRE tunnel {if_name}",
                        fix_commands=[
                            f"interface {if_name}",
                            " tunnel key <KEY_VALUE>  ! Same key on both endpoints"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="A",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="L",
                            integrity="L",
                            availability="N"
                        ),
                        nist_controls=["IA-3", "SC-8"],
                        vendor=VendorType.CISCO_IOS
                    ))

        return findings

    def _check_tunnels_basic(self, config: Dict[str, Any]) -> List[Finding]:
        """Fallback tunnel check using basic config_lines parsing."""
        findings = []
        config_lines = config.get("config_lines", [])

        current_interface = None
        tunnel_interfaces = {}  # Track tunnel interfaces and their config

        for line in config_lines:
            content = line.content.strip()

            # Track tunnel interfaces
            if content.startswith('interface Tunnel'):
                current_interface = content.split()[1]
                tunnel_interfaces[current_interface] = {
                    'mode': None,
                    'protection': False,
                    'crypto_map': False,
                    'keepalive': False,
                    'key': False,
                    'shutdown': False
                }

            # Tunnel configuration
            elif current_interface and current_interface in tunnel_interfaces:
                if content.startswith('tunnel mode'):
                    tunnel_interfaces[current_interface]['mode'] = content
                elif 'tunnel protection' in content or 'crypto map' in content:
                    tunnel_interfaces[current_interface]['protection'] = True
                    if 'crypto map' in content:
                        tunnel_interfaces[current_interface]['crypto_map'] = True
                elif content.startswith('keepalive'):
                    tunnel_interfaces[current_interface]['keepalive'] = True
                elif content.startswith('tunnel key'):
                    tunnel_interfaces[current_interface]['key'] = True
                elif content == 'shutdown':
                    tunnel_interfaces[current_interface]['shutdown'] = True

            # End of interface
            elif content.startswith('!') or (content and not content.startswith(' ')):
                current_interface = None

        # Generate findings for GRE tunnels without protection
        for if_name, tunnel_cfg in tunnel_interfaces.items():
            # Skip shutdown interfaces
            if tunnel_cfg['shutdown']:
                continue

            # Check if GRE
            mode = tunnel_cfg.get('mode', '')
            if mode and 'gre' in mode.lower():
                # Check for IPsec protection
                if not tunnel_cfg['protection']:
                    findings.append(self.create_finding(
                        rule_id="TUNNEL-001",
                        title=f"GRE Tunnel {if_name} Without IPsec Encryption",
                        description=f"GRE tunnel {if_name} is not protected with IPsec. All tunnel traffic is transmitted in cleartext.",
                        severity="CRITICAL",
                        recommendation=f"Apply IPsec protection to GRE tunnel {if_name}",
                        fix_commands=[
                            f"interface {if_name}",
                            " tunnel protection ipsec profile <PROFILE_NAME>"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="N",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H",
                            availability="L"
                        ),
                        nist_controls=["SC-8", "SC-13"],
                        vendor=VendorType.CISCO_IOS
                    ))

                # Check for keepalives
                if not tunnel_cfg['keepalive']:
                    findings.append(self.create_finding(
                        rule_id="TUNNEL-002",
                        title=f"GRE Tunnel {if_name} Missing Keepalives",
                        description=f"GRE tunnel {if_name} does not have keepalives configured.",
                        severity="HIGH",
                        recommendation=f"Configure keepalives on GRE tunnel {if_name}",
                        fix_commands=[
                            f"interface {if_name}",
                            " keepalive 10 3"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="L",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="N",
                            integrity="N",
                            availability="H"
                        ),
                        nist_controls=["SC-5"],
                        vendor=VendorType.CISCO_IOS
                    ))

        return findings
