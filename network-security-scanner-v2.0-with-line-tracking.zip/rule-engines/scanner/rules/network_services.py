"""Network services security rules."""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class NetworkServicesRules(BaseRuleEngine):
    """Security rules for network services configurations."""
    
    def __init__(self):
        super().__init__()
        self.category = "Network Services"
    
    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check network services security rules."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._check_cisco_services(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._check_juniper_services(parsed_config))
        
        return findings
    
    def _check_cisco_services(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Cisco IOS network services rules."""
        findings = []
        services = config.get("services", {})
        
        # Rule: HTTP without HTTPS
        if services.get("http", False) and not services.get("https", False):
            findings.append(self.create_finding(
                rule_id="NET-001",
                title="HTTP Server Enabled Without HTTPS",
                description="HTTP management interface enabled without HTTPS, leading to unencrypted traffic and credential exposure.",
                severity="MEDIUM",
                recommendation="Disable HTTP and enable HTTPS",
                fix_commands=["no ip http server", "ip http secure-server"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-8", "CM-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Both HTTP and HTTPS enabled
        elif services.get("http", False) and services.get("https", False):
            findings.append(self.create_finding(
                rule_id="NET-002",
                title="Both HTTP and HTTPS Servers Enabled",
                description="Both HTTP and HTTPS management interfaces are enabled. HTTP still presents a less secure option.",
                severity="LOW",
                recommendation="Disable HTTP server",
                fix_commands=["no ip http server"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["SC-8", "CM-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: CDP enabled globally
        if services.get("cdp", True):  # CDP is enabled by default
            findings.append(self.create_finding(
                rule_id="NET-003",
                title="CDP Enabled Globally",
                description="Cisco Discovery Protocol (CDP) is enabled globally, exposing network topology information.",
                severity="LOW",
                recommendation="Disable CDP globally",
                fix_commands=["no cdp run"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["SC-7", "CM-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Small servers enabled
        if services.get("tcp_small_servers", False) or services.get("udp_small_servers", False):
            enabled_services = []
            if services.get("tcp_small_servers", False):
                enabled_services.append("TCP")
            if services.get("udp_small_servers", False):
                enabled_services.append("UDP")
            
            findings.append(self.create_finding(
                rule_id="NET-004",
                title="Small Servers Enabled",
                description=f"{'/'.join(enabled_services)} small servers are enabled, providing unnecessary attack vectors (Chargen, Discard, Echo).",
                severity="MEDIUM",
                recommendation="Disable small servers",
                fix_commands=["no service tcp-small-servers", "no service udp-small-servers"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["CM-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: BOOTP server enabled
        if services.get("bootp", False):
            findings.append(self.create_finding(
                rule_id="NET-005",
                title="BOOTP Server Enabled", 
                description="BOOTP server is enabled, potentially allowing network reconnaissance or unauthorized configuration provisioning.",
                severity="MEDIUM",
                recommendation="Disable BOOTP server",
                fix_commands=["no ip bootp server"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["CM-7", "SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: IP source routing enabled
        if services.get("source_routing", True):  # Enabled by default
            findings.append(self.create_finding(
                rule_id="NET-006",
                title="IP Source Routing Enabled",
                description="IP source routing is enabled, which can be exploited to bypass network security controls.",
                severity="MEDIUM",
                recommendation="Disable IP source routing",
                fix_commands=["no ip source-route"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-7", "CM-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Domain lookups enabled (Nipper-style check)
        if services.get("domain_lookup", True):  # Enabled by default
            findings.append(self.create_finding(
                rule_id="NET-007",
                title="Domain Lookups Enabled",
                description="DNS lookups are enabled, which can broadcast DNS queries and expose network information. Mistyped commands may be interpreted as connection attempts.",
                severity="MEDIUM",
                recommendation="Disable domain lookups",
                fix_commands=["no ip domain-lookup"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["CM-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Classless routing enabled (Nipper-style check)
        routing = config.get("routing", {})
        if routing.get("classless", True):  # Enabled by default
            findings.append(self.create_finding(
                rule_id="NET-008",
                title="Classless Routing Enabled",
                description="Classless routing is enabled, which may route unintended network traffic when no specific route is defined.",
                severity="MEDIUM",
                recommendation="Disable classless routing",
                fix_commands=["no ip classless"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Rule: Check interface security features
        interfaces = config.get("interfaces", {})
        self._check_interface_security(interfaces, findings, VendorType.CISCO_IOS)
        
        # Rule: Check line configurations
        line_configs = config.get("line_configs", {})
        self._check_line_security(line_configs, findings, VendorType.CISCO_IOS)
        
        # Rule: Check NTP security
        ntp = config.get("ntp", {})
        self._check_ntp_security(ntp, findings, VendorType.CISCO_IOS)
        
        # Rule: Check SNMP security
        snmp = config.get("snmp", {})
        self._check_snmp_security(snmp, findings, VendorType.CISCO_IOS)
        
        return findings
    
    def _check_interface_security(self, interfaces: Dict[str, Any], findings: List[Finding], vendor: VendorType):
        """Check interface-specific security settings."""
        urpf_missing = []
        proxy_arp_enabled = []
        directed_broadcast_enabled = []
        
        for interface_name, interface_config in interfaces.items():
            # Skip shutdown interfaces
            if interface_config.get("status") == "shutdown":
                continue
            
            features = interface_config.get("features", {})
            
            # Check for missing uRPF
            if not features.get("urpf", False):
                urpf_missing.append(interface_name)
            
            # Check for enabled proxy ARP (enabled by default)
            if not features.get("proxy_arp_disabled", False):
                proxy_arp_enabled.append(interface_name)
            
            # Check for enabled directed broadcast (enabled by default)
            if not features.get("directed_broadcast_disabled", False):
                directed_broadcast_enabled.append(interface_name)
        
        # Generate findings for interface issues
        if urpf_missing:
            # Find first interface config line for context
            first_interface = next(iter(interfaces.values()))
            config_line = first_interface.get("config_lines", [None])[0]
            
            findings.append(self.create_finding(
                rule_id="NET-009",
                title="Unicast RPF Disabled",
                description=f"Unicast Reverse Path Forwarding (uRPF) is not enabled on active interface(s): {', '.join(urpf_missing)}. This makes the network vulnerable to IP spoofing attacks.",
                severity="HIGH",
                config_line=config_line,
                recommendation="Enable uRPF on interfaces",
                fix_commands=["ip verify unicast source reachable-via rx"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="H",
                    availability="N"
                ),
                nist_controls=["SC-7"],
                vendor=vendor
            ))
        
        if proxy_arp_enabled:
            first_interface = next(iter(interfaces.values()))
            config_line = first_interface.get("config_lines", [None])[0]
            
            findings.append(self.create_finding(
                rule_id="NET-010",
                title="Proxy ARP Enabled",
                description=f"Proxy ARP is enabled on active interface(s): {', '.join(proxy_arp_enabled)}. This can be exploited for man-in-the-middle attacks.",
                severity="LOW",
                config_line=config_line,
                recommendation="Disable proxy ARP on interfaces",
                fix_commands=["no ip proxy-arp"],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-7", "CM-7"],
                vendor=vendor
            ))
    
    def _check_line_security(self, line_configs: Dict[str, Any], findings: List[Finding], vendor: VendorType):
        """Check line configuration security."""
        insecure_lines = []
        timeout_issues = []
        missing_acl = []
        
        for line_name, line_config in line_configs.items():
            # Check transport protocols
            transport_input = line_config.get("transport", {}).get("input", [])
            if not transport_input or "telnet" in transport_input or "all" in transport_input:
                insecure_lines.append(line_name)
            
            # Check timeouts (should be <= 10 minutes = 600 seconds)
            exec_timeout = line_config.get("timeouts", {}).get("exec", 0)
            if exec_timeout == 0 or exec_timeout > 600:
                timeout_issues.append(f"{line_name} ({exec_timeout//60 if exec_timeout > 0 else 'no'} min)")
            
            # Check access control for VTY lines
            if "vty" in line_name.lower():
                access_control = line_config.get("access_control", {})
                if not access_control.get("in"):
                    missing_acl.append(line_name)
        
        # Generate findings
        if insecure_lines:
            first_line_config = next(iter(line_configs.values()))
            config_line = first_line_config.get("config_lines", [None])[0]
            
            findings.append(self.create_finding(
                rule_id="NET-011",
                title="Insecure Transport Protocol Enabled",
                description=f"Insecure transport methods (Telnet) are enabled on: {', '.join(insecure_lines)}. This exposes credentials to eavesdropping.",
                severity="HIGH",
                config_line=config_line,
                recommendation="Restrict to SSH only",
                fix_commands=["transport input ssh"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="L",
                    confidentiality="H",
                    integrity="H",
                    availability="N"
                ),
                nist_controls=["SC-8", "AC-17"],
                vendor=vendor
            ))
        
        if timeout_issues:
            first_line_config = next(iter(line_configs.values()))
            config_line = first_line_config.get("config_lines", [None])[0]
            
            findings.append(self.create_finding(
                rule_id="NET-012",
                title="Session Timeout Issues",
                description=f"Terminal session timeout is disabled or excessive on: {', '.join(timeout_issues)}. This increases unauthorized access risk.",
                severity="MEDIUM",
                config_line=config_line,
                recommendation="Set appropriate session timeout",
                fix_commands=["exec-timeout 10 0"],
                cvss_vector=CVSSVector(
                    attack_vector="P",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-12", "SC-10"],
                vendor=vendor
            ))
        
        if missing_acl:
            first_vty_config = None
            for line_name, line_config in line_configs.items():
                if "vty" in line_name.lower():
                    first_vty_config = line_config
                    break
            
            config_line = first_vty_config.get("config_lines", [None])[0] if first_vty_config else None
            
            findings.append(self.create_finding(
                rule_id="NET-013",
                title="Missing Inbound Management ACL on VTY Lines",
                description=f"No inbound access control found on VTY lines: {', '.join(missing_acl)}. This allows unrestricted management access.",
                severity="HIGH",
                config_line=config_line,
                recommendation="Apply access control to VTY lines",
                fix_commands=["access-class <ACL_NAME> in"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-4"],
                vendor=vendor
            ))
    
    def _check_ntp_security(self, ntp: Dict[str, Any], findings: List[Finding], vendor: VendorType):
        """Check NTP security configuration."""
        if ntp.get("enabled", False) and not ntp.get("authentication", False):
            # Find first NTP server line for context
            servers = ntp.get("servers", [])
            config_line = servers[0].get("line") if servers else None
            
            findings.append(self.create_finding(
                rule_id="NET-014",
                title="NTP Authentication Disabled",
                description="NTP server configured without authentication, making it vulnerable to time manipulation attacks.",
                severity="LOW",
                config_line=config_line,
                recommendation="Enable NTP authentication",
                fix_commands=["ntp authenticate", "ntp trusted-key 1"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-45"],
                vendor=vendor
            ))
    
    def _check_snmp_security(self, snmp: Dict[str, Any], findings: List[Finding], vendor: VendorType):
        """Check SNMP security configuration."""
        if not snmp.get("enabled", False):
            return
        
        # Check for write access communities
        communities = snmp.get("communities", [])
        for community in communities:
            if community.get("access") == "RW":
                findings.append(self.create_finding(
                    rule_id="NET-015",
                    title="SNMP Write Access Enabled",
                    description=f"SNMP community '{community.get('name')}' has write access, posing a significant security risk if compromised.",
                    severity="HIGH",
                    config_line=community.get("line"),
                    recommendation="Remove write access or use read-only communities",
                    fix_commands=[f"snmp-server community {community.get('name')} RO"],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="L"
                    ),
                    nist_controls=["AC-3", "CM-6"],
                    vendor=vendor
                ))
        
        # Check for trap hosts
        hosts = snmp.get("hosts", [])
        if not hosts:
            findings.append(self.create_finding(
                rule_id="NET-016",
                title="SNMP Trap Host Not Configured",
                description="No SNMP trap host is configured. SNMP traps are not being sent to a monitoring system.",
                severity="MEDIUM",
                recommendation="Configure SNMP trap host",
                fix_commands=["snmp-server host <IP_ADDRESS> traps <COMMUNITY>"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="N",
                    availability="L"
                ),
                nist_controls=["AU-3"],
                vendor=vendor
            ))
    
    def _check_juniper_services(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Juniper JUNOS network services rules."""
        findings = []
        system = config.get("system", {})
        services = system.get("services", {})
        
        # Rule: Telnet enabled
        if services.get("telnet", {}).get("enabled", False):
            telnet_config = services.get("telnet", {})
            config_line = telnet_config.get("config_lines", [None])[0]
            
            findings.append(self.create_finding(
                rule_id="NET-J001",
                title="Telnet Service Enabled",
                description="Telnet service is enabled, transmitting data in clear text and exposing credentials.",
                severity="HIGH",
                config_line=config_line,
                recommendation="Disable Telnet service",
                fix_commands=["delete system services telnet"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-8"],
                vendor=VendorType.JUNIPER_JUNOS
            ))
        
        return findings