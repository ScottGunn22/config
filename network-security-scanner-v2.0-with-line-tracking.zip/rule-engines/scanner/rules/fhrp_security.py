"""First Hop Redundancy Protocol (FHRP) security rules.

Detects misconfigurations in HSRP and VRRP that create security vulnerabilities.
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class FHRPSecurityRules(BaseRuleEngine):
    """Security rules for HSRP and VRRP configurations."""

    def __init__(self):
        super().__init__()
        self.category = "First-Hop Redundancy"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check FHRP security rules."""
        findings = []

        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._check_cisco_fhrp(parsed_config))

        return findings

    def _check_cisco_fhrp(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Cisco HSRP/VRRP security."""
        findings = []

        # Check if we have detailed interface data from enhanced parser
        interfaces = config.get("interfaces_detailed", {})

        if not interfaces:
            # Fallback to basic parsing if enhanced data not available
            return self._check_fhrp_basic(config)

        for if_name, if_data in interfaces.items():
            # Check HSRP groups
            hsrp_groups = if_data.get('hsrp', {})
            for group_num, hsrp in hsrp_groups.items():
                # CRITICAL: Check for missing authentication
                if not hsrp.get('authentication'):
                    findings.append(self.create_finding(
                        rule_id="FHRP-001",
                        title=f"HSRP Group {group_num} on {if_name} Missing Authentication",
                        description=f"HSRP group {group_num} on interface {if_name} does not have MD5 authentication configured. "
                                  f"This allows attackers to spoof HSRP hello messages and hijack the default gateway, "
                                  f"enabling man-in-the-middle attacks and traffic interception.",
                        severity="CRITICAL",
                        recommendation=f"Configure MD5 authentication on HSRP group {group_num}",
                        fix_commands=[
                            f"interface {if_name}",
                            f" standby {group_num} authentication md5 key-string <STRONG_KEY>"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="A",  # Adjacent network
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H",
                            availability="H"
                        ),
                        nist_controls=["SC-23", "SC-8", "IA-3"],
                        vendor=VendorType.CISCO_IOS
                    ))

                # MEDIUM: Check for missing interface tracking
                if not hsrp.get('track'):
                    # Only flag if this appears to be the active router (higher priority)
                    priority = hsrp.get('priority', 100)
                    if priority > 100:  # Higher than default = likely active router
                        findings.append(self.create_finding(
                            rule_id="FHRP-002",
                            title=f"HSRP Group {group_num} on {if_name} Missing Interface Tracking",
                            description=f"HSRP group {group_num} on interface {if_name} does not track any uplink interfaces. "
                                      f"If the upstream link fails, this router will remain active even though it cannot "
                                      f"route traffic, causing an outage. Interface tracking ensures automatic failover.",
                            severity="MEDIUM",
                            recommendation=f"Configure interface tracking to monitor uplink status",
                            fix_commands=[
                                f"interface {if_name}",
                                f" standby {group_num} track <UPLINK_INTERFACE> decrement 20"
                            ],
                            cvss_vector=CVSSVector(
                                attack_vector="L",
                                attack_complexity="L",
                                privileges_required="N",
                                confidentiality="N",
                                integrity="N",
                                availability="H"
                            ),
                            nist_controls=["SC-5", "SC-6"],
                            vendor=VendorType.CISCO_IOS
                        ))

            # Check VRRP groups
            vrrp_groups = if_data.get('vrrp', {})
            for group_num, vrrp in vrrp_groups.items():
                # CRITICAL: Check for missing authentication
                if not vrrp.get('authentication'):
                    findings.append(self.create_finding(
                        rule_id="FHRP-003",
                        title=f"VRRP Group {group_num} on {if_name} Missing Authentication",
                        description=f"VRRP group {group_num} on interface {if_name} does not have authentication configured. "
                                  f"This allows attackers to inject malicious VRRP advertisements and become the master router, "
                                  f"enabling traffic interception and man-in-the-middle attacks.",
                        severity="CRITICAL",
                        recommendation=f"Configure authentication on VRRP group {group_num}",
                        fix_commands=[
                            f"interface {if_name}",
                            f" vrrp {group_num} authentication md5 key-string <STRONG_KEY>"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="A",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H",
                            availability="H"
                        ),
                        nist_controls=["SC-23", "SC-8", "IA-3"],
                        vendor=VendorType.CISCO_IOS
                    ))

        return findings

    def _check_fhrp_basic(self, config: Dict[str, Any]) -> List[Finding]:
        """Fallback FHRP check using basic config_lines parsing."""
        findings = []
        config_lines = config.get("config_lines", [])

        current_interface = None
        hsrp_groups_on_interface = {}  # Track HSRP groups per interface
        hsrp_auth_on_interface = {}    # Track which groups have auth

        for line in config_lines:
            content = line.content.strip()

            # Track current interface
            if content.startswith('interface '):
                current_interface = content.split()[1]
                hsrp_groups_on_interface[current_interface] = set()
                hsrp_auth_on_interface[current_interface] = set()

            # Detect HSRP group
            elif content.startswith('standby ') and current_interface:
                parts = content.split()
                if len(parts) >= 2 and parts[1].isdigit():
                    group_num = parts[1]
                    hsrp_groups_on_interface[current_interface].add(group_num)

                    # Check if this line has authentication
                    if 'authentication' in content:
                        hsrp_auth_on_interface[current_interface].add(group_num)

            # End of interface
            elif content.startswith('!') or (content and not content.startswith(' ')):
                current_interface = None

        # Generate findings for groups without authentication
        for interface, groups in hsrp_groups_on_interface.items():
            authed_groups = hsrp_auth_on_interface.get(interface, set())
            for group in groups:
                if group not in authed_groups:
                    findings.append(self.create_finding(
                        rule_id="FHRP-001",
                        title=f"HSRP Group {group} on {interface} Missing Authentication",
                        description=f"HSRP group {group} on interface {interface} does not have MD5 authentication configured. "
                                  f"This allows attackers to spoof HSRP messages and hijack the default gateway.",
                        severity="CRITICAL",
                        recommendation=f"Configure MD5 authentication on HSRP group {group}",
                        fix_commands=[
                            f"interface {interface}",
                            f" standby {group} authentication md5 key-string <STRONG_KEY>"
                        ],
                        cvss_vector=CVSSVector(
                            attack_vector="A",
                            attack_complexity="L",
                            privileges_required="N",
                            confidentiality="H",
                            integrity="H",
                            availability="H"
                        ),
                        nist_controls=["SC-23", "SC-8", "IA-3"],
                        vendor=VendorType.CISCO_IOS
                    ))

        return findings
