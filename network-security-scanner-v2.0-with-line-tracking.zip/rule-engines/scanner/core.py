"""Core scanner components and data structures."""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, Tuple
from enum import Enum
import re
import json
from datetime import datetime
import uuid


class Severity(Enum):
    """Security finding severity levels."""
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class VendorType(Enum):
    """Supported network device vendors."""
    CISCO_IOS = "cisco_ios"
    CISCO_ASA = "cisco_asa"
    CISCO_NXOS = "cisco_nxos"
    JUNIPER_JUNOS = "juniper_junos"
    FORTINET_FORTIOS = "fortinet_fortios"
    PALOALTO_PANOS = "paloalto_panos"
    UNKNOWN = "unknown"


@dataclass
class ConfigLine:
    """Represents a single configuration line with context."""
    line_number: int
    content: str
    section: str = ""
    indentation: int = 0
    
    def __str__(self) -> str:
        return f"Line {self.line_number}: {self.content}"


@dataclass
class CVSSVector:
    """CVSS v3.1 vector components."""
    attack_vector: str = "N"  # Network, Adjacent, Local, Physical
    attack_complexity: str = "L"  # Low, High
    privileges_required: str = "N"  # None, Low, High
    user_interaction: str = "N"  # None, Required
    scope: str = "U"  # Unchanged, Changed
    confidentiality: str = "N"  # None, Low, High
    integrity: str = "N"  # None, Low, High
    availability: str = "N"  # None, Low, High
    
    def calculate_score(self) -> float:
        """Calculate CVSS v3.1 base score."""
        # Simplified CVSS calculation
        # In production, use proper CVSS library
        impact_scores = {"N": 0, "L": 0.22, "H": 0.56}
        exploitability_scores = {"N": 0.85, "L": 0.62, "H": 0.27}
        
        impact = (
            impact_scores[self.confidentiality] +
            impact_scores[self.integrity] +
            impact_scores[self.availability]
        )
        
        # Simplified exploitability calculation
        exploitability = 8.22  # Base value
        if self.attack_vector == "L":
            exploitability *= 0.55
        elif self.attack_vector == "P":
            exploitability *= 0.2
            
        if self.attack_complexity == "H":
            exploitability *= 0.44
            
        if self.privileges_required == "L":
            exploitability *= 0.62
        elif self.privileges_required == "H":
            exploitability *= 0.27
            
        if self.user_interaction == "R":
            exploitability *= 0.85
        
        # Simple base score calculation
        if impact <= 0:
            return 0.0
        
        base_score = min(10.0, (impact + exploitability) / 2)
        return round(base_score, 1)
    
    def to_vector_string(self) -> str:
        """Convert to CVSS vector string."""
        return (f"CVSS:3.1/AV:{self.attack_vector}/AC:{self.attack_complexity}/"
                f"PR:{self.privileges_required}/UI:{self.user_interaction}/"
                f"S:{self.scope}/C:{self.confidentiality}/I:{self.integrity}/"
                f"A:{self.availability}")


@dataclass
class Finding:
    """Represents a security finding."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    title: str = ""
    description: str = ""
    category: str = ""
    severity: Severity = Severity.INFO
    
    # Configuration context
    config_line: Optional[ConfigLine] = None
    affected_lines: List[ConfigLine] = field(default_factory=list)
    
    # Risk assessment
    cvss_vector: CVSSVector = field(default_factory=CVSSVector)
    cvss_score: float = 0.0
    
    # Remediation
    recommendation: str = ""
    fix_commands: List[str] = field(default_factory=list)
    
    # Compliance
    nist_controls: List[str] = field(default_factory=list)
    cis_controls: List[str] = field(default_factory=list)
    
    # Metadata
    vendor: VendorType = VendorType.UNKNOWN
    rule_id: str = ""
    confidence: float = 1.0
    false_positive_risk: str = "LOW"
    
    def __post_init__(self):
        """Calculate CVSS score after initialization."""
        if self.cvss_score == 0.0:
            self.cvss_score = self.cvss_vector.calculate_score()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert finding to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "category": self.category,
            "severity": self.severity.value,
            "config_line": {
                "line_number": self.config_line.line_number if self.config_line else 0,
                "content": self.config_line.content if self.config_line else "Not configured",
                "section": self.config_line.section if self.config_line else ""
            },
            "affected_lines": [
                {
                    "line_number": line.line_number,
                    "content": line.content,
                    "section": line.section
                } for line in self.affected_lines
            ],
            "cvss_vector": self.cvss_vector.to_vector_string(),
            "cvss_score": self.cvss_score,
            "recommendation": self.recommendation,
            "fix_commands": self.fix_commands,
            "nist_controls": self.nist_controls,
            "cis_controls": self.cis_controls,
            "vendor": self.vendor.value,
            "rule_id": self.rule_id,
            "confidence": self.confidence,
            "false_positive_risk": self.false_positive_risk
        }


@dataclass
class ScanResults:
    """Container for scan results."""
    findings: List[Finding] = field(default_factory=list)
    vendor: VendorType = VendorType.UNKNOWN
    device_hostname: str = ""
    scan_timestamp: datetime = field(default_factory=datetime.now)
    config_lines_total: int = 0
    rules_executed: int = 0
    scan_duration_ms: int = 0
    
    def get_summary(self) -> Dict[str, Any]:
        """Get scan results summary."""
        severity_counts = {}
        for severity in Severity:
            severity_counts[severity.value] = len([
                f for f in self.findings if f.severity == severity
            ])
        
        return {
            "total_findings": len(self.findings),
            "severity_breakdown": severity_counts,
            "highest_cvss": max([f.cvss_score for f in self.findings], default=0.0),
            "vendor": self.vendor.value,
            "device_hostname": self.device_hostname,
            "scan_timestamp": self.scan_timestamp.isoformat(),
            "config_lines_total": self.config_lines_total,
            "rules_executed": self.rules_executed,
            "scan_duration_ms": self.scan_duration_ms
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert results to dictionary for JSON serialization."""
        return {
            "summary": self.get_summary(),
            "findings": [finding.to_dict() for finding in self.findings]
        }


class SecurityScanner:
    """Main security scanner engine."""
    
    def __init__(self):
        self.vendor_parsers = {}
        self.rule_engines = {}
        self._register_default_components()
    
    def _register_default_components(self):
        """Register default vendor parsers and rule engines."""
        # Import and register vendor parsers
        from .vendors.cisco import CiscoParser
        from .vendors.juniper import JuniperParser
        
        self.vendor_parsers[VendorType.CISCO_IOS] = CiscoParser()
        self.vendor_parsers[VendorType.JUNIPER_JUNOS] = JuniperParser()
        
        # Import and register rule engines
        from .rules.authentication import AuthenticationRules
        from .rules.network_services import NetworkServicesRules
        from .rules.logging import LoggingRules
        from .rules.comprehensive_security import ComprehensiveSecurityRules
        
        self.rule_engines["authentication"] = AuthenticationRules()
        self.rule_engines["network_services"] = NetworkServicesRules()
        self.rule_engines["logging"] = LoggingRules()
        self.rule_engines["comprehensive"] = ComprehensiveSecurityRules()
    
    def scan_config(self, config_content: str, vendor: Optional[VendorType] = None) -> ScanResults:
        """Scan a network device configuration."""
        start_time = datetime.now()
        
        # Parse configuration
        if vendor is None:
            vendor = self._detect_vendor(config_content)
        
        parser = self.vendor_parsers.get(vendor)
        if not parser:
            raise ValueError(f"Unsupported vendor: {vendor}")
        
        parsed_config = parser.parse_config(config_content)
        
        # Run security rules
        findings = []
        rules_executed = 0
        
        for rule_engine in self.rule_engines.values():
            engine_findings = rule_engine.check_config(parsed_config, vendor)
            findings.extend(engine_findings)
            rules_executed += len(engine_findings)
        
        # Calculate scan duration
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        
        # Create results
        results = ScanResults(
            findings=findings,
            vendor=vendor,
            device_hostname=parsed_config.get("hostname", "Unknown"),
            scan_timestamp=start_time,
            config_lines_total=len(parsed_config.get("config_lines", [])),
            rules_executed=rules_executed,
            scan_duration_ms=duration_ms
        )
        
        return results
    
    def _detect_vendor(self, config_content: str) -> VendorType:
        """Automatically detect the vendor from configuration content."""
        config_lower = config_content.lower()
        
        # Cisco indicators
        cisco_indicators = [
            "cisco ios", "version ", "hostname ", "interface gigabitethernet",
            "ip route", "router ospf", "access-list", "line vty", "enable secret"
        ]
        
        # Juniper indicators
        juniper_indicators = [
            "set system", "set interfaces", "set protocols", "set security",
            "junos", "commit", "edit", "show configuration"
        ]
        
        cisco_count = sum(1 for indicator in cisco_indicators if indicator in config_lower)
        juniper_count = sum(1 for indicator in juniper_indicators if indicator in config_lower)
        
        if cisco_count > juniper_count:
            return VendorType.CISCO_IOS
        elif juniper_count > 0:
            return VendorType.JUNIPER_JUNOS
        else:
            return VendorType.UNKNOWN