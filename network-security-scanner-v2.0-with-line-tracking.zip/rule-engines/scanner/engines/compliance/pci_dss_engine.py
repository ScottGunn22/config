"""PCI DSS Compliance Analysis Engine."""

import re
from typing import List, Dict, Any, Optional
from ..base_engine import ComplianceEngine, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector
from ..utils import safe_get_content, create_mock_config_line


class PCIDSSComplianceEngine(ComplianceEngine):
    """PCI DSS (Payment Card Industry Data Security Standard) compliance analysis engine."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 20
    
    def get_framework_name(self) -> str:
        return "PCI DSS"
    
    def get_framework_version(self) -> str:
        return "3.2.1"
    
    def check_compliance_requirements(self, parsed_config: Dict[str, Any], 
                                    vendor: VendorType) -> List[Finding]:
        """Check PCI DSS compliance requirements."""
        return self.analyze_configuration(parsed_config, vendor)
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.HIGH
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS, VendorType.JUNIPER_JUNOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze configuration for PCI DSS compliance."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_pci_dss(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._analyze_juniper_pci_dss(parsed_config))
        
        return findings
    
    def _analyze_cisco_pci_dss(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco configuration for PCI DSS compliance."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Extract relevant configuration
        pci_config = self._extract_pci_relevant_config(config_lines)
        
        # PCI DSS Requirements Analysis
        findings.extend(self._check_req_2_network_security(pci_config))  # Requirement 2
        findings.extend(self._check_req_4_encryption(pci_config))        # Requirement 4
        findings.extend(self._check_req_8_access_control(pci_config))    # Requirement 8
        findings.extend(self._check_req_10_logging(pci_config))          # Requirement 10
        findings.extend(self._check_req_11_security_testing(pci_config)) # Requirement 11
        
        return findings
    
    def _extract_pci_relevant_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract PCI DSS relevant configuration elements."""
        pci_config = {
            "default_passwords": [],
            "encryption_config": [],
            "access_controls": [],
            "logging_config": [],
            "snmp_config": [],
            "ssh_config": [],
            "banner_config": [],
            "timeout_config": [],
            "acl_config": []
        }
        
        for line in config_lines:
            content = safe_get_content(line)
            if not hasattr(line, 'content'):
                line = create_mock_config_line(content)
            
            # Default passwords (PCI DSS 2.1)
            default_password_patterns = [
                "password cisco", "password admin", "password password",
                "community public", "community private"
            ]
            
            for pattern in default_password_patterns:
                if pattern in content.lower():
                    pci_config["default_passwords"].append({
                        "config_line": line,
                        "pattern": pattern,
                        "command": content
                    })
            
            # Encryption configuration (PCI DSS 4)
            if any(keyword in content.lower() for keyword in ["ssh", "ssl", "tls", "crypto", "encrypt"]):
                pci_config["encryption_config"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Access controls (PCI DSS 8)
            if any(keyword in content for keyword in ["username", "aaa", "login", "privilege"]):
                pci_config["access_controls"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Logging configuration (PCI DSS 10)
            if any(keyword in content for keyword in ["logging", "log", "archive"]):
                pci_config["logging_config"].append({
                    "config_line": line,
                    "command": content
                })
            
            # SNMP configuration
            if "snmp-server" in content:
                pci_config["snmp_config"].append({
                    "config_line": line,
                    "command": content
                })
            
            # SSH configuration
            if content.startswith("ip ssh"):
                pci_config["ssh_config"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Banner configuration
            if "banner" in content:
                pci_config["banner_config"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Timeout configuration
            if "timeout" in content or "exec-timeout" in content:
                pci_config["timeout_config"].append({
                    "config_line": line,
                    "command": content
                })
            
            # ACL configuration
            if content.startswith("access-list") or content.startswith("ip access-list"):
                pci_config["acl_config"].append({
                    "config_line": line,
                    "command": content
                })
        
        return pci_config
    
    def _check_req_2_network_security(self, pci_config: Dict) -> List[Finding]:
        """Check PCI DSS Requirement 2: Do not use vendor-supplied defaults."""
        findings = []
        
        # 2.1 - Always change vendor-supplied defaults
        default_passwords = pci_config.get("default_passwords", [])
        if default_passwords:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-2.1",
                title="PCI DSS 2.1: Vendor Default Passwords Detected",
                description=f"Default passwords detected: {', '.join(set(p['pattern'] for p in default_passwords))}. "
                           f"PCI DSS requires changing all vendor-supplied defaults.",
                severity=Severity.CRITICAL,
                category="PCI DSS Compliance",
                config_line=default_passwords[0]["config_line"],
                recommendation="Change all default passwords and community strings",
                fix_commands=["enable secret <STRONG_PASSWORD>", "snmp-server community <UNIQUE_COMMUNITY> RO 99"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # 2.2 - Configuration standards for system components
        snmp_configs = pci_config.get("snmp_config", [])
        insecure_snmp = []
        for snmp in snmp_configs:
            if any(community in snmp["command"].lower() for community in ["public", "private"]):
                insecure_snmp.append(snmp)
        
        if insecure_snmp:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-2.2",
                title="PCI DSS 2.2: Insecure System Configuration",
                description="Default SNMP community strings detected. This violates PCI DSS configuration hardening requirements.",
                severity=Severity.HIGH,
                category="PCI DSS Compliance",
                config_line=insecure_snmp[0]["config_line"],
                recommendation="Remove or secure SNMP configuration per PCI DSS guidelines",
                fix_commands=["no snmp-server community public", "snmp-server community <SECURE_STRING> RO 99"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["CM-6", "SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_req_4_encryption(self, pci_config: Dict) -> List[Finding]:
        """Check PCI DSS Requirement 4: Encrypt transmission of cardholder data."""
        findings = []
        
        encryption_configs = pci_config.get("encryption_config", [])
        ssh_configs = pci_config.get("ssh_config", [])
        
        # 4.1 - Use strong cryptography and security protocols
        has_ssh_v2 = any("version 2" in ssh["command"] for ssh in ssh_configs)
        has_ssh_config = len(ssh_configs) > 0
        
        if not has_ssh_v2 and has_ssh_config:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-4.1",
                title="PCI DSS 4.1: Weak Cryptographic Protocols",
                description="SSH version not explicitly set to version 2. PCI DSS requires strong cryptography for cardholder data transmission.",
                severity=Severity.HIGH,
                category="PCI DSS Compliance",
                config_line=ssh_configs[0]["config_line"] if ssh_configs else None,
                recommendation="Configure SSH version 2 and disable weaker protocols",
                fix_commands=["ip ssh version 2"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="N"
                ),
                nist_controls=["SC-8", "SC-13"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for insecure protocols that might carry cardholder data
        insecure_protocols = []
        for config in encryption_configs:
            if any(protocol in config["command"].lower() for protocol in ["telnet", "ftp", "http", "snmp"]):
                insecure_protocols.append(config)
        
        if insecure_protocols:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-4.2",
                title="PCI DSS 4.2: Unencrypted Transmission Protocols",
                description="Insecure protocols detected that may transmit cardholder data without encryption.",
                severity=Severity.CRITICAL,
                category="PCI DSS Compliance",
                config_line=insecure_protocols[0]["config_line"],
                recommendation="Disable insecure protocols and use encrypted alternatives",
                fix_commands=["no ip http server", "transport input ssh"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-8"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_req_8_access_control(self, pci_config: Dict) -> List[Finding]:
        """Check PCI DSS Requirement 8: Identify and authenticate access."""
        findings = []
        
        access_controls = pci_config.get("access_controls", [])
        
        # 8.1 - Define and implement policies for proper user identification
        has_aaa = any("aaa new-model" in ac["command"] for ac in access_controls)
        
        if not has_aaa:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-8.1",
                title="PCI DSS 8.1: Inadequate Access Control Framework",
                description="AAA (Authentication, Authorization, Accounting) not configured. "
                           "PCI DSS requires proper user identification and authentication.",
                severity=Severity.HIGH,
                category="PCI DSS Compliance",
                recommendation="Implement AAA framework for proper access control",
                fix_commands=["aaa new-model", "aaa authentication login default group tacacs+ local"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["IA-2", "AC-2"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # 8.3 - Secure authentication for individual access
        timeout_configs = pci_config.get("timeout_config", [])
        has_proper_timeout = any("exec-timeout" in tc["command"] for tc in timeout_configs)
        
        if not has_proper_timeout:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-8.3",
                title="PCI DSS 8.3: Session Timeout Not Configured",
                description="Session timeouts not properly configured. PCI DSS requires automatic session termination.",
                severity=Severity.MEDIUM,
                category="PCI DSS Compliance",
                recommendation="Configure appropriate session timeouts",
                fix_commands=["line vty 0 4", " exec-timeout 10 0"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="L",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-12"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_req_10_logging(self, pci_config: Dict) -> List[Finding]:
        """Check PCI DSS Requirement 10: Track and monitor all access."""
        findings = []
        
        logging_configs = pci_config.get("logging_config", [])
        
        # 10.2 - Implement automated audit trails
        has_logging_enabled = len(logging_configs) > 0
        
        if not has_logging_enabled:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-10.2",
                title="PCI DSS 10.2: Insufficient Audit Logging",
                description="Insufficient logging configuration detected. PCI DSS requires comprehensive audit trails.",
                severity=Severity.HIGH,
                category="PCI DSS Compliance",
                recommendation="Configure comprehensive logging per PCI DSS requirements",
                fix_commands=[
                    "logging buffered 16384",
                    "logging trap informational",
                    "logging <SYSLOG_SERVER>"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AU-2", "AU-3", "AU-12"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_req_11_security_testing(self, pci_config: Dict) -> List[Finding]:
        """Check PCI DSS Requirement 11: Regularly test security systems."""
        findings = []
        
        # This is more of a procedural requirement, but we can check for security configurations
        acl_configs = pci_config.get("acl_config", [])
        
        # 11.1 - Implement processes to test for and detect wireless access points
        # This would typically be detected through network scanning, not config analysis
        
        # 11.2 - Run internal and external network vulnerability scans
        # We can flag if there are no ACLs configured (poor network segmentation)
        if not acl_configs:
            findings.append(self.create_finding(
                rule_id="PCI-DSS-11.2",
                title="PCI DSS 11.2: Insufficient Network Security Controls",
                description="No access control lists detected. PCI DSS requires network segmentation and security testing.",
                severity=Severity.MEDIUM,
                category="PCI DSS Compliance",
                recommendation="Implement network ACLs for proper segmentation and security testing",
                fix_commands=[
                    "access-list 100 permit tcp <AUTHORIZED_NETWORKS> any eq 22",
                    "access-list 100 deny ip any any log"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-7", "CA-2"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _analyze_juniper_pci_dss(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Juniper configuration for PCI DSS compliance (placeholder)."""
        # TODO: Implement Juniper PCI DSS analysis
        return []