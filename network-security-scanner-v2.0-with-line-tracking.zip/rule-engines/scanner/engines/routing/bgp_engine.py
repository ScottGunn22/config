"""BGP Security Analysis Engine."""

import re
from typing import List, Dict, Any
from ..base_engine import ProtocolSecurityEngine, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector


class BGPSecurityEngine(ProtocolSecurityEngine):
    """Comprehensive BGP security analysis engine."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 15
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS, VendorType.JUNIPER_JUNOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze BGP configuration for security issues."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_bgp(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._analyze_juniper_bgp(parsed_config))
        
        return findings
    
    def _analyze_cisco_bgp(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco BGP configuration."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Extract BGP configuration
        bgp_config = self._extract_bgp_config(config_lines)
        
        if not bgp_config:
            return findings  # No BGP configured
        
        # Run BGP security checks
        findings.extend(self.check_authentication(bgp_config))
        findings.extend(self.check_filtering(bgp_config))
        findings.extend(self.check_hardening(bgp_config))
        
        return findings
    
    def _extract_bgp_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract BGP configuration from config lines."""
        bgp_config = {
            "router_bgp": None,
            "neighbors": [],
            "networks": [],
            "route_maps": [],
            "prefix_lists": [],
            "as_path_lists": [],
            "bgp_section_lines": []
        }
        
        in_bgp_section = False
        current_neighbor = None
        
        for line in config_lines:
            # Handle both ConfigLine objects and strings
            if hasattr(line, 'content'):
                content = line.content.strip()
            else:
                content = str(line).strip()
                # Create a mock line object for compatibility
                class MockLine:
                    def __init__(self, content):
                        self.content = content
                        self.line_number = 0
                        self.section = ""
                line = MockLine(content)
            
            # Start of BGP section
            if re.match(r'router bgp (\d+)', content):
                in_bgp_section = True
                match = re.match(r'router bgp (\d+)', content)
                bgp_config["router_bgp"] = {
                    "as_number": match.group(1),
                    "config_line": line
                }
                bgp_config["bgp_section_lines"].append(line)
                continue
            
            # End of BGP section (next router or interface command)
            if in_bgp_section and (content.startswith('router ') or 
                                 content.startswith('interface ') or
                                 content.startswith('line ')) and not content.startswith('router bgp'):
                in_bgp_section = False
                current_neighbor = None
                continue
            
            if in_bgp_section:
                bgp_config["bgp_section_lines"].append(line)
                
                # BGP neighbor configuration
                neighbor_match = re.match(r'neighbor ([\d.]+|[\w:]+) (.+)', content)
                if neighbor_match:
                    neighbor_ip = neighbor_match.group(1)
                    neighbor_cmd = neighbor_match.group(2)
                    
                    # Find or create neighbor entry
                    neighbor = next((n for n in bgp_config["neighbors"] if n["ip"] == neighbor_ip), None)
                    if not neighbor:
                        neighbor = {
                            "ip": neighbor_ip,
                            "remote_as": None,
                            "password": None,
                            "update_source": None,
                            "route_map_in": None,
                            "route_map_out": None,
                            "prefix_list_in": None,
                            "prefix_list_out": None,
                            "maximum_prefix": None,
                            "ttl_security": False,
                            "config_lines": []
                        }
                        bgp_config["neighbors"].append(neighbor)
                    
                    neighbor["config_lines"].append(line)
                    
                    # Parse neighbor commands
                    if neighbor_cmd.startswith('remote-as'):
                        neighbor["remote_as"] = neighbor_cmd.split()[1]
                    elif neighbor_cmd.startswith('password'):
                        neighbor["password"] = neighbor_cmd
                    elif neighbor_cmd.startswith('update-source'):
                        neighbor["update_source"] = neighbor_cmd.split()[1]
                    elif neighbor_cmd.startswith('route-map') and 'in' in neighbor_cmd:
                        neighbor["route_map_in"] = neighbor_cmd.split()[1]
                    elif neighbor_cmd.startswith('route-map') and 'out' in neighbor_cmd:
                        neighbor["route_map_out"] = neighbor_cmd.split()[1]
                    elif neighbor_cmd.startswith('prefix-list') and 'in' in neighbor_cmd:
                        neighbor["prefix_list_in"] = neighbor_cmd.split()[1]
                    elif neighbor_cmd.startswith('prefix-list') and 'out' in neighbor_cmd:
                        neighbor["prefix_list_out"] = neighbor_cmd.split()[1]
                    elif neighbor_cmd.startswith('maximum-prefix'):
                        neighbor["maximum_prefix"] = neighbor_cmd
                    elif 'ttl-security' in neighbor_cmd:
                        neighbor["ttl_security"] = True
                
                # BGP networks
                if content.startswith('network '):
                    bgp_config["networks"].append({
                        "network": content,
                        "config_line": line
                    })
        
        return bgp_config
    
    def check_authentication(self, bgp_config: Dict) -> List[Finding]:
        """Check BGP neighbor authentication."""
        findings = []
        
        if not bgp_config.get("neighbors"):
            return findings
        
        # Check for neighbors without authentication
        unauthenticated_neighbors = []
        weak_auth_neighbors = []
        
        for neighbor in bgp_config["neighbors"]:
            neighbor_ip = neighbor["ip"]
            password = neighbor.get("password")
            
            if not password:
                unauthenticated_neighbors.append(neighbor)
            elif "password 7" in password or "password 0" in password:
                # Type 7 or clear text password
                weak_auth_neighbors.append(neighbor)
        
        # Report unauthenticated neighbors
        if unauthenticated_neighbors:
            neighbor_ips = [n["ip"] for n in unauthenticated_neighbors]
            first_neighbor = unauthenticated_neighbors[0]
            
            findings.append(self.create_finding(
                rule_id="BGP-001",
                title="BGP Neighbors Without Authentication",
                description=f"BGP neighbors without MD5 authentication: {', '.join(neighbor_ips)}. "
                           f"Unauthenticated BGP sessions are vulnerable to route injection attacks.",
                severity=Severity.HIGH,
                category="BGP Security",
                config_line=first_neighbor["config_lines"][0] if first_neighbor["config_lines"] else None,
                recommendation="Configure MD5 authentication for all BGP neighbors",
                fix_commands=[f"neighbor {neighbor_ips[0]} password <MD5_PASSWORD>"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L", 
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["SC-45", "AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Report weak authentication
        if weak_auth_neighbors:
            neighbor_ips = [n["ip"] for n in weak_auth_neighbors]
            first_neighbor = weak_auth_neighbors[0]
            
            findings.append(self.create_finding(
                rule_id="BGP-002", 
                title="BGP Neighbors with Weak Authentication",
                description=f"BGP neighbors with weak authentication: {', '.join(neighbor_ips)}. "
                           f"Type 7 passwords can be easily reversed.",
                severity=Severity.MEDIUM,
                category="BGP Security",
                config_line=first_neighbor["config_lines"][0] if first_neighbor["config_lines"] else None,
                recommendation="Use strong MD5 passwords for BGP authentication",
                fix_commands=[f"neighbor {neighbor_ips[0]} password <STRONG_MD5_PASSWORD>"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="L", 
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["IA-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def check_filtering(self, bgp_config: Dict) -> List[Finding]:
        """Check BGP route filtering configuration."""
        findings = []
        
        if not bgp_config.get("neighbors"):
            return findings
        
        # Check for neighbors without input/output filtering
        unfiltered_neighbors = []
        
        for neighbor in bgp_config["neighbors"]:
            neighbor_ip = neighbor["ip"]
            has_input_filter = (neighbor.get("route_map_in") or 
                              neighbor.get("prefix_list_in"))
            has_output_filter = (neighbor.get("route_map_out") or
                               neighbor.get("prefix_list_out"))
            
            if not has_input_filter or not has_output_filter:
                unfiltered_neighbors.append({
                    "neighbor": neighbor,
                    "missing_input": not has_input_filter,
                    "missing_output": not has_output_filter
                })
        
        if unfiltered_neighbors:
            neighbor_list = [n["neighbor"]["ip"] for n in unfiltered_neighbors]
            first_neighbor = unfiltered_neighbors[0]["neighbor"]
            
            findings.append(self.create_finding(
                rule_id="BGP-003",
                title="BGP Neighbors Without Route Filtering",
                description=f"BGP neighbors without proper route filtering: {', '.join(neighbor_list)}. "
                           f"Unfiltered BGP sessions can accept/advertise unintended routes.",
                severity=Severity.HIGH,
                category="BGP Security",
                config_line=first_neighbor["config_lines"][0] if first_neighbor["config_lines"] else None,
                recommendation="Configure route-maps or prefix-lists for BGP neighbor filtering",
                fix_commands=[
                    f"neighbor {neighbor_list[0]} route-map BGP-IN in",
                    f"neighbor {neighbor_list[0]} route-map BGP-OUT out"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["SC-7", "AC-4"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def check_hardening(self, bgp_config: Dict) -> List[Finding]:
        """Check BGP hardening measures."""
        findings = []
        
        if not bgp_config.get("router_bgp"):
            return findings
        
        bgp_section_lines = bgp_config["bgp_section_lines"]
        
        # Check for BGP logging
        has_bgp_logging = any(
            "bgp log-neighbor-changes" in line.content
            for line in bgp_section_lines
        )
        
        if not has_bgp_logging:
            findings.append(self.create_finding(
                rule_id="BGP-004",
                title="BGP Neighbor Logging Disabled",
                description="BGP neighbor state changes are not logged, reducing visibility into routing changes.",
                severity=Severity.MEDIUM,
                category="BGP Security", 
                config_line=bgp_config["router_bgp"]["config_line"],
                recommendation="Enable BGP neighbor change logging",
                fix_commands=["bgp log-neighbor-changes"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="L", 
                    availability="N"
                ),
                nist_controls=["AU-3", "AU-12"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for maximum prefix limits
        neighbors_without_max_prefix = []
        for neighbor in bgp_config.get("neighbors", []):
            if not neighbor.get("maximum_prefix"):
                neighbors_without_max_prefix.append(neighbor["ip"])
        
        if neighbors_without_max_prefix:
            findings.append(self.create_finding(
                rule_id="BGP-005",
                title="BGP Neighbors Without Maximum Prefix Limits",
                description=f"BGP neighbors without maximum prefix limits: {', '.join(neighbors_without_max_prefix)}. "
                           f"Could lead to memory exhaustion attacks.",
                severity=Severity.MEDIUM,
                category="BGP Security",
                recommendation="Configure maximum prefix limits for BGP neighbors",
                fix_commands=[f"neighbor {neighbors_without_max_prefix[0]} maximum-prefix 100000"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N",
                    integrity="N",
                    availability="H"
                ),
                nist_controls=["SC-5"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for TTL security
        neighbors_without_ttl_security = []
        for neighbor in bgp_config.get("neighbors", []):
            if not neighbor.get("ttl_security"):
                neighbors_without_ttl_security.append(neighbor["ip"])
        
        if neighbors_without_ttl_security:
            findings.append(self.create_finding(
                rule_id="BGP-006",
                title="BGP Neighbors Without TTL Security",
                description=f"BGP neighbors without TTL security (GTSM): {', '.join(neighbors_without_ttl_security)}. "
                           f"Vulnerable to remote attacks and session hijacking.",
                severity=Severity.LOW,
                category="BGP Security",
                recommendation="Configure TTL security for directly connected BGP neighbors",
                fix_commands=[f"neighbor {neighbors_without_ttl_security[0]} ttl-security hops 1"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="H",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _analyze_juniper_bgp(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Juniper BGP configuration (placeholder)."""
        # TODO: Implement Juniper BGP analysis
        return []