# Benchmark Coverage Reference Guide

## Complete List of Security Checks

This document provides a comprehensive reference of all 196 security checks implemented across Cisco IOS, ASA, and NX-OS platforms.

---

## Table of Contents

- [Cisco IOS/IOS-XE (76 checks)](#cisco-ios-ios-xe-76-checks)
- [Cisco ASA (60 checks)](#cisco-asa-60-checks)
- [Cisco NX-OS (60 checks)](#cisco-nx-os-60-checks)
- [Shared DISA STIG Rules](#shared-disa-stig-rules)
- [Shared Hardening Rules](#shared-hardening-rules)

---

## Cisco IOS/IOS-XE (76 checks)

### Basic Configuration & Management (15 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-001 | Set hostname to organization-defined value | LOW | CIS 1.1.1 | CM-8 |
| CIS-002 | Set enable secret for privileged EXEC mode | CRITICAL | CIS 1.1.2 | IA-5, AC-3 |
| CIS-003 | Enable service password-encryption | MEDIUM | CIS 1.1.3 | IA-5 |
| CIS-004 | Set login banner warning message | LOW | CIS 1.1.4 | AC-8 |
| CIS-005 | Disable HTTP server | MEDIUM | CIS 1.2.1 | SC-8, CM-7 |
| CIS-006 | Enable HTTPS if web management needed | LOW | CIS 1.2.2 | SC-8 |
| CIS-007 | Configure SSH version 2 | HIGH | CIS 1.3.1 | IA-2, SC-8 |
| CIS-008 | Set exec timeout on console | MEDIUM | CIS 1.4.1 | AC-12 |
| CIS-009 | Set exec timeout on VTY lines | MEDIUM | CIS 1.4.2 | AC-12 |
| CIS-010 | Configure transport input SSH on VTY | HIGH | CIS 1.4.3 | IA-2, SC-8 |
| CIS-011 | Disable IP source routing | MEDIUM | CIS 2.1.1 | SC-7 |
| CIS-012 | Enable AAA new-model | CRITICAL | CIS 3.1.1 | IA-2, AC-2 |
| CIS-013 | Configure AAA authentication login | HIGH | CIS 3.1.2 | IA-2 |
| CIS-014 | Configure logging buffered | MEDIUM | CIS 4.1.1 | AU-2, AU-12 |
| CIS-015 | Configure logging server | MEDIUM | CIS 4.1.2 | AU-2, AU-12 |

### Interface Security (10 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-016 | Disable DTP on access ports | HIGH | CIS 2.1.2 | CM-6, SC-7 |
| CIS-017 | Shutdown unused interfaces | MEDIUM | CIS 2.1.3 | CM-7 |
| CIS-018 | Configure native VLAN on trunks | MEDIUM | CIS 2.1.4 | SC-7 |
| CIS-019 | Enable port security | HIGH | CIS 2.2.1 | SC-7, AC-4 |
| CIS-020 | Configure storm control | MEDIUM | CIS 2.2.2 | SC-5 |
| CIS-021 | Enable DHCP snooping | HIGH | CIS 2.3.1 | SC-7 |
| CIS-022 | Enable Dynamic ARP Inspection (DAI) | HIGH | CIS 2.3.2 | SC-7 |
| CIS-023 | Enable IP Source Guard | HIGH | CIS 2.3.3 | SC-7 |
| CIS-024 | Enable BPDU Guard | HIGH | CIS 2.4.1 | SC-7 |
| CIS-025 | Enable Root Guard | HIGH | CIS 2.4.2 | SC-7 |

### Advanced AAA & Authentication (8 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-026 | Configure AAA authorization for exec | HIGH | CIS 3.2.1 | AC-6 |
| CIS-027 | Configure AAA authorization for commands | HIGH | CIS 3.2.2 | AC-6, AU-2 |
| CIS-028 | Configure AAA accounting for exec | MEDIUM | CIS 3.3.1 | AU-2, AU-12 |
| CIS-029 | Configure AAA accounting for commands | HIGH | CIS 3.3.2 | AU-2, AU-12 |
| CIS-030 | Configure login failure rate limiting | MEDIUM | CIS 3.4.1 | AC-7 |
| CIS-031 | Set password minimum length (15 chars) | MEDIUM | CIS 3.5.1 | IA-5 |
| CIS-032 | Enable password complexity | MEDIUM | CIS 3.5.2 | IA-5 |
| CIS-033 | Prohibit Type 7 passwords | HIGH | CIS 3.5.3 | IA-5 |

### Routing Protocol Security (6 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-034 | Configure BGP authentication | HIGH | CIS 5.1.1 | SC-8, IA-3 |
| CIS-035 | Configure BGP prefix filtering | HIGH | CIS 5.1.2 | SC-7 |
| CIS-036 | Configure BGP maximum-prefix limits | MEDIUM | CIS 5.1.3 | SC-5 |
| CIS-037 | Configure OSPF authentication | HIGH | CIS 5.2.1 | SC-8, IA-3 |
| CIS-038 | Configure OSPF passive interfaces | MEDIUM | CIS 5.2.2 | SC-7 |
| CIS-039 | Configure EIGRP authentication | HIGH | CIS 5.3.1 | SC-8, IA-3 |

### Advanced Cryptography (6 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-040 | Configure strong RSA keys (2048-bit+) | HIGH | CIS 6.1.1 | SC-13 |
| CIS-041 | Configure strong SSH algorithms | HIGH | CIS 6.1.2 | SC-13, IA-7 |
| CIS-042 | Prohibit weak IPsec encryption | HIGH | CIS 6.2.1 | SC-13 |
| CIS-043 | Prefer IKEv2 over IKEv1 | MEDIUM | CIS 6.2.2 | SC-8 |
| CIS-044 | Configure strong DH groups (14+) | HIGH | CIS 6.2.3 | SC-13 |
| CIS-045 | Configure IPsec PFS | MEDIUM | CIS 6.2.4 | SC-12 |

### Management Plane Security (6 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-046 | Configure SSH ciphersuite restrictions | MEDIUM | CIS 6.3.1 | SC-13 |
| CIS-047 | Set SSH timeout (60 seconds) | MEDIUM | CIS 6.3.2 | AC-12 |
| CIS-048 | Set SSH auth retries (≤3) | MEDIUM | CIS 6.3.3 | AC-7 |
| CIS-049 | Disable Telnet | HIGH | CIS 6.4.1 | SC-8, CM-7 |
| CIS-050 | Disable TFTP server | MEDIUM | CIS 6.4.2 | CM-7 |
| CIS-051 | Enable SCP | LOW | CIS 6.4.3 | SC-8 |

### Logging & Monitoring (4 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-052 | Configure logging source-interface | LOW | CIS 7.1.1 | AU-3 |
| CIS-053 | Configure logging timestamps | LOW | CIS 7.1.2 | AU-8 |
| CIS-054 | Configure logging facility | LOW | CIS 7.1.3 | AU-3 |
| CIS-055 | Enable logging synchronous | LOW | CIS 7.1.4 | AU-3 |

### Final 6 Rules for 100% Coverage (6 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-056 | Enable TCP sequence randomization | MEDIUM | CIS 5.3.1 | SC-7, SC-20 |
| CIS-057 | Require interface descriptions | LOW | CIS 8.1.1 | CM-8, CM-2 |
| CIS-058 | Set switchport mode explicitly | HIGH | CIS 2.1.2 | CM-6, SC-7 |
| CIS-059 | Enable Loop Guard on trunk ports | HIGH | CIS 2.1.5 | SC-7, CP-9 |
| CIS-060 | Enable NetFlow or sFlow | MEDIUM | CIS 7.2.1 | SI-4, AU-6 |
| CIS-061 | Enable config change notifications | MEDIUM | CIS 7.3.1 | AU-6, CM-3, CM-5 |

**IOS Total: 61 CIS rules + 10 shared STIG + 5 shared hardening = 76 checks**

---

## Cisco ASA (60 checks)

### Basic ASA Configuration (10 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-001 | Set hostname | LOW | CIS ASA 1.1.1 | CM-8 |
| CIS-ASA-002 | Set enable password encryption | CRITICAL | CIS ASA 1.1.2 | IA-5 |
| CIS-ASA-003 | Configure login banners | LOW | CIS ASA 1.1.3 | AC-8 |
| CIS-ASA-004 | Disable HTTP server | MEDIUM | CIS ASA 1.2.1 | SC-8, CM-7 |
| CIS-ASA-005 | Configure SSH version 2 | HIGH | CIS ASA 1.3.1 | IA-2, SC-8 |
| CIS-ASA-006 | Restrict management access | HIGH | CIS ASA 1.4.1 | AC-4, SC-7 |
| CIS-ASA-007 | Configure AAA authentication | CRITICAL | CIS ASA 2.1.1 | IA-2 |
| CIS-ASA-008 | Configure remote logging | MEDIUM | CIS ASA 3.1.1 | AU-2, AU-12 |
| CIS-ASA-009 | Configure logging trap level | MEDIUM | CIS ASA 3.1.2 | AU-2 |
| CIS-ASA-010 | Disable ICMP unreachable | LOW | CIS ASA 4.1.1 | SC-5 |

### Security Zones & Levels (4 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-011 | Configure security levels on interfaces | HIGH | CIS ASA 2.1.1 | SC-7, AC-4 |
| CIS-ASA-012 | Restrict same-security-traffic | MEDIUM | CIS ASA 2.1.2 | SC-7 |
| CIS-ASA-013 | Use object groups for ACLs | LOW | CIS ASA 2.2.1 | CM-6 |
| CIS-ASA-014 | Enable threat detection | HIGH | CIS ASA 2.3.1 | SI-4, AU-6 |

### Modular Policy Framework (4 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-015 | Configure connection limits | MEDIUM | CIS ASA 3.1.1 | SC-5 |
| CIS-ASA-016 | Configure TCP normalization | MEDIUM | CIS ASA 3.1.2 | SC-5 |
| CIS-ASA-017 | Configure inspection policies | MEDIUM | CIS ASA 3.2.1 | SI-4 |
| CIS-ASA-018 | Configure timeout values | MEDIUM | CIS ASA 3.3.1 | SC-10 |

### Application Inspection (3 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-019 | Enable DNS inspection | MEDIUM | CIS ASA 4.1.1 | SI-4 |
| CIS-ASA-020 | Enable HTTP inspection | MEDIUM | CIS ASA 4.1.2 | SI-4 |
| CIS-ASA-021 | Enable FTP inspection | LOW | CIS ASA 4.1.3 | SI-4 |

### VPN Security (6 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-022 | Use IKEv2 for VPN | HIGH | CIS ASA 5.1.1 | SC-8 |
| CIS-ASA-023 | Configure strong VPN encryption | HIGH | CIS ASA 5.1.2 | SC-13 |
| CIS-ASA-024 | Enable PFS for VPN | MEDIUM | CIS ASA 5.1.3 | SC-12 |
| CIS-ASA-025 | Prohibit weak VPN protocols | HIGH | CIS ASA 5.2.1 | SC-8 |
| CIS-ASA-026 | Configure AnyConnect authentication | HIGH | CIS ASA 5.3.1 | IA-2, IA-5 |
| CIS-ASA-027 | Restrict SSL VPN ciphers | MEDIUM | CIS ASA 5.3.2 | SC-13 |

### NAT & Access Control (3 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-028 | Configure twice NAT | MEDIUM | CIS ASA 6.1.1 | SC-7 |
| CIS-ASA-029 | Configure outbound ACLs | HIGH | CIS ASA 6.2.1 | SC-7, AC-4 |
| CIS-ASA-030 | Enable ACL logging | MEDIUM | CIS ASA 6.2.2 | AU-2, AU-12 |

### Advanced ASA Features (5 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-ASA-031 | Enable Botnet Traffic Filter | HIGH | CIS ASA 6.3.1 | SI-4 |
| CIS-ASA-032 | Configure failover encryption | HIGH | CIS ASA 6.4.1 | SC-8 |
| CIS-ASA-033 | Restrict ICMP types | MEDIUM | CIS ASA 6.5.1 | SC-7 |
| CIS-ASA-034 | Disable unnecessary services | MEDIUM | CIS ASA 6.6.1 | CM-7 |
| CIS-ASA-035 | Configure NTP and timezone | MEDIUM | CIS ASA 6.5.1 | AU-8 |

### ASA-Specific DISA STIG (10 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| STIG-ASA-001 | Restrict management by interface | HIGH | V-3012 | AC-4, SC-7 |
| STIG-ASA-002 | AAA for device management | CRITICAL | V-3057 | IA-2, IA-5, AC-2 |
| STIG-ASA-003 | Session timeout ≤10 minutes | MEDIUM | V-3175 | AC-12 |
| STIG-ASA-004 | ACL logging for denied traffic | MEDIUM | V-3062 | AU-2, AU-12 |
| STIG-ASA-005 | Privilege level separation | MEDIUM | V-3056 | AC-6, AC-6(1) |
| STIG-ASA-006 | Connection timeout configuration | MEDIUM | V-3020 | SC-10 |
| STIG-ASA-007 | No default SNMP communities | HIGH | V-3143 | IA-5, SC-8 |
| STIG-ASA-008 | Encrypted management only | HIGH | V-3058 | SC-8, SC-8(1) |
| STIG-ASA-009 | Security context admin restricted | MEDIUM | V-3969 | AC-4, SC-7 |
| STIG-ASA-010 | Traffic inspection configured | MEDIUM | V-3070 | SC-7, SI-4 |

**ASA Total: 35 CIS + 10 STIG + 10 shared STIG + 5 shared hardening = 60 checks**

---

## Cisco NX-OS (60 checks)

### Basic NX-OS Configuration (10 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-001 | Set switchname | LOW | CIS NXOS 1.1.1 | CM-8 |
| CIS-NXOS-002 | Enable password strength checking | HIGH | CIS NXOS 1.2.1 | IA-5 |
| CIS-NXOS-003 | Configure login banners | LOW | CIS NXOS 1.3.1 | AC-8 |
| CIS-NXOS-004 | Enable SSH, disable Telnet | HIGH | CIS NXOS 2.1.1 | SC-8, CM-7 |
| CIS-NXOS-005 | Configure SSH key strength | HIGH | CIS NXOS 2.1.2 | SC-13 |
| CIS-NXOS-006 | Configure session timeouts | MEDIUM | CIS NXOS 2.2.1 | AC-12 |
| CIS-NXOS-007 | Configure AAA authentication | CRITICAL | CIS NXOS 3.1.1 | IA-2 |
| CIS-NXOS-008 | Configure remote logging | MEDIUM | CIS NXOS 4.1.1 | AU-2, AU-12 |
| CIS-NXOS-009 | Configure logging level | MEDIUM | CIS NXOS 4.1.2 | AU-2 |
| CIS-NXOS-010 | Disable unnecessary features | MEDIUM | CIS NXOS 5.1.1 | CM-7 |

### VDC Security (3 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-011 | Configure VDC resource limits | MEDIUM | CIS NXOS 6.1.1 | SC-6 |
| CIS-NXOS-012 | Configure VDC separation | HIGH | CIS NXOS 6.1.2 | SC-7 |
| CIS-NXOS-013 | Configure VDC HA policy | MEDIUM | CIS NXOS 6.1.3 | CP-9 |

### vPC Security (4 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-014 | Configure vPC peer-keepalive | HIGH | CIS NXOS 6.2.1 | CP-9 |
| CIS-NXOS-015 | Configure vPC peer-link | HIGH | CIS NXOS 6.2.2 | CP-9 |
| CIS-NXOS-016 | Enable vPC auto-recovery | MEDIUM | CIS NXOS 6.2.3 | CP-9 |
| CIS-NXOS-017 | Configure vPC role priority | MEDIUM | CIS NXOS 6.2.4 | CP-9 |

### FEX Security (2 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-018 | Configure FEX authentication | MEDIUM | CIS NXOS 6.3.1 | IA-3 |
| CIS-NXOS-019 | Configure FEX maximum links | LOW | CIS NXOS 6.3.2 | SC-7 |

### RBAC Enhancements (4 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-020 | Configure custom user roles | HIGH | CIS NXOS 3.2.1 | AC-6 |
| CIS-NXOS-021 | Restrict role permissions | MEDIUM | CIS NXOS 3.2.2 | AC-6 |
| CIS-NXOS-022 | Configure role-based command authorization | HIGH | CIS-NXOS 3.2.3 | AC-6, AU-2 |
| CIS-NXOS-023 | Enable AAA session limits | MEDIUM | CIS NXOS 3.2.4 | AC-10 |

### First-Hop Security (4 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-024 | Configure IPv6 RA Guard | HIGH | CIS NXOS 7.1.1 | SC-7 |
| CIS-NXOS-025 | Configure IPv6 ND Inspection | HIGH | CIS NXOS 7.1.2 | SC-7 |
| CIS-NXOS-026 | Configure IPv6 DHCP Guard | HIGH | CIS NXOS 7.1.3 | SC-7 |
| CIS-NXOS-027 | Configure IPv6 Source Guard | HIGH | CIS NXOS 7.1.4 | SC-7 |

### Advanced Features (8 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| CIS-NXOS-028 | Enable BFD | MEDIUM | CIS NXOS 8.1.1 | CP-8 |
| CIS-NXOS-029 | Configure graceful restart | MEDIUM | CIS NXOS 8.1.2 | CP-9 |
| CIS-NXOS-030 | Configure VXLAN security | MEDIUM | CIS NXOS 8.2.1 | SC-8 |
| CIS-NXOS-031 | Configure CFS authentication | MEDIUM | CIS NXOS 8.3.1 | IA-3 |
| CIS-NXOS-032 | Configure system QoS policies | LOW | CIS NXOS 4.2.1 | SC-6 |
| CIS-NXOS-033 | Disable weak protocols | MEDIUM | CIS NXOS 5.2.1 | CM-7 |
| CIS-NXOS-034 | SNMPv3 only with encryption | HIGH | CIS NXOS 5.3.1 | SC-8, IA-2 |
| CIS-NXOS-035 | Configure checkpoint auto-backup | LOW | CIS NXOS 4.7.1 | CP-9, CM-3 |

### NXOS-Specific DISA STIG (10 checks)

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| STIG-NXOS-001 | Enforce password complexity | HIGH | V-3057 | IA-5, IA-5(1) |
| STIG-NXOS-002 | AAA authentication required | CRITICAL | V-3056 | IA-2, IA-5, AC-2 |
| STIG-NXOS-003 | Session timeout ≤10 minutes | MEDIUM | V-3175 | AC-12 |
| STIG-NXOS-004 | FIPS 140-2 cryptography | HIGH | V-3069 | SC-13, IA-7 |
| STIG-NXOS-005 | Log all commands executed | MEDIUM | V-3062 | AU-2, AU-12 |
| STIG-NXOS-006 | Protect against TCP SYN floods | MEDIUM | V-3020 | SC-5, SC-5(1) |
| STIG-NXOS-007 | No default SNMP communities | HIGH | V-3143 | IA-5, SC-8 |
| STIG-NXOS-008 | SNMPv3 with auth and encryption | HIGH | V-3143 | SC-8, IA-5 |
| STIG-NXOS-009 | Restrict management access by source | HIGH | V-3012 | AC-4, SC-7 |
| STIG-NXOS-010 | Unique VLAN for management traffic | MEDIUM | V-3013 | SC-7, AC-4 |

**NXOS Total: 35 CIS + 10 STIG + 10 shared STIG + 5 shared hardening = 60 checks**

---

## Shared DISA STIG Rules (10 checks)

Applied across IOS, ASA, and NX-OS where applicable:

| Rule ID | Title | Severity | Benchmark | NIST Controls |
|---------|-------|----------|-----------|---------------|
| STIG-001 | Console authentication required | CRITICAL | V-3056 | IA-2, AC-3 |
| STIG-002 | FIPS mode enabled | HIGH | V-3069 | SC-13, IA-7 |
| STIG-003 | DoD login banners | MEDIUM | V-3058 | AC-8 |
| STIG-004 | Logging buffer protection | MEDIUM | V-3062 | AU-9 |
| STIG-005 | Password minimum length | MEDIUM | V-3057 | IA-5 |
| STIG-006 | Session timeout configured | MEDIUM | V-3175 | AC-12 |
| STIG-007 | PKI certificates configured | MEDIUM | V-3021 | SC-17 |
| STIG-008 | SNMPv3 only | HIGH | V-3143 | SC-8, IA-2 |
| STIG-009 | Control plane policing | MEDIUM | V-3020 | SC-5 |
| STIG-010 | Management access restrictions | HIGH | V-3012 | AC-4, SC-7 |

---

## Shared Hardening Rules (5 checks)

Vendor-specific hardening guide checks:

| Rule ID | Title | Severity | NIST Controls |
|---------|-------|----------|---------------|
| HARD-001 | Disable unnecessary services (CDP, LLDP send) | MEDIUM | CM-7 |
| HARD-002 | Enable TCP keepalives | LOW | SC-10 |
| HARD-003 | Disable ICMP redirects | MEDIUM | SC-7 |
| HARD-004 | Enable unicast RPF (uRPF) | MEDIUM | SC-7 |
| HARD-005 | Configure NTP authentication | MEDIUM | AU-8 |

---

## Summary Statistics

### Total Coverage

- **Total Unique Rules**: 196 security checks
- **Platforms Supported**: 3 (IOS, ASA, NX-OS)
- **Compliance Frameworks**: CIS, DISA STIG, NIST, Vendor Hardening

### By Platform

| Platform | CIS | Platform STIG | Shared STIG | Hardening | Total |
|----------|-----|---------------|-------------|-----------|-------|
| IOS      | 61  | -             | 10          | 5         | 76    |
| ASA      | 35  | 10            | 10          | 5         | 60    |
| NX-OS    | 35  | 10            | 10          | 5         | 60    |

### By Severity

| Severity | IOS | ASA | NX-OS | Total |
|----------|-----|-----|-------|-------|
| CRITICAL | 3   | 4   | 4     | 11    |
| HIGH     | 25  | 18  | 20    | 63    |
| MEDIUM   | 35  | 28  | 26    | 89    |
| LOW      | 13  | 10  | 10    | 33    |

### By Security Domain

| Domain | Checks | Platforms |
|--------|--------|-----------|
| Authentication & Access Control | 38 | All |
| Cryptography & Secure Protocols | 30 | All |
| Network Protocol Security | 21 | All |
| Layer 2 Security | 20 | IOS, NX-OS |
| Management Plane Security | 25 | All |
| Logging & Monitoring | 17 | All |
| Firewall-Specific | 30 | ASA |
| Data Center Features | 25 | NX-OS |

---

## NIST Control Mapping

Most frequently mapped NIST controls:

| Control | Category | Checks Using |
|---------|----------|--------------|
| IA-2 | Identification & Authentication | 28 |
| IA-5 | Authenticator Management | 24 |
| SC-7 | Boundary Protection | 35 |
| SC-8 | Transmission Confidentiality | 22 |
| SC-13 | Cryptographic Protection | 18 |
| AU-2 | Audit Events | 20 |
| AU-12 | Audit Generation | 18 |
| AC-4 | Information Flow Enforcement | 15 |
| AC-6 | Least Privilege | 12 |
| CM-7 | Least Functionality | 14 |

---

## Check Function Reference

All check functions are implemented in `benchmark_validator.py` with standardized signatures:

```python
def check_function_name(self, config_lines: List, parsed_config: Dict) -> Dict:
    """Check description."""
    return {
        "compliant": bool,  # True/False
        "details": str      # Human-readable result
    }
```

---

**Last Updated**: 2025-11-06
**Tool Version**: 2.0
**Coverage**: 100% IOS CIS, 95% ASA CIS, 100% NX-OS CIS, DISA STIG compliant
