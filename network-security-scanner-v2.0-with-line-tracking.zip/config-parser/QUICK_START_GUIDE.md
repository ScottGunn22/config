# Quick Start Guide

Get up and running with the Network Security Configuration Scanner in 5 minutes.

---

## Installation (30 seconds)

### Requirements

- Python 3.7+
- No external dependencies required!

### Setup

```bash
# Extract the package
cd config-parser

# Verify it works
python3 enterprise_security_parser.py --help
```

That's it! The tool is ready to use.

---

## Your First Scan (2 minutes)

### Step 1: Get a Configuration File

Export your device configuration:

**Cisco IOS/IOS-XE:**
```
show running-config
```

**Cisco ASA:**
```
show running-config
```

**Cisco NX-OS:**
```
show running-config
```

Save the output to a text file (e.g., `router_config.txt`)

### Step 2: Run the Scan

```bash
python3 enterprise_security_parser.py router_config.txt --output report.html
```

### Step 3: View Results

Open `report.html` in your web browser.

You'll see:
- ✅ **Compliance Score**: Overall security posture
- 🔴 **Critical Findings**: Issues requiring immediate attention
- 📊 **Findings by Severity**: Organized list of all issues
- 🔧 **Fix Commands**: Exact CLI commands to remediate

---

## Common Use Cases

### Scan Multiple Devices

```bash
# Create reports directory
mkdir reports

# Scan all configs
for config in configs/*.txt; do
    filename=$(basename "$config" .txt)
    python3 enterprise_security_parser.py "$config" \
        --output "reports/${filename}_report.html"
done
```

### Generate JSON for Automation

```bash
python3 enterprise_security_parser.py config.txt \
    --output findings.json \
    --format json
```

### Filter Critical Issues Only

```bash
python3 enterprise_security_parser.py config.txt \
    --output report.html \
    --min-severity CRITICAL
```

### Scan Different Platforms

```bash
# Cisco IOS Router
python3 enterprise_security_parser.py ios_config.txt --output ios_report.html

# Cisco ASA Firewall
python3 enterprise_security_parser.py asa_config.txt --output asa_report.html

# Cisco NX-OS Switch
python3 enterprise_security_parser.py nxos_config.txt --output nxos_report.html
```

---

## Understanding Your Report

### Severity Levels

| Icon | Severity | Meaning | Action Timeline |
|------|----------|---------|-----------------|
| 🔴 | **CRITICAL** | Exploitable vulnerability | Fix immediately |
| 🟠 | **HIGH** | Significant security risk | Fix within 24-48 hours |
| 🟡 | **MEDIUM** | Security weakness | Fix within 1-2 weeks |
| 🟢 | **LOW** | Best practice deviation | Fix during maintenance |

### Compliance Score

```
Compliance Score: 67%
├── Compliant: 51 checks
└── Non-compliant: 25 checks
```

**Score Ranges:**
- 90-100%: Excellent
- 70-89%: Good
- 50-69%: Needs improvement
- Below 50%: Critical attention required

### Typical First Scan Results

**First scan of unaudited device:**
- 30-50 findings typical
- 3-8 critical issues
- Most common: weak passwords, insecure protocols, missing authentication

**Well-maintained device:**
- 10-20 findings
- 0-2 critical issues
- Mostly low-severity best practice items

---

## Quick Remediation Workflow

### 1. Prioritize by Severity

Start with CRITICAL findings, work down to LOW.

### 2. Review Fix Commands

Each finding includes exact CLI commands:

```
Fix Commands:
  enable secret MyStr0ngP@ssw0rd!
  service password-encryption
```

### 3. Test in Lab (Recommended)

```bash
# Copy fix commands to test device
# Verify functionality
# Check for breaking changes
```

### 4. Apply to Production

During maintenance window:
1. Take configuration backup
2. Apply fix commands
3. Verify connectivity
4. Re-scan to confirm fix

### 5. Verify Fix

```bash
python3 enterprise_security_parser.py config.txt --output after_fix.html
```

Compare before/after compliance scores.

---

## Command-Line Reference

### Basic Syntax

```bash
python3 enterprise_security_parser.py <config_file> [OPTIONS]
```

### Essential Options

| Option | Description | Example |
|--------|-------------|---------|
| `--output`, `-o` | Output file path | `-o report.html` |
| `--format` | Output format (html/json) | `--format json` |
| `--platform` | Force platform type | `--platform ios` |
| `--min-severity` | Filter by severity | `--min-severity HIGH` |
| `--verbose`, `-v` | Enable debug output | `-v` |

### Examples

```bash
# HTML report (default)
python3 enterprise_security_parser.py config.txt -o report.html

# JSON output
python3 enterprise_security_parser.py config.txt -o findings.json --format json

# Specify platform manually
python3 enterprise_security_parser.py config.txt -o report.html --platform asa

# Show only critical and high
python3 enterprise_security_parser.py config.txt -o report.html --min-severity HIGH

# Debug mode
python3 enterprise_security_parser.py config.txt -o report.html --verbose
```

---

## Troubleshooting

### ❌ "Platform detection failed"

**Solution:** Specify platform manually

```bash
python3 enterprise_security_parser.py config.txt --output report.html --platform ios
```

Valid platforms: `ios`, `asa`, `nxos`

### ❌ "No findings generated"

**Possible causes:**
1. Config file is empty → Check file content
2. All checks passed → Congratulations!
3. Platform mismatch → Specify `--platform`

**Debug:**
```bash
python3 enterprise_security_parser.py config.txt -o report.html --verbose
```

### ❌ "Permission denied"

**Solution:** Check file permissions

```bash
chmod 644 config.txt
python3 enterprise_security_parser.py config.txt -o report.html
```

### ⚠️ "Genie parser not installed"

**This is just a warning, not an error!**

The tool works fine without Genie (uses regex parsing).

**Optional:** Install Genie for enhanced parsing:
```bash
pip install genie pyats
```

---

## What Gets Checked?

### All Platforms

✅ Authentication (AAA, passwords, banners)
✅ SSH security (version 2, strong algorithms)
✅ SNMP security (SNMPv3 only)
✅ Logging configuration
✅ Management plane security
✅ NTP configuration

### Cisco IOS/IOS-XE (76 checks)

✅ Layer 2 security (DTP, BPDU Guard, DAI, DHCP snooping)
✅ Routing protocol security (BGP, OSPF, EIGRP authentication)
✅ IPsec/VPN security
✅ Interface security
✅ **100% CIS Benchmark coverage**

### Cisco ASA (60 checks)

✅ Firewall security levels
✅ Stateful inspection policies
✅ VPN configuration (IKEv2, strong encryption)
✅ Threat detection
✅ Application inspection
✅ **95% CIS Benchmark coverage**

### Cisco NX-OS (60 checks)

✅ VDC (Virtual Device Context) security
✅ vPC configuration
✅ First-hop security (IPv6 RA Guard, ND Inspection)
✅ RBAC configuration
✅ Data center features
✅ **100% CIS Benchmark coverage**

See `BENCHMARK_COVERAGE_REFERENCE.md` for complete list of all 196 checks.

---

## Integration Examples

### CI/CD Pipeline

```bash
#!/bin/bash
# Fail build if critical findings exist

python3 enterprise_security_parser.py config.txt \
    --output findings.json \
    --format json

CRITICAL=$(jq '.summary.critical' findings.json)

if [ "$CRITICAL" -gt 0 ]; then
    echo "FAIL: $CRITICAL critical findings"
    exit 1
fi

echo "PASS: No critical findings"
```

### Scheduled Scanning (Cron)

```cron
# Run daily at 2 AM
0 2 * * * cd /opt/scanner && python3 enterprise_security_parser.py \
    /configs/router.txt --output /reports/daily_$(date +\%Y\%m\%d).html
```

### Ansible Playbook

```yaml
- name: Security scan
  command: >
    python3 /opt/scanner/enterprise_security_parser.py
    {{ config_path }}
    --output {{ output_path }}
  register: scan_result

- name: Check for critical findings
  fail:
    msg: "Critical security findings detected"
  when: '"Critical: 0" not in scan_result.stdout'
```

---

## Performance

**Scan Times:**
- Small config (<500 lines): 2-3 seconds
- Medium config (500-2000 lines): 5-8 seconds
- Large config (2000-5000 lines): 10-15 seconds
- Very large (5000+ lines): 15-25 seconds

**Memory Usage:** 50-100 MB

**CPU:** Single-threaded, minimal usage

---

## Next Steps

### Daily Usage

1. **Baseline Scan**: Run on all devices, document current state
2. **Regular Scans**: Weekly automated scans
3. **Change Validation**: Scan before/after configuration changes
4. **Audit Prep**: Generate reports for compliance audits

### Advanced Features

See main documentation for:
- JSON API integration
- Custom check development
- Batch processing scripts
- Report customization

### Getting Help

📖 **Full Documentation**: See `README.md`
📊 **All Checks**: See `BENCHMARK_COVERAGE_REFERENCE.md`
🔍 **Coverage Gaps**: See `COVERAGE_GAPS.md`

---

## Success Checklist

After your first scan:

- [ ] Config file scanned successfully
- [ ] HTML report generated
- [ ] Compliance score reviewed
- [ ] Critical findings identified
- [ ] Fix commands reviewed
- [ ] Remediation plan created
- [ ] Findings prioritized by severity

---

## Example Output

```
╔════════════════════════════════════════════════════════╗
║   Network Security Configuration Scanner v2.0          ║
╚════════════════════════════════════════════════════════╝

Parsing configuration: router_config.txt
✓ Platform detected: Cisco IOS
✓ Lines parsed: 1,247
✓ Running 76 security checks...

Security Analysis Complete:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Compliance Score: 67.1% (51/76 checks passed)

Findings by Severity:
  🔴 Critical: 3
  🟠 High: 8
  🟡 Medium: 12
  🟢 Low: 2

Top Issues:
  🔴 CIS-002: Enable secret not configured
  🔴 CIS-012: AAA new-model not enabled
  🔴 STIG-001: Console authentication missing
  🟠 CIS-007: SSH version 1 allowed
  🟠 CIS-033: Type 7 passwords detected

Report: report.html
JSON: findings.json (optional)

Recommendation: Address 3 critical findings immediately
```

---

**You're ready to start! Run your first scan now.**

```bash
python3 enterprise_security_parser.py your_config.txt --output report.html
```
