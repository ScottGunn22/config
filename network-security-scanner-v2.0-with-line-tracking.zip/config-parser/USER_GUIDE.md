# Enterprise Security Parser - User Guide

## Overview

The Enterprise Security Parser is a comprehensive command-line tool for analyzing network device configurations for security vulnerabilities and compliance issues. It provides 1:1 parity with the Network Security Scanner web application by using the exact same security analysis engines.

## Table of Contents

1. [Features](#features)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Quick Start](#quick-start)
5. [Usage Examples](#usage-examples)
6. [Output Formats](#output-formats)
7. [Supported Vendors](#supported-vendors)
8. [Security Checks](#security-checks)
9. [Understanding the Results](#understanding-the-results)
10. [Troubleshooting](#troubleshooting)
11. [Advanced Usage](#advanced-usage)

---

## Features

- **Multi-Vendor Support**: Cisco IOS, Juniper JunOS, Palo Alto PAN-OS, Fortinet FortiOS
- **Comprehensive Security Analysis**:
  - Access Control Lists (ACL) security
  - Cryptography and encryption validation
  - SNMP security
  - Routing protocol security (BGP, OSPF)
  - Switching security (STP)
  - Authentication and authorization
  - Network services hardening
  - Tunnel security (GRE, IPSec, VPNs)
  - First Hop Redundancy Protocol (HSRP/VRRP) security
- **Compliance Benchmarks**:
  - CIS Benchmarks (v4.1.0)
  - DISA STIG
  - Vendor hardening guides
  - PCI-DSS requirements
- **CVA ID Mapping**: Maps findings to internal vulnerability IDs
- **Multiple Output Formats**: HTML reports and JSON output
- **Automatic Vendor Detection**: Intelligently detects device vendor from configuration

---

## System Requirements

### Required

- **Python**: 3.7 or higher
- **Operating System**: Linux, macOS, or Windows
- **Python Packages**: Standard library only (see Installation for optional packages)

### Optional (Recommended)

- **Genie Parser**: For enhanced Cisco configuration parsing
  ```bash
  pip install genie
  ```

---

## Installation

### 1. Directory Structure

The Enterprise Security Parser requires the following directory structure:

```
project-root/
├── config-parser/
│   ├── enterprise_security_parser.py    (main script)
│   ├── benchmark_validator.py
│   ├── benchmark_rules.py
│   ├── genie_integration.py
│   ├── enhanced_parser.py
│   ├── juniper_enhanced_parser.py
│   ├── paloalto_enhanced_parser.py
│   └── cva_mapping.json
└── rule-engines/
    └── scanner/
        ├── core.py
        ├── engines/
        │   ├── security/
        │   ├── routing/
        │   ├── switching/
        │   └── compliance/
        └── rules/
```

### 2. Python Dependencies

**Required (included in Python standard library):**
- sys, os, argparse, json, re, pathlib, typing, dataclasses

**Optional but recommended:**
```bash
# For enhanced Cisco IOS parsing
pip install genie

# For better performance
pip install regex
```

### 3. Make Script Executable

```bash
chmod +x enterprise_security_parser.py
```

### 4. Verify Installation

```bash
python3 enterprise_security_parser.py --help
```

You should see the help message with usage instructions.

---

## Quick Start

### Basic Usage

```bash
# Analyze a configuration file and generate HTML report
python3 enterprise_security_parser.py config.txt --output report.html

# Generate JSON output instead
python3 enterprise_security_parser.py config.txt --output findings.json --format json --pretty
```

### Example with Vendor Specification

```bash
# Explicitly specify the vendor
python3 enterprise_security_parser.py cisco-router.txt --output cisco-report.html --vendor cisco_ios
```

---

## Usage Examples

### 1. Analyze Cisco IOS Configuration

```bash
python3 enterprise_security_parser.py router-config.txt \
  --output cisco-security-report.html \
  --vendor cisco_ios
```

**Expected Output:**
```
Parsing configuration...
✓ Parsed 1247 lines
✓ Detected vendor: cisco_ios
Running security analysis...
✓ ACLSecurityEngine: 12 findings
✓ CryptographySecurityEngine: 5 findings
✓ SNMPSecurityEngine: 2 findings
✓ BGPSecurityEngine: 0 findings
✓ OSPFSecurityEngine: 3 findings
✓ STPSecurityEngine: 0 findings
✓ PCIDSSComplianceEngine: 8 findings
✓ AuthenticationRules: 7 findings
✓ NetworkServicesRules: 15 findings
✓ ComprehensiveSecurityRules: 9 findings
✓ LoggingRules: 4 findings
✓ FHRPSecurityRules: 2 findings
✓ TunnelSecurityRules: 1 findings
✓ BenchmarkValidator: 23 findings
✓ HTML report written to: cisco-security-report.html

Parsing Summary:
  Vendor: cisco_ios
  Hostname: CORE-RTR-01
  Total Lines: 1247

Security Analysis:
  Total Findings: 91
  Critical: 8
  High: 23
  Medium: 34
  Low: 19
  Info: 7
```

### 2. Analyze Juniper JunOS Configuration

```bash
python3 enterprise_security_parser.py juniper-config.txt \
  --output juniper-report.html \
  --vendor juniper_junos
```

### 3. Analyze Palo Alto PAN-OS Configuration

```bash
python3 enterprise_security_parser.py paloalto-config.xml \
  --output palo-alto-report.html \
  --vendor paloalto_panos
```

### 4. Generate Pretty-Printed JSON for Automation

```bash
python3 enterprise_security_parser.py config.txt \
  --output findings.json \
  --format json \
  --pretty
```

**Sample JSON Output:**
```json
{
  "vendor": "cisco_ios",
  "hostname": "CORE-RTR-01",
  "total_lines": 1247,
  "security_findings": [
    {
      "rule_id": "AUTH-001",
      "title": "Enable secret not configured",
      "description": "The enable secret command is not configured...",
      "severity": "CRITICAL",
      "category": "Authentication",
      "recommendation": "Configure enable secret with a strong password",
      "cva_id": "CVA 0039",
      "nist_controls": ["IA-5", "AC-3"],
      "fix_commands": ["enable secret <STRONG_PASSWORD>"]
    }
  ],
  "security_summary": {
    "total_findings": 91,
    "critical": 8,
    "high": 23,
    "medium": 34,
    "low": 19,
    "info": 7
  }
}
```

### 5. Auto-Detect Vendor (No --vendor Flag)

```bash
# The parser will automatically detect the vendor
python3 enterprise_security_parser.py unknown-device.txt --output report.html
```

### 6. Skip Security Analysis (Parse Only)

```bash
# Only parse the configuration without running security checks
python3 enterprise_security_parser.py config.txt \
  --output parsed.json \
  --format json \
  --no-security
```

---

## Output Formats

### HTML Report

The HTML report includes:

- **Configuration Summary**: Vendor, hostname, total lines
- **Security Summary**: Finding counts by severity
- **Detailed Findings**: Each finding includes:
  - Title and severity badge
  - Rule ID and CVA ID (if applicable)
  - Category and description
  - Configuration line and line number
  - Recommendation and fix commands
  - NIST security controls mapping
  - Detection sources (when multiple rules detect the same issue)

**Features:**
- Bootstrap-based responsive design
- Color-coded severity levels
- Printable format
- No external dependencies (uses CDN for CSS/JS)

### JSON Format

The JSON output is ideal for:
- Integration with other tools
- Automated processing pipelines
- Custom reporting
- API consumption
- Data analysis

**Use `--pretty` flag** for human-readable formatting.

---

## Supported Vendors

| Vendor | Vendor Code | Auto-Detection | Notes |
|--------|-------------|----------------|-------|
| Cisco IOS/IOS-XE | `cisco_ios` | ✓ | Full support with Genie integration |
| Juniper JunOS | `juniper_junos` | ✓ | Full support for set-style configs |
| Palo Alto PAN-OS | `paloalto_panos` | ✓ | XML and set-style configs |
| Fortinet FortiOS | `fortinet_fortios` | ✓ | Config-style format |

### Vendor Auto-Detection

The parser uses pattern matching to detect vendors:

- **Cisco IOS**: Looks for `interface GigabitEthernet`, `router bgp`, `ip route`, etc.
- **Juniper JunOS**: Looks for `set system`, `set interfaces`, `set protocols`, etc.
- **Palo Alto**: Looks for `set deviceconfig`, `set zone`, `set rulebase`, etc.
- **Fortinet**: Looks for `config system`, `config firewall`, etc.

**Minimum confidence threshold**: At least 2 pattern matches required for auto-detection.

---

## Security Checks

### 1. Access Control List (ACL) Security

- Overly permissive rules (any/any)
- Missing ACLs on critical interfaces
- Undefined ACL references
- ACL shadowing and ordering issues

### 2. Cryptography & Encryption

- Weak encryption algorithms (DES, 3DES, MD5)
- Type 7 passwords (reversible)
- Plain-text passwords
- Missing SSH configuration
- SSH version 1 usage
- Weak IPSec configurations

### 3. SNMP Security

- SNMPv1/v2c usage (plain-text community strings)
- RW (read-write) community strings
- Default community strings (public/private)
- Missing SNMPv3 configuration

### 4. Routing Protocol Security

- **BGP**: Missing MD5 authentication, no prefix filters, peer security
- **OSPF**: Missing authentication, passive interface configuration

### 5. Authentication & Authorization

- Missing AAA configuration
- No enable secret
- Weak password policies
- No console/VTY authentication
- Missing RADIUS/TACACS+ configuration

### 6. Network Services Hardening

- HTTP server enabled
- CDP/LLDP enabled
- Unnecessary services (finger, small servers, BOOTP)
- IP source routing
- IP directed broadcasts
- Proxy ARP

### 7. Compliance Benchmarks

#### CIS Benchmark (v4.1.0)
- 15 configuration checks
- Maps to NIST controls
- Covers hardening best practices

#### DISA STIG
- 10 mandatory checks
- DoD-specific requirements
- FIPS 140-2 compliance

#### Vendor Hardening Guides
- Cisco IOS Security Guide
- Juniper Best Practices
- Palo Alto Security Recommendations

#### PCI-DSS
- Section 4.2 requirements
- Encryption in transit
- Access control

### 8. Tunnel & VPN Security

- GRE tunnel encryption
- IPSec configuration validation
- Weak IKE/ISAKMP policies
- Missing tunnel protection

### 9. First Hop Redundancy (HSRP/VRRP)

- Plain-text authentication
- Missing authentication
- Default timers and priorities

### 10. Layer 2 Security (Switching)

- STP security (BPDU guard, root guard)
- Port security
- VLAN misconfigurations
- Trunk security

---

## Understanding the Results

### Severity Levels

| Severity | Description | Action Required |
|----------|-------------|-----------------|
| **CRITICAL** | Immediate security risk, active exploitation possible | Fix immediately |
| **HIGH** | Significant security weakness, should be addressed urgently | Fix within 24-48 hours |
| **MEDIUM** | Security concern that should be addressed | Fix within 1-2 weeks |
| **LOW** | Minor security improvement, best practice recommendation | Fix during next maintenance window |
| **INFO** | Informational finding, no immediate action needed | Consider for future improvements |

### CVA ID Mapping

CVA (Common Vulnerability Assessment) IDs are internal vulnerability identifiers that map findings to your organization's vulnerability management system.

The `cva_mapping.json` file controls this mapping:

```json
{
  "mappings": {
    "cdp": "CVA 0000",
    "http": "CVA 0001",
    "enable_secret": "CVA 0039",
    ...
  }
}
```

**To customize:** Edit `cva_mapping.json` with your own vulnerability IDs.

### NIST Controls

Each finding maps to NIST SP 800-53 security controls:

- **AC**: Access Control
- **AU**: Audit and Accountability
- **CM**: Configuration Management
- **IA**: Identification and Authentication
- **SC**: System and Communications Protection

Example: `IA-5` = Authenticator Management

### Deduplication

When multiple rules detect the same issue:
- Findings are automatically deduplicated
- All detection sources are listed
- Highest severity is used
- All rule IDs are preserved

Example:
```
Rule ID: AUTH-001, CIS-002, STIG-005
Detected by multiple rules:
1. AUTH-001 (Authentication Rules)
2. CIS-002 (CIS Cisco IOS Benchmark v4.1.0)
3. STIG-005 (DISA STIG V-3210)
```

---

## Troubleshooting

### Issue: "Configuration file not found"

**Solution:**
- Verify the file path is correct
- Use absolute paths: `/full/path/to/config.txt`
- Check file permissions

### Issue: "Detected vendor: unknown"

**Possible causes:**
1. Configuration file is empty or corrupted
2. Non-standard configuration format
3. Partial configuration

**Solutions:**
- Manually specify vendor: `--vendor cisco_ios`
- Ensure complete configuration (not just snippets)
- Check for minimum 2 vendor-specific patterns

### Issue: "Error reading file: Permission denied"

**Solution:**
```bash
chmod 644 config.txt
```

### Issue: Genie parsing warnings

**Message:**
```
⚠ Warning: Genie parser not installed. Falling back to regex parsing.
```

**Solution (optional):**
```bash
pip install genie
```

**Note:** Regex parsing is fully functional. Genie provides enhanced parsing but is not required.

### Issue: ImportError for scanner modules

**Cause:** The `rule-engines` directory is not in the correct location.

**Solution:**
- Ensure `rule-engines/` is in the parent directory of `config-parser/`
- Verify the directory structure matches Installation section

### Issue: No findings detected on valid configuration

**Possible causes:**
1. Configuration is already fully hardened
2. Vendor mismatch
3. Format parsing issues

**Debugging steps:**
```bash
# Check parsing output
python3 enterprise_security_parser.py config.txt \
  --output debug.json \
  --format json \
  --pretty \
  --no-security

# Manually specify vendor
python3 enterprise_security_parser.py config.txt \
  --output report.html \
  --vendor cisco_ios
```

---

## Advanced Usage

### Integrating with CI/CD Pipelines

```bash
#!/bin/bash
# ci-security-check.sh

CONFIG_FILE="$1"
OUTPUT_JSON="findings.json"
THRESHOLD_CRITICAL=0
THRESHOLD_HIGH=5

# Run analysis
python3 enterprise_security_parser.py "$CONFIG_FILE" \
  --output "$OUTPUT_JSON" \
  --format json

# Extract severity counts
CRITICAL=$(jq '.security_summary.critical' "$OUTPUT_JSON")
HIGH=$(jq '.security_summary.high' "$OUTPUT_JSON")

# Fail build if thresholds exceeded
if [ "$CRITICAL" -gt "$THRESHOLD_CRITICAL" ]; then
  echo "FAIL: $CRITICAL critical findings detected"
  exit 1
fi

if [ "$HIGH" -gt "$THRESHOLD_HIGH" ]; then
  echo "FAIL: $HIGH high-severity findings detected (threshold: $THRESHOLD_HIGH)"
  exit 1
fi

echo "PASS: Configuration meets security requirements"
exit 0
```

### Batch Processing Multiple Configurations

```bash
#!/bin/bash
# batch-analyze.sh

for config in configs/*.txt; do
  filename=$(basename "$config" .txt)
  echo "Processing $filename..."

  python3 enterprise_security_parser.py "$config" \
    --output "reports/${filename}-report.html"
done

echo "Batch processing complete. Reports in reports/"
```

### Custom CVA Mapping

Edit `cva_mapping.json` to map findings to your vulnerability management system:

```json
{
  "comment": "Custom CVA ID mapping for your organization",
  "mappings": {
    "cdp": "VULN-2024-001",
    "http": "VULN-2024-002",
    "enable_secret": "VULN-2024-003"
  }
}
```

### Filtering Results with jq

```bash
# Extract only CRITICAL findings
python3 enterprise_security_parser.py config.txt --output findings.json --format json
jq '.security_findings[] | select(.severity == "CRITICAL")' findings.json

# Count findings by category
jq '.security_findings | group_by(.category) | map({category: .[0].category, count: length})' findings.json

# Extract findings with fix commands
jq '.security_findings[] | select(.fix_commands | length > 0) | {title, fix_commands}' findings.json
```

---

## Command-Line Reference

### Positional Arguments

- `config_file`: Path to configuration file (required)

### Optional Arguments

| Argument | Short | Description | Default |
|----------|-------|-------------|---------|
| `--output` | `-o` | Output file path | (required) |
| `--format` | `-f` | Output format: `html` or `json` | `html` |
| `--vendor` | `-v` | Vendor type: `cisco_ios`, `juniper_junos`, `paloalto_panos`, `fortinet_fortios`, `unknown` | auto-detect |
| `--pretty` | `-p` | Pretty-print JSON output | disabled |
| `--no-security` | `-n` | Skip security analysis (parse only) | disabled |

### Examples

```bash
# Minimal usage
python3 enterprise_security_parser.py config.txt -o report.html

# All options
python3 enterprise_security_parser.py config.txt \
  --output report.json \
  --format json \
  --vendor cisco_ios \
  --pretty

# Parse only, no analysis
python3 enterprise_security_parser.py config.txt \
  -o parsed.json \
  -f json \
  -n
```

---

## Support and Contributing

### Getting Help

1. Check this user guide
2. Review the Troubleshooting section
3. Examine the console output for error messages
4. Verify your Python version: `python3 --version`

### Reporting Issues

When reporting issues, include:
- Python version
- Operating system
- Command used
- Full error message
- Sample configuration (sanitized)

---

## License and Credits

This tool uses the Network Security Scanner engines and provides 1:1 parity with the web application for command-line usage.

**Security Analysis Engines:**
- ACL Security Engine
- Cryptography Security Engine
- SNMP Security Engine
- BGP Security Engine
- OSPF Security Engine
- STP Security Engine
- PCI-DSS Compliance Engine

**Rule Sets:**
- CIS Benchmark v4.1.0
- DISA STIG
- Vendor Hardening Guides
- Custom Security Rules

---

## Appendix A: Complete Example Session

```bash
$ python3 enterprise_security_parser.py sample-router.txt --output report.html

Parsing configuration...
✓ Parsed 856 lines
✓ Detected vendor: cisco_ios
Running security analysis...
✓ Using regex-based parsing
✓ ACLSecurityEngine: 8 findings
✓ CryptographySecurityEngine: 3 findings
✓ SNMPSecurityEngine: 2 findings
✓ BGPSecurityEngine: 0 findings
✓ OSPFSecurityEngine: 1 findings
✓ STPSecurityEngine: 0 findings
✓ PCIDSSComplianceEngine: 5 findings
✓ AuthenticationRules: 4 findings
✓ NetworkServicesRules: 12 findings
✓ ComprehensiveSecurityRules: 7 findings
✓ LoggingRules: 3 findings
✓ FHRPSecurityRules: 0 findings
✓ TunnelSecurityRules: 0 findings
✓ JuniperAuthenticationRules: 0 findings
✓ JuniperServicesRules: 0 findings
✓ JuniperComprehensiveRules: 0 findings
✓ JuniperTunnelRules: 0 findings
✓ PaloAltoSecurityRules: 0 findings
✓ BenchmarkValidator: 18 findings
✓ HTML report written to: report.html

Parsing Summary:
  Vendor: cisco_ios
  Hostname: BRANCH-RTR-02
  Total Lines: 856

Security Analysis:
  Total Findings: 63
  Critical: 5
  High: 15
  Medium: 28
  Low: 12
  Info: 3

$ open report.html  # Opens the HTML report in your browser
```

---

**End of User Guide**
