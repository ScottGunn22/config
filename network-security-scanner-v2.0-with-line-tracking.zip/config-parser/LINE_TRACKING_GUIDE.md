# Line Number Tracking - Implementation Guide

## Overview

Line number tracking has been implemented using **simplified helper methods** that automatically extract and report line numbers for misconfigurations.

---

## How It Works

### New Helper Methods

Three helper methods have been added to `benchmark_validator.py`:

**1. `_find_lines(config_lines, pattern=None, condition=None)`**
- Finds lines matching a pattern or condition
- Automatically extracts line numbers
- Returns list of `(line_number, content)` tuples

**2. `_wrap_finding(compliant, base_message, found_lines=None)`**
- Automatically formats findings with line numbers
- Handles both "misconfiguration found" and "configuration missing" cases
- Returns standardized finding dict

**3. `_create_finding(compliant, message, affected_lines=None, line_content=None)`**
- Low-level method for custom formatting
- Adds `affected_lines`, `line_content`, and `evidence_type` fields

---

## Finding Format

### When Misconfiguration is Found

```json
{
  "compliant": false,
  "details": "HTTP server enabled - Misconfiguration found on line 145",
  "affected_lines": [145],
  "line_content": ["ip http server"],
  "evidence_type": "misconfiguration"
}
```

### When Configuration is Missing

```json
{
  "compliant": false,
  "details": "Enable secret not configured - Best practice: Configuration not found",
  "evidence_type": "missing_configuration"
}
```

### When Multiple Lines Have Issues

```json
{
  "compliant": false,
  "details": "Type 7 passwords found - Misconfiguration found on lines: 23, 45, 67",
  "affected_lines": [23, 45, 67],
  "line_content": [
    "username admin password 7 0822455D0A16",
    "username guest password 7 094F471A1A0A",
    "username test password 7 121A0C041104"
  ],
  "evidence_type": "misconfiguration"
}
```

---

## Usage Examples

### Example 1: Simple Pattern Match

**Old Way (no line tracking):**
```python
def check_password_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
    has_encryption = any(
        "service password-encryption" in self._safe_content(line)
        for line in config_lines
    )
    return {
        "compliant": has_encryption,
        "details": "Password encryption enabled" if has_encryption else "Not enabled"
    }
```

**New Way (automatic line tracking):**
```python
def check_password_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
    # Find all lines with the pattern
    encryption_lines = self._find_lines(config_lines, pattern="service password-encryption")

    # Wrap finding with automatic line tracking
    return self._wrap_finding(
        compliant=len(encryption_lines) > 0,
        base_message="Password encryption" + (" enabled" if encryption_lines else " not enabled"),
        found_lines=encryption_lines
    )
```

**Result when found:**
```
"Password encryption enabled (line 42)"
affected_lines: [42]
line_content: ["service password-encryption"]
```

---

### Example 2: Finding Problems (Negative Check)

**Check for unwanted configuration:**
```python
def check_no_http_server(self, config_lines: List, parsed_config: Dict) -> Dict:
    # Find problematic lines
    http_lines = self._find_lines(config_lines, pattern="ip http server")

    # Filter out "no ip http server" (which is good)
    problem_lines = [(ln, content) for ln, content in http_lines
                     if not content.startswith("no ")]

    return self._wrap_finding(
        compliant=len(problem_lines) == 0,
        base_message="HTTP server " + ("disabled" if not problem_lines else "enabled"),
        found_lines=problem_lines
    )
```

**Result when problem found:**
```
"HTTP server enabled - Misconfiguration found on line 145"
affected_lines: [145]
line_content: ["ip http server"]
evidence_type: "misconfiguration"
```

---

### Example 3: Using Custom Condition

**For complex pattern matching:**
```python
def check_weak_snmp(self, config_lines: List, parsed_config: Dict) -> Dict:
    # Use custom condition function
    weak_snmp = self._find_lines(
        config_lines,
        condition=lambda content: (
            "snmp-server community" in content and
            ("public" in content or "private" in content)
        )
    )

    return self._wrap_finding(
        compliant=len(weak_snmp) == 0,
        base_message="Default SNMP communities" + (" not found" if not weak_snmp else " detected"),
        found_lines=weak_snmp
    )
```

---

### Example 4: Multi-Stage Check

**For checks requiring multiple conditions:**
```python
def check_ssh_version(self, config_lines: List, parsed_config: Dict) -> Dict:
    # Find SSH configuration
    ssh_lines = self._find_lines(config_lines, pattern="ip ssh version")

    # Check if version 2 is configured
    ssh_v2_lines = [(ln, content) for ln, content in ssh_lines
                    if "version 2" in content]

    if not ssh_lines:
        # SSH not configured at all
        return self._create_finding(
            False,
            "SSH not configured - Best practice: Configure SSH version 2"
        )
    elif ssh_v2_lines:
        # SSH v2 found - good!
        return self._wrap_finding(
            True,
            "SSH version 2 configured",
            found_lines=ssh_v2_lines
        )
    else:
        # SSH configured but not v2 - problem!
        return self._wrap_finding(
            False,
            "SSH version 1 or unspecified",
            found_lines=ssh_lines
        )
```

---

## Migration Strategy

### Functions Already Updated

The agent has already updated many functions. These use the manual pattern:
```python
matching_lines = [
    (self._get_line_number(line), self._safe_content(line))
    for line in config_lines
    if CONDITION
]
```

### Functions to Update

Remaining functions can be easily updated using the simplified helpers:
1. Replace `any()` checks with `self._find_lines()`
2. Replace manual return dict with `self._wrap_finding()`

### Priority

**High Priority (Critical/High Severity):**
- Functions checking for security vulnerabilities
- Functions looking for weak configurations

**Medium Priority:**
- Best practice checks
- Logging/monitoring checks

**Low Priority:**
- Informational checks
- Already compliant configurations

---

## Benefits

✅ **Automatic line tracking** - No manual line number extraction
✅ **Consistent formatting** - All findings follow same pattern
✅ **Clear messaging** - "Misconfiguration on line X" vs "Best practice not found"
✅ **Easy to implement** - 2-3 lines of code per function
✅ **Backward compatible** - Existing checks still work

---

## Testing

To test line tracking:

```bash
# Run scanner on a config
python3 enterprise_security_parser.py test_config.txt --output report.json --format json

# Check for line numbers in output
jq '.findings[] | select(.affected_lines != null) | {rule_id, affected_lines, line_content}' report.json
```

Expected output:
```json
{
  "rule_id": "CIS-005",
  "affected_lines": [145],
  "line_content": ["ip http server"]
}
```

---

## Summary

**Before:**
- No line numbers reported
- Users had to manually search configs
- "SSH not configured" - where should I add it?

**After:**
- Exact line numbers for all misconfigurations
- "HTTP server enabled - Misconfiguration found on line 145"
- "Enable secret not configured - Best practice: Configuration not found"
- Easy remediation with precise line references

---

**Implementation Status:** ✅ Helper methods complete, many functions updated, more updates in progress
