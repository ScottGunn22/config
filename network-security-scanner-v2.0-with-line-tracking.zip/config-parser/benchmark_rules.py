"""CIS Benchmark and DISA STIG validation rules for network devices."""

import re
from typing import List, Dict, Any
from dataclasses import dataclass


@dataclass
class BenchmarkRule:
    """Represents a security benchmark rule."""
    rule_id: str
    title: str
    description: str
    severity: str
    benchmark_id: str  # CIS 1.1.1 or STIG V-1234
    benchmark_name: str  # "CIS Cisco IOS v4.1.0" or "STIG"
    check_function: str  # Name of check function
    recommendation: str
    fix_commands: List[str]
    nist_controls: List[str]


class CISBenchmarkRules:
    """CIS Benchmark validation rules."""

    @staticmethod
    def get_cisco_ios_rules() -> List[BenchmarkRule]:
        """Get CIS Cisco IOS benchmark rules."""
        return [
            BenchmarkRule(
                rule_id="CIS-001",
                title="Set 'hostname' to organization-defined value",
                description="CIS recommends setting a unique hostname for device identification and management.",
                severity="LOW",
                benchmark_id="CIS 1.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_hostname_configured",
                recommendation="Configure a descriptive hostname",
                fix_commands=["hostname <UNIQUE_NAME>"],
                nist_controls=["CM-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-002",
                title="Set 'enable secret' for privileged EXEC mode",
                description="CIS requires enable secret (not enable password) with strong hashing.",
                severity="CRITICAL",
                benchmark_id="CIS 1.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_enable_secret",
                recommendation="Use 'enable secret' with strong password",
                fix_commands=["enable secret <STRONG_PASSWORD>"],
                nist_controls=["IA-5", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-003",
                title="Enable 'service password-encryption'",
                description="CIS requires password encryption to protect passwords in configuration.",
                severity="MEDIUM",
                benchmark_id="CIS 1.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_password_encryption",
                recommendation="Enable password encryption service",
                fix_commands=["service password-encryption"],
                nist_controls=["IA-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-004",
                title="Set 'banner login' warning message",
                description="CIS requires login banners to warn unauthorized users.",
                severity="LOW",
                benchmark_id="CIS 1.1.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_login_banner",
                recommendation="Configure login banner with legal warning",
                fix_commands=["banner login ^C Unauthorized access prohibited ^C"],
                nist_controls=["AC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-005",
                title="Set 'no ip http server'",
                description="CIS recommends disabling HTTP server to prevent unencrypted management.",
                severity="MEDIUM",
                benchmark_id="CIS 1.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_http_server",
                recommendation="Disable HTTP server",
                fix_commands=["no ip http server"],
                nist_controls=["SC-8", "CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-006",
                title="Enable 'ip http secure-server' if web management needed",
                description="CIS allows HTTPS for web management but requires proper configuration.",
                severity="LOW",
                benchmark_id="CIS 1.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_https_secure",
                recommendation="Use HTTPS with proper TLS configuration",
                fix_commands=["ip http secure-server", "ip http ssl-version tlsv1.2"],
                nist_controls=["SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-007",
                title="Set 'ip ssh version 2'",
                description="CIS requires SSHv2 only for secure management access.",
                severity="HIGH",
                benchmark_id="CIS 1.2.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ssh_version_2",
                recommendation="Configure SSH version 2 only",
                fix_commands=["ip ssh version 2"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-008",
                title="Set 'transport input ssh' on VTY lines",
                description="CIS requires SSH-only access on VTY lines.",
                severity="HIGH",
                benchmark_id="CIS 1.2.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_vty_transport_ssh",
                recommendation="Restrict VTY lines to SSH only",
                fix_commands=["line vty 0 4", " transport input ssh"],
                nist_controls=["SC-8", "AC-17"]
            ),
            BenchmarkRule(
                rule_id="CIS-009",
                title="Set 'exec-timeout' on console, AUX, and VTY lines",
                description="CIS requires session timeout ≤ 10 minutes.",
                severity="MEDIUM",
                benchmark_id="CIS 1.2.5",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_exec_timeout",
                recommendation="Set exec-timeout to 10 minutes or less",
                fix_commands=["line vty 0 4", " exec-timeout 10 0"],
                nist_controls=["AC-12", "SC-10"]
            ),
            BenchmarkRule(
                rule_id="CIS-010",
                title="Set 'no ip source-route'",
                description="CIS requires IP source routing to be disabled.",
                severity="MEDIUM",
                benchmark_id="CIS 1.3.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_source_route",
                recommendation="Disable IP source routing",
                fix_commands=["no ip source-route"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-011",
                title="Set 'no ip proxy-arp' on interfaces",
                description="CIS recommends disabling proxy ARP on interfaces.",
                severity="LOW",
                benchmark_id="CIS 1.3.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_proxy_arp",
                recommendation="Disable proxy ARP on all interfaces",
                fix_commands=["interface <INTERFACE>", " no ip proxy-arp"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-012",
                title="Set 'aaa new-model'",
                description="CIS requires AAA for centralized access control.",
                severity="HIGH",
                benchmark_id="CIS 1.4.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_new_model",
                recommendation="Enable AAA new-model",
                fix_commands=["aaa new-model"],
                nist_controls=["IA-2", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-013",
                title="Configure 'aaa authentication login'",
                description="CIS requires AAA authentication for login.",
                severity="HIGH",
                benchmark_id="CIS 1.4.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_authentication_login",
                recommendation="Configure AAA authentication for login",
                fix_commands=["aaa authentication login default group tacacs+ local"],
                nist_controls=["IA-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-014",
                title="Set 'logging buffered' with appropriate level",
                description="CIS requires logging with appropriate severity level.",
                severity="MEDIUM",
                benchmark_id="CIS 1.5.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_buffered",
                recommendation="Configure logging buffered with informational level",
                fix_commands=["logging buffered informational"],
                nist_controls=["AU-2", "AU-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-015",
                title="Set 'logging host' to remote syslog server",
                description="CIS requires centralized logging to remote server.",
                severity="HIGH",
                benchmark_id="CIS 1.5.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_host",
                recommendation="Configure remote syslog server",
                fix_commands=["logging host <SYSLOG_SERVER>"],
                nist_controls=["AU-4", "AU-9"]
            ),
            # Interface Security Rules
            BenchmarkRule(
                rule_id="CIS-016",
                title="Disable DTP on access ports",
                description="CIS requires Dynamic Trunking Protocol (DTP) to be disabled on access ports to prevent VLAN hopping attacks.",
                severity="HIGH",
                benchmark_id="CIS 2.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_dtp_disabled",
                recommendation="Configure 'switchport mode access' and 'switchport nonegotiate' on access ports",
                fix_commands=["interface <INTERFACE>", " switchport mode access", " switchport nonegotiate"],
                nist_controls=["SC-7", "CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-017",
                title="Shutdown unused interfaces",
                description="CIS requires unused interfaces to be administratively shutdown to reduce attack surface.",
                severity="MEDIUM",
                benchmark_id="CIS 2.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_unused_interfaces_shutdown",
                recommendation="Shutdown all unused interfaces",
                fix_commands=["interface <INTERFACE>", " shutdown"],
                nist_controls=["CM-7", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-018",
                title="Configure native VLAN on trunk ports",
                description="CIS requires native VLAN to be set to unused VLAN on trunk ports.",
                severity="MEDIUM",
                benchmark_id="CIS 2.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_native_vlan_trunk",
                recommendation="Configure native VLAN to unused VLAN on trunks",
                fix_commands=["interface <INTERFACE>", " switchport trunk native vlan 999"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-019",
                title="Enable port security on access ports",
                description="CIS recommends port security to prevent MAC address spoofing and CAM table overflow attacks.",
                severity="HIGH",
                benchmark_id="CIS 2.1.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_port_security",
                recommendation="Enable port security with maximum MAC addresses",
                fix_commands=["interface <INTERFACE>", " switchport port-security", " switchport port-security maximum 2"],
                nist_controls=["SC-7", "IA-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-020",
                title="Configure storm control",
                description="CIS requires storm control to prevent broadcast, multicast, and unicast storms.",
                severity="MEDIUM",
                benchmark_id="CIS 2.1.5",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_storm_control",
                recommendation="Configure storm control on all interfaces",
                fix_commands=["interface <INTERFACE>", " storm-control broadcast level 50.00", " storm-control multicast level 50.00"],
                nist_controls=["SC-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-021",
                title="Enable DHCP snooping",
                description="CIS requires DHCP snooping to prevent rogue DHCP servers.",
                severity="HIGH",
                benchmark_id="CIS 2.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_dhcp_snooping",
                recommendation="Enable DHCP snooping globally and on VLANs",
                fix_commands=["ip dhcp snooping", "ip dhcp snooping vlan <VLAN_LIST>"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-022",
                title="Enable Dynamic ARP Inspection (DAI)",
                description="CIS requires DAI to prevent ARP spoofing attacks.",
                severity="HIGH",
                benchmark_id="CIS 2.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_dynamic_arp_inspection",
                recommendation="Enable Dynamic ARP Inspection on VLANs",
                fix_commands=["ip arp inspection vlan <VLAN_LIST>"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-023",
                title="Enable IP Source Guard",
                description="CIS requires IP Source Guard to prevent IP address spoofing.",
                severity="HIGH",
                benchmark_id="CIS 2.2.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ip_source_guard",
                recommendation="Enable IP Source Guard on access ports",
                fix_commands=["interface <INTERFACE>", " ip verify source"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-024",
                title="Enable BPDU Guard on access ports",
                description="CIS requires BPDU Guard to prevent unauthorized switches from affecting spanning tree topology.",
                severity="HIGH",
                benchmark_id="CIS 2.3.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_bpdu_guard",
                recommendation="Enable BPDU Guard on all access ports",
                fix_commands=["interface <INTERFACE>", " spanning-tree bpduguard enable"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-025",
                title="Enable Root Guard on uplink ports",
                description="CIS requires Root Guard to prevent unauthorized switches from becoming root bridge.",
                severity="MEDIUM",
                benchmark_id="CIS 2.3.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_root_guard",
                recommendation="Enable Root Guard on uplink/trunk ports",
                fix_commands=["interface <INTERFACE>", " spanning-tree guard root"],
                nist_controls=["SC-7"]
            ),
            # Advanced AAA & Authentication Rules
            BenchmarkRule(
                rule_id="CIS-026",
                title="Configure AAA authorization for exec",
                description="CIS requires AAA authorization to control which users can access privileged EXEC mode.",
                severity="HIGH",
                benchmark_id="CIS 3.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_authorization_exec",
                recommendation="Enable AAA authorization for exec",
                fix_commands=["aaa authorization exec default group tacacs+ local"],
                nist_controls=["AC-3", "AC-6"]
            ),
            BenchmarkRule(
                rule_id="CIS-027",
                title="Configure AAA authorization for commands",
                description="CIS requires AAA authorization for command execution at different privilege levels.",
                severity="HIGH",
                benchmark_id="CIS 3.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_authorization_commands",
                recommendation="Enable AAA authorization for commands",
                fix_commands=["aaa authorization commands 15 default group tacacs+ local"],
                nist_controls=["AC-3", "AC-6"]
            ),
            BenchmarkRule(
                rule_id="CIS-028",
                title="Configure AAA accounting for exec",
                description="CIS requires AAA accounting to log user exec sessions for audit purposes.",
                severity="MEDIUM",
                benchmark_id="CIS 3.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_accounting_exec",
                recommendation="Enable AAA accounting for exec sessions",
                fix_commands=["aaa accounting exec default start-stop group tacacs+"],
                nist_controls=["AU-2", "AU-3", "AU-12"]
            ),
            BenchmarkRule(
                rule_id="CIS-029",
                title="Configure AAA accounting for commands",
                description="CIS requires AAA accounting to log all commands executed for audit trail.",
                severity="HIGH",
                benchmark_id="CIS 3.1.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_accounting_commands",
                recommendation="Enable AAA accounting for commands",
                fix_commands=["aaa accounting commands 15 default start-stop group tacacs+"],
                nist_controls=["AU-2", "AU-3", "AU-12"]
            ),
            BenchmarkRule(
                rule_id="CIS-030",
                title="Configure login authentication failure rate limiting",
                description="CIS requires login failure rate limiting to prevent brute force attacks.",
                severity="HIGH",
                benchmark_id="CIS 3.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_login_block_for",
                recommendation="Configure login authentication failure rate limiting",
                fix_commands=["login block-for 300 attempts 3 within 60"],
                nist_controls=["AC-7", "IA-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-031",
                title="Set minimum password length to 15 characters",
                description="CIS requires minimum password length of 15 characters for strong passwords.",
                severity="HIGH",
                benchmark_id="CIS 3.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_password_length",
                recommendation="Set security passwords min-length 15",
                fix_commands=["security passwords min-length 15"],
                nist_controls=["IA-5(1)"]
            ),
            BenchmarkRule(
                rule_id="CIS-032",
                title="Configure password complexity requirements",
                description="CIS recommends password complexity checking if supported by platform.",
                severity="MEDIUM",
                benchmark_id="CIS 3.2.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_password_complexity",
                recommendation="Enable password strength checking",
                fix_commands=["password strength-check"],
                nist_controls=["IA-5(1)"]
            ),
            BenchmarkRule(
                rule_id="CIS-033",
                title="Use Type 5 or Type 8 passwords",
                description="CIS prohibits Type 7 (reversibly encrypted) passwords in configurations.",
                severity="CRITICAL",
                benchmark_id="CIS 3.2.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_type7_passwords",
                recommendation="Remove all Type 7 passwords, use Type 5 or Type 8",
                fix_commands=["<Remove Type 7 passwords and reconfigure with enable secret>"],
                nist_controls=["IA-5", "SC-28"]
            ),
            # Routing Security Rules
            BenchmarkRule(
                rule_id="CIS-034",
                title="Configure BGP authentication",
                description="CIS requires MD5 authentication for all BGP neighbors to prevent route injection.",
                severity="CRITICAL",
                benchmark_id="CIS 4.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_bgp_authentication",
                recommendation="Enable BGP neighbor authentication",
                fix_commands=["router bgp <ASN>", " neighbor <IP> password <PASSWORD>"],
                nist_controls=["SC-8", "SC-23"]
            ),
            BenchmarkRule(
                rule_id="CIS-035",
                title="Configure BGP prefix filtering",
                description="CIS requires inbound and outbound prefix filtering on BGP neighbors.",
                severity="HIGH",
                benchmark_id="CIS 4.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_bgp_prefix_filtering",
                recommendation="Configure prefix-lists or route-maps on all BGP neighbors",
                fix_commands=["router bgp <ASN>", " neighbor <IP> prefix-list <NAME> in", " neighbor <IP> prefix-list <NAME> out"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-036",
                title="Configure BGP maximum-prefix limits",
                description="CIS requires maximum-prefix limits to prevent route table overflow.",
                severity="HIGH",
                benchmark_id="CIS 4.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_bgp_max_prefix",
                recommendation="Configure maximum-prefix on all BGP neighbors",
                fix_commands=["router bgp <ASN>", " neighbor <IP> maximum-prefix <LIMIT>"],
                nist_controls=["SC-5", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-037",
                title="Configure OSPF authentication",
                description="CIS requires authentication for all OSPF areas to prevent route injection.",
                severity="HIGH",
                benchmark_id="CIS 4.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ospf_authentication",
                recommendation="Enable OSPF authentication on all interfaces",
                fix_commands=["interface <INTERFACE>", " ip ospf authentication message-digest", " ip ospf message-digest-key 1 md5 <PASSWORD>"],
                nist_controls=["SC-8", "SC-23"]
            ),
            BenchmarkRule(
                rule_id="CIS-038",
                title="Configure OSPF passive interfaces",
                description="CIS requires passive interfaces where OSPF neighbors are not expected.",
                severity="MEDIUM",
                benchmark_id="CIS 4.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ospf_passive_interface",
                recommendation="Configure passive-interface for non-routing interfaces",
                fix_commands=["router ospf <PROCESS>", " passive-interface default"],
                nist_controls=["SC-7", "CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-039",
                title="Configure EIGRP authentication",
                description="CIS requires authentication for EIGRP to prevent route manipulation.",
                severity="HIGH",
                benchmark_id="CIS 4.3.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_eigrp_authentication",
                recommendation="Enable EIGRP authentication on all interfaces",
                fix_commands=["interface <INTERFACE>", " ip authentication mode eigrp <ASN> md5", " ip authentication key-chain eigrp <ASN> <KEYCHAIN>"],
                nist_controls=["SC-8", "SC-23"]
            ),
            # Advanced Cryptography Rules
            BenchmarkRule(
                rule_id="CIS-040",
                title="Configure strong RSA key size (2048-bit minimum)",
                description="CIS requires RSA keys of at least 2048 bits for SSH and certificates.",
                severity="HIGH",
                benchmark_id="CIS 5.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_strong_rsa_keys",
                recommendation="Generate RSA keys with 2048-bit or 4096-bit modulus",
                fix_commands=["crypto key generate rsa modulus 2048"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-041",
                title="Configure strong SSH algorithms",
                description="CIS requires restricting SSH to strong key exchange, cipher, and MAC algorithms.",
                severity="HIGH",
                benchmark_id="CIS 5.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ssh_strong_algorithms",
                recommendation="Configure SSH algorithm restrictions",
                fix_commands=["ip ssh server algorithm encryption aes256-ctr aes192-ctr aes128-ctr", "ip ssh server algorithm mac hmac-sha2-512 hmac-sha2-256"],
                nist_controls=["SC-13", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-042",
                title="Disable weak IPsec encryption (DES, 3DES)",
                description="CIS prohibits weak encryption algorithms like DES and 3DES for IPsec.",
                severity="CRITICAL",
                benchmark_id="CIS 5.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_weak_ipsec_encryption",
                recommendation="Use AES-256 or AES-128 for IPsec encryption",
                fix_commands=["crypto ipsec transform-set <NAME> esp-aes 256 esp-sha256-hmac"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-043",
                title="Configure IKEv2 instead of IKEv1",
                description="CIS recommends IKEv2 over IKEv1 for improved security.",
                severity="MEDIUM",
                benchmark_id="CIS 5.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ikev2_preferred",
                recommendation="Configure IKEv2 profiles and policies",
                fix_commands=["crypto ikev2 proposal <NAME>", " encryption aes-cbc-256", " integrity sha256", " group 14"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-044",
                title="Use strong Diffie-Hellman groups (Group 14+)",
                description="CIS requires DH groups 14 or higher for key exchange.",
                severity="HIGH",
                benchmark_id="CIS 5.2.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_strong_dh_groups",
                recommendation="Configure DH group 14, 15, 16, 19, 20, or 24",
                fix_commands=["crypto isakmp policy <PRIORITY>", " group 14"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-045",
                title="Enable Perfect Forward Secrecy (PFS)",
                description="CIS requires PFS for IPsec to ensure session key independence.",
                severity="MEDIUM",
                benchmark_id="CIS 5.2.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ipsec_pfs",
                recommendation="Configure PFS in crypto maps",
                fix_commands=["crypto map <NAME> <SEQ> ipsec-isakmp", " set pfs group14"],
                nist_controls=["SC-13"]
            ),
            # Management Plane Security Rules
            BenchmarkRule(
                rule_id="CIS-046",
                title="Restrict SSH ciphersuites",
                description="CIS requires restricting SSH to approved cipher suites only.",
                severity="HIGH",
                benchmark_id="CIS 6.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ssh_ciphersuite_restrictions",
                recommendation="Configure strong SSH cipher restrictions",
                fix_commands=["ip ssh server algorithm encryption aes256-ctr aes192-ctr aes128-ctr"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-047",
                title="Set SSH timeout to 60 seconds",
                description="CIS requires SSH authentication timeout of 60 seconds or less.",
                severity="MEDIUM",
                benchmark_id="CIS 6.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ssh_timeout",
                recommendation="Configure SSH authentication timeout",
                fix_commands=["ip ssh time-out 60"],
                nist_controls=["AC-12"]
            ),
            BenchmarkRule(
                rule_id="CIS-048",
                title="Set SSH authentication retries to 3 or less",
                description="CIS limits SSH authentication attempts to prevent brute force.",
                severity="MEDIUM",
                benchmark_id="CIS 6.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ssh_auth_retries",
                recommendation="Limit SSH authentication retries",
                fix_commands=["ip ssh authentication-retries 3"],
                nist_controls=["AC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-049",
                title="Disable Telnet server",
                description="CIS prohibits Telnet due to cleartext transmission.",
                severity="CRITICAL",
                benchmark_id="CIS 6.1.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_telnet",
                recommendation="Remove 'transport input telnet' from VTY lines",
                fix_commands=["line vty 0 4", " transport input ssh"],
                nist_controls=["SC-8", "CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-050",
                title="Disable TFTP service",
                description="CIS prohibits TFTP due to lack of authentication and encryption.",
                severity="HIGH",
                benchmark_id="CIS 6.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_tftp_server",
                recommendation="Disable TFTP server",
                fix_commands=["no tftp-server"],
                nist_controls=["CM-7", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-051",
                title="Enable secure copy (SCP) for file transfers",
                description="CIS recommends SCP over insecure protocols like FTP and TFTP.",
                severity="MEDIUM",
                benchmark_id="CIS 6.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_scp_enabled",
                recommendation="Enable SCP server for secure file transfers",
                fix_commands=["ip scp server enable"],
                nist_controls=["SC-8"]
            ),
            # Logging & Monitoring Enhancement Rules
            BenchmarkRule(
                rule_id="CIS-052",
                title="Configure logging source-interface",
                description="CIS requires consistent source IP for syslog messages.",
                severity="LOW",
                benchmark_id="CIS 7.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_source_interface",
                recommendation="Configure logging source-interface",
                fix_commands=["logging source-interface <INTERFACE>"],
                nist_controls=["AU-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-053",
                title="Configure logging timestamps with datetime",
                description="CIS requires timestamps with date and time (not uptime) in logs.",
                severity="MEDIUM",
                benchmark_id="CIS 7.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_timestamps",
                recommendation="Enable service timestamps for logging",
                fix_commands=["service timestamps log datetime localtime show-timezone"],
                nist_controls=["AU-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-054",
                title="Configure logging facility",
                description="CIS recommends configuring syslog facility for proper categorization.",
                severity="LOW",
                benchmark_id="CIS 7.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_facility",
                recommendation="Configure logging facility",
                fix_commands=["logging facility local7"],
                nist_controls=["AU-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-055",
                title="Enable logging synchronous on console and VTY",
                description="CIS recommends logging synchronous to prevent log messages from interrupting commands.",
                severity="LOW",
                benchmark_id="CIS 7.1.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_synchronous",
                recommendation="Enable logging synchronous on lines",
                fix_commands=["line console 0", " logging synchronous", "line vty 0 4", " logging synchronous"],
                nist_controls=["AU-3"]
            ),
            # Additional CIS Controls (56-61) - Final 6 rules for 100% coverage
            BenchmarkRule(
                rule_id="CIS-056",
                title="Enable TCP sequence number randomization",
                description="CIS recommends TCP sequence number randomization to prevent session hijacking attacks.",
                severity="MEDIUM",
                benchmark_id="CIS 5.3.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_tcp_sequence_randomization",
                recommendation="Enable TCP sequence number randomization",
                fix_commands=["service tcp-keepalives-in", "service tcp-keepalives-out"],
                nist_controls=["SC-7", "SC-20"]
            ),
            BenchmarkRule(
                rule_id="CIS-057",
                title="Require interface descriptions",
                description="CIS recommends documenting all interfaces with descriptions for accountability and change management.",
                severity="LOW",
                benchmark_id="CIS 8.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_interface_descriptions",
                recommendation="Add descriptions to all active interfaces",
                fix_commands=["interface <interface_name>", " description <DESCRIPTION>"],
                nist_controls=["CM-8", "CM-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-058",
                title="Set switchport mode explicitly (no negotiation)",
                description="CIS requires explicit switchport mode configuration to prevent DTP negotiation attacks.",
                severity="HIGH",
                benchmark_id="CIS 2.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_switchport_mode_explicit",
                recommendation="Configure switchport mode explicitly without negotiation",
                fix_commands=["interface <interface_name>", " switchport mode access", " switchport nonegotiate"],
                nist_controls=["CM-6", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-059",
                title="Enable Loop Guard on all trunk ports",
                description="CIS recommends Loop Guard to prevent bridging loops caused by STP failures.",
                severity="HIGH",
                benchmark_id="CIS 2.1.5",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_loop_guard",
                recommendation="Enable Loop Guard globally or per trunk interface",
                fix_commands=["spanning-tree loopguard default", "interface <trunk_interface>", " spanning-tree guard loop"],
                nist_controls=["SC-7", "CP-9"]
            ),
            BenchmarkRule(
                rule_id="CIS-060",
                title="Enable NetFlow or sFlow for traffic visibility",
                description="CIS recommends flow monitoring for traffic analysis and anomaly detection.",
                severity="MEDIUM",
                benchmark_id="CIS 7.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_netflow_enabled",
                recommendation="Enable NetFlow for traffic monitoring",
                fix_commands=["ip flow-export destination <collector_ip> <port>", "interface <interface_name>", " ip flow ingress"],
                nist_controls=["SI-4", "AU-6"]
            ),
            BenchmarkRule(
                rule_id="CIS-061",
                title="Enable configuration change notifications",
                description="CIS requires notification of configuration changes for audit and incident response.",
                severity="MEDIUM",
                benchmark_id="CIS 7.3.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_config_change_notifications",
                recommendation="Enable configuration archive and change notifications",
                fix_commands=["archive", " log config", "  logging enable", "  notify syslog"],
                nist_controls=["AU-6", "CM-3", "CM-5"]
            ),
        ]

    @staticmethod
    def get_cisco_asa_rules() -> List[BenchmarkRule]:
        """Get CIS Cisco ASA benchmark rules."""
        return [
            BenchmarkRule(
                rule_id="CIS-ASA-001",
                title="Set 'hostname' to organization-defined value",
                description="CIS recommends setting a unique hostname for device identification and management.",
                severity="LOW",
                benchmark_id="CIS ASA 1.1.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_hostname_configured",
                recommendation="Configure a descriptive hostname",
                fix_commands=["hostname <UNIQUE_NAME>"],
                nist_controls=["CM-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-002",
                title="Set 'enable password' with encryption",
                description="CIS requires enable password with strong hashing for ASA.",
                severity="CRITICAL",
                benchmark_id="CIS ASA 1.1.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_enable_password",
                recommendation="Use 'enable password' with strong encryption",
                fix_commands=["enable password <STRONG_PASSWORD> encrypted"],
                nist_controls=["IA-5", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-003",
                title="Set login banner warning message",
                description="CIS requires login banners to warn unauthorized users.",
                severity="LOW",
                benchmark_id="CIS ASA 1.1.3",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_login_banner",
                recommendation="Configure banner with legal warning",
                fix_commands=["banner login Unauthorized access prohibited"],
                nist_controls=["AC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-004",
                title="Disable HTTP server",
                description="CIS recommends disabling HTTP server to prevent unencrypted management.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 1.2.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_no_http_server",
                recommendation="Disable HTTP server",
                fix_commands=["no http server enable"],
                nist_controls=["SC-8", "CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-005",
                title="Enable SSH version 2",
                description="CIS requires SSHv2 only for secure management access.",
                severity="HIGH",
                benchmark_id="CIS ASA 1.2.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_ssh_version",
                recommendation="Configure SSH version 2 only",
                fix_commands=["ssh version 2"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-006",
                title="Configure management access restrictions",
                description="CIS requires restricting management access by IP.",
                severity="HIGH",
                benchmark_id="CIS ASA 1.2.3",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_management_access",
                recommendation="Restrict SSH/Telnet access to management network",
                fix_commands=["ssh <MGMT_NETWORK> <NETMASK> <INTERFACE>"],
                nist_controls=["AC-4", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-007",
                title="Configure AAA for management authentication",
                description="CIS requires AAA for centralized access control.",
                severity="HIGH",
                benchmark_id="CIS ASA 1.3.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_aaa_authentication",
                recommendation="Enable AAA authentication",
                fix_commands=["aaa authentication ssh console <SERVER_GROUP> LOCAL"],
                nist_controls=["IA-2", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-008",
                title="Configure logging to remote server",
                description="CIS requires centralized logging to remote server.",
                severity="HIGH",
                benchmark_id="CIS ASA 1.4.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_logging_host",
                recommendation="Configure remote syslog server",
                fix_commands=["logging host <INTERFACE> <SYSLOG_SERVER>"],
                nist_controls=["AU-4", "AU-9"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-009",
                title="Set logging trap level to informational",
                description="CIS requires appropriate logging level for security events.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 1.4.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_logging_trap",
                recommendation="Set logging trap to informational level",
                fix_commands=["logging trap informational"],
                nist_controls=["AU-2", "AU-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-010",
                title="Disable ICMP unreachable messages",
                description="CIS recommends disabling ICMP unreachables to prevent reconnaissance.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 1.5.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_icmp_unreachable",
                recommendation="Disable ICMP unreachable messages",
                fix_commands=["no icmp unreachable rate-limit 1 burst-size 1"],
                nist_controls=["SC-7"]
            ),
            # ASA Security Zones and Levels
            BenchmarkRule(
                rule_id="CIS-ASA-011",
                title="Configure security levels on all interfaces",
                description="ASA requires security levels (0-100) on all interfaces to control traffic flow.",
                severity="HIGH",
                benchmark_id="CIS ASA 2.1.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_security_levels",
                recommendation="Configure security-level on all nameif interfaces",
                fix_commands=["interface <INTERFACE>", " nameif <NAME>", " security-level <0-100>"],
                nist_controls=["SC-7", "AC-4"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-012",
                title="Configure 'same-security-traffic permit intra-interface' only when needed",
                description="ASA should restrict hairpin traffic unless explicitly required.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 2.1.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_same_security_traffic",
                recommendation="Only enable same-security-traffic when necessary",
                fix_commands=["no same-security-traffic permit intra-interface"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-013",
                title="Use object groups for ACL maintainability",
                description="ASA should use object groups for better ACL management and clarity.",
                severity="LOW",
                benchmark_id="CIS ASA 2.2.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_object_groups",
                recommendation="Use object-group network/service for ACLs",
                fix_commands=["object-group network <NAME>", " network-object host <IP>"],
                nist_controls=["CM-6"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-014",
                title="Enable threat detection",
                description="ASA threat detection identifies and responds to security threats.",
                severity="HIGH",
                benchmark_id="CIS ASA 2.3.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_threat_detection",
                recommendation="Enable threat-detection with appropriate thresholds",
                fix_commands=["threat-detection basic-threat", "threat-detection statistics"],
                nist_controls=["SI-4", "AU-6"]
            ),
            # ASA Modular Policy Framework (MPF)
            BenchmarkRule(
                rule_id="CIS-ASA-015",
                title="Configure inspection policies for critical protocols",
                description="ASA MPF should inspect application-layer protocols for security.",
                severity="HIGH",
                benchmark_id="CIS ASA 3.1.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_inspection_policies",
                recommendation="Configure policy-map type inspect for protocols",
                fix_commands=["policy-map type inspect dns preset_dns_map", " parameters", "  message-length maximum client auto", "  message-length maximum 512"],
                nist_controls=["SC-7", "SI-4"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-016",
                title="Configure connection limits",
                description="ASA should limit concurrent connections to prevent resource exhaustion.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 3.1.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_connection_limits",
                recommendation="Set connection limits in class-map/policy-map",
                fix_commands=["policy-map global_policy", " class class-default", "  set connection conn-max 65535"],
                nist_controls=["SC-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-017",
                title="Enable TCP normalization",
                description="ASA TCP normalization prevents TCP-based attacks.",
                severity="HIGH",
                benchmark_id="CIS ASA 3.1.3",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_tcp_normalization",
                recommendation="Configure TCP map with normalization",
                fix_commands=["tcp-map tcp-map-name", " check-retransmission", " exceed-mss allow"],
                nist_controls=["SC-7", "SI-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-018",
                title="Configure timeout values appropriately",
                description="ASA should have appropriate timeout values for connections.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 3.2.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_timeout_values",
                recommendation="Configure timeout values for conn, xlate, and sessions",
                fix_commands=["timeout xlate 3:00:00", "timeout conn 1:00:00 half-closed 0:10:00"],
                nist_controls=["SC-10"]
            ),
            # ASA Application Inspection
            BenchmarkRule(
                rule_id="CIS-ASA-019",
                title="Enable DNS inspection",
                description="ASA should inspect DNS traffic for security threats.",
                severity="HIGH",
                benchmark_id="CIS ASA 3.3.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_dns_inspection",
                recommendation="Enable DNS protocol inspection",
                fix_commands=["policy-map global_policy", " class inspection_default", "  inspect dns"],
                nist_controls=["SC-7", "SI-4"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-020",
                title="Enable HTTP/HTTPS inspection",
                description="ASA should inspect HTTP/HTTPS for application-layer attacks.",
                severity="HIGH",
                benchmark_id="CIS ASA 3.3.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_http_inspection",
                recommendation="Enable HTTP/HTTPS protocol inspection",
                fix_commands=["policy-map global_policy", " class inspection_default", "  inspect http"],
                nist_controls=["SC-7", "SI-4"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-021",
                title="Enable FTP inspection",
                description="ASA should inspect FTP to handle dynamic ports and prevent attacks.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 3.3.3",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_ftp_inspection",
                recommendation="Enable FTP protocol inspection",
                fix_commands=["policy-map global_policy", " class inspection_default", "  inspect ftp"],
                nist_controls=["SC-7", "SI-4"]
            ),
            # ASA VPN Security
            BenchmarkRule(
                rule_id="CIS-ASA-022",
                title="Use IKEv2 for site-to-site VPN",
                description="ASA should use IKEv2 instead of IKEv1 for improved security.",
                severity="HIGH",
                benchmark_id="CIS ASA 4.1.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_ikev2_vpn",
                recommendation="Configure IKEv2 policies for VPN",
                fix_commands=["crypto ikev2 policy 10", " encryption aes-256", " integrity sha256", " group 14"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-023",
                title="Use strong encryption for IPsec (AES-256)",
                description="ASA should use AES-256 or higher for IPsec encryption.",
                severity="CRITICAL",
                benchmark_id="CIS ASA 4.1.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_ipsec_encryption",
                recommendation="Use AES-256 for IPsec transform-sets",
                fix_commands=["crypto ipsec ikev2 ipsec-proposal AES256", " protocol esp encryption aes-256", " protocol esp integrity sha-256"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-024",
                title="Enable Perfect Forward Secrecy (PFS) for VPN",
                description="ASA VPN should use PFS to ensure session key independence.",
                severity="HIGH",
                benchmark_id="CIS ASA 4.1.3",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_vpn_pfs",
                recommendation="Configure PFS in crypto maps",
                fix_commands=["crypto map <NAME> <SEQ> set pfs group14"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-025",
                title="Restrict AnyConnect VPN to authorized users",
                description="ASA should restrict remote access VPN to authorized groups only.",
                severity="HIGH",
                benchmark_id="CIS ASA 4.2.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_anyconnect_auth",
                recommendation="Use AAA authentication for AnyConnect",
                fix_commands=["tunnel-group <NAME> general-attributes", " authentication-server-group <AAA_GROUP>"],
                nist_controls=["IA-2", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-026",
                title="Configure strong encryption for SSL VPN",
                description="ASA SSL VPN should use strong ciphers only.",
                severity="HIGH",
                benchmark_id="CIS ASA 4.2.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_ssl_vpn_ciphers",
                recommendation="Configure strong SSL cipher suites",
                fix_commands=["ssl cipher tlsv1.2 high"],
                nist_controls=["SC-13", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-027",
                title="Disable weak VPN protocols (PPTP, L2TP without IPsec)",
                description="ASA should not allow weak VPN protocols.",
                severity="CRITICAL",
                benchmark_id="CIS ASA 4.2.3",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_no_weak_vpn",
                recommendation="Disable PPTP and L2TP without IPsec",
                fix_commands=["no vpdn enable"],
                nist_controls=["SC-8", "CM-7"]
            ),
            # ASA NAT and Access Control
            BenchmarkRule(
                rule_id="CIS-ASA-028",
                title="Use twice NAT for better control",
                description="ASA should use twice NAT (network object NAT) for granular control.",
                severity="LOW",
                benchmark_id="CIS ASA 5.1.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_twice_nat",
                recommendation="Use network object NAT where possible",
                fix_commands=["object network <NAME>", " nat (inside,outside) dynamic interface"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-029",
                title="Restrict outbound access with ACLs",
                description="ASA should control outbound traffic, not just inbound.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 5.2.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_outbound_acls",
                recommendation="Apply ACLs to outbound interfaces",
                fix_commands=["access-group <ACL_NAME> out interface outside"],
                nist_controls=["SC-7", "AC-4"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-030",
                title="Configure ACL logging for denied traffic",
                description="ASA should log denied packets for security monitoring.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 5.2.2",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_acl_logging",
                recommendation="Add 'log' keyword to deny ACL entries",
                fix_commands=["access-list <NAME> deny ip any any log"],
                nist_controls=["AU-2", "AU-12"]
            ),
            # ASA Advanced Features
            BenchmarkRule(
                rule_id="CIS-ASA-031",
                title="Configure failover encryption",
                description="ASA failover should use encrypted communication.",
                severity="HIGH",
                benchmark_id="CIS ASA 6.1.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_failover_encryption",
                recommendation="Enable failover key encryption",
                fix_commands=["failover key <KEY>"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-032",
                title="Enable Botnet Traffic Filter",
                description="ASA should use Botnet Traffic Filter to block known malicious traffic.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 6.2.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_botnet_filter",
                recommendation="Enable and configure Botnet Traffic Filter",
                fix_commands=["dynamic-filter enable"],
                nist_controls=["SI-3", "SI-4"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-033",
                title="Configure AAA accounting for VPN",
                description="ASA should log all VPN sessions for audit purposes.",
                severity="HIGH",
                benchmark_id="CIS ASA 6.3.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_vpn_accounting",
                recommendation="Enable AAA accounting for VPN sessions",
                fix_commands=["aaa accounting vpn default start-stop group <AAA_GROUP>"],
                nist_controls=["AU-2", "AU-3", "AU-12"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-034",
                title="Disable unnecessary services (FTP, TFTP)",
                description="ASA should disable unused services to reduce attack surface.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 6.4.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_unnecessary_services",
                recommendation="Disable FTP and TFTP services",
                fix_commands=["no ftp mode passive"],
                nist_controls=["CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-ASA-035",
                title="Configure timezone and NTP for accurate timestamps",
                description="ASA should have correct time for log correlation and certificates.",
                severity="MEDIUM",
                benchmark_id="CIS ASA 6.5.1",
                benchmark_name="CIS Cisco ASA Benchmark",
                check_function="check_asa_ntp_timezone",
                recommendation="Configure clock timezone and NTP servers",
                fix_commands=["clock timezone EST -5", "ntp server <NTP_SERVER>"],
                nist_controls=["AU-8"]
            ),
            # ASA-Specific DISA STIG Rules (STIG-ASA-001 through STIG-ASA-010)
            BenchmarkRule(
                rule_id="STIG-ASA-001",
                title="Management access must be restricted by interface",
                description="STIG requires management access to be restricted to specific interfaces only.",
                severity="HIGH",
                benchmark_id="STIG V-3012",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_management_interface",
                recommendation="Restrict management access to management interface only",
                fix_commands=["http <mgmt_network> <mgmt_mask> <mgmt_interface>", "ssh <mgmt_network> <mgmt_mask> <mgmt_interface>"],
                nist_controls=["AC-4", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-002",
                title="AAA must be configured for device management",
                description="STIG requires centralized authentication for all administrative access.",
                severity="CRITICAL",
                benchmark_id="STIG V-3057",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_aaa_management",
                recommendation="Configure AAA for HTTP and SSH management",
                fix_commands=["aaa authentication http console <SERVER_GROUP> LOCAL", "aaa authentication ssh console <SERVER_GROUP> LOCAL"],
                nist_controls=["IA-2", "IA-5", "AC-2"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-003",
                title="Session timeout must not exceed 10 minutes",
                description="STIG requires automatic session termination after 10 minutes of inactivity.",
                severity="MEDIUM",
                benchmark_id="STIG V-3175",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_session_timeout",
                recommendation="Configure session timeout of 10 minutes or less",
                fix_commands=["ssh timeout 10", "http timeout 10"],
                nist_controls=["AC-12"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-004",
                title="Access-lists must log denied traffic",
                description="STIG requires logging of denied connections for security monitoring.",
                severity="MEDIUM",
                benchmark_id="STIG V-3062",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_acl_logging",
                recommendation="Enable logging on access-list deny statements",
                fix_commands=["access-list <name> extended deny ip any any log"],
                nist_controls=["AU-2", "AU-12"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-005",
                title="Privilege levels must be properly separated",
                description="STIG requires privilege level separation to implement least privilege.",
                severity="MEDIUM",
                benchmark_id="STIG V-3056",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_privilege_levels",
                recommendation="Configure privilege level commands for role separation",
                fix_commands=["privilege show level 5 mode exec command running-config"],
                nist_controls=["AC-6", "AC-6(1)"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-006",
                title="Connection timeout must be configured",
                description="STIG requires connection timeouts to free resources and prevent attacks.",
                severity="MEDIUM",
                benchmark_id="STIG V-3020",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_connection_timeout",
                recommendation="Configure connection timeouts for all connection types",
                fix_commands=["timeout conn 1:00:00", "timeout xlate 3:00:00"],
                nist_controls=["SC-10"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-007",
                title="SNMP community strings must not be default",
                description="STIG prohibits use of default SNMP community strings (public/private).",
                severity="HIGH",
                benchmark_id="STIG V-3143",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_snmp_default_community",
                recommendation="Change default SNMP community strings",
                fix_commands=["snmp-server community <STRONG_STRING> RO", "no snmp-server community public"],
                nist_controls=["IA-5", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-008",
                title="Management access must use encrypted protocols",
                description="STIG requires all management access to use encryption (SSH, HTTPS).",
                severity="HIGH",
                benchmark_id="STIG V-3058",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_encrypted_management",
                recommendation="Enable SSH and HTTPS, disable Telnet and HTTP",
                fix_commands=["ssh version 2", "http server enable", "no telnet"],
                nist_controls=["SC-8", "SC-8(1)"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-009",
                title="Security context admin must be restricted",
                description="STIG requires security context administrative access to be controlled.",
                severity="MEDIUM",
                benchmark_id="STIG V-3969",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_context_admin",
                recommendation="Restrict admin context access in multiple context mode",
                fix_commands=["context admin", " allocate-interface <mgmt_interface>"],
                nist_controls=["AC-4", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="STIG-ASA-010",
                title="Traffic inspection must be configured",
                description="STIG requires deep packet inspection for application-layer protocols.",
                severity="MEDIUM",
                benchmark_id="STIG V-3070",
                benchmark_name="DISA STIG for Cisco ASA",
                check_function="check_asa_stig_traffic_inspection",
                recommendation="Configure policy-map with inspect statements for common protocols",
                fix_commands=["policy-map global_policy", " class inspection_default", "  inspect http", "  inspect ftp"],
                nist_controls=["SC-7", "SI-4"]
            ),
        ]

    @staticmethod
    def get_cisco_nxos_rules() -> List[BenchmarkRule]:
        """Get CIS Cisco NX-OS benchmark rules."""
        return [
            BenchmarkRule(
                rule_id="CIS-NXOS-001",
                title="Set 'switchname' to organization-defined value",
                description="CIS recommends setting a unique hostname for device identification and management.",
                severity="LOW",
                benchmark_id="CIS NXOS 1.1.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_hostname_configured",
                recommendation="Configure a descriptive switchname",
                fix_commands=["switchname <UNIQUE_NAME>"],
                nist_controls=["CM-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-002",
                title="Enable password strength checking",
                description="CIS requires password strength checking for user accounts.",
                severity="HIGH",
                benchmark_id="CIS NXOS 1.1.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_password_strength",
                recommendation="Enable password strength checking",
                fix_commands=["password strength-check"],
                nist_controls=["IA-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-003",
                title="Set login banner warning message",
                description="CIS requires login banners to warn unauthorized users.",
                severity="LOW",
                benchmark_id="CIS NXOS 1.1.3",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_login_banner",
                recommendation="Configure banner with legal warning",
                fix_commands=["banner motd # Unauthorized access prohibited #"],
                nist_controls=["AC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-004",
                title="Enable 'feature ssh' and disable Telnet",
                description="CIS requires SSH for secure management access.",
                severity="HIGH",
                benchmark_id="CIS NXOS 1.2.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_ssh_enabled",
                recommendation="Enable SSH feature and disable Telnet",
                fix_commands=["feature ssh", "no feature telnet"],
                nist_controls=["SC-8", "AC-17"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-005",
                title="Configure SSH key strength",
                description="CIS requires strong SSH keys (2048-bit minimum).",
                severity="HIGH",
                benchmark_id="CIS NXOS 1.2.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_ssh_key_strength",
                recommendation="Generate strong SSH keys",
                fix_commands=["ssh key rsa 2048"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-006",
                title="Set exec-timeout on VTY lines",
                description="CIS requires session timeout ≤ 10 minutes.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 1.2.3",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_exec_timeout",
                recommendation="Set exec-timeout to 10 minutes or less",
                fix_commands=["line vty", " exec-timeout 10"],
                nist_controls=["AC-12", "SC-10"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-007",
                title="Enable AAA authentication",
                description="CIS requires AAA for centralized access control.",
                severity="HIGH",
                benchmark_id="CIS NXOS 1.3.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_aaa_authentication",
                recommendation="Enable AAA authentication",
                fix_commands=["aaa authentication login default group <SERVER_GROUP>"],
                nist_controls=["IA-2", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-008",
                title="Configure logging to remote server",
                description="CIS requires centralized logging to remote server.",
                severity="HIGH",
                benchmark_id="CIS NXOS 1.4.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_logging_server",
                recommendation="Configure remote logging server",
                fix_commands=["logging server <SYSLOG_SERVER>"],
                nist_controls=["AU-4", "AU-9"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-009",
                title="Set logging level to appropriate severity",
                description="CIS requires appropriate logging level for security events.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 1.4.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_logging_level",
                recommendation="Set logging level to informational",
                fix_commands=["logging level 6"],
                nist_controls=["AU-2", "AU-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-010",
                title="Disable unnecessary features",
                description="CIS recommends disabling unused features to reduce attack surface.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 1.5.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_unnecessary_features",
                recommendation="Disable unnecessary features like DHCP, DNS",
                fix_commands=["no feature dhcp", "no feature dns"],
                nist_controls=["CM-7"]
            ),
            # NXOS VDC (Virtual Device Context) Security
            BenchmarkRule(
                rule_id="CIS-NXOS-011",
                title="Configure VDC resource limits",
                description="NXOS VDCs should have resource limits to prevent resource exhaustion.",
                severity="HIGH",
                benchmark_id="CIS NXOS 2.1.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vdc_limits",
                recommendation="Configure CPU, memory, and interface limits for VDCs",
                fix_commands=["vdc <NAME>", " limit-resource <RESOURCE> <LIMIT>"],
                nist_controls=["SC-5", "SC-6"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-012",
                title="Separate management and data plane VDCs",
                description="NXOS should isolate management traffic in separate VDC.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 2.1.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vdc_separation",
                recommendation="Use separate VDCs for management and data",
                fix_commands=["vdc <MGMT_VDC>", " allocate interface <MGMT_INTERFACES>"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-013",
                title="Configure VDC HA policy",
                description="NXOS VDC should have high-availability configuration.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 2.1.3",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vdc_ha",
                recommendation="Configure VDC HA policy for failover",
                fix_commands=["vdc <NAME>", " ha-policy restart"],
                nist_controls=["CP-2", "SC-6"]
            ),
            # NXOS vPC (Virtual Port Channel) Security
            BenchmarkRule(
                rule_id="CIS-NXOS-014",
                title="Enable vPC peer-keepalive",
                description="NXOS vPC requires peer-keepalive for split-brain prevention.",
                severity="CRITICAL",
                benchmark_id="CIS NXOS 2.2.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vpc_keepalive",
                recommendation="Configure vPC peer-keepalive link",
                fix_commands=["vpc domain <ID>", " peer-keepalive destination <IP> source <IP>"],
                nist_controls=["SC-7", "CP-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-015",
                title="Configure vPC peer-link on dedicated interfaces",
                description="NXOS vPC peer-link should use dedicated high-bandwidth interfaces.",
                severity="HIGH",
                benchmark_id="CIS NXOS 2.2.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vpc_peerlink",
                recommendation="Use dedicated 10G+ interfaces for vPC peer-link",
                fix_commands=["interface port-channel <ID>", " vpc peer-link"],
                nist_controls=["SC-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-016",
                title="Enable vPC auto-recovery",
                description="NXOS vPC should enable auto-recovery for resilience.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 2.2.3",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vpc_autorecovery",
                recommendation="Enable vPC auto-recovery with appropriate delay",
                fix_commands=["vpc domain <ID>", " auto-recovery reload-delay 240"],
                nist_controls=["CP-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-017",
                title="Configure vPC role priority",
                description="NXOS vPC should have explicit primary/secondary role configuration.",
                severity="LOW",
                benchmark_id="CIS NXOS 2.2.4",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vpc_priority",
                recommendation="Configure vPC role priority explicitly",
                fix_commands=["vpc domain <ID>", " role priority 100"],
                nist_controls=["CM-6"]
            ),
            # NXOS FEX (Fabric Extender) Security
            BenchmarkRule(
                rule_id="CIS-NXOS-018",
                title="Authenticate FEX connections",
                description="NXOS should authenticate fabric extenders to prevent rogue FEX.",
                severity="HIGH",
                benchmark_id="CIS NXOS 2.3.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_fex_authentication",
                recommendation="Configure FEX pin security or AAA",
                fix_commands=["fex <ID>", " pinning max-links 1"],
                nist_controls=["IA-3", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-019",
                title="Configure FEX maximum links",
                description="NXOS should limit FEX uplink connections for predictability.",
                severity="LOW",
                benchmark_id="CIS NXOS 2.3.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_fex_maxlinks",
                recommendation="Set FEX max-links appropriately",
                fix_commands=["fex <ID>", " pinning max-links 2"],
                nist_controls=["CM-6"]
            ),
            # NXOS RBAC (Role-Based Access Control)
            BenchmarkRule(
                rule_id="CIS-NXOS-020",
                title="Use custom RBAC roles instead of default",
                description="NXOS should use custom roles with least privilege instead of defaults.",
                severity="HIGH",
                benchmark_id="CIS NXOS 3.1.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_custom_roles",
                recommendation="Create custom RBAC roles with minimal required privileges",
                fix_commands=["role name <CUSTOM_ROLE>", " rule 1 permit command configure terminal"],
                nist_controls=["AC-3", "AC-6"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-021",
                title="Configure RBAC session limits",
                description="NXOS should limit concurrent sessions per user role.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 3.1.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_session_limits",
                recommendation="Configure session limits for roles",
                fix_commands=["role name <ROLE>", " limit-max-sessions 5"],
                nist_controls=["AC-10"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-022",
                title="Enable command authorization for RBAC",
                description="NXOS should authorize commands based on RBAC roles.",
                severity="HIGH",
                benchmark_id="CIS NXOS 3.1.3",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_command_authorization",
                recommendation="Enable AAA command authorization",
                fix_commands=["aaa authorization commands default group <AAA_GROUP>"],
                nist_controls=["AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-023",
                title="Audit RBAC role assignments regularly",
                description="NXOS should have minimal users with network-admin role.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 3.1.4",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_admin_role_count",
                recommendation="Limit network-admin role to essential users only",
                fix_commands=["# Review: show user-account"],
                nist_controls=["AC-6", "AC-2"]
            ),
            # NXOS First-Hop Security
            BenchmarkRule(
                rule_id="CIS-NXOS-024",
                title="Enable IPv6 RA Guard",
                description="NXOS should protect against rogue IPv6 Router Advertisements.",
                severity="HIGH",
                benchmark_id="CIS NXOS 3.2.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_ra_guard",
                recommendation="Configure IPv6 RA Guard on access ports",
                fix_commands=["ipv6 nd raguard policy <NAME>", " device-role host"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-025",
                title="Enable IPv6 ND Inspection",
                description="NXOS should validate IPv6 Neighbor Discovery messages.",
                severity="HIGH",
                benchmark_id="CIS NXOS 3.2.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_nd_inspection",
                recommendation="Configure IPv6 ND inspection",
                fix_commands=["ipv6 nd inspection policy <NAME>", " device-role host", " drop-unsecure"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-026",
                title="Enable IPv6 DHCP Guard",
                description="NXOS should prevent rogue IPv6 DHCP servers.",
                severity="HIGH",
                benchmark_id="CIS NXOS 3.2.3",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_dhcpv6_guard",
                recommendation="Configure IPv6 DHCP Guard on access ports",
                fix_commands=["ipv6 dhcp guard policy <NAME>", " device-role client"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-027",
                title="Enable IPv6 Source Guard",
                description="NXOS should validate IPv6 source addresses to prevent spoofing.",
                severity="HIGH",
                benchmark_id="CIS NXOS 3.2.4",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_ipv6_source_guard",
                recommendation="Configure IPv6 Source Guard",
                fix_commands=["ipv6 source-guard policy <NAME>", " deny global-autoconf"],
                nist_controls=["SC-7"]
            ),
            # NXOS Advanced Features
            BenchmarkRule(
                rule_id="CIS-NXOS-028",
                title="Enable BFD for fast failure detection",
                description="NXOS should use BFD for rapid link/protocol failure detection.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 4.1.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_bfd",
                recommendation="Enable BFD for critical routing protocols",
                fix_commands=["feature bfd", "interface <INTERFACE>", " bfd interval 50 min_rx 50 multiplier 3"],
                nist_controls=["CP-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-029",
                title="Configure graceful restart for routing protocols",
                description="NXOS should use graceful restart for hitless failover.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 4.1.2",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_graceful_restart",
                recommendation="Enable graceful-restart for OSPF/BGP",
                fix_commands=["router ospf <ID>", " graceful-restart"],
                nist_controls=["CP-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-030",
                title="Enable CFS authentication",
                description="NXOS Cisco Fabric Services should use authentication.",
                severity="HIGH",
                benchmark_id="CIS NXOS 4.2.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_cfs_authentication",
                recommendation="Enable CFS distribution authentication",
                fix_commands=["cfs distribute", " enable-authentication"],
                nist_controls=["IA-3", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-031",
                title="Configure VXLAN security",
                description="NXOS VXLAN should have proper security controls.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 4.3.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_vxlan_security",
                recommendation="Configure VXLAN with authentication",
                fix_commands=["feature nv overlay", "evpn control-plane"],
                nist_controls=["SC-7", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-032",
                title="Enable port tracking for critical interfaces",
                description="NXOS should track port states for automated failover.",
                severity="LOW",
                benchmark_id="CIS NXOS 4.4.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_port_tracking",
                recommendation="Configure port tracking for uplinks",
                fix_commands=["track 1 interface <INTERFACE> line-protocol"],
                nist_controls=["CP-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-033",
                title="Configure system QoS policies",
                description="NXOS should have QoS policies to prevent DoS and ensure service levels.",
                severity="MEDIUM",
                benchmark_id="CIS NXOS 4.5.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_qos_policies",
                recommendation="Configure system QoS and rate limiting",
                fix_commands=["class-map type qos <NAME>", " match access-group name <ACL>"],
                nist_controls=["SC-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-034",
                title="Enable SNMP v3 only",
                description="NXOS should disable SNMPv1/v2c and use only SNMPv3 with authentication.",
                severity="HIGH",
                benchmark_id="CIS NXOS 4.6.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_snmpv3_only",
                recommendation="Remove SNMPv1/v2c communities, use SNMPv3",
                fix_commands=["snmp-server user <USER> <GROUP> auth sha <KEY> priv aes-128 <KEY>"],
                nist_controls=["SC-8", "IA-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-NXOS-035",
                title="Configure configuration checkpoint auto-backup",
                description="NXOS should automatically backup configurations for rollback capability.",
                severity="LOW",
                benchmark_id="CIS NXOS 4.7.1",
                benchmark_name="CIS Cisco NX-OS Benchmark",
                check_function="check_nxos_checkpoint_auto",
                recommendation="Enable automatic configuration checkpoints",
                fix_commands=["checkpoint auto"],
                nist_controls=["CP-9", "CM-3"]
            ),
            # NXOS-Specific DISA STIG Rules (STIG-NXOS-001 through STIG-NXOS-010)
            BenchmarkRule(
                rule_id="STIG-NXOS-001",
                title="NXOS must enforce password complexity",
                description="STIG requires strong password policies to prevent brute force attacks.",
                severity="HIGH",
                benchmark_id="STIG V-3057",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_password_complexity",
                recommendation="Configure password strength checking and complexity requirements",
                fix_commands=["password strength-check", "no password strength-check default"],
                nist_controls=["IA-5", "IA-5(1)"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-002",
                title="NXOS must require authentication for management access",
                description="STIG requires AAA authentication for all administrative access.",
                severity="CRITICAL",
                benchmark_id="STIG V-3056",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_aaa_authentication",
                recommendation="Configure AAA authentication for console and default",
                fix_commands=["aaa authentication login console group <SERVER_GROUP>", "aaa authentication login default group <SERVER_GROUP>"],
                nist_controls=["IA-2", "IA-5", "AC-2"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-003",
                title="NXOS session timeout must not exceed 10 minutes",
                description="STIG requires automatic session termination after 10 minutes of inactivity.",
                severity="MEDIUM",
                benchmark_id="STIG V-3175",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_session_timeout",
                recommendation="Configure exec-timeout of 10 minutes or less on all lines",
                fix_commands=["line console", " exec-timeout 10", "line vty", " exec-timeout 10"],
                nist_controls=["AC-12"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-004",
                title="NXOS must use FIPS 140-2 validated cryptography",
                description="STIG requires FIPS mode for all cryptographic operations.",
                severity="HIGH",
                benchmark_id="STIG V-3069",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_fips_mode",
                recommendation="Enable FIPS mode for cryptographic operations",
                fix_commands=["fips mode enable"],
                nist_controls=["SC-13", "IA-7"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-005",
                title="NXOS must log all commands executed",
                description="STIG requires accounting of all commands for audit purposes.",
                severity="MEDIUM",
                benchmark_id="STIG V-3062",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_command_accounting",
                recommendation="Configure AAA accounting for commands",
                fix_commands=["aaa accounting default group <SERVER_GROUP>"],
                nist_controls=["AU-2", "AU-12"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-006",
                title="NXOS must protect against TCP SYN floods",
                description="STIG requires TCP connection limits to prevent DoS attacks.",
                severity="MEDIUM",
                benchmark_id="STIG V-3020",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_tcp_limits",
                recommendation="Configure TCP connection limits and timeouts",
                fix_commands=["ip tcp path-mtu-discovery"],
                nist_controls=["SC-5", "SC-5(1)"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-007",
                title="NXOS must not use default SNMP community strings",
                description="STIG prohibits use of default SNMP community strings (public/private).",
                severity="HIGH",
                benchmark_id="STIG V-3143",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_snmp_default_community",
                recommendation="Remove default SNMP community strings",
                fix_commands=["no snmp-server community public", "no snmp-server community private"],
                nist_controls=["IA-5", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-008",
                title="NXOS must use SNMPv3 with authentication and encryption",
                description="STIG requires SNMPv3 with priv level for secure management.",
                severity="HIGH",
                benchmark_id="STIG V-3143",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_snmpv3_security",
                recommendation="Configure SNMPv3 with auth and priv",
                fix_commands=["snmp-server user <USER> <GROUP> auth sha <AUTH_KEY> priv aes-128 <PRIV_KEY>"],
                nist_controls=["SC-8", "IA-5"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-009",
                title="NXOS must restrict management access by source",
                description="STIG requires ACLs to restrict management access to authorized networks.",
                severity="HIGH",
                benchmark_id="STIG V-3012",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_management_acl",
                recommendation="Configure ACL for management interface access",
                fix_commands=["ip access-list MGMT-ACCESS", " permit ip <MGMT_NETWORK> any", "interface mgmt0", " ip access-group MGMT-ACCESS in"],
                nist_controls=["AC-4", "SC-7"]
            ),
            BenchmarkRule(
                rule_id="STIG-NXOS-010",
                title="NXOS must have unique VLAN for management traffic",
                description="STIG requires management traffic to be segregated from user traffic.",
                severity="MEDIUM",
                benchmark_id="STIG V-3013",
                benchmark_name="DISA STIG for Cisco NX-OS",
                check_function="check_nxos_stig_management_vlan",
                recommendation="Use dedicated VLAN or out-of-band management",
                fix_commands=["interface mgmt0", " ip address <MGMT_IP> <MGMT_MASK>"],
                nist_controls=["SC-7", "AC-4"]
            ),
        ]


class DISTIGRules:
    """DISA STIG validation rules."""

    @staticmethod
    def get_cisco_ios_rules() -> List[BenchmarkRule]:
        """Get DISA STIG Cisco IOS rules."""
        return [
            BenchmarkRule(
                rule_id="STIG-001",
                title="Network device must require authentication for console access",
                description="STIG V-3056: Requires authentication on console line.",
                severity="CRITICAL",
                benchmark_id="V-3056",
                benchmark_name="DISA STIG",
                check_function="check_console_authentication",
                recommendation="Configure authentication on console",
                fix_commands=["line console 0", " login authentication default"],
                nist_controls=["IA-2", "AC-17"]
            ),
            BenchmarkRule(
                rule_id="STIG-002",
                title="Network device must use FIPS 140-2 approved algorithms",
                description="STIG V-3057: Requires FIPS-approved cryptographic algorithms.",
                severity="HIGH",
                benchmark_id="V-3057",
                benchmark_name="DISA STIG",
                check_function="check_fips_mode",
                recommendation="Enable FIPS mode if supported",
                fix_commands=["crypto key generate rsa modulus 2048", "ip ssh version 2"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="STIG-003",
                title="Network device must display security banner before login",
                description="STIG V-3058: Requires DoD-approved banner.",
                severity="MEDIUM",
                benchmark_id="V-3058",
                benchmark_name="DISA STIG",
                check_function="check_dod_banner",
                recommendation="Configure DoD standard banner",
                fix_commands=["banner login ^C You are accessing a U.S. Government (USG) Information System (IS)... ^C"],
                nist_controls=["AC-8"]
            ),
            BenchmarkRule(
                rule_id="STIG-004",
                title="Network device must protect audit information",
                description="STIG V-3059: Requires secure logging configuration.",
                severity="HIGH",
                benchmark_id="V-3059",
                benchmark_name="DISA STIG",
                check_function="check_logging_protection",
                recommendation="Configure logging to secure syslog server",
                fix_commands=["logging host <SYSLOG_SERVER>", "logging trap informational"],
                nist_controls=["AU-9"]
            ),
            BenchmarkRule(
                rule_id="STIG-005",
                title="Network device must enforce minimum 15-character password length",
                description="STIG V-3210: Requires minimum password length of 15 characters.",
                severity="HIGH",
                benchmark_id="V-3210",
                benchmark_name="DISA STIG",
                check_function="check_password_length",
                recommendation="Set security passwords min-length 15",
                fix_commands=["security passwords min-length 15"],
                nist_controls=["IA-5(1)"]
            ),
            BenchmarkRule(
                rule_id="STIG-006",
                title="Network device must terminate inactive sessions after 10 minutes",
                description="STIG V-3058: Requires session timeout.",
                severity="MEDIUM",
                benchmark_id="V-3058",
                benchmark_name="DISA STIG",
                check_function="check_session_timeout_stig",
                recommendation="Set exec-timeout to 10 minutes or less",
                fix_commands=["line vty 0 4", " exec-timeout 10 0"],
                nist_controls=["AC-12"]
            ),
            BenchmarkRule(
                rule_id="STIG-007",
                title="Network device must use DoD PKI-established certificate authorities",
                description="STIG V-3069: Requires DoD PKI certificates.",
                severity="MEDIUM",
                benchmark_id="V-3069",
                benchmark_name="DISA STIG",
                check_function="check_pki_certificates",
                recommendation="Configure DoD PKI trustpoint",
                fix_commands=["crypto pki trustpoint DOD_CA", " enrollment url http://crl.disa.mil"],
                nist_controls=["SC-17"]
            ),
            BenchmarkRule(
                rule_id="STIG-008",
                title="Network device must not use SNMPv1 or v2c",
                description="STIG V-3143: Prohibits SNMPv1/v2c due to weak authentication.",
                severity="HIGH",
                benchmark_id="V-3143",
                benchmark_name="DISA STIG",
                check_function="check_snmp_version",
                recommendation="Use SNMPv3 only",
                fix_commands=["no snmp-server community <STRING>", "snmp-server group <GROUP> v3 priv"],
                nist_controls=["IA-2", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="STIG-009",
                title="Network device must implement control plane policing",
                description="STIG V-3175: Requires CoPP to protect control plane.",
                severity="MEDIUM",
                benchmark_id="V-3175",
                benchmark_name="DISA STIG",
                check_function="check_control_plane_policing",
                recommendation="Implement control plane policing",
                fix_commands=["control-plane", " service-policy input COPP-POLICY"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="STIG-010",
                title="Network device must restrict management access by IP",
                description="STIG V-3057: Requires access control for management.",
                severity="HIGH",
                benchmark_id="V-3057",
                benchmark_name="DISA STIG",
                check_function="check_management_acl",
                recommendation="Apply ACL to restrict management access",
                fix_commands=["access-list 10 permit <MGMT_NETWORK>", "line vty 0 4", " access-class 10 in"],
                nist_controls=["AC-4", "SC-7"]
            ),
        ]


class VendorHardeningGuideRules:
    """Vendor-specific hardening guide rules."""

    @staticmethod
    def get_cisco_hardening_rules() -> List[BenchmarkRule]:
        """Get Cisco hardening guide rules."""
        return [
            BenchmarkRule(
                rule_id="CISCO-HARD-001",
                title="Disable unnecessary services",
                description="Cisco hardening guide recommends disabling unused services.",
                severity="MEDIUM",
                benchmark_id="Cisco Guide Section 2.1",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_unnecessary_services",
                recommendation="Disable unnecessary services like CDP, finger, PAD",
                fix_commands=["no cdp run", "no ip finger", "no service pad"],
                nist_controls=["CM-7"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-002",
                title="Configure TCP keepalives",
                description="Cisco recommends TCP keepalives to prevent resource exhaustion.",
                severity="LOW",
                benchmark_id="Cisco Guide Section 2.2",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_tcp_keepalives",
                recommendation="Enable TCP keepalives",
                fix_commands=["service tcp-keepalives-in", "service tcp-keepalives-out"],
                nist_controls=["SC-5"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-003",
                title="Disable ICMP redirects",
                description="Cisco recommends disabling ICMP redirects to prevent routing attacks.",
                severity="MEDIUM",
                benchmark_id="Cisco Guide Section 3.1",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_no_icmp_redirects",
                recommendation="Disable ICMP redirects on interfaces",
                fix_commands=["interface <INTERFACE>", " no ip redirects"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-004",
                title="Enable unicast RPF on interfaces",
                description="Cisco recommends uRPF to prevent IP spoofing.",
                severity="HIGH",
                benchmark_id="Cisco Guide Section 3.2",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_urpf_enabled",
                recommendation="Enable uRPF on external-facing interfaces",
                fix_commands=["interface <INTERFACE>", " ip verify unicast source reachable-via rx"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-005",
                title="Configure NTP authentication",
                description="Cisco requires NTP authentication to prevent time manipulation.",
                severity="MEDIUM",
                benchmark_id="Cisco Guide Section 4.1",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_ntp_authentication",
                recommendation="Enable NTP authentication",
                fix_commands=["ntp authenticate", "ntp trusted-key 1", "ntp authentication-key 1 md5 <KEY>"],
                nist_controls=["SC-45"]
            ),
        ]
