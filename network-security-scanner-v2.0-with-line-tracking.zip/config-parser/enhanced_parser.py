#!/usr/bin/env python3
"""Enhanced configuration parser with Genie-inspired patterns.

This module provides advanced parsing capabilities for complex Cisco configurations:
- Multi-line interface configurations
- Crypto maps and IPSec configurations
- Route-maps with match/set statements
- Complex ACLs (numbered and named)
"""

import re
from typing import Dict, List, Any, Optional
from pathlib import Path
import sys

# Add rule-engines to path
SCRIPT_DIR = Path(__file__).parent
RULE_ENGINE_PATH = SCRIPT_DIR.parent / 'rule-engines'
sys.path.insert(0, str(RULE_ENGINE_PATH))

from scanner.core import ConfigLine


class EnhancedConfigParser:
    """Enhanced parser using patterns learned from Genie."""

    def __init__(self):
        """Initialize parser with regex patterns."""
        # Interface patterns
        self.interface_pattern = re.compile(r'^interface\s+(\S+)', re.I)

        # Crypto patterns
        self.crypto_isakmp_policy = re.compile(r'^crypto isakmp policy\s+(\d+)', re.I)
        self.crypto_transform_set = re.compile(r'^crypto ipsec transform-set\s+(\S+)\s+(.+)', re.I)
        self.crypto_map = re.compile(r'^crypto map\s+(\S+)\s+(\d+)\s+(\S+)', re.I)

        # Route-map patterns
        self.routemap_pattern = re.compile(r'^route-map\s+(\S+)\s+(permit|deny)\s+(\d+)', re.I)

        # ACL patterns
        self.numbered_acl = re.compile(r'^access-list\s+(\d+)\s+(permit|deny)\s+(.+)', re.I)
        self.named_acl_start = re.compile(r'^ip access-list\s+(standard|extended)\s+(\S+)', re.I)
        self.named_acl_entry = re.compile(r'^\s+(permit|deny|remark)\s+(.+)', re.I)

        # Generic indentation pattern
        self.indented = re.compile(r'^\s+(.+)')

    def parse_interfaces(self, config_lines: List[ConfigLine]) -> Dict[str, Any]:
        """Parse interface configurations with full context.

        Args:
            config_lines: List of configuration lines

        Returns:
            Dictionary of interfaces with their configurations
        """
        interfaces = {}
        current_interface = None

        for line in config_lines:
            content = line.content.strip()

            # Interface declaration
            m = self.interface_pattern.match(content)
            if m:
                interface_name = m.group(1)
                current_interface = interface_name
                interfaces[interface_name] = {
                    'name': interface_name,
                    'description': None,
                    'ip_address': None,
                    'access_group_in': None,
                    'access_group_out': None,
                    'shutdown': False,
                    'switchport_mode': None,
                    'vlan': None,
                    'hsrp': {},  # HSRP groups
                    'vrrp': {},  # VRRP groups
                    'tunnel': None,  # GRE/tunnel config
                    'security_features': [],
                    'config_lines': [line]
                }

                # Initialize tunnel config if this is a tunnel interface
                if 'tunnel' in interface_name.lower():
                    interfaces[interface_name]['tunnel'] = {
                        'source': None,
                        'destination': None,
                        'mode': None,
                        'key': None,
                        'keepalive': False,
                        'protection': None,  # IPsec protection
                        'crypto_map': None
                    }
                continue

            # Interface configuration (indented)
            if current_interface and line.indentation > 0:
                interfaces[current_interface]['config_lines'].append(line)

                # Parse specific settings
                if content.startswith('description '):
                    interfaces[current_interface]['description'] = content[12:].strip()

                elif content.startswith('ip address '):
                    parts = content.split()
                    if len(parts) >= 3:
                        interfaces[current_interface]['ip_address'] = {
                            'address': parts[2],
                            'mask': parts[3] if len(parts) > 3 else None
                        }

                elif content.startswith('ip access-group '):
                    parts = content.split()
                    if len(parts) >= 3:
                        acl_name = parts[2]
                        direction = parts[3] if len(parts) > 3 else 'in'
                        if direction == 'in':
                            interfaces[current_interface]['access_group_in'] = acl_name
                        else:
                            interfaces[current_interface]['access_group_out'] = acl_name

                elif content == 'shutdown':
                    interfaces[current_interface]['shutdown'] = True

                elif content == 'no shutdown':
                    interfaces[current_interface]['shutdown'] = False

                elif content.startswith('switchport mode '):
                    interfaces[current_interface]['switchport_mode'] = content.split()[-1]

                elif content.startswith('switchport access vlan '):
                    interfaces[current_interface]['vlan'] = content.split()[-1]

                # HSRP configuration (standby)
                elif content.startswith('standby '):
                    parts = content.split()
                    if len(parts) >= 2:
                        group_num = parts[1]

                        # Initialize group if not exists
                        if group_num not in interfaces[current_interface]['hsrp']:
                            interfaces[current_interface]['hsrp'][group_num] = {
                                'group': group_num,
                                'ip': None,
                                'priority': 100,  # Default
                                'preempt': False,
                                'authentication': None,
                                'timers': None,
                                'track': []
                            }

                        # Parse HSRP parameters
                        if 'ip' in parts:
                            ip_idx = parts.index('ip')
                            if ip_idx + 1 < len(parts):
                                interfaces[current_interface]['hsrp'][group_num]['ip'] = parts[ip_idx + 1]

                        elif 'priority' in parts:
                            pri_idx = parts.index('priority')
                            if pri_idx + 1 < len(parts):
                                interfaces[current_interface]['hsrp'][group_num]['priority'] = int(parts[pri_idx + 1])

                        elif 'preempt' in parts:
                            interfaces[current_interface]['hsrp'][group_num]['preempt'] = True

                        elif 'authentication' in parts:
                            auth_idx = parts.index('authentication')
                            if auth_idx + 1 < len(parts):
                                interfaces[current_interface]['hsrp'][group_num]['authentication'] = ' '.join(parts[auth_idx + 1:])

                        elif 'timers' in parts:
                            timers_idx = parts.index('timers')
                            if timers_idx + 2 < len(parts):
                                interfaces[current_interface]['hsrp'][group_num]['timers'] = {
                                    'hello': parts[timers_idx + 1],
                                    'hold': parts[timers_idx + 2]
                                }

                        elif 'track' in parts:
                            track_idx = parts.index('track')
                            if track_idx + 1 < len(parts):
                                interfaces[current_interface]['hsrp'][group_num]['track'].append(' '.join(parts[track_idx + 1:]))

                # VRRP configuration
                elif content.startswith('vrrp '):
                    parts = content.split()
                    if len(parts) >= 2:
                        group_num = parts[1]

                        # Initialize group if not exists
                        if group_num not in interfaces[current_interface]['vrrp']:
                            interfaces[current_interface]['vrrp'][group_num] = {
                                'group': group_num,
                                'ip': None,
                                'priority': 100,  # Default
                                'preempt': False,
                                'authentication': None,
                                'timers': None
                            }

                        # Parse VRRP parameters
                        if 'ip' in parts:
                            ip_idx = parts.index('ip')
                            if ip_idx + 1 < len(parts):
                                interfaces[current_interface]['vrrp'][group_num]['ip'] = parts[ip_idx + 1]

                        elif 'priority' in parts:
                            pri_idx = parts.index('priority')
                            if pri_idx + 1 < len(parts):
                                interfaces[current_interface]['vrrp'][group_num]['priority'] = int(parts[pri_idx + 1])

                        elif 'preempt' in parts:
                            interfaces[current_interface]['vrrp'][group_num]['preempt'] = True

                        elif 'authentication' in parts:
                            auth_idx = parts.index('authentication')
                            if auth_idx + 1 < len(parts):
                                interfaces[current_interface]['vrrp'][group_num]['authentication'] = ' '.join(parts[auth_idx + 1:])

                        elif 'timers' in parts:
                            timers_idx = parts.index('timers')
                            if timers_idx + 2 < len(parts):
                                interfaces[current_interface]['vrrp'][group_num]['timers'] = {
                                    'advertise': parts[timers_idx + 1]
                                }

                # GRE/Tunnel configuration
                elif content.startswith('tunnel ') and interfaces[current_interface].get('tunnel') is not None:
                    parts = content.split()
                    tunnel_cfg = interfaces[current_interface]['tunnel']

                    if 'source' in parts:
                        src_idx = parts.index('source')
                        if src_idx + 1 < len(parts):
                            tunnel_cfg['source'] = parts[src_idx + 1]

                    elif 'destination' in parts:
                        dst_idx = parts.index('destination')
                        if dst_idx + 1 < len(parts):
                            tunnel_cfg['destination'] = parts[dst_idx + 1]

                    elif 'mode' in parts:
                        mode_idx = parts.index('mode')
                        if mode_idx + 1 < len(parts):
                            tunnel_cfg['mode'] = ' '.join(parts[mode_idx + 1:])

                    elif 'key' in parts:
                        key_idx = parts.index('key')
                        if key_idx + 1 < len(parts):
                            tunnel_cfg['key'] = parts[key_idx + 1]

                    elif 'protection' in parts:
                        # tunnel protection ipsec profile <name>
                        tunnel_cfg['protection'] = ' '.join(parts[1:])

                elif content.startswith('keepalive') and interfaces[current_interface].get('tunnel') is not None:
                    interfaces[current_interface]['tunnel']['keepalive'] = True

                elif content.startswith('crypto map ') and interfaces[current_interface].get('tunnel') is not None:
                    # crypto map applied to interface
                    parts = content.split()
                    if len(parts) >= 3:
                        interfaces[current_interface]['tunnel']['crypto_map'] = parts[2]

                # Track security features
                security_keywords = ['ip verify', 'no ip redirects', 'no ip proxy-arp',
                                    'storm-control', 'port-security', 'dhcp snooping']
                for keyword in security_keywords:
                    if keyword in content.lower():
                        interfaces[current_interface]['security_features'].append(content)

            # End of interface block
            elif line.indentation == 0 and current_interface and not content.startswith('interface'):
                current_interface = None

        return interfaces

    def parse_crypto_config(self, config_lines: List[ConfigLine]) -> Dict[str, Any]:
        """Parse crypto map and IPSec configurations.

        Args:
            config_lines: List of configuration lines

        Returns:
            Dictionary with crypto configurations
        """
        crypto_config = {
            'isakmp_policies': {},
            'transform_sets': {},
            'crypto_maps': {}
        }

        current_section = None
        current_section_type = None

        for line in config_lines:
            content = line.content.strip()

            # ISAKMP policy
            m = self.crypto_isakmp_policy.match(content)
            if m:
                policy_num = m.group(1)
                current_section = policy_num
                current_section_type = 'isakmp'
                crypto_config['isakmp_policies'][policy_num] = {
                    'policy_number': policy_num,
                    'encryption': None,
                    'hash': None,
                    'authentication': None,
                    'group': None,
                    'lifetime': None,
                    'config_lines': [line]
                }
                continue

            # Transform set
            m = self.crypto_transform_set.match(content)
            if m:
                set_name = m.group(1)
                transforms = m.group(2)
                current_section = set_name
                current_section_type = 'transform'
                crypto_config['transform_sets'][set_name] = {
                    'name': set_name,
                    'transforms': transforms,
                    'mode': None,
                    'config_lines': [line]
                }
                continue

            # Crypto map
            m = self.crypto_map.match(content)
            if m:
                map_name = m.group(1)
                sequence = m.group(2)
                map_type = m.group(3)
                map_key = f"{map_name} {sequence}"
                current_section = map_key
                current_section_type = 'map'

                if map_name not in crypto_config['crypto_maps']:
                    crypto_config['crypto_maps'][map_name] = {}

                crypto_config['crypto_maps'][map_name][sequence] = {
                    'sequence': int(sequence),
                    'type': map_type,
                    'peer': None,
                    'transform_set': None,
                    'match_address': None,
                    'config_lines': [line]
                }
                continue

            # Indented configuration
            m = self.indented.match(line.content)
            if m and current_section:
                config = m.group(1).strip()

                if current_section_type == 'isakmp':
                    crypto_config['isakmp_policies'][current_section]['config_lines'].append(line)
                    # Parse ISAKMP settings
                    if config.startswith('encr ') or config.startswith('encryption '):
                        crypto_config['isakmp_policies'][current_section]['encryption'] = config.split()[-1]
                    elif config.startswith('hash '):
                        crypto_config['isakmp_policies'][current_section]['hash'] = config.split()[-1]
                    elif config.startswith('authentication '):
                        crypto_config['isakmp_policies'][current_section]['authentication'] = config.split()[-1]
                    elif config.startswith('group '):
                        crypto_config['isakmp_policies'][current_section]['group'] = config.split()[-1]
                    elif config.startswith('lifetime '):
                        crypto_config['isakmp_policies'][current_section]['lifetime'] = config.split()[-1]

                elif current_section_type == 'transform':
                    crypto_config['transform_sets'][current_section]['config_lines'].append(line)
                    if config.startswith('mode '):
                        crypto_config['transform_sets'][current_section]['mode'] = config.split()[-1]

                elif current_section_type == 'map':
                    map_name, seq = current_section.rsplit(' ', 1)
                    crypto_config['crypto_maps'][map_name][seq]['config_lines'].append(line)
                    if config.startswith('set peer '):
                        crypto_config['crypto_maps'][map_name][seq]['peer'] = config.split()[-1]
                    elif config.startswith('set transform-set '):
                        crypto_config['crypto_maps'][map_name][seq]['transform_set'] = config.split()[-1]
                    elif config.startswith('match address '):
                        crypto_config['crypto_maps'][map_name][seq]['match_address'] = config.split()[-1]

            # End of section
            elif line.indentation == 0 and current_section:
                current_section = None
                current_section_type = None

        return crypto_config

    def parse_route_maps(self, config_lines: List[ConfigLine]) -> Dict[str, Any]:
        """Parse route-map configurations.

        Args:
            config_lines: List of configuration lines

        Returns:
            Dictionary of route-maps
        """
        route_maps = {}
        current_map = None
        current_sequence = None

        for line in config_lines:
            content = line.content.strip()

            # Route-map declaration
            m = self.routemap_pattern.match(content)
            if m:
                map_name = m.group(1)
                action = m.group(2)
                sequence = m.group(3)

                current_map = map_name
                current_sequence = sequence

                if map_name not in route_maps:
                    route_maps[map_name] = {}

                route_maps[map_name][sequence] = {
                    'sequence': int(sequence),
                    'action': action,
                    'match_clauses': [],
                    'set_clauses': [],
                    'description': None,
                    'config_lines': [line]
                }
                continue

            # Route-map entries (indented)
            m = self.indented.match(line.content)
            if m and current_map and current_sequence:
                config = m.group(1).strip()
                route_maps[current_map][current_sequence]['config_lines'].append(line)

                # Parse match clauses
                if config.startswith('match '):
                    match_clause = config[6:]  # Remove 'match '
                    route_maps[current_map][current_sequence]['match_clauses'].append(match_clause)

                # Parse set clauses
                elif config.startswith('set '):
                    set_clause = config[4:]  # Remove 'set '
                    route_maps[current_map][current_sequence]['set_clauses'].append(set_clause)

                # Description
                elif config.startswith('description '):
                    route_maps[current_map][current_sequence]['description'] = config[12:]

            # End of route-map
            elif line.indentation == 0 and current_map:
                current_map = None
                current_sequence = None

        return route_maps

    def parse_acls(self, config_lines: List[ConfigLine]) -> Dict[str, Any]:
        """Parse both numbered and named ACLs.

        Args:
            config_lines: List of configuration lines

        Returns:
            Dictionary with numbered and named ACLs
        """
        acls = {
            'numbered': {},
            'named': {}
        }

        current_named_acl = None

        for line in config_lines:
            content = line.content.strip()

            # Numbered ACL
            m = self.numbered_acl.match(content)
            if m:
                acl_num = m.group(1)
                action = m.group(2)
                rule = m.group(3)

                if acl_num not in acls['numbered']:
                    # Determine type based on number range
                    # 1-99, 1300-1999: standard
                    # 100-199, 2000-2699: extended
                    num = int(acl_num)
                    if (1 <= num <= 99) or (1300 <= num <= 1999):
                        acl_type = 'standard'
                    else:
                        acl_type = 'extended'

                    acls['numbered'][acl_num] = {
                        'number': acl_num,
                        'type': acl_type,
                        'entries': []
                    }

                acls['numbered'][acl_num]['entries'].append({
                    'action': action,
                    'rule': rule,
                    'line': line
                })
                continue

            # Named ACL start
            m = self.named_acl_start.match(content)
            if m:
                acl_type = m.group(1)
                acl_name = m.group(2)
                current_named_acl = acl_name

                acls['named'][acl_name] = {
                    'name': acl_name,
                    'type': acl_type,
                    'entries': []
                }
                continue

            # Named ACL entry
            m = self.named_acl_entry.match(line.content)
            if m and current_named_acl:
                action = m.group(1)
                rule = m.group(2)

                acls['named'][current_named_acl]['entries'].append({
                    'action': action,
                    'rule': rule,
                    'line': line
                })
                continue

            # End of named ACL
            if line.indentation == 0 and current_named_acl and not content.startswith(' '):
                current_named_acl = None

        return acls

    def parse_all(self, config_lines: List[ConfigLine]) -> Dict[str, Any]:
        """Parse all advanced configuration sections.

        Args:
            config_lines: List of configuration lines

        Returns:
            Dictionary with all parsed configurations
        """
        return {
            'interfaces': self.parse_interfaces(config_lines),
            'crypto': self.parse_crypto_config(config_lines),
            'route_maps': self.parse_route_maps(config_lines),
            'acls': self.parse_acls(config_lines)
        }
