#!/usr/bin/env python3
"""Genie Parser Integration for structured configuration parsing.

This module provides integration with Cisco's Genie parser to convert
raw configuration text into structured data for more accurate security analysis.
"""

import sys
import re
from typing import Dict, Any, List, Optional
from pathlib import Path

# Add rule-engines to path
SCRIPT_DIR = Path(__file__).parent
RULE_ENGINE_PATH = SCRIPT_DIR.parent / 'rule-engines'
sys.path.insert(0, str(RULE_ENGINE_PATH))

from scanner.core import VendorType, ConfigLine
from enhanced_parser import EnhancedConfigParser
from juniper_enhanced_parser import JuniperEnhancedParser
from paloalto_enhanced_parser import PaloAltoEnhancedParser

try:
    from genie.conf.base import Device
    from genie.libs.parser.utils import get_parser
    GENIE_AVAILABLE = True
except ImportError:
    GENIE_AVAILABLE = False
    print("⚠ Warning: Genie parser not installed. Falling back to regex parsing.", file=sys.stderr)


class GenieConfigParser:
    """Wrapper for Genie parser to extract structured configuration data."""

    def __init__(self, vendor: VendorType):
        """Initialize parser for specific vendor.

        Args:
            vendor: Network device vendor type
        """
        self.vendor = vendor
        self.genie_available = GENIE_AVAILABLE
        self.enhanced_parser = EnhancedConfigParser()
        self.juniper_parser = JuniperEnhancedParser()
        self.paloalto_parser = PaloAltoEnhancedParser()

        # Map our vendor types to Genie OS names
        self.os_mapping = {
            VendorType.CISCO_IOS: 'ios',
            VendorType.CISCO_IOS: 'iosxe',  # Try IOS-XE first
            VendorType.JUNIPER_JUNOS: 'junos',
            VendorType.FORTINET_FORTIOS: None,  # Not supported by Genie
            VendorType.PALOALTO_PANOS: None,   # Not supported by Genie
        }

    def parse_config(self, config_text: str, config_lines: List[ConfigLine]) -> Dict[str, Any]:
        """Parse configuration using Genie and extract security-relevant data.

        Args:
            config_text: Raw configuration text
            config_lines: Pre-parsed ConfigLine objects

        Returns:
            Dictionary with structured configuration data
        """
        # Initialize base structure
        parsed_data = {
            "config_lines": config_lines,
            "authentication": {},
            "services": {},
            "line_configs": {},
            "interfaces": {},
            "routing": {},
            "raw_config": config_text
        }

        # Try Genie parsing if available and supported
        if self.genie_available and self.vendor in self.os_mapping:
            genie_os = self.os_mapping[self.vendor]
            if genie_os:
                try:
                    genie_data = self._parse_with_genie(config_text, genie_os)
                    if genie_data:
                        # Merge Genie data into our structure
                        parsed_data = self._convert_genie_to_internal(genie_data, parsed_data)
                        print(f"✓ Genie parser extracted structured data", file=sys.stderr)
                        return parsed_data
                except Exception as e:
                    print(f"⚠ Genie parsing failed: {e}. Falling back to regex.", file=sys.stderr)

        # Use enhanced parser for all vendors
        if self.vendor == VendorType.CISCO_IOS:
            # Basic regex parsing (existing)
            parsed_data = self._parse_cisco_regex(config_lines, parsed_data)

            # Enhanced parsing (Genie-inspired patterns)
            enhanced_data = self.enhanced_parser.parse_all(config_lines)

            # Merge enhanced data
            parsed_data['interfaces_detailed'] = enhanced_data['interfaces']
            parsed_data['crypto_detailed'] = enhanced_data['crypto']
            parsed_data['route_maps_detailed'] = enhanced_data['route_maps']
            parsed_data['acls_detailed'] = enhanced_data['acls']

        elif self.vendor == VendorType.JUNIPER_JUNOS:
            # Use Juniper enhanced parser
            juniper_data = self.juniper_parser.parse(config_lines)
            # Merge Juniper data into parsed_data
            parsed_data.update(juniper_data)
            print("✓ Using Juniper enhanced parser", file=sys.stderr)

        elif self.vendor == VendorType.PALOALTO_PANOS:
            # Use Palo Alto enhanced parser
            paloalto_data = self.paloalto_parser.parse(config_lines)
            # Merge Palo Alto data into parsed_data
            parsed_data.update(paloalto_data)
            print("✓ Using Palo Alto enhanced parser", file=sys.stderr)

        return parsed_data

    def _parse_with_genie(self, config_text: str, os_type: str) -> Optional[Dict[str, Any]]:
        """Parse configuration using Genie parser.

        Args:
            config_text: Raw configuration text
            os_type: Genie OS type (ios, iosxe, nxos, etc.)

        Returns:
            Parsed configuration dictionary or None if failed

        Note:
            Genie is primarily designed for parsing live device output.
            For offline config files, we fall back to regex parsing which
            works well for our security analysis use case.
        """
        try:
            # Note: Genie doesn't have a comprehensive offline running-config parser
            # It's designed to parse specific show commands from live devices
            # For now, we'll use regex fallback which is reliable for security checks
            # Future: Could integrate specific Genie parsers for targeted features
            return None
        except Exception as e:
            print(f"Genie parse error: {e}", file=sys.stderr)
            return None

    def _convert_genie_to_internal(self, genie_data: Dict[str, Any],
                                    base_structure: Dict[str, Any]) -> Dict[str, Any]:
        """Convert Genie's structured output to our internal format.

        Args:
            genie_data: Data from Genie parser
            base_structure: Our base data structure

        Returns:
            Merged configuration dictionary
        """
        # Genie's "show running-config" parser returns the full structured config
        # The structure varies by device type, but generally includes sections like:
        # - aaa
        # - interface
        # - router
        # - line
        # - etc.

        # Extract authentication settings
        if 'aaa' in genie_data:
            aaa_config = genie_data['aaa']
            base_structure['authentication']['aaa_new_model'] = aaa_config.get('new_model', False)

        # Check for enable secret/password
        if 'enable' in genie_data:
            enable_config = genie_data['enable']
            base_structure['authentication']['enable_secret'] = 'secret' in enable_config
            base_structure['authentication']['enable_password'] = 'password' in enable_config

        # Extract line configurations
        if 'line' in genie_data:
            for line_type, line_data in genie_data['line'].items():
                for line_num, line_config in line_data.items():
                    line_key = f"{line_type} {line_num}"
                    base_structure['line_configs'][line_key] = {
                        'transport': line_config.get('transport', {}),
                        'timeouts': {
                            'exec': self._parse_exec_timeout(line_config.get('exec_timeout'))
                        },
                        'config_lines': []  # Will be populated from original config_lines
                    }

        # Extract service settings
        if 'service' in genie_data:
            services = genie_data['service']
            base_structure['services']['password_encryption'] = services.get('password_encryption', False)
            base_structure['services']['tcp_small_servers'] = services.get('tcp_small_servers', False)
            base_structure['services']['udp_small_servers'] = services.get('udp_small_servers', False)
            base_structure['services']['timestamps'] = services.get('timestamps', False)

        # Extract IP HTTP settings
        if 'ip' in genie_data and 'http' in genie_data['ip']:
            http_config = genie_data['ip']['http']
            base_structure['services']['http'] = http_config.get('server', False)
            base_structure['services']['https'] = http_config.get('secure_server', False)

        # Extract CDP settings (default is enabled)
        if 'cdp' in genie_data:
            base_structure['services']['cdp'] = genie_data['cdp'].get('run', True)
        else:
            base_structure['services']['cdp'] = True  # Default is enabled

        # Extract SNMP settings
        if 'snmp_server' in genie_data or 'snmp-server' in genie_data:
            snmp_data = genie_data.get('snmp_server', genie_data.get('snmp-server', {}))
            base_structure['snmp'] = {
                'enabled': bool(snmp_data),
                'communities': snmp_data.get('community', {}),
                'version': self._detect_snmp_version(snmp_data)
            }

        # Extract routing protocol configs
        if 'router' in genie_data:
            base_structure['routing'] = genie_data['router']

        # Extract interface configs
        if 'interface' in genie_data:
            base_structure['interfaces'] = genie_data['interface']

        return base_structure

    def _parse_exec_timeout(self, timeout_str: Optional[str]) -> int:
        """Parse exec-timeout value to seconds.

        Args:
            timeout_str: Timeout string like '10 0' or '5 30'

        Returns:
            Timeout in seconds
        """
        if not timeout_str:
            return 0

        parts = str(timeout_str).split()
        if len(parts) >= 2:
            minutes = int(parts[0])
            seconds = int(parts[1])
            return minutes * 60 + seconds
        elif len(parts) == 1:
            return int(parts[0]) * 60
        return 0

    def _detect_snmp_version(self, snmp_data: Dict[str, Any]) -> str:
        """Detect SNMP version from configuration.

        Args:
            snmp_data: SNMP configuration data

        Returns:
            SNMP version string (v1, v2c, v3)
        """
        # Check for v3 user/group configurations
        if 'user' in snmp_data or 'group' in snmp_data:
            return 'v3'

        # Check community strings (v1/v2c)
        communities = snmp_data.get('community', {})
        if communities:
            # If any community has 'version' specified
            for comm_data in communities.values():
                if isinstance(comm_data, dict) and comm_data.get('version'):
                    return comm_data['version']
            return 'v2c'  # Default for community strings

        return 'unknown'

    def _parse_cisco_regex(self, config_lines: List[ConfigLine],
                           parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback regex-based parsing for Cisco IOS.

        Args:
            config_lines: List of configuration lines
            parsed_data: Base parsed data structure

        Returns:
            Updated parsed data with regex-extracted information
        """
        print("✓ Using regex-based parsing", file=sys.stderr)

        # Track what we find
        enable_secret_found = False
        enable_password_found = False
        aaa_new_model_found = False
        cdp_disabled = False
        http_server = False
        https_server = False
        tcp_small_servers = False
        udp_small_servers = False
        bootp_server = False
        source_routing = True  # Enabled by default

        # Line configuration tracking
        current_line = None
        line_configs = {}

        for line in config_lines:
            content = line.content.strip()

            # Authentication
            if content.startswith('enable secret'):
                enable_secret_found = True
            elif content.startswith('enable password'):
                enable_password_found = True
            elif content == 'aaa new-model':
                aaa_new_model_found = True

            # Services
            elif content == 'no cdp run':
                cdp_disabled = True
            elif content == 'ip http server':
                http_server = True
            elif content == 'ip http secure-server':
                https_server = True
            elif content == 'service tcp-small-servers':
                tcp_small_servers = True
            elif content == 'service udp-small-servers':
                udp_small_servers = True
            elif content == 'ip bootp server':
                bootp_server = True
            elif content == 'no ip source-route':
                source_routing = False

            # Line configurations
            elif content.startswith('line '):
                current_line = content
                if current_line not in line_configs:
                    line_configs[current_line] = {
                        'transport': {'input': []},
                        'timeouts': {'exec': 0},
                        'config_lines': [line]
                    }
            elif current_line and line.indentation > 0:
                # This line belongs to the current line block
                line_configs[current_line]['config_lines'].append(line)

                # Parse line-specific settings
                if content.startswith('transport input'):
                    transports = content.replace('transport input', '').strip().split()
                    line_configs[current_line]['transport']['input'] = transports
                elif content.startswith('exec-timeout'):
                    parts = content.replace('exec-timeout', '').strip().split()
                    if len(parts) >= 2:
                        minutes = int(parts[0])
                        seconds = int(parts[1])
                        line_configs[current_line]['timeouts']['exec'] = minutes * 60 + seconds
                    elif len(parts) == 1:
                        line_configs[current_line]['timeouts']['exec'] = int(parts[0]) * 60
            elif current_line and line.indentation == 0:
                # End of line block
                current_line = None

        # Update parsed data
        parsed_data['authentication']['enable_secret'] = enable_secret_found
        parsed_data['authentication']['enable_password'] = enable_password_found
        parsed_data['authentication']['aaa_new_model'] = aaa_new_model_found

        parsed_data['services']['cdp'] = not cdp_disabled
        parsed_data['services']['http'] = http_server
        parsed_data['services']['https'] = https_server
        parsed_data['services']['tcp_small_servers'] = tcp_small_servers
        parsed_data['services']['udp_small_servers'] = udp_small_servers
        parsed_data['services']['bootp'] = bootp_server
        parsed_data['services']['source_routing'] = source_routing

        parsed_data['line_configs'] = line_configs

        return parsed_data


def create_parser(vendor: VendorType) -> GenieConfigParser:
    """Factory function to create appropriate parser for vendor.

    Args:
        vendor: Network device vendor type

    Returns:
        GenieConfigParser instance
    """
    return GenieConfigParser(vendor)
