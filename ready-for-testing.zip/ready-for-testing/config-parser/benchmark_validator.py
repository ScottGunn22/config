"""Benchmark validation engine for CIS, DISA STIG, and vendor hardening guides."""

import re
from typing import List, Dict, Any, Optional
from benchmark_rules import CISBenchmarkRules, DISTIGRules, VendorHardeningGuideRules, BenchmarkRule


class BenchmarkValidator:
    """Validates network configurations against security benchmarks."""

    def __init__(self):
        """Initialize benchmark validator with all rule sets."""
        self.cis_cisco_rules = CISBenchmarkRules.get_cisco_ios_rules()
        self.stig_cisco_rules = DISTIGRules.get_cisco_ios_rules()
        self.cisco_hardening_rules = VendorHardeningGuideRules.get_cisco_hardening_rules()

    def validate_cisco_ios(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco IOS configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_cisco_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def _run_benchmark_checks(self, rules: List[BenchmarkRule],
                              config_lines: List,
                              parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Run benchmark checks and return findings."""
        findings = []

        for rule in rules:
            check_func = getattr(self, rule.check_function, None)
            if check_func:
                result = check_func(config_lines, parsed_config)
                if result:
                    finding = {
                        "rule_id": rule.rule_id,
                        "title": rule.title,
                        "description": rule.description,
                        "severity": rule.severity,
                        "category": "Benchmark Compliance",
                        "benchmark_id": rule.benchmark_id,
                        "benchmark_name": rule.benchmark_name,
                        "recommendation": rule.recommendation,
                        "fix_commands": rule.fix_commands,
                        "nist_controls": rule.nist_controls,
                        "compliant": result["compliant"],
                        "details": result.get("details", "")
                    }

                    if not result["compliant"]:
                        findings.append(finding)

        return findings

    # CIS Benchmark check functions

    def check_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.1: Check hostname is configured."""
        has_hostname = any(
            self._safe_content(line).startswith("hostname ")
            for line in config_lines
        )

        # Check if hostname is default
        default_hostnames = ["Router", "Switch", "router", "switch"]
        hostname_value = None
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("hostname "):
                hostname_value = content.split()[1] if len(content.split()) > 1 else None

        is_default = hostname_value in default_hostnames if hostname_value else True

        return {
            "compliant": has_hostname and not is_default,
            "details": f"Hostname: {hostname_value}" if hostname_value else "No hostname configured"
        }

    def check_enable_secret(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.2: Check enable secret is configured."""
        has_enable_secret = any(
            self._safe_content(line).startswith("enable secret")
            for line in config_lines
        )

        return {
            "compliant": has_enable_secret,
            "details": "Enable secret configured" if has_enable_secret else "Enable secret not found"
        }

    def check_password_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.3: Check password encryption is enabled."""
        has_encryption = any(
            "service password-encryption" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_encryption,
            "details": "Password encryption enabled" if has_encryption else "Password encryption not enabled"
        }

    def check_login_banner(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.4: Check login banner is configured."""
        has_banner = any(
            re.search(r'banner (login|motd)', self._safe_content(line), re.I)
            for line in config_lines
        )

        return {
            "compliant": has_banner,
            "details": "Login banner configured" if has_banner else "No login banner found"
        }

    def check_no_http_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.1: Check HTTP server is disabled."""
        http_enabled = any(
            self._safe_content(line) == "ip http server"
            for line in config_lines
        )

        http_disabled = any(
            self._safe_content(line) == "no ip http server"
            for line in config_lines
        )

        return {
            "compliant": not http_enabled or http_disabled,
            "details": "HTTP server properly disabled" if not http_enabled or http_disabled else "HTTP server is enabled"
        }

    def check_https_secure(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.2: Check HTTPS is properly configured if enabled."""
        https_enabled = any(
            "ip http secure-server" in self._safe_content(line)
            for line in config_lines
        )

        if not https_enabled:
            return {"compliant": True, "details": "HTTPS not enabled (acceptable)"}

        # If HTTPS is enabled, check for proper TLS version
        has_tls_12 = any(
            "tlsv1.2" in self._safe_content(line).lower()
            for line in config_lines
        )

        return {
            "compliant": has_tls_12,
            "details": "HTTPS with TLS 1.2+" if has_tls_12 else "HTTPS enabled but TLS version not configured"
        }

    def check_ssh_version_2(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.3: Check SSH version 2 is configured."""
        has_ssh_v2 = any(
            "ip ssh version 2" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_ssh_v2,
            "details": "SSH version 2 configured" if has_ssh_v2 else "SSH version not explicitly set to 2"
        }

    def check_vty_transport_ssh(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.4: Check VTY lines use SSH only."""
        in_vty_block = False
        vty_ssh_only = True
        vty_found = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'line vty', content):
                in_vty_block = True
                vty_found = True
            elif in_vty_block and content.startswith("line "):
                in_vty_block = False
            elif in_vty_block and "transport input" in content:
                if "ssh" not in content or ("telnet" in content or "all" in content):
                    vty_ssh_only = False

        if not vty_found:
            return {"compliant": False, "details": "No VTY lines configured"}

        return {
            "compliant": vty_ssh_only,
            "details": "VTY lines use SSH only" if vty_ssh_only else "VTY lines allow insecure protocols"
        }

    def check_exec_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.5: Check exec-timeout is configured appropriately."""
        timeout_issues = []
        in_line_block = False
        current_line = None

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'line (console|aux|vty)', content):
                in_line_block = True
                current_line = content.split()[1]
            elif in_line_block and content.startswith("line "):
                in_line_block = False
                current_line = None
            elif in_line_block and "exec-timeout" in content:
                # Parse timeout value (minutes seconds)
                match = re.search(r'exec-timeout (\d+)(?: (\d+))?', content)
                if match:
                    minutes = int(match.group(1))
                    if minutes > 10 or minutes == 0:
                        timeout_issues.append(current_line)

        return {
            "compliant": len(timeout_issues) == 0,
            "details": f"Timeout issues on: {', '.join(timeout_issues)}" if timeout_issues else "All timeouts properly configured"
        }

    def check_no_source_route(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.3.1: Check IP source routing is disabled."""
        has_no_source_route = any(
            "no ip source-route" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_no_source_route,
            "details": "IP source routing disabled" if has_no_source_route else "IP source routing not disabled"
        }

    def check_no_proxy_arp(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.3.2: Check proxy ARP is disabled."""
        has_no_proxy_arp = any(
            "no ip proxy-arp" in self._safe_content(line)
            for line in config_lines
        )

        # This is a recommendation, not always required
        return {
            "compliant": has_no_proxy_arp,
            "details": "Proxy ARP disabled" if has_no_proxy_arp else "Proxy ARP not explicitly disabled"
        }

    def check_aaa_new_model(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.4.1: Check AAA new-model is enabled."""
        has_aaa = any(
            "aaa new-model" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_aaa,
            "details": "AAA new-model enabled" if has_aaa else "AAA new-model not configured"
        }

    def check_aaa_authentication_login(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.4.2: Check AAA authentication login is configured."""
        has_auth_login = any(
            "aaa authentication login" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_auth_login,
            "details": "AAA authentication login configured" if has_auth_login else "AAA authentication login not configured"
        }

    def check_logging_buffered(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.5.1: Check logging buffered is configured."""
        has_logging_buffered = any(
            "logging buffered" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_logging_buffered,
            "details": "Logging buffered configured" if has_logging_buffered else "Logging buffered not configured"
        }

    def check_logging_host(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.5.2: Check remote logging is configured."""
        has_logging_host = any(
            re.match(r'logging (host|\d+\.\d+\.\d+\.\d+)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_logging_host,
            "details": "Remote logging configured" if has_logging_host else "No remote logging server configured"
        }

    # DISA STIG check functions

    def check_console_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3056: Check console authentication."""
        in_console = False
        has_auth = False

        for line in config_lines:
            content = self._safe_content(line)
            if "line console" in content:
                in_console = True
            elif in_console and content.startswith("line "):
                break
            elif in_console and ("login authentication" in content or "login local" in content):
                has_auth = True

        return {
            "compliant": has_auth,
            "details": "Console authentication configured" if has_auth else "Console lacks authentication"
        }

    def check_fips_mode(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3057: Check FIPS mode or approved algorithms."""
        # Check for SSH v2 and strong key size as proxy
        has_ssh_v2 = any("ip ssh version 2" in self._safe_content(line) for line in config_lines)
        has_strong_rsa = any(re.search(r'crypto key generate rsa.*(?:2048|4096)', self._safe_content(line)) for line in config_lines)

        return {
            "compliant": has_ssh_v2 and has_strong_rsa,
            "details": "FIPS-approved algorithms in use" if (has_ssh_v2 and has_strong_rsa) else "FIPS compliance not verified"
        }

    def check_dod_banner(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3058: Check DoD banner."""
        has_banner = any(re.search(r'banner login', self._safe_content(line), re.I) for line in config_lines)

        return {
            "compliant": has_banner,
            "details": "Login banner configured" if has_banner else "No login banner"
        }

    def check_logging_protection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3059: Check logging protection."""
        has_logging_host = any(re.match(r'logging (host|\d+\.\d+\.\d+\.\d+)', self._safe_content(line)) for line in config_lines)

        return {
            "compliant": has_logging_host,
            "details": "Logging to secure server" if has_logging_host else "No secure logging configured"
        }

    def check_password_length(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3210: Check minimum password length."""
        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'security passwords min-length (\d+)', content)
            if match:
                length = int(match.group(1))
                return {
                    "compliant": length >= 15,
                    "details": f"Password min-length: {length}"
                }

        return {
            "compliant": False,
            "details": "Password min-length not configured"
        }

    def check_session_timeout_stig(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3058: Check session timeout."""
        return self.check_exec_timeout(config_lines, parsed_config)

    def check_pki_certificates(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3069: Check PKI certificates."""
        has_pki = any("crypto pki" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_pki,
            "details": "PKI configured" if has_pki else "No PKI configuration"
        }

    def check_snmp_version(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3143: Check SNMP version."""
        has_snmpv1v2 = any(
            re.search(r'snmp-server community \S+ (RO|RW)', self._safe_content(line))
            for line in config_lines
        )

        has_snmpv3 = any(
            "snmp-server group" in self._safe_content(line) and "v3" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": not has_snmpv1v2 or has_snmpv3,
            "details": "SNMPv3 configured" if has_snmpv3 else "SNMPv1/v2c detected" if has_snmpv1v2 else "No SNMP configured"
        }

    def check_control_plane_policing(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3175: Check control plane policing."""
        has_copp = any(
            re.search(r'control-plane|service-policy.*control-plane', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_copp,
            "details": "Control plane policing configured" if has_copp else "No CoPP configured"
        }

    def check_management_acl(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3057: Check management ACL."""
        in_vty = False
        has_acl = False

        for line in config_lines:
            content = self._safe_content(line)
            if "line vty" in content:
                in_vty = True
            elif in_vty and content.startswith("line "):
                break
            elif in_vty and "access-class" in content:
                has_acl = True

        return {
            "compliant": has_acl,
            "details": "Management ACL configured" if has_acl else "No VTY access control"
        }

    # Vendor Hardening Guide check functions

    def check_unnecessary_services(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check unnecessary services are disabled."""
        unnecessary_services = ["cdp run", "ip finger", "service pad"]
        issues = []

        for service in unnecessary_services:
            if any(service in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines):
                issues.append(service)

        return {
            "compliant": len(issues) == 0,
            "details": f"Unnecessary services enabled: {', '.join(issues)}" if issues else "Unnecessary services disabled"
        }

    def check_tcp_keepalives(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check TCP keepalives."""
        has_keepalives_in = any("service tcp-keepalives-in" in self._safe_content(line) for line in config_lines)
        has_keepalives_out = any("service tcp-keepalives-out" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_keepalives_in and has_keepalives_out,
            "details": "TCP keepalives configured" if (has_keepalives_in and has_keepalives_out) else "TCP keepalives not fully configured"
        }

    def check_no_icmp_redirects(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check ICMP redirects disabled."""
        has_no_redirects = any("no ip redirects" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_no_redirects,
            "details": "ICMP redirects disabled" if has_no_redirects else "ICMP redirects not disabled"
        }

    def check_urpf_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check uRPF enabled."""
        has_urpf = any("ip verify unicast source reachable-via" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_urpf,
            "details": "uRPF enabled" if has_urpf else "uRPF not configured"
        }

    def check_ntp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check NTP authentication."""
        has_ntp_auth = any("ntp authenticate" in self._safe_content(line) for line in config_lines)
        has_ntp_key = any("ntp authentication-key" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_ntp_auth and has_ntp_key,
            "details": "NTP authentication configured" if (has_ntp_auth and has_ntp_key) else "NTP authentication not configured"
        }

    # Helper methods

    def _safe_content(self, line) -> str:
        """Safely extract content from line object or string."""
        if hasattr(line, 'content'):
            return line.content.strip()
        return str(line).strip()
