"""CIS Benchmark and DISA STIG validation rules for network devices."""

import re
from typing import List, Dict, Any
from dataclasses import dataclass


@dataclass
class BenchmarkRule:
    """Represents a security benchmark rule."""
    rule_id: str
    title: str
    description: str
    severity: str
    benchmark_id: str  # CIS 1.1.1 or STIG V-1234
    benchmark_name: str  # "CIS Cisco IOS v4.1.0" or "STIG"
    check_function: str  # Name of check function
    recommendation: str
    fix_commands: List[str]
    nist_controls: List[str]


class CISBenchmarkRules:
    """CIS Benchmark validation rules."""

    @staticmethod
    def get_cisco_ios_rules() -> List[BenchmarkRule]:
        """Get CIS Cisco IOS benchmark rules."""
        return [
            BenchmarkRule(
                rule_id="CIS-001",
                title="Set 'hostname' to organization-defined value",
                description="CIS recommends setting a unique hostname for device identification and management.",
                severity="LOW",
                benchmark_id="CIS 1.1.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_hostname_configured",
                recommendation="Configure a descriptive hostname",
                fix_commands=["hostname <UNIQUE_NAME>"],
                nist_controls=["CM-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-002",
                title="Set 'enable secret' for privileged EXEC mode",
                description="CIS requires enable secret (not enable password) with strong hashing.",
                severity="CRITICAL",
                benchmark_id="CIS 1.1.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_enable_secret",
                recommendation="Use 'enable secret' with strong password",
                fix_commands=["enable secret <STRONG_PASSWORD>"],
                nist_controls=["IA-5", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-003",
                title="Enable 'service password-encryption'",
                description="CIS requires password encryption to protect passwords in configuration.",
                severity="MEDIUM",
                benchmark_id="CIS 1.1.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_password_encryption",
                recommendation="Enable password encryption service",
                fix_commands=["service password-encryption"],
                nist_controls=["IA-5"]
            ),
            BenchmarkRule(
                rule_id="CIS-004",
                title="Set 'banner login' warning message",
                description="CIS requires login banners to warn unauthorized users.",
                severity="LOW",
                benchmark_id="CIS 1.1.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_login_banner",
                recommendation="Configure login banner with legal warning",
                fix_commands=["banner login ^C Unauthorized access prohibited ^C"],
                nist_controls=["AC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-005",
                title="Set 'no ip http server'",
                description="CIS recommends disabling HTTP server to prevent unencrypted management.",
                severity="MEDIUM",
                benchmark_id="CIS 1.2.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_http_server",
                recommendation="Disable HTTP server",
                fix_commands=["no ip http server"],
                nist_controls=["SC-8", "CM-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-006",
                title="Enable 'ip http secure-server' if web management needed",
                description="CIS allows HTTPS for web management but requires proper configuration.",
                severity="LOW",
                benchmark_id="CIS 1.2.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_https_secure",
                recommendation="Use HTTPS with proper TLS configuration",
                fix_commands=["ip http secure-server", "ip http ssl-version tlsv1.2"],
                nist_controls=["SC-8"]
            ),
            BenchmarkRule(
                rule_id="CIS-007",
                title="Set 'ip ssh version 2'",
                description="CIS requires SSHv2 only for secure management access.",
                severity="HIGH",
                benchmark_id="CIS 1.2.3",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_ssh_version_2",
                recommendation="Configure SSH version 2 only",
                fix_commands=["ip ssh version 2"],
                nist_controls=["SC-8", "SC-13"]
            ),
            BenchmarkRule(
                rule_id="CIS-008",
                title="Set 'transport input ssh' on VTY lines",
                description="CIS requires SSH-only access on VTY lines.",
                severity="HIGH",
                benchmark_id="CIS 1.2.4",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_vty_transport_ssh",
                recommendation="Restrict VTY lines to SSH only",
                fix_commands=["line vty 0 4", " transport input ssh"],
                nist_controls=["SC-8", "AC-17"]
            ),
            BenchmarkRule(
                rule_id="CIS-009",
                title="Set 'exec-timeout' on console, AUX, and VTY lines",
                description="CIS requires session timeout ≤ 10 minutes.",
                severity="MEDIUM",
                benchmark_id="CIS 1.2.5",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_exec_timeout",
                recommendation="Set exec-timeout to 10 minutes or less",
                fix_commands=["line vty 0 4", " exec-timeout 10 0"],
                nist_controls=["AC-12", "SC-10"]
            ),
            BenchmarkRule(
                rule_id="CIS-010",
                title="Set 'no ip source-route'",
                description="CIS requires IP source routing to be disabled.",
                severity="MEDIUM",
                benchmark_id="CIS 1.3.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_source_route",
                recommendation="Disable IP source routing",
                fix_commands=["no ip source-route"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-011",
                title="Set 'no ip proxy-arp' on interfaces",
                description="CIS recommends disabling proxy ARP on interfaces.",
                severity="LOW",
                benchmark_id="CIS 1.3.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_no_proxy_arp",
                recommendation="Disable proxy ARP on all interfaces",
                fix_commands=["interface <INTERFACE>", " no ip proxy-arp"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CIS-012",
                title="Set 'aaa new-model'",
                description="CIS requires AAA for centralized access control.",
                severity="HIGH",
                benchmark_id="CIS 1.4.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_new_model",
                recommendation="Enable AAA new-model",
                fix_commands=["aaa new-model"],
                nist_controls=["IA-2", "AC-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-013",
                title="Configure 'aaa authentication login'",
                description="CIS requires AAA authentication for login.",
                severity="HIGH",
                benchmark_id="CIS 1.4.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_aaa_authentication_login",
                recommendation="Configure AAA authentication for login",
                fix_commands=["aaa authentication login default group tacacs+ local"],
                nist_controls=["IA-2"]
            ),
            BenchmarkRule(
                rule_id="CIS-014",
                title="Set 'logging buffered' with appropriate level",
                description="CIS requires logging with appropriate severity level.",
                severity="MEDIUM",
                benchmark_id="CIS 1.5.1",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_buffered",
                recommendation="Configure logging buffered with informational level",
                fix_commands=["logging buffered informational"],
                nist_controls=["AU-2", "AU-3"]
            ),
            BenchmarkRule(
                rule_id="CIS-015",
                title="Set 'logging host' to remote syslog server",
                description="CIS requires centralized logging to remote server.",
                severity="HIGH",
                benchmark_id="CIS 1.5.2",
                benchmark_name="CIS Cisco IOS Benchmark v4.1.0",
                check_function="check_logging_host",
                recommendation="Configure remote syslog server",
                fix_commands=["logging host <SYSLOG_SERVER>"],
                nist_controls=["AU-4", "AU-9"]
            ),
        ]


class DISTIGRules:
    """DISA STIG validation rules."""

    @staticmethod
    def get_cisco_ios_rules() -> List[BenchmarkRule]:
        """Get DISA STIG Cisco IOS rules."""
        return [
            BenchmarkRule(
                rule_id="STIG-001",
                title="Network device must require authentication for console access",
                description="STIG V-3056: Requires authentication on console line.",
                severity="CRITICAL",
                benchmark_id="V-3056",
                benchmark_name="DISA STIG",
                check_function="check_console_authentication",
                recommendation="Configure authentication on console",
                fix_commands=["line console 0", " login authentication default"],
                nist_controls=["IA-2", "AC-17"]
            ),
            BenchmarkRule(
                rule_id="STIG-002",
                title="Network device must use FIPS 140-2 approved algorithms",
                description="STIG V-3057: Requires FIPS-approved cryptographic algorithms.",
                severity="HIGH",
                benchmark_id="V-3057",
                benchmark_name="DISA STIG",
                check_function="check_fips_mode",
                recommendation="Enable FIPS mode if supported",
                fix_commands=["crypto key generate rsa modulus 2048", "ip ssh version 2"],
                nist_controls=["SC-13"]
            ),
            BenchmarkRule(
                rule_id="STIG-003",
                title="Network device must display security banner before login",
                description="STIG V-3058: Requires DoD-approved banner.",
                severity="MEDIUM",
                benchmark_id="V-3058",
                benchmark_name="DISA STIG",
                check_function="check_dod_banner",
                recommendation="Configure DoD standard banner",
                fix_commands=["banner login ^C You are accessing a U.S. Government (USG) Information System (IS)... ^C"],
                nist_controls=["AC-8"]
            ),
            BenchmarkRule(
                rule_id="STIG-004",
                title="Network device must protect audit information",
                description="STIG V-3059: Requires secure logging configuration.",
                severity="HIGH",
                benchmark_id="V-3059",
                benchmark_name="DISA STIG",
                check_function="check_logging_protection",
                recommendation="Configure logging to secure syslog server",
                fix_commands=["logging host <SYSLOG_SERVER>", "logging trap informational"],
                nist_controls=["AU-9"]
            ),
            BenchmarkRule(
                rule_id="STIG-005",
                title="Network device must enforce minimum 15-character password length",
                description="STIG V-3210: Requires minimum password length of 15 characters.",
                severity="HIGH",
                benchmark_id="V-3210",
                benchmark_name="DISA STIG",
                check_function="check_password_length",
                recommendation="Set security passwords min-length 15",
                fix_commands=["security passwords min-length 15"],
                nist_controls=["IA-5(1)"]
            ),
            BenchmarkRule(
                rule_id="STIG-006",
                title="Network device must terminate inactive sessions after 10 minutes",
                description="STIG V-3058: Requires session timeout.",
                severity="MEDIUM",
                benchmark_id="V-3058",
                benchmark_name="DISA STIG",
                check_function="check_session_timeout_stig",
                recommendation="Set exec-timeout to 10 minutes or less",
                fix_commands=["line vty 0 4", " exec-timeout 10 0"],
                nist_controls=["AC-12"]
            ),
            BenchmarkRule(
                rule_id="STIG-007",
                title="Network device must use DoD PKI-established certificate authorities",
                description="STIG V-3069: Requires DoD PKI certificates.",
                severity="MEDIUM",
                benchmark_id="V-3069",
                benchmark_name="DISA STIG",
                check_function="check_pki_certificates",
                recommendation="Configure DoD PKI trustpoint",
                fix_commands=["crypto pki trustpoint DOD_CA", " enrollment url http://crl.disa.mil"],
                nist_controls=["SC-17"]
            ),
            BenchmarkRule(
                rule_id="STIG-008",
                title="Network device must not use SNMPv1 or v2c",
                description="STIG V-3143: Prohibits SNMPv1/v2c due to weak authentication.",
                severity="HIGH",
                benchmark_id="V-3143",
                benchmark_name="DISA STIG",
                check_function="check_snmp_version",
                recommendation="Use SNMPv3 only",
                fix_commands=["no snmp-server community <STRING>", "snmp-server group <GROUP> v3 priv"],
                nist_controls=["IA-2", "SC-8"]
            ),
            BenchmarkRule(
                rule_id="STIG-009",
                title="Network device must implement control plane policing",
                description="STIG V-3175: Requires CoPP to protect control plane.",
                severity="MEDIUM",
                benchmark_id="V-3175",
                benchmark_name="DISA STIG",
                check_function="check_control_plane_policing",
                recommendation="Implement control plane policing",
                fix_commands=["control-plane", " service-policy input COPP-POLICY"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="STIG-010",
                title="Network device must restrict management access by IP",
                description="STIG V-3057: Requires access control for management.",
                severity="HIGH",
                benchmark_id="V-3057",
                benchmark_name="DISA STIG",
                check_function="check_management_acl",
                recommendation="Apply ACL to restrict management access",
                fix_commands=["access-list 10 permit <MGMT_NETWORK>", "line vty 0 4", " access-class 10 in"],
                nist_controls=["AC-4", "SC-7"]
            ),
        ]


class VendorHardeningGuideRules:
    """Vendor-specific hardening guide rules."""

    @staticmethod
    def get_cisco_hardening_rules() -> List[BenchmarkRule]:
        """Get Cisco hardening guide rules."""
        return [
            BenchmarkRule(
                rule_id="CISCO-HARD-001",
                title="Disable unnecessary services",
                description="Cisco hardening guide recommends disabling unused services.",
                severity="MEDIUM",
                benchmark_id="Cisco Guide Section 2.1",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_unnecessary_services",
                recommendation="Disable unnecessary services like CDP, finger, PAD",
                fix_commands=["no cdp run", "no ip finger", "no service pad"],
                nist_controls=["CM-7"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-002",
                title="Configure TCP keepalives",
                description="Cisco recommends TCP keepalives to prevent resource exhaustion.",
                severity="LOW",
                benchmark_id="Cisco Guide Section 2.2",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_tcp_keepalives",
                recommendation="Enable TCP keepalives",
                fix_commands=["service tcp-keepalives-in", "service tcp-keepalives-out"],
                nist_controls=["SC-5"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-003",
                title="Disable ICMP redirects",
                description="Cisco recommends disabling ICMP redirects to prevent routing attacks.",
                severity="MEDIUM",
                benchmark_id="Cisco Guide Section 3.1",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_no_icmp_redirects",
                recommendation="Disable ICMP redirects on interfaces",
                fix_commands=["interface <INTERFACE>", " no ip redirects"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-004",
                title="Enable unicast RPF on interfaces",
                description="Cisco recommends uRPF to prevent IP spoofing.",
                severity="HIGH",
                benchmark_id="Cisco Guide Section 3.2",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_urpf_enabled",
                recommendation="Enable uRPF on external-facing interfaces",
                fix_commands=["interface <INTERFACE>", " ip verify unicast source reachable-via rx"],
                nist_controls=["SC-7"]
            ),
            BenchmarkRule(
                rule_id="CISCO-HARD-005",
                title="Configure NTP authentication",
                description="Cisco requires NTP authentication to prevent time manipulation.",
                severity="MEDIUM",
                benchmark_id="Cisco Guide Section 4.1",
                benchmark_name="Cisco IOS Security Hardening Guide",
                check_function="check_ntp_authentication",
                recommendation="Enable NTP authentication",
                fix_commands=["ntp authenticate", "ntp trusted-key 1", "ntp authentication-key 1 md5 <KEY>"],
                nist_controls=["SC-45"]
            ),
        ]
