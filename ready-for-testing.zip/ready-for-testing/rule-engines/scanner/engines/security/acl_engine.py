"""Access Control List (ACL) Security Analysis Engine."""

import re
from typing import List, Dict, Any, Optional, Tuple
from ..base_engine import BaseSecurityEngine, EngineCategory, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector


class ACLSecurityEngine(BaseSecurityEngine):
    """Comprehensive Access Control List security analysis engine."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 22
    
    def get_category(self) -> EngineCategory:
        return EngineCategory.SECURITY
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.HIGH
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS, VendorType.JUNIPER_JUNOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze ACL configuration for security issues."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_acls(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._analyze_juniper_acls(parsed_config))
        
        return findings
    
    def _analyze_cisco_acls(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco ACL configuration."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Extract ACL configuration
        acl_config = self._extract_acl_config(config_lines)
        
        if not acl_config.get("standard_acls") and not acl_config.get("extended_acls"):
            return findings  # No ACLs configured
        
        # Run ACL security checks
        findings.extend(self._check_acl_structure(acl_config))
        findings.extend(self._check_acl_rules(acl_config))
        findings.extend(self._check_acl_application(acl_config, config_lines))
        findings.extend(self._check_acl_logging(acl_config))
        findings.extend(self._check_acl_security_best_practices(acl_config))
        
        return findings
    
    def _extract_acl_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract ACL configuration from config lines."""
        acl_config = {
            "standard_acls": {},  # Numbered 1-99, 1300-1999
            "extended_acls": {},  # Numbered 100-199, 2000-2699
            "named_acls": {},     # Named ACLs
            "interface_acls": {},  # ACLs applied to interfaces
            "line_acls": {},      # ACLs applied to lines
            "vty_acls": {}        # VTY access-class
        }
        
        current_acl = None
        current_acl_type = None
        
        for line in config_lines:
            # Handle both ConfigLine objects and strings
            if hasattr(line, 'content'):
                content = line.content.strip()
            else:
                content = str(line).strip()
                # Create a mock line object for compatibility
                class MockLine:
                    def __init__(self, content):
                        self.content = content
                        self.line_number = 0
                        self.section = ""
                line = MockLine(content)
            
            # Standard numbered ACL (1-99, 1300-1999)
            std_match = re.match(r'access-list (\d+) (permit|deny) (.+)', content)
            if std_match:
                acl_num = std_match.group(1)
                action = std_match.group(2)
                criteria = std_match.group(3)
                
                if int(acl_num) in range(1, 100) or int(acl_num) in range(1300, 2000):
                    if acl_num not in acl_config["standard_acls"]:
                        acl_config["standard_acls"][acl_num] = {
                            "number": acl_num,
                            "type": "standard",
                            "rules": [],
                            "has_logging": False
                        }
                    
                    rule = {
                        "action": action,
                        "criteria": criteria,
                        "config_line": line,
                        "has_log": "log" in content.lower()
                    }
                    acl_config["standard_acls"][acl_num]["rules"].append(rule)
                    
                    if rule["has_log"]:
                        acl_config["standard_acls"][acl_num]["has_logging"] = True
                continue
            
            # Extended numbered ACL (100-199, 2000-2699)
            ext_match = re.match(r'access-list (\d+) (permit|deny) (.+)', content)
            if ext_match:
                acl_num = ext_match.group(1)
                action = ext_match.group(2)
                criteria = ext_match.group(3)
                
                if int(acl_num) in range(100, 200) or int(acl_num) in range(2000, 2700):
                    if acl_num not in acl_config["extended_acls"]:
                        acl_config["extended_acls"][acl_num] = {
                            "number": acl_num,
                            "type": "extended", 
                            "rules": [],
                            "has_logging": False
                        }
                    
                    rule = {
                        "action": action,
                        "criteria": criteria,
                        "config_line": line,
                        "has_log": "log" in content.lower(),
                        "protocol": self._extract_protocol(criteria),
                        "source": self._extract_source_dest(criteria)[0],
                        "destination": self._extract_source_dest(criteria)[1],
                        "ports": self._extract_ports(criteria)
                    }
                    acl_config["extended_acls"][acl_num]["rules"].append(rule)
                    
                    if rule["has_log"]:
                        acl_config["extended_acls"][acl_num]["has_logging"] = True
                continue
            
            # Named ACL start
            named_match = re.match(r'ip access-list (standard|extended) (\S+)', content)
            if named_match:
                acl_type = named_match.group(1)
                acl_name = named_match.group(2)
                current_acl = acl_name
                current_acl_type = acl_type
                
                acl_config["named_acls"][acl_name] = {
                    "name": acl_name,
                    "type": acl_type,
                    "rules": [],
                    "has_logging": False,
                    "config_line": line
                }
                continue
            
            # Named ACL rules
            if current_acl and (content.startswith('permit ') or content.startswith('deny ')):
                parts = content.split(None, 1)
                action = parts[0]
                criteria = parts[1] if len(parts) > 1 else ""
                
                rule = {
                    "action": action,
                    "criteria": criteria,
                    "config_line": line,
                    "has_log": "log" in content.lower()
                }
                
                if current_acl_type == "extended":
                    rule.update({
                        "protocol": self._extract_protocol(criteria),
                        "source": self._extract_source_dest(criteria)[0],
                        "destination": self._extract_source_dest(criteria)[1],
                        "ports": self._extract_ports(criteria)
                    })
                
                acl_config["named_acls"][current_acl]["rules"].append(rule)
                
                if rule["has_log"]:
                    acl_config["named_acls"][current_acl]["has_logging"] = True
                continue
            
            # End of named ACL
            if current_acl and (content.startswith('interface ') or 
                              content.startswith('router ') or
                              content.startswith('ip access-list ') or
                              content.startswith('line ') or
                              not content.startswith(' ')):
                current_acl = None
                current_acl_type = None
            
            # Interface ACL application
            if re.search(r'ip access-group (\S+) (in|out)', content):
                interface_acl_match = re.search(r'ip access-group (\S+) (in|out)', content)
                acl_name = interface_acl_match.group(1)
                direction = interface_acl_match.group(2)
                # Would need interface context to store this properly
                # This is a simplified extraction
            
            # VTY access-class
            if "access-class" in content:
                vty_match = re.search(r'access-class (\S+) (in|out)', content)
                if vty_match:
                    acl_name = vty_match.group(1)
                    direction = vty_match.group(2)
                    acl_config["vty_acls"][acl_name] = {
                        "acl": acl_name,
                        "direction": direction,
                        "config_line": line
                    }
        
        return acl_config
    
    def _extract_protocol(self, criteria: str) -> Optional[str]:
        """Extract protocol from ACL criteria."""
        parts = criteria.split()
        if parts:
            protocol = parts[0].lower()
            if protocol in ['ip', 'tcp', 'udp', 'icmp', 'ospf', 'eigrp', 'gre']:
                return protocol
        return None
    
    def _extract_source_dest(self, criteria: str) -> Tuple[str, str]:
        """Extract source and destination from ACL criteria."""
        # Simplified extraction - would need more sophisticated parsing
        parts = criteria.split()
        source = "any"
        destination = "any"
        
        try:
            if len(parts) >= 2:
                if parts[1] != "any":
                    source = parts[1]
                if len(parts) >= 4 and parts[3] != "any":
                    destination = parts[3]
        except IndexError:
            pass
        
        return source, destination
    
    def _extract_ports(self, criteria: str) -> Dict[str, Any]:
        """Extract port information from ACL criteria."""
        ports = {"source_port": None, "dest_port": None, "operators": []}
        
        # Look for port operators
        if "eq " in criteria:
            ports["operators"].append("eq")
        if "neq " in criteria:
            ports["operators"].append("neq")
        if "gt " in criteria:
            ports["operators"].append("gt")
        if "lt " in criteria:
            ports["operators"].append("lt")
        if "range " in criteria:
            ports["operators"].append("range")
        
        return ports
    
    def _check_acl_structure(self, acl_config: Dict) -> List[Finding]:
        """Check ACL structural issues."""
        findings = []
        
        all_acls = {}
        all_acls.update(acl_config.get("standard_acls", {}))
        all_acls.update(acl_config.get("extended_acls", {}))
        all_acls.update(acl_config.get("named_acls", {}))
        
        # Check for empty ACLs
        empty_acls = []
        for acl_id, acl in all_acls.items():
            if not acl.get("rules"):
                empty_acls.append(acl_id)
        
        if empty_acls:
            findings.append(self.create_finding(
                rule_id="ACL-001",
                title="Empty Access Control Lists",
                description=f"Empty ACLs configured: {', '.join(empty_acls)}. "
                           f"Empty ACLs provide no security benefit and may cause confusion.",
                severity=Severity.LOW,
                category="ACL Structure",
                recommendation="Remove empty ACLs or add appropriate rules",
                fix_commands=[f"no access-list {empty_acls[0]}"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for ACLs with only permit any statements
        overly_permissive_acls = []
        for acl_id, acl in all_acls.items():
            rules = acl.get("rules", [])
            if rules and all(rule["action"] == "permit" and "any" in rule["criteria"] for rule in rules):
                overly_permissive_acls.append(acl_id)
        
        if overly_permissive_acls:
            findings.append(self.create_finding(
                rule_id="ACL-002",
                title="Overly Permissive Access Control Lists",
                description=f"ACLs that permit all traffic: {', '.join(overly_permissive_acls)}. "
                           f"These ACLs provide no access control.",
                severity=Severity.MEDIUM,
                category="ACL Structure",
                recommendation="Restrict ACL rules to only necessary traffic",
                fix_commands=["permit <specific_traffic>", "deny any"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-3", "AC-4"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_acl_rules(self, acl_config: Dict) -> List[Finding]:
        """Check individual ACL rules for security issues."""
        findings = []
        
        extended_acls = acl_config.get("extended_acls", {})
        named_extended_acls = {k: v for k, v in acl_config.get("named_acls", {}).items() 
                              if v.get("type") == "extended"}
        
        all_extended_acls = {}
        all_extended_acls.update(extended_acls)
        all_extended_acls.update(named_extended_acls)
        
        # Check for dangerous protocols and ports
        risky_rules = []
        
        for acl_id, acl in all_extended_acls.items():
            for rule in acl.get("rules", []):
                if rule["action"] == "permit":
                    protocol = rule.get("protocol", "")
                    criteria = rule.get("criteria", "")
                    
                    # Check for dangerous protocols/ports
                    dangerous_patterns = [
                        ("telnet", "eq 23", "Telnet (unencrypted)"),
                        ("ftp", "eq 21", "FTP (unencrypted)"),
                        ("tftp", "eq 69", "TFTP (insecure)"),
                        ("snmp", "eq 161", "SNMP (potentially insecure)"),
                        ("rlogin", "eq 513", "rlogin (unencrypted)"),
                        ("rsh", "eq 514", "rsh (unencrypted)"),
                        ("finger", "eq 79", "Finger (information disclosure)")
                    ]
                    
                    for service, port_pattern, description in dangerous_patterns:
                        if port_pattern in criteria.lower():
                            risky_rules.append({
                                "acl": acl_id,
                                "rule": rule,
                                "risk": description,
                                "service": service
                            })
        
        if risky_rules:
            services = list(set(r["service"] for r in risky_rules))
            first_rule = risky_rules[0]
            
            findings.append(self.create_finding(
                rule_id="ACL-003",
                title="ACL Permits Insecure Protocols",
                description=f"ACL permits insecure protocols: {', '.join(services)}. "
                           f"These protocols transmit data in clear text or have known vulnerabilities.",
                severity=Severity.HIGH,
                category="ACL Rules",
                config_line=first_rule["rule"]["config_line"],
                recommendation="Replace with secure alternatives (SSH, SFTP, HTTPS, SNMPv3)",
                fix_commands=["permit tcp any any eq 22", "deny tcp any any eq 23"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-3", "SC-8"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for overly broad source/destination addresses
        broad_rules = []
        for acl_id, acl in all_extended_acls.items():
            for rule in acl.get("rules", []):
                if rule["action"] == "permit":
                    criteria = rule.get("criteria", "")
                    if "any any" in criteria:
                        broad_rules.append({
                            "acl": acl_id,
                            "rule": rule
                        })
        
        if broad_rules:
            findings.append(self.create_finding(
                rule_id="ACL-004",
                title="ACL Rules with Overly Broad Address Ranges",
                description=f"ACL rules allowing any source to any destination found in {len(broad_rules)} rules. "
                           f"This defeats the purpose of access control.",
                severity=Severity.MEDIUM,
                category="ACL Rules",
                config_line=broad_rules[0]["rule"]["config_line"],
                recommendation="Specify specific source and destination networks",
                fix_commands=["permit tcp <SOURCE_NET> <DEST_NET> eq <PORT>"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-3", "AC-4"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_acl_application(self, acl_config: Dict, config_lines: List) -> List[Finding]:
        """Check ACL application to interfaces and lines."""
        findings = []
        
        # Check for defined but unapplied ACLs
        all_acl_ids = set()
        all_acl_ids.update(acl_config.get("standard_acls", {}).keys())
        all_acl_ids.update(acl_config.get("extended_acls", {}).keys())
        all_acl_ids.update(acl_config.get("named_acls", {}).keys())
        
        applied_acls = set()
        
        # Find applied ACLs
        for line in config_lines:
            # Handle both ConfigLine objects and strings
            if hasattr(line, 'content'):
                content = line.content.strip()
            else:
                content = str(line).strip()
                # Create a mock line object for compatibility
                class MockLine:
                    def __init__(self, content):
                        self.content = content
                        self.line_number = 0
                        self.section = ""
                line = MockLine(content)
            if "ip access-group" in content:
                match = re.search(r'ip access-group (\S+)', content)
                if match:
                    applied_acls.add(match.group(1))
            elif "access-class" in content:
                match = re.search(r'access-class (\S+)', content)
                if match:
                    applied_acls.add(match.group(1))
        
        unapplied_acls = all_acl_ids - applied_acls
        
        if unapplied_acls:
            findings.append(self.create_finding(
                rule_id="ACL-005",
                title="Defined ACLs Not Applied",
                description=f"ACLs defined but not applied: {', '.join(list(unapplied_acls)[:5])}. "
                           f"Unused ACLs provide no security benefit and create maintenance overhead.",
                severity=Severity.LOW,
                category="ACL Application",
                recommendation="Apply ACLs to interfaces/lines or remove unused ACLs",
                fix_commands=["ip access-group <ACL_NAME> in", "access-class <ACL_NAME> in"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="H",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AC-3"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check for interfaces without ACLs (simplified check)
        interfaces_without_acls = []
        current_interface = None
        interface_has_acl = False
        
        for line in config_lines:
            # Handle both ConfigLine objects and strings
            if hasattr(line, 'content'):
                content = line.content.strip()
            else:
                content = str(line).strip()
                # Create a mock line object for compatibility
                class MockLine:
                    def __init__(self, content):
                        self.content = content
                        self.line_number = 0
                        self.section = ""
                line = MockLine(content)
            if content.startswith("interface "):
                if current_interface and not interface_has_acl:
                    if not current_interface.startswith("Loopback"):
                        interfaces_without_acls.append(current_interface)
                
                current_interface = content.split()[1]
                interface_has_acl = False
            elif current_interface and "ip access-group" in content:
                interface_has_acl = True
        
        # Check last interface
        if current_interface and not interface_has_acl and not current_interface.startswith("Loopback"):
            interfaces_without_acls.append(current_interface)
        
        if len(interfaces_without_acls) > 5:  # Only flag if many interfaces lack ACLs
            findings.append(self.create_finding(
                rule_id="ACL-006",
                title="Multiple Interfaces Without Access Control",
                description=f"{len(interfaces_without_acls)} interfaces without ACLs applied. "
                           f"Unprotected interfaces may allow unauthorized traffic.",
                severity=Severity.MEDIUM,
                category="ACL Application",
                recommendation="Apply appropriate ACLs to interfaces based on security zones",
                fix_commands=["ip access-group <ACL_NAME> in"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-3", "SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_acl_logging(self, acl_config: Dict) -> List[Finding]:
        """Check ACL logging configuration."""
        findings = []
        
        all_acls = {}
        all_acls.update(acl_config.get("standard_acls", {}))
        all_acls.update(acl_config.get("extended_acls", {}))
        all_acls.update(acl_config.get("named_acls", {}))
        
        # Check for ACLs without logging
        acls_without_logging = []
        for acl_id, acl in all_acls.items():
            if not acl.get("has_logging"):
                acls_without_logging.append(acl_id)
        
        if acls_without_logging:
            findings.append(self.create_finding(
                rule_id="ACL-007",
                title="ACLs Without Logging Configuration",
                description=f"ACLs without logging: {', '.join(acls_without_logging[:5])}. "
                           f"Missing logs reduce security monitoring and incident response capabilities.",
                severity=Severity.MEDIUM,
                category="ACL Logging",
                recommendation="Add logging to ACL rules for security monitoring",
                fix_commands=["permit tcp any any eq 80 log", "deny ip any any log"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["AU-2", "AU-3", "SI-4"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_acl_security_best_practices(self, acl_config: Dict) -> List[Finding]:
        """Check ACL security best practices."""
        findings = []
        
        # Check for reflexive ACLs (basic check)
        extended_acls = acl_config.get("extended_acls", {})
        named_extended_acls = {k: v for k, v in acl_config.get("named_acls", {}).items() 
                              if v.get("type") == "extended"}
        
        all_extended_acls = {}
        all_extended_acls.update(extended_acls)
        all_extended_acls.update(named_extended_acls)
        
        # Check for established connections
        acls_without_established = []
        for acl_id, acl in all_extended_acls.items():
            has_established = False
            for rule in acl.get("rules", []):
                if "established" in rule.get("criteria", "").lower():
                    has_established = True
                    break
            
            if not has_established and any("tcp" in rule.get("protocol", "") for rule in acl.get("rules", [])):
                acls_without_established.append(acl_id)
        
        if acls_without_established:
            findings.append(self.create_finding(
                rule_id="ACL-008",
                title="TCP ACLs Without Established Connection Rules",
                description=f"TCP ACLs without 'established' keyword: {', '.join(acls_without_established[:3])}. "
                           f"May allow unwanted inbound TCP connections.",
                severity=Severity.MEDIUM,
                category="ACL Best Practices",
                recommendation="Use 'established' keyword for return TCP traffic",
                fix_commands=["permit tcp any any established"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-3", "SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _analyze_juniper_acls(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Juniper ACL configuration (placeholder)."""
        # TODO: Implement Juniper firewall filter analysis
        return []