"""Utility functions for security engines."""

from typing import Any, Union
from ..core import ConfigLine


def safe_get_content(line: Union[ConfigLine, str, Any]) -> str:
    """Safely extract content from a line object or string."""
    if hasattr(line, 'content'):
        return str(line.content).strip()
    elif isinstance(line, str):
        return line.strip()
    else:
        return str(line).strip()


def safe_get_line_number(line: Union[ConfigLine, str, Any]) -> int:
    """Safely extract line number from a line object."""
    if hasattr(line, 'line_number'):
        return int(line.line_number)
    return 0


def create_mock_config_line(content: str, line_number: int = 0, section: str = "") -> ConfigLine:
    """Create a ConfigLine object for compatibility."""
    return ConfigLine(
        line_number=line_number,
        content=content,
        section=section,
        indentation=0
    )