"""Spanning Tree Protocol Security Analysis Engine."""

import re
from typing import List, Dict, Any
from ..base_engine import SwitchingSecurityEngine, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector


class STPSecurityEngine(SwitchingSecurityEngine):
    """Comprehensive Spanning Tree Protocol security analysis."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 12
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze STP configuration for security issues."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_stp(parsed_config))
        
        return findings
    
    def _analyze_cisco_stp(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco STP configuration."""
        findings = []
        
        # Extract interface and STP configuration
        interfaces = self._extract_interface_config(config.get("config_lines", []))
        global_stp_config = self._extract_global_stp_config(config.get("config_lines", []))
        
        # Run STP security checks
        findings.extend(self.check_spanning_tree_security(interfaces, global_stp_config))
        findings.extend(self.check_port_security(interfaces))
        findings.extend(self.check_vlan_security(interfaces, config.get("config_lines", [])))
        
        return findings
    
    def _extract_interface_config(self, config_lines: List) -> Dict[str, Dict]:
        """Extract interface configurations."""
        interfaces = {}
        current_interface = None
        
        for line in config_lines:
            # Handle both ConfigLine objects and strings
            if hasattr(line, 'content'):
                content = line.content.strip()
            else:
                content = str(line).strip()
                # Create a mock line object for compatibility
                class MockLine:
                    def __init__(self, content):
                        self.content = content
                        self.line_number = 0
                        self.section = ""
                line = MockLine(content)
            
            # Interface definition
            interface_match = re.match(r'interface (\S+)', content)
            if interface_match:
                interface_name = interface_match.group(1)
                current_interface = interface_name
                interfaces[interface_name] = {
                    "name": interface_name,
                    "config_line": line,
                    "commands": [],
                    "switchport_mode": None,
                    "access_vlan": None,
                    "trunk_vlans": None,
                    "spanning_tree": {
                        "portfast": False,
                        "bpduguard": False,
                        "rootguard": False,
                        "loopguard": False,
                        "udld": False
                    },
                    "port_security": {
                        "enabled": False,
                        "max_addresses": None,
                        "violation_action": None,
                        "sticky": False
                    },
                    "storm_control": {
                        "broadcast": None,
                        "multicast": None,
                        "unicast": None
                    }
                }
                continue
            
            # End of interface section
            if current_interface and (content.startswith('interface ') or 
                                    content.startswith('router ') or
                                    content.startswith('line ')):
                current_interface = None
                continue
            
            if current_interface and current_interface in interfaces:
                interface_config = interfaces[current_interface]
                interface_config["commands"].append(line)
                
                # Parse interface commands
                if "switchport mode" in content:
                    interface_config["switchport_mode"] = content.split()[-1]
                elif "switchport access vlan" in content:
                    interface_config["access_vlan"] = content.split()[-1]
                elif "switchport trunk allowed vlan" in content:
                    interface_config["trunk_vlans"] = content
                
                # Spanning tree commands
                elif "spanning-tree portfast" in content:
                    interface_config["spanning_tree"]["portfast"] = "disable" not in content
                elif "spanning-tree bpduguard" in content:
                    interface_config["spanning_tree"]["bpduguard"] = "disable" not in content
                elif "spanning-tree guard root" in content:
                    interface_config["spanning_tree"]["rootguard"] = True
                elif "spanning-tree guard loop" in content:
                    interface_config["spanning_tree"]["loopguard"] = True
                elif "udld port" in content:
                    interface_config["spanning_tree"]["udld"] = "disable" not in content
                
                # Port security commands
                elif "switchport port-security" in content:
                    if content.strip() == "switchport port-security":
                        interface_config["port_security"]["enabled"] = True
                    elif "maximum" in content:
                        interface_config["port_security"]["max_addresses"] = content.split()[-1]
                    elif "violation" in content:
                        interface_config["port_security"]["violation_action"] = content.split()[-1]
                    elif "mac-address sticky" in content:
                        interface_config["port_security"]["sticky"] = True
                
                # Storm control commands
                elif "storm-control broadcast" in content:
                    interface_config["storm_control"]["broadcast"] = content
                elif "storm-control multicast" in content:
                    interface_config["storm_control"]["multicast"] = content
                elif "storm-control unicast" in content:
                    interface_config["storm_control"]["unicast"] = content
        
        return interfaces
    
    def _extract_global_stp_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract global spanning tree configuration."""
        stp_config = {
            "mode": "pvst+",  # Default
            "root_guard_timeout": None,
            "bpduguard_timeout": None,
            "loopguard_default": False,
            "portfast_default": False,
            "bpduguard_default": False
        }
        
        for line in config_lines:
            # Handle both ConfigLine objects and strings
            if hasattr(line, 'content'):
                content = line.content.strip()
            else:
                content = str(line).strip()
                # Create a mock line object for compatibility
                class MockLine:
                    def __init__(self, content):
                        self.content = content
                        self.line_number = 0
                        self.section = ""
                line = MockLine(content)
            
            if "spanning-tree mode" in content:
                stp_config["mode"] = content.split()[-1]
            elif "spanning-tree loopguard default" in content:
                stp_config["loopguard_default"] = True
            elif "spanning-tree portfast default" in content:
                stp_config["portfast_default"] = True
            elif "spanning-tree portfast bpduguard default" in content:
                stp_config["bpduguard_default"] = True
            elif "spanning-tree guard root timeout" in content:
                stp_config["root_guard_timeout"] = content.split()[-1]
        
        return stp_config
    
    def check_spanning_tree_security(self, interfaces: Dict, global_stp: Dict) -> List[Finding]:
        """Check spanning tree security configuration."""
        findings = []
        
        # Check for access ports without BPDU guard
        access_ports_without_bpduguard = []
        trunk_ports_without_rootguard = []
        access_ports_without_portfast = []
        
        for interface_name, interface_config in interfaces.items():
            switchport_mode = interface_config.get("switchport_mode")
            stp_config = interface_config.get("spanning_tree", {})
            
            # Skip non-switchports
            if not switchport_mode:
                continue
            
            # Check access ports
            if switchport_mode == "access":
                if not stp_config.get("bpduguard") and not global_stp.get("bpduguard_default"):
                    access_ports_without_bpduguard.append(interface_name)
                
                if not stp_config.get("portfast") and not global_stp.get("portfast_default"):
                    access_ports_without_portfast.append(interface_name)
            
            # Check trunk ports  
            elif switchport_mode == "trunk":
                if not stp_config.get("rootguard"):
                    trunk_ports_without_rootguard.append(interface_name)
        
        # Report access ports without BPDU guard
        if access_ports_without_bpduguard:
            findings.append(self.create_finding(
                rule_id="STP-001",
                title="Access Ports Without BPDU Guard",
                description=f"Access ports without BPDU guard: {', '.join(access_ports_without_bpduguard[:5])}. "
                           f"Vulnerable to spanning tree manipulation attacks.",
                severity=Severity.HIGH,
                category="Spanning Tree Security",
                config_line=interfaces[access_ports_without_bpduguard[0]]["config_line"],
                recommendation="Enable BPDU guard on all access ports",
                fix_commands=[
                    f"interface {access_ports_without_bpduguard[0]}",
                    "spanning-tree bpduguard enable"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L", 
                    privileges_required="N",
                    confidentiality="N",
                    integrity="L",
                    availability="H"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Report access ports without portfast
        if access_ports_without_portfast:
            findings.append(self.create_finding(
                rule_id="STP-002",
                title="Access Ports Without PortFast",
                description=f"Access ports without PortFast: {', '.join(access_ports_without_portfast[:5])}. "
                           f"Causes unnecessary convergence delays.",
                severity=Severity.MEDIUM,
                category="Spanning Tree Security",
                config_line=interfaces[access_ports_without_portfast[0]]["config_line"],
                recommendation="Enable PortFast on access ports connected to end devices",
                fix_commands=[
                    f"interface {access_ports_without_portfast[0]}", 
                    "spanning-tree portfast"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="L",
                    confidentiality="N",
                    integrity="N",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Report trunk ports without root guard
        if trunk_ports_without_rootguard:
            findings.append(self.create_finding(
                rule_id="STP-003",
                title="Trunk Ports Without Root Guard",
                description=f"Trunk ports without root guard: {', '.join(trunk_ports_without_rootguard[:5])}. "
                           f"Vulnerable to root bridge takeover attacks.",
                severity=Severity.MEDIUM,
                category="Spanning Tree Security",
                config_line=interfaces[trunk_ports_without_rootguard[0]]["config_line"],
                recommendation="Enable root guard on trunk ports to prevent root bridge changes",
                fix_commands=[
                    f"interface {trunk_ports_without_rootguard[0]}",
                    "spanning-tree guard root"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N", 
                    confidentiality="N",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def check_port_security(self, interfaces: Dict) -> List[Finding]:
        """Check port security configuration.""" 
        findings = []
        
        access_ports_without_port_security = []
        ports_with_weak_port_security = []
        
        for interface_name, interface_config in interfaces.items():
            switchport_mode = interface_config.get("switchport_mode")
            port_security = interface_config.get("port_security", {})
            
            # Only check access ports
            if switchport_mode != "access":
                continue
            
            if not port_security.get("enabled"):
                access_ports_without_port_security.append(interface_name)
            else:
                # Check for weak port security configuration
                max_addresses = port_security.get("max_addresses")
                violation_action = port_security.get("violation_action")
                
                if not max_addresses or int(max_addresses) > 10:
                    ports_with_weak_port_security.append(interface_name)
                elif violation_action not in ["shutdown", "restrict"]:
                    ports_with_weak_port_security.append(interface_name)
        
        # Report access ports without port security
        if access_ports_without_port_security:
            findings.append(self.create_finding(
                rule_id="STP-004",
                title="Access Ports Without Port Security",
                description=f"Access ports without port security: {', '.join(access_ports_without_port_security[:5])}. "
                           f"Vulnerable to MAC address table overflow attacks.",
                severity=Severity.MEDIUM,
                category="Port Security",
                config_line=interfaces[access_ports_without_port_security[0]]["config_line"],
                recommendation="Enable port security on access ports",
                fix_commands=[
                    f"interface {access_ports_without_port_security[0]}",
                    "switchport port-security",
                    "switchport port-security maximum 2",
                    "switchport port-security violation shutdown"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="N", 
                    integrity="L",
                    availability="H"
                ),
                nist_controls=["SC-7", "AC-4"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def check_vlan_security(self, interfaces: Dict, config_lines: List) -> List[Finding]:
        """Check VLAN security configuration."""
        findings = []
        
        # Check for VLAN 1 usage
        vlan1_access_ports = []
        native_vlan1_trunks = []
        
        for interface_name, interface_config in interfaces.items():
            access_vlan = interface_config.get("access_vlan")
            switchport_mode = interface_config.get("switchport_mode")
            
            if switchport_mode == "access" and access_vlan == "1":
                vlan1_access_ports.append(interface_name)
            elif switchport_mode == "trunk":
                # Check for native VLAN 1 (default)
                trunk_native_found = False
                for line in interface_config.get("commands", []):
                    if "switchport trunk native vlan" in line.content:
                        trunk_native_found = True
                        break
                
                if not trunk_native_found:  # Default native VLAN 1
                    native_vlan1_trunks.append(interface_name)
        
        # Report VLAN 1 usage issues
        if vlan1_access_ports or native_vlan1_trunks:
            findings.append(self.create_finding(
                rule_id="STP-005",
                title="VLAN 1 Security Issues",
                description=f"VLAN 1 usage detected on access ports: {', '.join(vlan1_access_ports[:3])} "
                           f"and trunk native VLAN: {', '.join(native_vlan1_trunks[:3])}. "
                           f"VLAN 1 cannot be pruned and may carry unnecessary traffic.",
                severity=Severity.LOW,
                category="VLAN Security",
                recommendation="Minimize VLAN 1 usage and change native VLAN on trunks",
                fix_commands=[
                    "switchport trunk native vlan 999",
                    "switchport access vlan 10"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="A",
                    attack_complexity="H",
                    privileges_required="L",
                    confidentiality="L",
                    integrity="L", 
                    availability="N"
                ),
                nist_controls=["SC-7"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings