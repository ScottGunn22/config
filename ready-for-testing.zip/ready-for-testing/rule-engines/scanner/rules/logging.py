"""Logging and monitoring security rules."""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class LoggingRules(BaseRuleEngine):
    """Security rules for logging and monitoring configurations."""
    
    def __init__(self):
        super().__init__()
        self.category = "Logging"
    
    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check logging-related security rules."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._check_cisco_logging(parsed_config))
        
        return findings
    
    def _check_cisco_logging(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Cisco IOS logging rules."""
        findings = []
        logging = config.get("logging", {})
        
        # Rule: Logging hosts configured but no trap level
        hosts = logging.get("hosts", [])
        if hosts and not logging.get("level"):
            # Find first logging host line for context
            config_line = hosts[0].get("line") if hosts else None
            
            findings.append(self.create_finding(
                rule_id="LOG-001",
                title="Basic Logging Configuration",
                description="Logging host configured but trap level not specified, potentially missing critical security events.",
                severity="LOW",
                config_line=config_line,
                recommendation="Configure appropriate logging level",
                fix_commands=["logging trap informational"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="N",
                    availability="N"
                ),
                nist_controls=["AU-3", "AU-6"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings