#!/bin/bash
# Verify package integrity and readiness

echo "=========================================="
echo "Package Integrity Verification"
echo "=========================================="
echo ""

ERRORS=0

# Check required files
echo "Checking required files..."
REQUIRED_FILES=(
    "README.md"
    "QUICK_START.md"
    "MANIFEST.md"
    "SETUP.sh"
    "requirements.txt"
    "config-parser/enterprise_security_parser.py"
    "config-parser/benchmark_validator.py"
    "config-parser/benchmark_rules.py"
    "config-parser/cva_mapping.json"
    "config-parser/validate_findings.py"
    "config-parser/compare_results.py"
    "rule-engines/scanner/core.py"
    "test-configs/false_positive_test.txt"
    "test-configs/false_positive_expected.json"
    "docs/FALSE_POSITIVE_DETECTION.md"
    "docs/TESTING_GUIDE.md"
    "examples/sample-cisco-config.txt"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ MISSING: $file"
        ERRORS=$((ERRORS + 1))
    fi
done

echo ""
echo "Checking executability..."
if [ -x "SETUP.sh" ]; then
    echo "  ✓ SETUP.sh is executable"
else
    echo "  ✗ SETUP.sh is not executable"
    ERRORS=$((ERRORS + 1))
fi

if [ -x "config-parser/enterprise_security_parser.py" ]; then
    echo "  ✓ enterprise_security_parser.py is executable"
else
    echo "  ✗ enterprise_security_parser.py is not executable"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "Checking JSON files..."
for jsonfile in config-parser/cva_mapping.json test-configs/false_positive_expected.json; do
    if python3 -m json.tool "$jsonfile" > /dev/null 2>&1; then
        echo "  ✓ $jsonfile is valid JSON"
    else
        echo "  ✗ $jsonfile has JSON errors"
        ERRORS=$((ERRORS + 1))
    fi
done

echo ""
echo "Checking Python syntax..."
for pyfile in config-parser/*.py; do
    if python3 -m py_compile "$pyfile" 2>/dev/null; then
        echo "  ✓ $(basename $pyfile) syntax OK"
    else
        echo "  ✗ $(basename $pyfile) has syntax errors"
        ERRORS=$((ERRORS + 1))
    fi
done

echo ""
echo "=========================================="
if [ $ERRORS -eq 0 ]; then
    echo "✓ Package verification PASSED"
    echo "  All files present and valid"
    echo "  Ready for testing"
    echo ""
    echo "Next step: Run ./SETUP.sh"
else
    echo "✗ Package verification FAILED"
    echo "  $ERRORS error(s) found"
    echo "  Fix errors before proceeding"
fi
echo "=========================================="

exit $ERRORS
