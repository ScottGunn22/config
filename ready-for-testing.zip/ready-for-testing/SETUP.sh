#!/bin/bash
# Enterprise Network Security Configuration Parser - Setup Script

set -e

echo "=========================================="
echo "Enterprise Security Parser - Setup"
echo "=========================================="
echo ""

# Check Python version
echo "[1/5] Checking Python version..."
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)
REQUIRED_VERSION="3.8"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo "ERROR: Python 3.8 or higher required. Found: $PYTHON_VERSION"
    exit 1
fi
echo "✓ Python $PYTHON_VERSION detected"
echo ""

# Create Python path configuration
echo "[2/5] Setting up Python paths..."
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Create a simple startup script
cat > "$SCRIPT_DIR/run_scanner.sh" << 'EOF'
#!/bin/bash
# Convenience script to run the scanner with correct paths

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export PYTHONPATH="$SCRIPT_DIR/rule-engines:$PYTHONPATH"

cd "$SCRIPT_DIR"
python3 config-parser/enterprise_security_parser.py "$@"
EOF

chmod +x "$SCRIPT_DIR/run_scanner.sh"
echo "✓ Python paths configured"
echo ""

# Update enterprise_security_parser.py to use local rule engines
echo "[3/5] Configuring rule engine paths..."
sed -i "s|sys.path.insert(0, '/home/sx0tt/work/network-security-scanner/src')|sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'rule-engines'))|g" "$SCRIPT_DIR/config-parser/enterprise_security_parser.py"
echo "✓ Rule engine paths updated"
echo ""

# Make scripts executable
echo "[4/5] Making scripts executable..."
chmod +x "$SCRIPT_DIR/config-parser/enterprise_security_parser.py"
chmod +x "$SCRIPT_DIR/config-parser/validate_findings.py"
chmod +x "$SCRIPT_DIR/config-parser/compare_results.py"
echo "✓ Scripts are now executable"
echo ""

# Run quick test
echo "[5/5] Running validation test..."
export PYTHONPATH="$SCRIPT_DIR/rule-engines:$PYTHONPATH"
cd "$SCRIPT_DIR"

python3 config-parser/enterprise_security_parser.py \
    test-configs/false_positive_test.txt \
    --output test-output.html > /dev/null 2>&1

if [ -f "test-output.html" ]; then
    echo "✓ Test scan completed successfully"
    rm test-output.html
else
    echo "⚠ Test scan completed with warnings (check manually)"
fi
echo ""

# Success message
echo "=========================================="
echo "✓ Setup Complete!"
echo "=========================================="
echo ""
echo "Quick start:"
echo "  ./run_scanner.sh test-configs/false_positive_test.txt -o test.html"
echo ""
echo "Or use directly:"
echo "  python3 config-parser/enterprise_security_parser.py <config> -o <output>"
echo ""
echo "Documentation:"
echo "  README.md         - Full documentation"
echo "  QUICK_START.md    - 5-minute tutorial"
echo "  docs/             - Detailed guides"
echo ""
echo "Next steps:"
echo "  1. Read QUICK_START.md"
echo "  2. Customize config-parser/cva_mapping.json"
echo "  3. Scan your first config!"
echo ""
