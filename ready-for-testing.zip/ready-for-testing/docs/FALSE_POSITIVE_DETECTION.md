# False Positive Detection Strategies

## Overview
This document outlines strategies to identify and eliminate false positives in the security scanner.

## 1. Automated Testing (Recommended)

### Setup Test Suite
```bash
# Create test config
vim test_configs/false_positive_test.txt

# Run scanner
python3 enterprise_security_parser.py test_configs/false_positive_test.txt \
  --output test_results.json --format json

# Validate results
python3 validate_findings.py \
  test_configs/false_positive_expected.json \
  test_results.json
```

### Benefits
- Repeatable validation
- Catches regressions
- Quantifies accuracy (FP rate, FN rate)

## 2. Comparison Against Known Tools

### Compare with Nipper
```bash
# Run Nipper on same config
nipper --ios --input=config.txt --output=nipper_report.html

# Run our scanner
python3 enterprise_security_parser.py config.txt -o our_report.html

# Manual comparison:
# - What did Nipper catch that we missed? (False Negatives)
# - What did we catch that Nipper didn't? (Could be False Positives OR better detection)
# - What findings are common? (Likely correct)
```

### Red Flags for False Positives
- **We flag 50+ issues, Nipper flags 15** → Likely over-detecting
- **Findings on unusual line numbers** → Check config context
- **Same rule triggering 10+ times** → May be too sensitive

## 3. Manual Code Review Patterns

### Common False Positive Causes

#### A. Overly Broad Regex
```python
# BAD: Matches too much
r'password'  # Matches "password", "passwords", "password-policy", etc.

# GOOD: More specific
r'\bpassword\s+(?![57]\s)'  # Word boundary, followed by space, not type 5/7
```

#### B. Missing Context
```python
# BAD: Flags all "password" occurrences
if "password" in line:
    flag_issue()

# GOOD: Check context
if line.startswith("enable password") and not is_encrypted(line):
    flag_issue()
```

#### C. Ignoring Configuration Blocks
```python
# BAD: Flags "no shutdown" globally
if "shutdown" in config:
    flag_issue("Interface not shutdown")

# GOOD: Parse interface blocks
if in_interface_block and not has_shutdown():
    flag_issue()
```

## 4. Statistical Analysis

### Run Against 10+ Configs
```bash
# Generate reports for multiple configs
for config in configs/*.txt; do
    python3 enterprise_security_parser.py "$config" \
      -o "results/$(basename $config .txt).json" -f json
done

# Analyze patterns
python3 analyze_patterns.py results/*.json
```

### Look For:
- **Findings that appear in 100% of configs** → May be false positives or defaults
  - Example: "CDP Enabled" appears everywhere → Maybe too aggressive
- **Findings with unusual frequency** → Investigate
- **Findings on similar line numbers across configs** → Could indicate template detection

## 5. Context-Aware Validation

### Environment Flags
Add context to reduce false positives:

```python
# In scanner
parser.add_argument('--environment', choices=['production', 'lab', 'dmz', 'internal'])
parser.add_argument('--risk-tolerance', choices=['strict', 'moderate', 'relaxed'])

# Adjust rules based on context
if environment == 'lab':
    # Don't flag missing AAA (labs often use local auth)
    skip_rule('AUTH-002')

if environment == 'dmz':
    # Stricter on external-facing services
    severity_increase(['HTTP', 'Telnet', 'SNMP'])
```

### Device Type Detection
```python
# Detect device role from config
if has_wireless_controller_config():
    # Don't flag CDP on wireless controllers (needed for AP discovery)
    suppress_finding('NET-003', reason='Wireless controller needs CDP')
```

## 6. Peer Review Process

### Review Workflow
1. **First Pass** - Automated scanner
2. **Technical Review** - Network engineer validates findings
3. **False Positive Tagging** - Mark incorrect findings
4. **Pattern Analysis** - Identify why false positives occurred
5. **Rule Refinement** - Update detection logic

### Checklist for Reviewers
- [ ] Does finding make sense given device role?
- [ ] Is configuration command legitimate for this vendor?
- [ ] Are there business reasons for this "issue"?
- [ ] Would fixing this break legitimate functionality?
- [ ] Is the line number correct?

## 7. Whitelist/Exception Management

### Create Exception File
```json
{
  "exceptions": {
    "NET-003": {
      "reason": "CDP required for Cisco wireless infrastructure",
      "applies_to": ["device_role:wireless_controller"],
      "approved_by": "Network Team",
      "expiry": "2025-12-31"
    },
    "NET-007": {
      "reason": "DNS required for dynamic routing updates",
      "applies_to": ["hostname:border-*"],
      "approved_by": "John Smith",
      "expiry": "permanent"
    }
  }
}
```

## 8. Confidence Scoring

### Add Confidence Levels
```python
finding.confidence = "high"  # 90-100% sure
finding.confidence = "medium"  # 70-90% sure
finding.confidence = "low"  # 50-70% sure - needs review

# Example
if "enable password" in line:
    if is_default_password(line):
        confidence = "high"  # Definitely a problem
    elif is_weak_password(line):
        confidence = "medium"  # Probably a problem
    else:
        confidence = "low"  # Maybe a problem
```

## 9. Field Validation Metrics

### Track in Production
```python
findings_log = {
    "finding_id": "AUTH-001-20250101-001",
    "rule_id": "AUTH-001",
    "device": "router1",
    "marked_false_positive": False,
    "reviewed_by": "admin",
    "review_date": "2025-01-15",
    "action_taken": "remediated"
}
```

### Calculate Metrics
- **False Positive Rate**: FP / (FP + TP)
- **Precision**: TP / (TP + FP)
- **Recall**: TP / (TP + FN)

Target: **<5% false positive rate** for production use

## 10. Red Team Testing

### Have Security Team Review
- Intentionally misconfigure test devices
- Run scanner
- Check if all misconfigurations detected
- Check if any correct configs flagged

## Quick Reference: Testing Workflow

```bash
# 1. Create test config with known issues
vim test_configs/test1.txt

# 2. Document expected findings
vim test_configs/test1_expected.json

# 3. Run scanner
python3 enterprise_security_parser.py test_configs/test1.txt \
  -o test1_results.json -f json

# 4. Validate
python3 validate_findings.py \
  test_configs/test1_expected.json \
  test1_results.json

# 5. Review false positives
cat test1_results.json | jq '.security_findings[] | select(.line_number == 8)'

# 6. Fix detection logic
vim comprehensive_security.py

# 7. Re-test
python3 enterprise_security_parser.py test_configs/test1.txt \
  -o test1_results.json -f json

# 8. Repeat until clean
```

## Success Criteria

A finding is likely a **false positive** if:
- ✓ Command is legitimate vendor syntax
- ✓ Required for specific functionality
- ✓ Business justification exists
- ✓ Multiple engineers disagree with finding
- ✓ Fixing would break production
- ✓ Not mentioned in CIS/STIG/vendor guides

A finding is likely **correct** if:
- ✓ Matches CIS/STIG benchmark
- ✓ Appears in vendor security guides
- ✓ CVE exists for this misconfiguration
- ✓ Industry best practice violation
- ✓ Obviously insecure (plaintext passwords)
