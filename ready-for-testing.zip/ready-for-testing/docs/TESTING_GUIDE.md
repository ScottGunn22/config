# Testing Guide - False Positive Detection

## Quick Start

### 1. Test Against Known Config
```bash
# Run scanner on test config
python3 enterprise_security_parser.py \
  test_configs/false_positive_test.txt \
  -o test_results.json -f json

# Validate results
python3 validate_findings.py \
  test_configs/false_positive_expected.json \
  test_results.json
```

Expected output:
```
================================================================================
FINDING VALIDATION REPORT
================================================================================

SUMMARY
--------------------------------------------------------------------------------
Total Findings: 10
Correct: 8 (80.0%)
False Positives: 1 (10.0%)
False Negatives: 1 (10.0%)
```

### 2. Compare Against Nipper (if available)
```bash
# Run both tools on same config
nipper --ios --input=config.txt --output=nipper.json --format=json
python3 enterprise_security_parser.py config.txt -o ours.json -f json

# Compare results
python3 compare_results.py nipper.json ours.json
```

### 3. Manual Review Process
```bash
# Generate HTML report for review
python3 enterprise_security_parser.py config.txt -o report.html

# Open in browser and check:
# - Do findings make sense?
# - Are line numbers correct?
# - Any obvious false positives?
```

## Testing Checklist

### Before QC Testing
- [ ] Run against false_positive_test.txt
- [ ] Validate <5% false positive rate
- [ ] Check all CVA IDs appear correctly
- [ ] Verify deduplication works
- [ ] Test HTML and JSON output formats

### During QC Testing (1 week)
- [ ] Test against 10+ production configs
- [ ] Document all false positives found
- [ ] Track false positive rate per rule
- [ ] Compare against Nipper/industry tools
- [ ] Get peer review from 2+ network engineers

### Before Production
- [ ] False positive rate <5%
- [ ] All critical findings verified
- [ ] Exception/whitelist mechanism in place
- [ ] User documentation complete
- [ ] Training provided to users

## Common False Positive Patterns

### Pattern 1: Keyword Matching
**Problem:** Rule flags any occurrence of "password"
```
Line 8: mpls ldp logging password configuration  ← FALSE POSITIVE
```

**Fix:** Use context-aware matching
```python
# Only flag actual password commands
if line.startswith("enable password") or "username" in line:
    check_password(line)
```

### Pattern 2: Default Assumptions
**Problem:** Rule assumes feature not explicitly disabled
```
Finding: "CDP Enabled" ← May be intentional
```

**Fix:** Lower severity or add context flags
```python
if not args.dmz:  # CDP okay for internal networks
    severity = "LOW"
```

### Pattern 3: Environment Specific
**Problem:** Lab configs flagged as production risks
```
Finding: "No AAA configured" ← Expected in labs
```

**Fix:** Add environment awareness
```python
if environment != 'lab':
    flag_missing_aaa()
```

## Validation Metrics

### Target Metrics
- **Accuracy**: >95%
- **Precision** (TP/(TP+FP)): >90%
- **Recall** (TP/(TP+FN)): >85%
- **False Positive Rate**: <5%

### How to Calculate
```python
true_positives = correct_findings
false_positives = len(false_positive_list)
false_negatives = len(missed_issues)

precision = true_positives / (true_positives + false_positives)
recall = true_positives / (true_positives + false_negatives)
fp_rate = false_positives / (false_positives + true_positives)
```

## Tools Reference

### validate_findings.py
Validates scanner output against expected results.
```bash
python3 validate_findings.py <expected.json> <results.json>
```

### compare_results.py
Compares two scanner runs or tools.
```bash
python3 compare_results.py <baseline.json> <current.json>
```

## Creating Test Cases

### Test Case Template
```bash
# 1. Create test config
cat > test_configs/my_test.txt << 'EOF'
! Test description
enable password weak123  # SHOULD FLAG
password encryption aes  # SHOULD NOT FLAG
EOF

# 2. Create expected findings
cat > test_configs/my_test_expected.json << 'EOF'
{
  "should_flag": {
    "Plain Text Password Detected": [2]
  },
  "should_not_flag": {
    "password encryption": [3]
  }
}
EOF

# 3. Run test
python3 enterprise_security_parser.py test_configs/my_test.txt \
  -o my_test_results.json -f json

# 4. Validate
python3 validate_findings.py \
  test_configs/my_test_expected.json \
  my_test_results.json
```

## Debugging False Positives

### Step-by-Step Process
1. **Identify the finding**
   ```bash
   cat results.json | jq '.security_findings[] | select(.line_number == 8)'
   ```

2. **Check the config line**
   ```bash
   sed -n '8p' config.txt
   ```

3. **Find the detection rule**
   ```bash
   grep -r "COMP-002" network-security-scanner/
   ```

4. **Review the regex/logic**
   ```python
   # In comprehensive_security.py line 61
   if re.search(r'password (?![57]\s)[A-Za-z0-9]', line.content, re.I):
   ```

5. **Test the fix**
   ```python
   # Improve the regex to be more specific
   if re.search(r'^(enable\s+password|username.*password)\s+', line.content):
   ```

6. **Re-run validation**
   ```bash
   python3 validate_findings.py ...
   ```

## Red Flags for False Positives

Watch for these warning signs:

- ⚠️ **High finding count** (50+ on typical config)
- ⚠️ **Unusual line numbers** (flags comments or blank lines)
- ⚠️ **Same rule repeating** (10+ instances of same issue)
- ⚠️ **Vendor-specific features flagged** (legitimate commands)
- ⚠️ **Context-less detection** (doesn't parse config structure)

## Getting Help

If you find persistent false positives:

1. Document the finding with config context
2. Check against CIS/STIG benchmarks
3. Ask network engineering team
4. Compare with Nipper/commercial tools
5. Review FALSE_POSITIVE_DETECTION.md

## Success Stories

### Example: Password Detection Fix
**Before:** 25 findings, 12 false positives (48% FP rate)
- Flagged "mpls ldp logging password"
- Flagged "password encryption aes"
- Flagged event manager tracking

**After:** 13 findings, 0 false positives (0% FP rate)
- Fixed regex to match actual password commands
- Added keyword exclusions
- Context-aware detection

**Result:** Production ready ✓
