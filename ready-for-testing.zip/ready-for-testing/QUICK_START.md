# Quick Start - 5 Minutes to Your First Report

## Step 1: Setup (1 minute)

```bash
cd /home/sx0tt/work/ready-for-testing

# Run setup
chmod +x SETUP.sh
./SETUP.sh
```

## Step 2: Run Your First Scan (1 minute)

```bash
# Scan the test configuration
python3 config-parser/enterprise_security_parser.py \
  test-configs/false_positive_test.txt \
  --output my-first-report.html
```

Open `my-first-report.html` in your browser to see the results!

## Step 3: Scan Your Own Config (2 minutes)

```bash
# Copy your config to this directory
cp /path/to/your/router-config.txt .

# Scan it
python3 config-parser/enterprise_security_parser.py \
  router-config.txt \
  --output router-report.html

# Open the report
firefox router-report.html  # or chrome, or your browser
```

## Step 4: Validate Results (1 minute)

```bash
# Run the validation test to check accuracy
python3 config-parser/enterprise_security_parser.py \
  test-configs/false_positive_test.txt \
  -o test_results.json -f json

python3 config-parser/validate_findings.py \
  test-configs/false_positive_expected.json \
  test_results.json
```

Expected output:
```
================================================================================
FINDING VALIDATION REPORT
================================================================================

SUMMARY
--------------------------------------------------------------------------------
Total Findings: X
Correct: X (XX%)
False Positives: 0-1 (<5%)
False Negatives: 0-1 (<5%)
```

## Understanding Your Report

### Severity Levels

| Severity | Color | Meaning | Action |
|----------|-------|---------|--------|
| 🔴 CRITICAL | Red | Immediate risk | Fix now |
| 🟠 HIGH | Orange | Serious issue | Fix within days |
| 🟡 MEDIUM | Yellow | Moderate risk | Fix within weeks |
| 🟢 LOW | Green | Minor issue | Fix when convenient |
| 🔵 INFO | Blue | Informational | Review |

### Report Sections

1. **Configuration Summary**: Device info and line count
2. **Security Summary**: Findings breakdown by severity
3. **Security Findings**: Detailed issues with:
   - Rule ID (e.g., AUTH-001)
   - CVA ID (your tracking number)
   - Description and impact
   - Configuration line and line number
   - Fix commands
   - NIST control mappings

### What to Do With Findings

1. **Review CRITICAL/HIGH first** - These are urgent
2. **Check line numbers** - Verify findings are accurate
3. **Apply fix commands** - Test in lab first
4. **Mark false positives** - Document any incorrect findings
5. **Track with CVA IDs** - Use for remediation tracking

## Common Commands

### Generate HTML Report
```bash
python3 config-parser/enterprise_security_parser.py config.txt -o report.html
```

### Generate JSON for Automation
```bash
python3 config-parser/enterprise_security_parser.py config.txt -o findings.json -f json --pretty
```

### Specify Vendor (if auto-detect fails)
```bash
python3 config-parser/enterprise_security_parser.py config.txt -o report.html --vendor cisco_ios
```

### Compare Before/After
```bash
# Before changes
python3 config-parser/enterprise_security_parser.py before.txt -o before.json -f json

# After changes
python3 config-parser/enterprise_security_parser.py after.txt -o after.json -f json

# Compare
python3 config-parser/compare_results.py before.json after.json
```

## Next Steps

Now that you have your first report:

1. **Review findings** - Are they accurate?
2. **Update CVA mappings** - Edit `config-parser/cva_mapping.json`
3. **Create baseline** - Save clean config scan as baseline
4. **Test more configs** - Run against 5-10 devices
5. **Read full docs** - See `README.md` and `docs/`

## Getting Help

- **False positives?** → See `docs/FALSE_POSITIVE_DETECTION.md`
- **Testing?** → See `docs/TESTING_GUIDE.md`
- **Questions?** → Check main `README.md`

## Example Workflow

```bash
# 1. Scan current config
python3 config-parser/enterprise_security_parser.py current.txt -o current-scan.html

# 2. Review findings in browser
firefox current-scan.html

# 3. Apply fixes to config
vim current.txt
# ... make changes ...

# 4. Re-scan to verify
python3 config-parser/enterprise_security_parser.py current.txt -o fixed-scan.html

# 5. Compare results
python3 config-parser/enterprise_security_parser.py current.txt -o before.json -f json
python3 config-parser/enterprise_security_parser.py fixed.txt -o after.json -f json
python3 config-parser/compare_results.py before.json after.json
```

## Pro Tips

💡 **Tip 1**: Start with test configs to verify accuracy before production
💡 **Tip 2**: Customize CVA mappings before scanning production
💡 **Tip 3**: Run validation tests after any rule changes
💡 **Tip 4**: Keep baseline scans for drift detection
💡 **Tip 5**: Review false positives with network engineers

---

**You're ready!** Start scanning your network configs and improving security posture.
