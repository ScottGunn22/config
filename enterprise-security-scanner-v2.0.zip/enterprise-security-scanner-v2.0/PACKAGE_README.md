# Enterprise Network Security Scanner

**Version:** 2.0
**Release Date:** 2025-01-18
**Status:** Production Ready

## Overview

The Enterprise Network Security Scanner is a comprehensive command-line tool for analyzing network device configurations against industry security benchmarks including:

- **CIS Benchmarks** (Cisco IOS, ASA, NX-OS, Juniper JunOS, Palo Alto PAN-OS)
- **DISA STIGs** (Security Technical Implementation Guides)
- **Vendor Hardening Guides** (Cisco, Juniper, Palo Alto)

### Key Features

✅ **Multi-Vendor Support**
- Cisco IOS, IOS-XE, ASA, NX-OS
- Juniper JunOS
- Fortinet FortiOS
- Palo Alto PAN-OS
- Automatic vendor detection

✅ **Comprehensive Security Analysis**
- 150+ security checks across all platforms
- Line-by-line configuration tracking
- CVA (Common Vulnerability Assessment) ID mapping
- NIST control mapping
- CVSS scoring for critical findings

✅ **Professional Reporting**
- Interactive HTML reports with Bootstrap UI
- JSON output for automation/integration
- Detailed findings with fix commands
- Evidence tracking (misconfigurations vs missing configs)

✅ **Benchmark Compliance**
- CIS Benchmark validation (all supported platforms)
- DISA STIG compliance checking
- Vendor-specific hardening guide validation
- PCI-DSS compliance checks

## Quick Start

### Installation

```bash
# Extract the package
unzip enterprise-security-scanner-v2.0.zip
cd enterprise-security-scanner

# No dependencies required - pure Python 3
```

### Basic Usage

```bash
# Analyze a configuration file (auto-detects vendor)
python3 config-parser/enterprise_security_parser.py router-config.txt --output report.html

# Specify output format
python3 config-parser/enterprise_security_parser.py config.txt --output findings.json --format json

# Specify vendor explicitly
python3 config-parser/enterprise_security_parser.py config.txt --output report.html --vendor cisco_asa
```

### Example Output

```
Parsing Summary:
  Vendor: cisco_asa
  Hostname: fw01-datacenter
  OS Version: 9.20(4)
  Total Lines: 892

Security Analysis:
  Total Findings: 27
  Critical: 1
  High: 9
  Medium: 16
  Low: 1
  Info: 0

✓ HTML report written to: report.html
```

## What's New in v2.0

### Major Enhancements

1. **Complete Line Tracking** - Every misconfiguration now shows exact line numbers in the config
2. **Evidence Type Classification** - Clear distinction between misconfigurations and missing configurations
3. **CVA ID Mapping** - Findings now mapped to Common Vulnerability Assessment IDs
4. **Enhanced ASA Support** - 35+ ASA-specific security checks
5. **Improved Reporting** - Bootstrap 5 UI with collapsible findings and syntax highlighting

### Bug Fixes

- Fixed line tracking infrastructure (findings now preserve affected_lines, line_content, evidence_type)
- Fixed ASA check functions to properly track configuration line numbers
- Fixed HTTP server detection to show exact line numbers
- Fixed encryption weakness detection with proper line tracking

## Package Contents

```
enterprise-security-scanner/
├── PACKAGE_README.md              # This file
├── INSTALL.md                     # Installation & setup guide
├── USAGE_GUIDE.md                 # Detailed usage examples
├── config-parser/                 # Main CLI tool
│   ├── enterprise_security_parser.py  # Main entry point
│   ├── benchmark_validator.py     # Benchmark validation engine
│   ├── benchmark_rules.py         # Rule definitions (CIS, STIG, etc.)
│   ├── genie_integration.py       # Config parsing integration
│   ├── cva_mapping.json           # CVA ID mappings
│   └── docs/                      # Additional documentation
├── rule-engines/                  # Security analysis engines
│   └── scanner/
│       ├── core.py                # Core scanner logic
│       ├── engines/               # Analysis engines
│       │   ├── security/          # Security-focused engines
│       │   │   ├── acl_engine.py
│       │   │   ├── crypto_engine.py
│       │   │   └── snmp_engine.py
│       │   ├── routing/           # Routing protocol engines
│       │   │   ├── bgp_engine.py
│       │   │   └── ospf_engine.py
│       │   ├── switching/         # Switching engines
│       │   │   └── stp_engine.py
│       │   └── compliance/        # Compliance engines
│       │       └── pci_dss_engine.py
│       ├── rules/                 # Rule-based analysis
│       │   ├── authentication.py
│       │   ├── network_services.py
│       │   ├── comprehensive_security.py
│       │   ├── logging.py
│       │   ├── juniper_*.py       # Juniper-specific rules
│       │   └── paloalto_security.py
│       └── vendors/               # Vendor-specific parsers
│           ├── cisco.py
│           └── juniper.py
└── examples/                      # Sample configs and outputs
    ├── sample-cisco-ios.txt
    ├── sample-cisco-asa.txt
    ├── sample-report.html
    └── sample-report.json
```

## Supported Platforms

| Platform | Version | Auto-Detect | CIS Benchmark | DISA STIG | Vendor Guide |
|----------|---------|-------------|---------------|-----------|--------------|
| Cisco IOS/IOS-XE | 12.x-17.x | ✅ | ✅ | ✅ | ✅ |
| Cisco ASA | 8.x-9.x | ✅ | ✅ | ✅ | ✅ |
| Cisco NX-OS | 7.x-10.x | ✅ | ✅ | ⚠️ | ✅ |
| Juniper JunOS | 18.x-23.x | ✅ | ✅ | ⚠️ | ✅ |
| Palo Alto PAN-OS | 9.x-11.x | ✅ | ⚠️ | ⚠️ | ✅ |
| Fortinet FortiOS | 6.x-7.x | ✅ | ⚠️ | ⚠️ | ⚠️ |

Legend: ✅ Full Support | ⚠️ Partial Support

## Security Check Categories

### 1. Authentication & Access Control (25+ checks)
- Console/VTY authentication
- AAA configuration
- TACACS+/RADIUS validation
- Local user security
- Enable secret configuration
- Password encryption and complexity

### 2. Network Services (20+ checks)
- HTTP/HTTPS server configuration
- Telnet/SSH version
- SNMP community strings
- CDP/LLDP exposure
- BOOTP/DHCP services
- Small services (echo, discard, etc.)

### 3. Cryptography (15+ checks)
- SSH version and key strength
- IPsec/IKE configuration
- Weak encryption algorithms (DES, 3DES, MD5)
- Certificate validation
- VPN encryption strength

### 4. Routing Protocols (12+ checks)
- BGP authentication
- OSPF authentication
- Route filtering
- TTL security
- Prefix limits

### 5. Switching & VLANs (10+ checks)
- STP security (BPDU Guard, Root Guard)
- VLAN pruning
- Port security
- DHCP snooping
- Dynamic ARP Inspection

### 6. Logging & Monitoring (15+ checks)
- Syslog configuration
- Logging levels
- Buffer sizes
- NTP configuration and authentication
- SNMP trap configuration

### 7. Hardening (20+ checks)
- Source routing disabled
- Proxy ARP disabled
- ICMP redirects disabled
- Directed broadcast disabled
- IP redirects disabled
- TCP keepalives

### 8. Firewall/ASA Specific (35+ checks)
- Security levels
- Inspection policies (DNS, HTTP, FTP)
- Connection limits
- TCP normalization
- Threat detection
- Same-security-traffic
- Botnet Traffic Filter

## Output Formats

### HTML Report

Interactive report with:
- Executive summary with severity breakdown
- Configuration metadata (vendor, hostname, OS version)
- Expandable findings with full details
- Color-coded severity badges
- Line number highlighting
- Fix commands for each finding
- NIST control mapping
- CVA ID references

### JSON Report

Structured data for automation:
```json
{
  "vendor": "cisco_asa",
  "hostname": "fw01",
  "os_version": "9.20(4)",
  "total_lines": 892,
  "security_findings": [
    {
      "rule_id": "CIS-ASA-004",
      "title": "Disable HTTP server",
      "severity": "MEDIUM",
      "affected_lines": [390],
      "line_content": ["http server enable 9443"],
      "evidence_type": "misconfiguration",
      "cva_id": "CVA 0001",
      "fix_commands": ["no http server enable"],
      "nist_controls": ["SC-8", "CM-7"]
    }
  ],
  "security_summary": {
    "total_findings": 27,
    "critical": 1,
    "high": 9,
    "medium": 16,
    "low": 1
  }
}
```

## Command Line Reference

```bash
# Basic usage
python3 enterprise_security_parser.py <config-file> --output <output-file>

# Options
--output, -o       Output file path (required)
--format, -f       Output format: html or json (default: html)
--vendor, -v       Specify vendor: cisco_ios, cisco_asa, cisco_nxos,
                   juniper_junos, fortinet_fortios, paloalto_panos
--pretty, -p       Pretty print JSON output
--no-security, -n  Skip security analysis (parse only)
```

## Requirements

- **Python:** 3.7 or higher
- **OS:** Linux, macOS, Windows
- **Dependencies:** None (pure Python implementation)

Optional dependencies for enhanced parsing:
- `pyats[library]` - For Genie parser support (not required)

## Use Cases

### 1. Pre-Deployment Security Review
Validate configurations before deploying to production

### 2. Compliance Auditing
Generate compliance reports for CIS, STIG, PCI-DSS audits

### 3. Security Hardening
Identify security gaps and get fix commands

### 4. Change Management
Analyze configuration changes for security impact

### 5. Vulnerability Assessment
Map findings to CVA IDs for vulnerability tracking

### 6. Automation & CI/CD
Integrate JSON output into security pipelines

## Support & Documentation

- **Installation Guide:** See `INSTALL.md`
- **Usage Examples:** See `USAGE_GUIDE.md`
- **Line Tracking Guide:** See `config-parser/LINE_TRACKING_GUIDE.md`
- **Benchmark Coverage:** See `config-parser/BENCHMARK_COVERAGE_REFERENCE.md`

## License

Proprietary - For authorized use only

## Version History

### v2.0 (2025-01-18)
- Complete line tracking implementation
- CVA ID mapping
- Enhanced ASA support
- Evidence type classification
- Bootstrap 5 UI upgrade

### v1.0 (2024-11-10)
- Initial release
- Multi-vendor support
- CIS/STIG validation
- HTML/JSON reporting

---

**For technical support, contact your system administrator**
