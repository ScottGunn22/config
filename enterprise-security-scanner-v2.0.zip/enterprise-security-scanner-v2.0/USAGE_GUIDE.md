# Usage Guide - Enterprise Network Security Scanner

## Table of Contents

1. [Basic Usage](#basic-usage)
2. [Output Formats](#output-formats)
3. [Vendor-Specific Scanning](#vendor-specific-scanning)
4. [Understanding Reports](#understanding-reports)
5. [Common Workflows](#common-workflows)
6. [Advanced Usage](#advanced-usage)
7. [Interpreting Findings](#interpreting-findings)
8. [Best Practices](#best-practices)

---

## Basic Usage

### Simplest Command

```bash
python3 config-parser/enterprise_security_parser.py router-config.txt --output report.html
```

This will:
- Auto-detect the vendor (Cisco, Juniper, Palo Alto, etc.)
- Run all applicable security checks
- Generate an HTML report

### Example Output

```
Parsing configuration...
✓ Parsed 892 lines
✓ Detected vendor: cisco_asa
✓ Detected OS version: 9.20(4)
Running security analysis...
✓ ACLSecurityEngine: 3 findings
✓ CryptographySecurityEngine: 2 findings
✓ SNMPSecurityEngine: 0 findings
✓ BenchmarkValidator: 27 findings
✓ Found 32 security issues
✓ HTML report written to: report.html

Parsing Summary:
  Vendor: cisco_asa
  Hostname: fw01-datacenter
  OS Version: 9.20(4)
  Total Lines: 892

Security Analysis:
  Total Findings: 32
  Critical: 1
  High: 11
  Medium: 18
  Low: 2
  Info: 0
```

---

## Output Formats

### HTML Report (Default)

Best for human review and presentations:

```bash
python3 config-parser/enterprise_security_parser.py config.txt --output security-report.html
```

**HTML Features:**
- Interactive Bootstrap UI
- Color-coded severity badges
- Expandable findings
- Line number highlighting
- Fix commands for each issue
- NIST control mapping
- CVA ID references

### JSON Report

Best for automation and integration:

```bash
python3 config-parser/enterprise_security_parser.py config.txt \
    --output findings.json \
    --format json \
    --pretty
```

**JSON Features:**
- Machine-readable format
- Complete finding metadata
- Line tracking information
- Easy integration with SIEM/ticketing systems

### Pretty vs Compact JSON

**Pretty (human-readable):**
```bash
python3 config-parser/enterprise_security_parser.py config.txt \
    --output findings.json --format json --pretty
```

**Compact (smaller file size):**
```bash
python3 config-parser/enterprise_security_parser.py config.txt \
    --output findings.json --format json
```

---

## Vendor-Specific Scanning

### Auto-Detection (Recommended)

Let the scanner detect the vendor automatically:

```bash
python3 config-parser/enterprise_security_parser.py config.txt --output report.html
```

The scanner can auto-detect:
- Cisco IOS/IOS-XE
- Cisco ASA
- Cisco NX-OS
- Juniper JunOS
- Fortinet FortiOS
- Palo Alto PAN-OS

### Explicit Vendor Specification

For configs where auto-detection may be ambiguous:

**Cisco IOS:**
```bash
python3 config-parser/enterprise_security_parser.py router.txt \
    --output report.html \
    --vendor cisco_ios
```

**Cisco ASA:**
```bash
python3 config-parser/enterprise_security_parser.py firewall.txt \
    --output report.html \
    --vendor cisco_asa
```

**Cisco NX-OS:**
```bash
python3 config-parser/enterprise_security_parser.py nexus.txt \
    --output report.html \
    --vendor cisco_nxos
```

**Juniper JunOS:**
```bash
python3 config-parser/enterprise_security_parser.py juniper.txt \
    --output report.html \
    --vendor juniper_junos
```

**Palo Alto:**
```bash
python3 config-parser/enterprise_security_parser.py palo.txt \
    --output report.html \
    --vendor paloalto_panos
```

**Fortinet:**
```bash
python3 config-parser/enterprise_security_parser.py fortigate.txt \
    --output report.html \
    --vendor fortinet_fortios
```

---

## Understanding Reports

### HTML Report Structure

#### 1. Header Section
```
Enterprise Security Analysis Report
Generated using Network Security Scanner Engines
```

#### 2. Configuration Summary
```
Vendor: cisco_asa
Hostname: fw01-datacenter
OS Version: 9.20(4)
Total Lines: 892
```

#### 3. Security Summary
```
Total Findings: 27
Critical: 1    High: 9    Medium: 16    Low: 1    Info: 0
```

#### 4. Individual Findings

Each finding shows:
- **Title:** Brief description
- **Severity:** CRITICAL, HIGH, MEDIUM, LOW, INFO
- **Rule ID:** e.g., "CIS-ASA-004", "STIG-001"
- **CVA ID:** Common Vulnerability Assessment ID (if applicable)
- **Category:** Benchmark Compliance, Security, etc.
- **Description:** Detailed explanation
- **Affected Lines:** Exact line numbers (for misconfigurations)
- **Evidence Type:** Misconfiguration or Missing Configuration
- **Recommendation:** What to do
- **Fix Commands:** Exact commands to remediate
- **NIST Controls:** Mapped NIST 800-53 controls

### JSON Report Structure

```json
{
  "vendor": "cisco_asa",
  "hostname": "fw01-datacenter",
  "os_version": "9.20(4)",
  "total_lines": 892,
  "security_findings": [
    {
      "rule_id": "CIS-ASA-004",
      "title": "Disable HTTP server",
      "description": "CIS recommends disabling HTTP server...",
      "severity": "MEDIUM",
      "category": "Benchmark Compliance",
      "recommendation": "Disable HTTP server",
      "nist_controls": ["SC-8", "CM-7"],
      "fix_commands": ["no http server enable"],
      "cva_id": "CVA 0001",
      "affected_lines": [390],
      "line_content": ["http server enable 9443"],
      "evidence_type": "misconfiguration"
    }
  ],
  "security_summary": {
    "total_findings": 27,
    "critical": 1,
    "high": 9,
    "medium": 16,
    "low": 1,
    "info": 0
  }
}
```

---

## Common Workflows

### Workflow 1: Pre-Deployment Review

Check a configuration before deploying to production:

```bash
# 1. Scan the config
python3 config-parser/enterprise_security_parser.py new-router-config.txt \
    --output pre-deploy-scan.html

# 2. Review findings in browser
open pre-deploy-scan.html

# 3. Fix critical/high findings
# (Apply fix commands from the report)

# 4. Re-scan to verify
python3 config-parser/enterprise_security_parser.py new-router-config.txt \
    --output pre-deploy-scan-v2.html

# 5. Compare results
diff <(grep "Total Findings" pre-deploy-scan.html) \
     <(grep "Total Findings" pre-deploy-scan-v2.html)
```

### Workflow 2: Compliance Audit

Generate compliance reports for audit:

```bash
# Scan all devices
for config in /network/configs/*.txt; do
    device=$(basename "$config" .txt)
    python3 config-parser/enterprise_security_parser.py "$config" \
        --output "/audit/reports/${device}-$(date +%Y%m%d).html"
done

# Also generate JSON for tracking
for config in /network/configs/*.txt; do
    device=$(basename "$config" .txt)
    python3 config-parser/enterprise_security_parser.py "$config" \
        --output "/audit/data/${device}-$(date +%Y%m%d).json" \
        --format json --pretty
done

# Create summary report
echo "Device,Total,Critical,High,Medium,Low" > audit-summary.csv
for json in /audit/data/*.json; do
    device=$(basename "$json" .json)
    python3 -c "
import json, sys
with open('$json') as f:
    data = json.load(f)
    s = data['security_summary']
    print(f'$device,{s[\"total_findings\"]},{s[\"critical\"]},{s[\"high\"]},{s[\"medium\"]},{s[\"low\"]}')
"  >> audit-summary.csv
done
```

### Workflow 3: Change Impact Analysis

Analyze security impact of configuration changes:

```bash
# Scan before change
python3 config-parser/enterprise_security_parser.py router-before.txt \
    --output before.json --format json

# Apply changes to config...

# Scan after change
python3 config-parser/enterprise_security_parser.py router-after.txt \
    --output after.json --format json

# Compare findings
python3 -c "
import json
with open('before.json') as f:
    before = json.load(f)
with open('after.json') as f:
    after = json.load(f)

before_count = before['security_summary']['total_findings']
after_count = after['security_summary']['total_findings']

if after_count < before_count:
    print(f'✓ Improved: {before_count - after_count} fewer findings')
elif after_count > before_count:
    print(f'⚠ Worsened: {after_count - before_count} more findings')
else:
    print('= No change in finding count')

# Show severity comparison
for severity in ['critical', 'high', 'medium', 'low']:
    before_sev = before['security_summary'][severity]
    after_sev = after['security_summary'][severity]
    if before_sev != after_sev:
        print(f'  {severity.upper()}: {before_sev} → {after_sev}')
"
```

### Workflow 4: Automated Scanning

Set up automated daily scans:

```bash
# cron job: Daily scan at 2 AM
# crontab -e
# 0 2 * * * /opt/scripts/daily-security-scan.sh

# /opt/scripts/daily-security-scan.sh
#!/bin/bash

DATE=$(date +%Y%m%d)
CONFIG_DIR="/network/configs"
REPORT_DIR="/security/reports/$DATE"
SCANNER="/opt/enterprise-security-scanner/config-parser/enterprise_security_parser.py"

mkdir -p "$REPORT_DIR"

for config in "$CONFIG_DIR"/*.txt; do
    device=$(basename "$config" .txt)

    python3 "$SCANNER" "$config" \
        --output "$REPORT_DIR/${device}.html" \
        2>&1 | logger -t security-scan

    python3 "$SCANNER" "$config" \
        --output "$REPORT_DIR/${device}.json" \
        --format json --pretty \
        2>&1 | logger -t security-scan
done

# Send notification
echo "Security scan completed: $REPORT_DIR" | \
    mail -s "Daily Security Scan - $DATE" security-team@company.com
```

---

## Advanced Usage

### Parsing Only (No Security Analysis)

Skip security checks for quick parsing:

```bash
python3 config-parser/enterprise_security_parser.py config.txt \
    --output parsed.json \
    --format json \
    --no-security
```

### Batch Processing with Error Handling

```bash
#!/bin/bash
SCANNER="python3 config-parser/enterprise_security_parser.py"

for config in configs/*.txt; do
    output="reports/$(basename "$config" .txt).html"

    if $SCANNER "$config" --output "$output" 2>&1 | tee scan.log; then
        echo "✓ Success: $config"
    else
        echo "✗ Failed: $config" >> failed-scans.txt
        cp scan.log "logs/$(basename "$config" .txt)-error.log"
    fi
done
```

### Filtering JSON Output with jq

**Show only CRITICAL findings:**
```bash
python3 config-parser/enterprise_security_parser.py config.txt \
    --output findings.json --format json

jq '.security_findings[] | select(.severity == "CRITICAL")' findings.json
```

**Show findings with line numbers:**
```bash
jq '.security_findings[] | select(.affected_lines != null) | {rule_id, title, lines: .affected_lines}' findings.json
```

**Export to CSV:**
```bash
jq -r '.security_findings[] | [.rule_id, .severity, .title] | @csv' findings.json > findings.csv
```

### Integration with SIEM

Send findings to Splunk/ELK:

```bash
# Generate JSON
python3 config-parser/enterprise_security_parser.py firewall.txt \
    --output findings.json --format json

# Send to Splunk HEC
curl -k https://splunk.company.com:8088/services/collector \
    -H "Authorization: Splunk YOUR-HEC-TOKEN" \
    -d @findings.json

# Or send to Elasticsearch
curl -X POST "localhost:9200/network-security/_doc" \
    -H 'Content-Type: application/json' \
    -d @findings.json
```

---

## Interpreting Findings

### Evidence Types

#### Misconfiguration
**What it means:** A problematic configuration exists in the device
**Shows:** Exact line numbers and config content
**Example:**
```
Line 390: http server enable 9443
```
**Action:** Review and remediate the specific line

#### Missing Configuration
**What it means:** A recommended configuration is not present
**Shows:** No line numbers (nothing to point to)
**Example:**
```
No NTP authentication configured
```
**Action:** Add the recommended configuration

### Severity Levels

| Severity | Risk Level | Response Time | Examples |
|----------|------------|---------------|----------|
| **CRITICAL** | Immediate threat | Fix within 24h | Console lacks authentication, default passwords |
| **HIGH** | Significant risk | Fix within 1 week | Weak encryption, missing AAA, HTTP enabled |
| **MEDIUM** | Moderate risk | Fix within 1 month | Missing inspection, no logging trap level |
| **LOW** | Minor concern | Fix when convenient | TCP keepalives, banner missing |
| **INFO** | Informational | No action required | Configuration notes, best practices |

### CVA IDs

Common Vulnerability Assessment IDs map findings to known vulnerabilities:

- **CVA 0001:** HTTP Server Enabled
- **CVA 0005:** ICMP Redirects Enabled
- **CVA 0007:** NTP Not Authenticated
- **CVA 0012:** Weak Cryptography
- **CVA 2197:** Missing AAA Accounting
- **CVA 2203:** CDP Enabled
- **CVA 2217:** uRPF Not Enabled
- **CVA 2232:** Session Timeout Excessive
- **CVA 2233:** Console Lacks Authentication

---

## Best Practices

### 1. Regular Scanning

Scan configurations regularly:
- **Pre-deployment:** Before any config change
- **Weekly:** For production devices
- **Monthly:** For all devices (including DR/backup)
- **After incidents:** To identify security gaps

### 2. Prioritize Findings

Address findings in this order:
1. CRITICAL severity (immediately)
2. HIGH severity (within 1 week)
3. Findings with CVA IDs (known vulnerabilities)
4. MEDIUM severity (within 1 month)
5. LOW severity (when convenient)

### 3. Track Progress

Create a remediation tracker:

```bash
# Initial scan
python3 config-parser/enterprise_security_parser.py config.txt \
    --output baseline-$(date +%Y%m%d).json --format json

# Weekly scans
python3 config-parser/enterprise_security_parser.py config.txt \
    --output week-$(date +%Y%m%d).json --format json

# Compare
jq '.security_summary' baseline-*.json
jq '.security_summary' week-*.json
```

### 4. Version Control Integration

Scan configs before committing to version control:

```bash
# Git pre-commit hook
#!/bin/bash
# .git/hooks/pre-commit

for config in $(git diff --cached --name-only | grep '\.txt$'); do
    python3 /path/to/enterprise_security_parser.py "$config" \
        --output /tmp/scan-result.json --format json --no-security

    if [ $? -ne 0 ]; then
        echo "❌ Config parsing failed: $config"
        exit 1
    fi
done
```

### 5. Document Exceptions

For findings that cannot be fixed (business requirements):

```bash
# Create exceptions file
cat > security-exceptions.md << 'EOF'
# Security Scan Exceptions

## HTTP Server Enabled (CVA 0001)
- Device: fw01-datacenter
- Line: 390
- Justification: Required for legacy management system
- Compensating controls: ACL restricts to management network
- Approved by: John Doe
- Date: 2025-01-18
- Review date: 2025-07-18
EOF
```

### 6. Trend Analysis

Track security posture over time:

```bash
#!/bin/bash
# Weekly trend report

echo "Date,Device,Total,Critical,High,Medium,Low" > security-trend.csv

for scan in reports/*.json; do
    date=$(basename "$scan" | cut -d- -f2 | cut -d. -f1)
    device=$(basename "$scan" | cut -d- -f1)

    python3 -c "
import json
with open('$scan') as f:
    s = json.load(f)['security_summary']
    print('$date,$device,{total},{crit},{high},{med},{low}'.format(
        total=s['total_findings'],
        crit=s['critical'],
        high=s['high'],
        med=s['medium'],
        low=s['low']
    ))
    " >> security-trend.csv
done
```

---

## Examples by Use Case

### Security Hardening

```bash
# Scan current config
python3 config-parser/enterprise_security_parser.py current.txt --output current.html

# Review HIGH and CRITICAL findings
# Apply fix commands from report

# Scan hardened config
python3 config-parser/enterprise_security_parser.py hardened.txt --output hardened.html

# Verify improvements
```

### Compliance Reporting

```bash
# Generate compliance report with all findings
python3 config-parser/enterprise_security_parser.py router.txt \
    --output compliance-report.html

# Extract CIS Benchmark findings only
python3 config-parser/enterprise_security_parser.py router.txt \
    --output findings.json --format json

jq '.security_findings[] | select(.rule_id | startswith("CIS"))' findings.json > cis-findings.json

# Extract STIG findings
jq '.security_findings[] | select(.rule_id | startswith("STIG"))' findings.json > stig-findings.json
```

### Vulnerability Assessment

```bash
# Find all CVA-mapped vulnerabilities
python3 config-parser/enterprise_security_parser.py config.txt \
    --output findings.json --format json

jq '.security_findings[] | select(.cva_id != null) | {cva_id, title, severity, lines: .affected_lines}' findings.json
```

---

## Getting Help

- **General usage:** This guide
- **Installation issues:** See `INSTALL.md`
- **Understanding findings:** See `config-parser/LINE_TRACKING_GUIDE.md`
- **Feature reference:** See `PACKAGE_README.md`
- **Technical support:** Contact your system administrator

---

**Ready to secure your network!**
