EXAMPLE FILES
=============

This directory contains sample configuration files for testing the scanner.

sample-cisco-router.txt
-----------------------
A Cisco IOS router configuration with intentional security issues.

Security issues present:
- No enable secret configured (weak password)
- No AAA configured
- No login banner
- HTTP server enabled (insecure management)
- CDP enabled (information disclosure)
- No uRPF on interfaces
- IP redirects enabled
- Proxy ARP enabled
- No OSPF authentication
- No logging host configured
- No NTP authentication
- VTY lines allow Telnet (insecure)
- VTY lines use weak password

To test:
--------
cd ..
python3 config-parser/enterprise_security_parser.py examples/sample-cisco-router.txt --output examples/sample-report.html

Expected findings: 15-20 security issues across multiple severity levels

The generated report will show both:
- Misconfigurations (with line numbers)
- Missing configurations (without line numbers)

