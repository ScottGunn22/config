"""Enhanced parser for Juniper JunOS configurations.

Provides structured parsing of JunOS configurations for security analysis.
Handles both hierarchical (show configuration) and flat (show configuration | display set) formats.
"""

from typing import Dict, Any, List, Optional
import re


class JuniperEnhancedParser:
    """Enhanced parser for Juniper JunOS configurations."""

    def __init__(self):
        self.config_data = {}

    def parse(self, config_lines: List[Any]) -> Dict[str, Any]:
        """Parse JunOS configuration into structured data.

        Args:
            config_lines: List of ConfigLine objects or strings

        Returns:
            Dictionary with structured configuration data
        """
        # Convert to list of strings
        lines = []
        for line in config_lines:
            if hasattr(line, 'content'):
                lines.append(line.content)
            else:
                lines.append(str(line))

        # Detect format
        is_set_format = any(line.strip().startswith('set ') for line in lines[:50])

        if is_set_format:
            return self._parse_set_format(lines)
        else:
            return self._parse_hierarchical_format(lines)

    def _parse_set_format(self, lines: List[str]) -> Dict[str, Any]:
        """Parse 'display set' format configuration."""
        data = {
            'system': {},
            'interfaces': {},
            'protocols': {},
            'security': {},
            'policy-options': {},
            'snmp': {},
            'routing-options': {},
            'chassis': {}
        }

        for line in lines:
            line = line.strip()
            if not line.startswith('set '):
                continue

            # Remove 'set ' prefix
            parts = line[4:].split()
            if not parts:
                continue

            # Route to appropriate parser
            if parts[0] == 'system':
                self._parse_system_set(parts[1:], data['system'])
            elif parts[0] == 'interfaces':
                self._parse_interfaces_set(parts[1:], data['interfaces'])
            elif parts[0] == 'protocols':
                self._parse_protocols_set(parts[1:], data['protocols'])
            elif parts[0] == 'security':
                self._parse_security_set(parts[1:], data['security'])
            elif parts[0] == 'snmp':
                self._parse_snmp_set(parts[1:], data['snmp'])
            elif parts[0] == 'routing-options':
                self._parse_routing_options_set(parts[1:], data['routing-options'])

        return data

    def _parse_system_set(self, parts: List[str], system_data: Dict[str, Any]):
        """Parse system configuration from set commands."""
        if not parts:
            return

        if parts[0] == 'root-authentication':
            if 'authentication' not in system_data:
                system_data['authentication'] = {}
            if len(parts) > 1:
                system_data['authentication']['root'] = {
                    'method': parts[1] if len(parts) > 1 else None,
                    'configured': True
                }

        elif parts[0] == 'login':
            if 'login' not in system_data:
                system_data['login'] = {'users': {}, 'classes': {}}

            if len(parts) > 1 and parts[1] == 'user':
                if len(parts) > 2:
                    username = parts[2]
                    if username not in system_data['login']['users']:
                        system_data['login']['users'][username] = {}

                    if len(parts) > 3:
                        if parts[3] == 'class':
                            system_data['login']['users'][username]['class'] = parts[4] if len(parts) > 4 else None
                        elif parts[3] == 'authentication':
                            if 'authentication' not in system_data['login']['users'][username]:
                                system_data['login']['users'][username]['authentication'] = {}
                            if len(parts) > 4:
                                system_data['login']['users'][username]['authentication'][parts[4]] = True

        elif parts[0] == 'services':
            if 'services' not in system_data:
                system_data['services'] = {}

            if len(parts) > 1:
                service_name = parts[1]
                system_data['services'][service_name] = {'enabled': True}

                # Check for SSH version
                if service_name == 'ssh' and len(parts) > 2:
                    if parts[2] == 'protocol-version':
                        system_data['services'][service_name]['protocol_version'] = parts[3] if len(parts) > 3 else None

        elif parts[0] == 'syslog':
            if 'syslog' not in system_data:
                system_data['syslog'] = {'hosts': [], 'files': {}}

            if len(parts) > 1:
                if parts[1] == 'host':
                    if len(parts) > 2:
                        system_data['syslog']['hosts'].append(parts[2])
                elif parts[1] == 'file':
                    if len(parts) > 2:
                        filename = parts[2]
                        if filename not in system_data['syslog']['files']:
                            system_data['syslog']['files'][filename] = {}

        elif parts[0] == 'ntp':
            if 'ntp' not in system_data:
                system_data['ntp'] = {'servers': [], 'authentication': False}

            if len(parts) > 1:
                if parts[1] == 'server':
                    if len(parts) > 2:
                        system_data['ntp']['servers'].append(parts[2])
                elif parts[1] == 'authentication-key':
                    system_data['ntp']['authentication'] = True

    def _parse_interfaces_set(self, parts: List[str], interfaces_data: Dict[str, Any]):
        """Parse interfaces from set commands."""
        if not parts:
            return

        # Interface name is first part
        if_name = parts[0]
        if if_name not in interfaces_data:
            interfaces_data[if_name] = {
                'name': if_name,
                'units': {},
                'description': None,
                'disable': False
            }

        if len(parts) > 1:
            if parts[1] == 'disable':
                interfaces_data[if_name]['disable'] = True
            elif parts[1] == 'description':
                interfaces_data[if_name]['description'] = ' '.join(parts[2:])
            elif parts[1] == 'unit':
                if len(parts) > 2:
                    unit_num = parts[2]
                    if unit_num not in interfaces_data[if_name]['units']:
                        interfaces_data[if_name]['units'][unit_num] = {
                            'family': {},
                            'vrrp': []
                        }

                    if len(parts) > 3:
                        unit_data = interfaces_data[if_name]['units'][unit_num]

                        if parts[3] == 'family':
                            if len(parts) > 4:
                                family = parts[4]
                                if family not in unit_data['family']:
                                    unit_data['family'][family] = {'addresses': [], 'filter': None}

                                if len(parts) > 5:
                                    if parts[5] == 'address':
                                        if len(parts) > 6:
                                            addr = parts[6]
                                            addr_data = {'address': addr, 'vrrp_group': None}

                                            # Check for VRRP
                                            if len(parts) > 7 and parts[7] == 'vrrp-group':
                                                if len(parts) > 8:
                                                    vrrp_group = parts[8]
                                                    addr_data['vrrp_group'] = vrrp_group

                                                    # Parse VRRP details
                                                    vrrp_data = {
                                                        'group': vrrp_group,
                                                        'virtual_address': None,
                                                        'priority': None,
                                                        'authentication': None,
                                                        'track': []
                                                    }

                                                    if len(parts) > 9:
                                                        if parts[9] == 'virtual-address':
                                                            vrrp_data['virtual_address'] = parts[10] if len(parts) > 10 else None
                                                        elif parts[9] == 'priority':
                                                            vrrp_data['priority'] = int(parts[10]) if len(parts) > 10 else None
                                                        elif parts[9] == 'authentication-type':
                                                            vrrp_data['authentication'] = parts[10] if len(parts) > 10 else None
                                                        elif parts[9] == 'track':
                                                            if len(parts) > 10:
                                                                vrrp_data['track'].append(parts[10])

                                                    # Add or update VRRP group
                                                    existing = next((v for v in unit_data['vrrp'] if v['group'] == vrrp_group), None)
                                                    if existing:
                                                        existing.update({k: v for k, v in vrrp_data.items() if v is not None})
                                                    else:
                                                        unit_data['vrrp'].append(vrrp_data)

                                            unit_data['family'][family]['addresses'].append(addr_data)

                                    elif parts[5] == 'filter':
                                        if len(parts) > 7:
                                            unit_data['family'][family]['filter'] = parts[7]

    def _parse_protocols_set(self, parts: List[str], protocols_data: Dict[str, Any]):
        """Parse routing protocols from set commands."""
        if not parts:
            return

        protocol = parts[0]
        if protocol not in protocols_data:
            protocols_data[protocol] = {}

        if protocol == 'ospf' or protocol == 'ospf3':
            if len(parts) > 1 and parts[1] == 'area':
                if 'areas' not in protocols_data[protocol]:
                    protocols_data[protocol]['areas'] = {}

                if len(parts) > 2:
                    area_id = parts[2]
                    if area_id not in protocols_data[protocol]['areas']:
                        protocols_data[protocol]['areas'][area_id] = {
                            'interfaces': {},
                            'authentication': None
                        }

                    if len(parts) > 3:
                        if parts[3] == 'interface':
                            if len(parts) > 4:
                                if_name = parts[4]
                                if if_name not in protocols_data[protocol]['areas'][area_id]['interfaces']:
                                    protocols_data[protocol]['areas'][area_id]['interfaces'][if_name] = {
                                        'authentication': None
                                    }

                                if len(parts) > 5:
                                    if parts[5] == 'authentication':
                                        auth_type = parts[6] if len(parts) > 6 else None
                                        protocols_data[protocol]['areas'][area_id]['interfaces'][if_name]['authentication'] = auth_type

                        elif parts[3] == 'authentication-type':
                            protocols_data[protocol]['areas'][area_id]['authentication'] = parts[4] if len(parts) > 4 else None

        elif protocol == 'bgp':
            if 'authentication' not in protocols_data[protocol]:
                protocols_data[protocol]['authentication'] = False

            if len(parts) > 1 and 'authentication' in ' '.join(parts):
                protocols_data[protocol]['authentication'] = True

        elif protocol == 'lldp':
            protocols_data[protocol]['enabled'] = True

        elif protocol == 'lldp-med':
            protocols_data[protocol]['enabled'] = True

    def _parse_security_set(self, parts: List[str], security_data: Dict[str, Any]):
        """Parse security configuration from set commands."""
        if not parts:
            return

        if parts[0] == 'ike':
            if 'ike' not in security_data:
                security_data['ike'] = {'policies': {}, 'gateways': {}}

            if len(parts) > 1:
                if parts[1] == 'policy':
                    if len(parts) > 2:
                        policy_name = parts[2]
                        if policy_name not in security_data['ike']['policies']:
                            security_data['ike']['policies'][policy_name] = {}

                        if len(parts) > 3:
                            if parts[3] == 'mode':
                                security_data['ike']['policies'][policy_name]['mode'] = parts[4] if len(parts) > 4 else None
                            elif parts[3] == 'proposals':
                                if 'proposals' not in security_data['ike']['policies'][policy_name]:
                                    security_data['ike']['policies'][policy_name]['proposals'] = []
                                security_data['ike']['policies'][policy_name]['proposals'].append(parts[4] if len(parts) > 4 else None)

        elif parts[0] == 'ipsec':
            if 'ipsec' not in security_data:
                security_data['ipsec'] = {'policies': {}, 'vpns': {}}

            if len(parts) > 1:
                if parts[1] == 'policy':
                    if len(parts) > 2:
                        policy_name = parts[2]
                        if policy_name not in security_data['ipsec']['policies']:
                            security_data['ipsec']['policies'][policy_name] = {}

                elif parts[1] == 'vpn':
                    if len(parts) > 2:
                        vpn_name = parts[2]
                        if vpn_name not in security_data['ipsec']['vpns']:
                            security_data['ipsec']['vpns'][vpn_name] = {
                                'ike_gateway': None,
                                'ipsec_policy': None
                            }

                        if len(parts) > 3:
                            if parts[3] == 'ike':
                                security_data['ipsec']['vpns'][vpn_name]['ike_gateway'] = parts[5] if len(parts) > 5 else None
                            elif parts[3] == 'ipsec-policy':
                                security_data['ipsec']['vpns'][vpn_name]['ipsec_policy'] = parts[4] if len(parts) > 4 else None

        elif parts[0] == 'zones':
            if 'zones' not in security_data:
                security_data['zones'] = {}

            if len(parts) > 2 and parts[1] == 'security-zone':
                zone_name = parts[2]
                if zone_name not in security_data['zones']:
                    security_data['zones'][zone_name] = {'interfaces': []}

                if len(parts) > 3:
                    if parts[3] == 'interfaces':
                        if len(parts) > 4:
                            security_data['zones'][zone_name]['interfaces'].append(parts[4])

    def _parse_snmp_set(self, parts: List[str], snmp_data: Dict[str, Any]):
        """Parse SNMP configuration from set commands."""
        if not parts:
            return

        if parts[0] == 'community':
            if 'communities' not in snmp_data:
                snmp_data['communities'] = {}

            if len(parts) > 1:
                community = parts[1]
                if community not in snmp_data['communities']:
                    snmp_data['communities'][community] = {
                        'authorization': None,
                        'clients': []
                    }

                if len(parts) > 2:
                    if parts[2] == 'authorization':
                        snmp_data['communities'][community]['authorization'] = parts[3] if len(parts) > 3 else None
                    elif parts[2] == 'clients':
                        if len(parts) > 3:
                            snmp_data['communities'][community]['clients'].append(parts[3])

        elif parts[0] == 'v3':
            if 'v3' not in snmp_data:
                snmp_data['v3'] = {'enabled': True}

    def _parse_routing_options_set(self, parts: List[str], routing_data: Dict[str, Any]):
        """Parse routing options from set commands."""
        if not parts:
            return

        if parts[0] == 'static':
            if 'static' not in routing_data:
                routing_data['static'] = {'routes': []}

            if len(parts) > 2 and parts[1] == 'route':
                routing_data['static']['routes'].append(parts[2])

    def _parse_hierarchical_format(self, lines: List[str]) -> Dict[str, Any]:
        """Parse hierarchical format configuration."""
        data = {
            'system': {},
            'interfaces': {},
            'protocols': {},
            'security': {},
            'policy-options': {},
            'snmp': {},
            'routing-options': {},
            'chassis': {}
        }

        # State tracking
        current_context = []

        for line in lines:
            # Determine indentation level
            stripped = line.lstrip()
            if not stripped or stripped.startswith('#'):
                continue

            indent_level = (len(line) - len(stripped)) // 4

            # Handle closing braces
            if stripped.startswith('}'):
                if current_context:
                    current_context.pop()
                continue

            # Remove trailing opening brace
            if stripped.endswith('{'):
                stripped = stripped[:-1].strip()

            # Update context based on indentation
            while len(current_context) > indent_level:
                current_context.pop()

            # Parse based on current context
            parts = stripped.split()
            if not parts:
                continue

            # Top level context
            if indent_level == 0:
                if parts[0] in data:
                    current_context = [parts[0]]
            else:
                # Add to current context
                current_context.append(stripped)

        # For now, return basic structure
        # Full hierarchical parsing would require more complex state machine
        return data
