"""Benchmark validation engine for CIS, DISA STIG, and vendor hardening guides."""

import re
from typing import List, Dict, Any, Optional
from benchmark_rules import CISBenchmarkRules, DISTIGRules, VendorHardeningGuideRules, BenchmarkRule


class BenchmarkValidator:
    """Validates network configurations against security benchmarks."""

    def __init__(self):
        """Initialize benchmark validator with all rule sets."""
        self.cis_cisco_rules = CISBenchmarkRules.get_cisco_ios_rules()
        self.stig_cisco_rules = DISTIGRules.get_cisco_ios_rules()
        self.cisco_hardening_rules = VendorHardeningGuideRules.get_cisco_hardening_rules()

        # ASA and NX-OS specific rules
        self.cis_asa_rules = CISBenchmarkRules.get_cisco_asa_rules()
        self.cis_nxos_rules = CISBenchmarkRules.get_cisco_nxos_rules()

    def validate_cisco_ios(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco IOS configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_cisco_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def validate_cisco_asa(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco ASA configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS ASA Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_asa_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks (many apply to ASA as well)
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks (many apply to ASA)
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def validate_cisco_nxos(self, parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate Cisco NX-OS configuration against all benchmarks."""
        findings = []
        config_lines = parsed_config.get("config_lines", [])

        # CIS NX-OS Benchmark checks
        findings.extend(self._run_benchmark_checks(
            self.cis_nxos_rules,
            config_lines,
            parsed_config
        ))

        # DISA STIG checks (many apply to NX-OS as well)
        findings.extend(self._run_benchmark_checks(
            self.stig_cisco_rules,
            config_lines,
            parsed_config
        ))

        # Cisco Hardening Guide checks (many apply to NX-OS)
        findings.extend(self._run_benchmark_checks(
            self.cisco_hardening_rules,
            config_lines,
            parsed_config
        ))

        return findings

    def _run_benchmark_checks(self, rules: List[BenchmarkRule],
                              config_lines: List,
                              parsed_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Run benchmark checks and return findings."""
        findings = []

        for rule in rules:
            check_func = getattr(self, rule.check_function, None)
            if check_func:
                result = check_func(config_lines, parsed_config)
                if result:
                    finding = {
                        "rule_id": rule.rule_id,
                        "title": rule.title,
                        "description": rule.description,
                        "severity": rule.severity,
                        "category": "Benchmark Compliance",
                        "benchmark_id": rule.benchmark_id,
                        "benchmark_name": rule.benchmark_name,
                        "recommendation": rule.recommendation,
                        "fix_commands": rule.fix_commands,
                        "nist_controls": rule.nist_controls,
                        "compliant": result["compliant"],
                        "details": result.get("details", "")
                    }

                    # Preserve line tracking information
                    if "affected_lines" in result:
                        finding["affected_lines"] = result["affected_lines"]
                    if "line_content" in result:
                        finding["line_content"] = result["line_content"]
                    if "evidence_type" in result:
                        finding["evidence_type"] = result["evidence_type"]

                    if not result["compliant"]:
                        findings.append(finding)

        return findings

    # CIS Benchmark check functions

    def check_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.1: Check hostname is configured."""
        has_hostname = any(
            self._safe_content(line).startswith("hostname ")
            for line in config_lines
        )

        # Check if hostname is default
        default_hostnames = ["Router", "Switch", "router", "switch"]
        hostname_value = None
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("hostname "):
                hostname_value = content.split()[1] if len(content.split()) > 1 else None

        is_default = hostname_value in default_hostnames if hostname_value else True

        return {
            "compliant": has_hostname and not is_default,
            "details": f"Hostname: {hostname_value}" if hostname_value else "No hostname configured"
        }

    def check_enable_secret(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.2: Check enable secret is configured."""
        enable_secret_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if self._safe_content(line).startswith("enable secret")
        ]

        if enable_secret_lines:
            line_nums = [ln for ln, _ in enable_secret_lines]
            contents = [content for _, content in enable_secret_lines]
            return self._create_finding(
                True,
                f"Enable secret configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Enable secret not configured - Best practice: Configure strong enable secret"
            )

    def check_password_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.3: Check password encryption is enabled."""
        encryption_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "service password-encryption" in self._safe_content(line)
        ]

        if encryption_lines:
            line_nums = [ln for ln, _ in encryption_lines]
            contents = [content for _, content in encryption_lines]
            return self._create_finding(
                True,
                f"Password encryption enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Password encryption not enabled - Best practice: Configure 'service password-encryption'"
            )

    def check_login_banner(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.1.4: Check login banner is configured."""
        banner_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'banner (login|motd)', self._safe_content(line), re.I)
        ]

        if banner_lines:
            line_nums = [ln for ln, _ in banner_lines]
            contents = [content for _, content in banner_lines]
            return self._create_finding(
                True,
                f"Login banner configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No login banner found - Best practice: Configure login or motd banner"
            )

    def check_no_http_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.1: Check HTTP server is disabled."""
        http_enabled_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if self._safe_content(line) == "ip http server"
        ]

        http_disabled_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if self._safe_content(line) == "no ip http server"
        ]

        if http_enabled_lines and not http_disabled_lines:
            line_nums = [ln for ln, _ in http_enabled_lines]
            contents = [content for _, content in http_enabled_lines]
            return self._create_finding(
                False,
                f"HTTP server is enabled on line(s) {', '.join(map(str, line_nums))}",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                True,
                "HTTP server properly disabled"
            )

    def check_https_secure(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.2: Check HTTPS is properly configured if enabled."""
        https_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip http secure-server" in self._safe_content(line)
        ]

        if not https_lines:
            return self._create_finding(True, "HTTPS not enabled (acceptable)")

        # If HTTPS is enabled, check for proper TLS version
        tls_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "tlsv1.2" in self._safe_content(line).lower()
        ]

        if tls_lines:
            line_nums = [ln for ln, _ in tls_lines]
            contents = [content for _, content in tls_lines]
            return self._create_finding(
                True,
                f"HTTPS with TLS 1.2+ configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            https_line_nums = [ln for ln, _ in https_lines]
            https_contents = [content for _, content in https_lines]
            return self._create_finding(
                False,
                f"HTTPS enabled but TLS version not configured (line {https_line_nums[0]})",
                https_line_nums,
                https_contents
            )

    def check_ssh_version_2(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.3: Check SSH version 2 is configured."""
        ssh_v2_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip ssh version 2" in self._safe_content(line)
        ]

        if ssh_v2_lines:
            line_nums = [ln for ln, _ in ssh_v2_lines]
            contents = [content for _, content in ssh_v2_lines]
            return self._create_finding(
                True,
                f"SSH version 2 configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "SSH version not explicitly set to 2 - Best practice: Configure 'ip ssh version 2'"
            )

    def check_vty_transport_ssh(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.4: Check VTY lines use SSH only."""
        in_vty_block = False
        vty_ssh_only = True
        vty_found = False
        vty_line_nums = []
        vty_contents = []
        problem_lines = []
        problem_contents = []

        for line in config_lines:
            content = self._safe_content(line)
            line_num = self._get_line_number(line)

            if re.match(r'line vty', content):
                in_vty_block = True
                vty_found = True
                if line_num:
                    vty_line_nums.append(line_num)
                    vty_contents.append(content)
            elif in_vty_block and content.startswith("line "):
                in_vty_block = False
            elif in_vty_block and "transport input" in content:
                if "ssh" not in content or ("telnet" in content or "all" in content):
                    vty_ssh_only = False
                    if line_num:
                        problem_lines.append(line_num)
                        problem_contents.append(content)

        if not vty_found:
            return self._create_finding(False, "No VTY lines configured - Best practice: Configure VTY lines with SSH-only access")

        if not vty_ssh_only:
            return self._create_finding(
                False,
                f"VTY lines allow insecure protocols on {len(problem_lines)} line(s)",
                problem_lines,
                problem_contents
            )
        else:
            return self._create_finding(
                True,
                f"VTY lines use SSH only (configured on line {vty_line_nums[0]})" if vty_line_nums else "VTY lines use SSH only",
                vty_line_nums if vty_line_nums else None,
                vty_contents if vty_contents else None
            )

    def check_exec_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.2.5: Check exec-timeout is configured appropriately."""
        timeout_issue_lines = []
        timeout_issue_contents = []
        in_line_block = False
        current_line = None

        for line in config_lines:
            content = self._safe_content(line)
            line_num = self._get_line_number(line)

            if re.match(r'line (console|aux|vty)', content):
                in_line_block = True
                current_line = content.split()[1]
            elif in_line_block and content.startswith("line "):
                in_line_block = False
                current_line = None
            elif in_line_block and "exec-timeout" in content:
                # Parse timeout value (minutes seconds)
                match = re.search(r'exec-timeout (\d+)(?: (\d+))?', content)
                if match:
                    minutes = int(match.group(1))
                    if minutes > 10 or minutes == 0:
                        if line_num:
                            timeout_issue_lines.append(line_num)
                            timeout_issue_contents.append(content)

        if timeout_issue_lines:
            return self._create_finding(
                False,
                f"Timeout misconfigured on {len(timeout_issue_lines)} line(s) (should be 1-10 minutes)",
                timeout_issue_lines,
                timeout_issue_contents
            )
        else:
            return self._create_finding(
                True,
                "All timeouts properly configured"
            )

    def check_no_source_route(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.3.1: Check IP source routing is disabled."""
        no_source_route_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "no ip source-route" in self._safe_content(line)
        ]

        if no_source_route_lines:
            line_nums = [ln for ln, _ in no_source_route_lines]
            contents = [content for _, content in no_source_route_lines]
            return self._create_finding(
                True,
                f"IP source routing disabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "IP source routing not disabled - Best practice: Configure 'no ip source-route'"
            )

    def check_no_proxy_arp(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.3.2: Check proxy ARP is disabled."""
        no_proxy_arp_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "no ip proxy-arp" in self._safe_content(line)
        ]

        if no_proxy_arp_lines:
            line_nums = [ln for ln, _ in no_proxy_arp_lines]
            contents = [content for _, content in no_proxy_arp_lines]
            return self._create_finding(
                True,
                f"Proxy ARP disabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Proxy ARP not explicitly disabled - Best practice: Configure 'no ip proxy-arp' on interfaces"
            )

    def check_aaa_new_model(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.4.1: Check AAA new-model is enabled."""
        aaa_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa new-model" in self._safe_content(line)
        ]

        if aaa_lines:
            line_nums = [ln for ln, _ in aaa_lines]
            contents = [content for _, content in aaa_lines]
            return self._create_finding(
                True,
                f"AAA new-model enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA new-model not configured - Best practice: Configure 'aaa new-model'"
            )

    def check_aaa_authentication_login(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.4.2: Check AAA authentication login is configured."""
        auth_login_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa authentication login" in self._safe_content(line)
        ]

        if auth_login_lines:
            line_nums = [ln for ln, _ in auth_login_lines]
            contents = [content for _, content in auth_login_lines]
            return self._create_finding(
                True,
                f"AAA authentication login configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA authentication login not configured - Best practice: Configure AAA authentication"
            )

    def check_logging_buffered(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.5.1: Check logging buffered is configured."""
        logging_buffered_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "logging buffered" in self._safe_content(line)
        ]

        if logging_buffered_lines:
            line_nums = [ln for ln, _ in logging_buffered_lines]
            contents = [content for _, content in logging_buffered_lines]
            return self._create_finding(
                True,
                f"Logging buffered configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging buffered not configured - Best practice: Configure 'logging buffered'"
            )

    def check_logging_host(self, config_lines: List, parsed_config: Dict) -> Dict:
        """CIS 1.5.2: Check remote logging is configured."""
        logging_host_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.match(r'logging (host|\d+\.\d+\.\d+\.\d+)', self._safe_content(line))
        ]

        if logging_host_lines:
            line_nums = [ln for ln, _ in logging_host_lines]
            contents = [content for _, content in logging_host_lines]
            return self._create_finding(
                True,
                f"Remote logging configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No remote logging server configured - Best practice: Configure remote syslog server"
            )

    # DISA STIG check functions

    def check_console_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3056: Check console authentication."""
        in_console = False
        has_auth = False
        auth_lines = []
        auth_contents = []
        console_line_nums = []

        for line in config_lines:
            content = self._safe_content(line)
            line_num = self._get_line_number(line)

            if "line console" in content:
                in_console = True
                if line_num:
                    console_line_nums.append(line_num)
            elif in_console and content.startswith("line "):
                break
            elif in_console and ("login authentication" in content or "login local" in content):
                has_auth = True
                if line_num:
                    auth_lines.append(line_num)
                    auth_contents.append(content)

        if has_auth:
            return self._create_finding(
                True,
                f"Console authentication configured (line {auth_lines[0]})" if auth_lines else "Console authentication configured",
                auth_lines if auth_lines else None,
                auth_contents if auth_contents else None
            )
        else:
            return self._create_finding(
                False,
                "Console lacks authentication - Best practice: Configure console authentication"
            )

    def check_fips_mode(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3057: Check FIPS mode or approved algorithms."""
        # Check for SSH v2 and strong key size as proxy
        ssh_v2_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip ssh version 2" in self._safe_content(line)
        ]

        rsa_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'crypto key generate rsa.*(?:2048|4096)', self._safe_content(line))
        ]

        if ssh_v2_lines and rsa_lines:
            all_lines = ssh_v2_lines + rsa_lines
            line_nums = [ln for ln, _ in all_lines]
            contents = [content for _, content in all_lines]
            return self._create_finding(
                True,
                f"FIPS-approved algorithms in use (lines {line_nums[0]}, {line_nums[-1] if len(line_nums) > 1 else line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "FIPS compliance not verified - Best practice: Configure SSH v2 and strong RSA keys (2048+ bits)"
            )

    def check_dod_banner(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3058: Check DoD banner."""
        banner_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'banner login', self._safe_content(line), re.I)
        ]

        if banner_lines:
            line_nums = [ln for ln, _ in banner_lines]
            contents = [content for _, content in banner_lines]
            return self._create_finding(
                True,
                f"Login banner configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No login banner - Best practice: Configure DoD-compliant login banner"
            )

    def check_logging_protection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3059: Check logging protection."""
        logging_host_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.match(r'logging (host|\d+\.\d+\.\d+\.\d+)', self._safe_content(line))
        ]

        if logging_host_lines:
            line_nums = [ln for ln, _ in logging_host_lines]
            contents = [content for _, content in logging_host_lines]
            return self._create_finding(
                True,
                f"Logging to secure server (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No secure logging configured - Best practice: Configure remote logging to secure server"
            )

    def check_password_length(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3210: Check minimum password length."""
        for line in config_lines:
            content = self._safe_content(line)
            line_num = self._get_line_number(line)
            match = re.search(r'security passwords min-length (\d+)', content)
            if match:
                length = int(match.group(1))
                if length >= 15:
                    return self._create_finding(
                        True,
                        f"Password min-length: {length} (line {line_num})" if line_num else f"Password min-length: {length}",
                        [line_num] if line_num else None,
                        [content] if line_num else None
                    )
                else:
                    return self._create_finding(
                        False,
                        f"Password min-length too short: {length} (should be >=15, line {line_num})" if line_num else f"Password min-length too short: {length}",
                        [line_num] if line_num else None,
                        [content] if line_num else None
                    )

        return self._create_finding(
            False,
            "Password min-length not configured - Best practice: Configure 'security passwords min-length 15'"
        )

    def check_session_timeout_stig(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3058: Check session timeout."""
        return self.check_exec_timeout(config_lines, parsed_config)

    def check_pki_certificates(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3069: Check PKI certificates."""
        
        pki_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "crypto pki" in self._safe_content(line)
        ]

        if pki_lines:
            line_nums = [ln for ln, _ in pki_lines]
            contents = [content for _, content in pki_lines]
            return self._create_finding(
                True,
                f"PKI configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No PKI configuration - Best practice: Configure appropriate setting"
            )

    def check_snmp_version(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3143: Check SNMP version."""
        has_snmpv1v2 = any(
            re.search(r'snmp-server community \S+ (RO|RW)', self._safe_content(line))
            for line in config_lines
        )

        has_snmpv3 = any(
            "snmp-server group" in self._safe_content(line) and "v3" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": not has_snmpv1v2 or has_snmpv3,
            "details": "SNMPv3 configured" if has_snmpv3 else "SNMPv1/v2c detected" if has_snmpv1v2 else "No SNMP configured"
        }

    def check_control_plane_policing(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3175: Check control plane policing."""
        
        copp_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'control-plane|service-policy.*control-plane', self._safe_content(line))
        ]

        if copp_lines:
            line_nums = [ln for ln, _ in copp_lines]
            contents = [content for _, content in copp_lines]
            return self._create_finding(
                True,
                f"Control plane policing configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No CoPP configured - Best practice: Configure appropriate setting"
            )

    def check_management_acl(self, config_lines: List, parsed_config: Dict) -> Dict:
        """STIG V-3057: Check management ACL."""
        in_vty = False
        has_acl = False

        for line in config_lines:
            content = self._safe_content(line)
            if "line vty" in content:
                in_vty = True
            elif in_vty and content.startswith("line "):
                break
            elif in_vty and "access-class" in content:
                has_acl = True

        return {
            "compliant": has_acl,
            "details": "Management ACL configured" if has_acl else "No VTY access control"
        }

    # Vendor Hardening Guide check functions

    def check_unnecessary_services(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check unnecessary services are disabled."""
        unnecessary_services = ["cdp run", "ip finger", "service pad"]
        issues = []

        for service in unnecessary_services:
            if any(service in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines):
                issues.append(service)

        return {
            "compliant": len(issues) == 0,
            "details": f"Unnecessary services enabled: {', '.join(issues)}" if issues else "Unnecessary services disabled"
        }

    def check_tcp_keepalives(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check TCP keepalives."""
        has_keepalives_in = any("service tcp-keepalives-in" in self._safe_content(line) for line in config_lines)
        has_keepalives_out = any("service tcp-keepalives-out" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_keepalives_in and has_keepalives_out,
            "details": "TCP keepalives configured" if (has_keepalives_in and has_keepalives_out) else "TCP keepalives not fully configured"
        }

    def check_no_icmp_redirects(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check ICMP redirects disabled."""
        
        no_redirects_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "no ip redirects" in self._safe_content(line)
        ]

        if no_redirects_lines:
            line_nums = [ln for ln, _ in no_redirects_lines]
            contents = [content for _, content in no_redirects_lines]
            return self._create_finding(
                True,
                f"ICMP redirects disabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "ICMP redirects not disabled - Best practice: Configure appropriate setting"
            )

    def check_urpf_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check uRPF enabled."""
        
        urpf_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip verify unicast source reachable-via" in self._safe_content(line)
        ]

        if urpf_lines:
            line_nums = [ln for ln, _ in urpf_lines]
            contents = [content for _, content in urpf_lines]
            return self._create_finding(
                True,
                f"uRPF enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "uRPF not configured - Best practice: Configure appropriate setting"
            )

    def check_ntp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Cisco Hardening: Check NTP authentication."""
        has_ntp_auth = any("ntp authenticate" in self._safe_content(line) for line in config_lines)
        has_ntp_key = any("ntp authentication-key" in self._safe_content(line) for line in config_lines)

        return {
            "compliant": has_ntp_auth and has_ntp_key,
            "details": "NTP authentication configured" if (has_ntp_auth and has_ntp_key) else "NTP authentication not configured"
        }

    # ASA-specific check functions

    def check_asa_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check hostname is configured."""
        hostname_lines = self._find_lines(config_lines, pattern="hostname ")

        # Check if hostname is default
        default_hostnames = ["ciscoasa", "asa", "firewall"]
        hostname_value = None

        if hostname_lines:
            line_num, content = hostname_lines[0]
            hostname_value = content.split()[1] if len(content.split()) > 1 else None

            if hostname_value and hostname_value.lower() in default_hostnames:
                # Default hostname is a misconfiguration
                return self._create_finding(
                    False,
                    f"Default hostname '{hostname_value}' configured - should be changed",
                    affected_lines=[line_num],
                    line_content=[content]
                )
            else:
                # Hostname configured and not default
                return self._create_finding(
                    True,
                    f"Hostname configured: {hostname_value}"
                )
        else:
            # No hostname configured
            return self._create_finding(
                False,
                "No hostname configured"
            )

    def check_asa_enable_password(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check enable password is configured with encryption."""
        enable_password_lines = self._find_lines(config_lines, pattern="enable password")

        if not enable_password_lines:
            return self._create_finding(False, "No enable password configured")

        # Check if encrypted (ASA uses pbkdf2, encrypted, or shows hash)
        line_nums = []
        contents = []
        has_weak = False

        for line_num, content in enable_password_lines:
            line_nums.append(line_num)
            contents.append(content)
            # Check for weak encryption (plain text would be "enable password <password>")
            if not any(keyword in content for keyword in ["pbkdf2", "encrypted", "sha512"]) and content.count(" ") == 2:
                has_weak = True

        if has_weak:
            return self._create_finding(
                False,
                "Enable password may use weak or no encryption",
                affected_lines=line_nums,
                line_content=contents
            )
        else:
            return self._create_finding(
                True,
                f"Enable password configured with encryption (line {line_nums[0]})"
            )

    def check_asa_no_http_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check HTTP server is disabled."""
        # Find lines with HTTP server enabled
        http_enabled_lines = self._find_lines(config_lines, pattern="http server enable")
        http_disabled_lines = self._find_lines(config_lines, pattern="no http server enable")

        # HTTP is compliant if it's not enabled, or if it's explicitly disabled
        is_compliant = len(http_enabled_lines) == 0 or len(http_disabled_lines) > 0

        if not is_compliant and http_enabled_lines:
            # Found HTTP server enabled - this is a misconfiguration
            line_nums = [ln for ln, _ in http_enabled_lines]
            contents = [content for _, content in http_enabled_lines]
            return self._create_finding(
                False,
                f"HTTP server is enabled on {len(line_nums)} line(s) - unencrypted management interface",
                affected_lines=line_nums,
                line_content=contents
            )
        else:
            return self._create_finding(
                True,
                "HTTP server properly disabled"
            )

    def check_asa_ssh_version(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check SSH version 2 is configured."""
        
        ssh_v2_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ssh version 2" in self._safe_content(line)
        ]

        if ssh_v2_lines:
            line_nums = [ln for ln, _ in ssh_v2_lines]
            contents = [content for _, content in ssh_v2_lines]
            return self._create_finding(
                True,
                f"SSH version 2 configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "SSH version not explicitly set to 2 - Best practice: Configure appropriate setting"
            )

    def check_asa_management_access(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check management access restrictions are configured."""
        
        ssh_restriction_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.match(r'ssh\s+\d+\.\d+\.\d+\.\d+', self._safe_content(line))
        ]

        if ssh_restriction_lines:
            line_nums = [ln for ln, _ in ssh_restriction_lines]
            contents = [content for _, content in ssh_restriction_lines]
            return self._create_finding(
                True,
                f"SSH access restricted by IP (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No SSH access restrictions configured - Best practice: Configure appropriate setting"
            )

    def check_asa_aaa_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check AAA authentication is configured."""
        
        aaa_auth_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa authentication" in self._safe_content(line)
        ]

        if aaa_auth_lines:
            line_nums = [ln for ln, _ in aaa_auth_lines]
            contents = [content for _, content in aaa_auth_lines]
            return self._create_finding(
                True,
                f"AAA authentication configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA authentication not configured - Best practice: Configure appropriate setting"
            )

    def check_asa_logging_host(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check logging to remote host is configured."""
        
        logging_host_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.match(r'logging host\s+', self._safe_content(line))
        ]

        if logging_host_lines:
            line_nums = [ln for ln, _ in logging_host_lines]
            contents = [content for _, content in logging_host_lines]
            return self._create_finding(
                True,
                f"Remote logging configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No remote logging server configured - Best practice: Configure appropriate setting"
            )

    def check_asa_logging_trap(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check logging trap level is configured."""
        
        logging_trap_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "logging trap" in self._safe_content(line)
        ]

        if logging_trap_lines:
            line_nums = [ln for ln, _ in logging_trap_lines]
            contents = [content for _, content in logging_trap_lines]
            return self._create_finding(
                True,
                f"Logging trap level configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging trap level not configured - Best practice: Configure appropriate setting"
            )

    def check_asa_icmp_unreachable(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check ICMP unreachable is disabled."""
        
        no_icmp_unreachable_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "no icmp unreachable" in self._safe_content(line)
        ]

        if no_icmp_unreachable_lines:
            line_nums = [ln for ln, _ in no_icmp_unreachable_lines]
            contents = [content for _, content in no_icmp_unreachable_lines]
            return self._create_finding(
                True,
                f"ICMP unreachable disabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "ICMP unreachable not disabled - Best practice: Configure appropriate setting"
            )

    # NX-OS-specific check functions

    def check_nxos_hostname_configured(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check switchname/hostname is configured."""
        has_switchname = any(
            self._safe_content(line).startswith("switchname ") or self._safe_content(line).startswith("hostname ")
            for line in config_lines
        )

        # Check if hostname is default
        default_hostnames = ["switch", "nexus", "nxos"]
        hostname_value = None
        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("switchname ") or content.startswith("hostname "):
                hostname_value = content.split()[1] if len(content.split()) > 1 else None

        is_default = hostname_value.lower() in default_hostnames if hostname_value else True

        return {
            "compliant": has_switchname and not is_default,
            "details": f"Switchname: {hostname_value}" if hostname_value else "No switchname configured"
        }

    def check_nxos_password_strength(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check password strength checking is enabled."""
        
        strength_check_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "password strength-check" in self._safe_content(line)
        ]

        if strength_check_lines:
            line_nums = [ln for ln, _ in strength_check_lines]
            contents = [content for _, content in strength_check_lines]
            return self._create_finding(
                True,
                f"Password strength checking enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Password strength checking not enabled - Best practice: Configure appropriate setting"
            )

    def check_nxos_ssh_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check SSH feature is enabled and Telnet is disabled."""
        has_ssh = any(
            "feature ssh" in self._safe_content(line)
            for line in config_lines
        )

        has_telnet = any(
            "feature telnet" in self._safe_content(line) and not self._safe_content(line).startswith("no ")
            for line in config_lines
        )

        return {
            "compliant": has_ssh and not has_telnet,
            "details": "SSH enabled, Telnet disabled" if (has_ssh and not has_telnet) else "SSH not properly configured"
        }

    def check_nxos_ssh_key_strength(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check SSH key strength is sufficient."""
        
        strong_key_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'ssh key rsa (2048|4096)', self._safe_content(line))
        ]

        if strong_key_lines:
            line_nums = [ln for ln, _ in strong_key_lines]
            contents = [content for _, content in strong_key_lines]
            return self._create_finding(
                True,
                f"Strong SSH key configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Strong SSH key not configured - Best practice: Configure appropriate setting"
            )

    def check_nxos_exec_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check exec-timeout is configured on VTY lines."""
        timeout_issues = []
        in_line_block = False
        current_line = None

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'line (console|vty)', content):
                in_line_block = True
                current_line = content.split()[1]
            elif in_line_block and content.startswith("line "):
                in_line_block = False
                current_line = None
            elif in_line_block and "exec-timeout" in content:
                # Parse timeout value (minutes)
                match = re.search(r'exec-timeout (\d+)', content)
                if match:
                    minutes = int(match.group(1))
                    if minutes > 10 or minutes == 0:
                        timeout_issues.append(current_line)

        return {
            "compliant": len(timeout_issues) == 0,
            "details": f"Timeout issues on: {', '.join(timeout_issues)}" if timeout_issues else "All timeouts properly configured"
        }

    def check_nxos_aaa_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check AAA authentication is configured."""
        
        aaa_auth_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa authentication login" in self._safe_content(line)
        ]

        if aaa_auth_lines:
            line_nums = [ln for ln, _ in aaa_auth_lines]
            contents = [content for _, content in aaa_auth_lines]
            return self._create_finding(
                True,
                f"AAA authentication configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA authentication not configured - Best practice: Configure appropriate setting"
            )

    def check_nxos_logging_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check logging server is configured."""
        
        logging_server_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.match(r'logging server', self._safe_content(line))
        ]

        if logging_server_lines:
            line_nums = [ln for ln, _ in logging_server_lines]
            contents = [content for _, content in logging_server_lines]
            return self._create_finding(
                True,
                f"Remote logging server configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No remote logging server configured - Best practice: Configure appropriate setting"
            )

    def check_nxos_logging_level(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check logging level is configured."""
        
        logging_level_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.match(r'logging level', self._safe_content(line))
        ]

        if logging_level_lines:
            line_nums = [ln for ln, _ in logging_level_lines]
            contents = [content for _, content in logging_level_lines]
            return self._create_finding(
                True,
                f"Logging level configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging level not configured - Best practice: Configure appropriate setting"
            )

    def check_nxos_unnecessary_features(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NX-OS: Check unnecessary features are disabled."""
        unnecessary_features = ["feature dhcp", "feature dns"]
        issues = []

        for feature in unnecessary_features:
            if any(feature in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines):
                issues.append(feature)

        return {
            "compliant": len(issues) == 0,
            "details": f"Unnecessary features enabled: {', '.join(issues)}" if issues else "Unnecessary features disabled"
        }

    # New ASA Check Functions (25 functions)

    def check_asa_security_levels(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check security levels configured on interfaces."""
        has_nameif = any("nameif" in self._safe_content(line) for line in config_lines)
        has_security_level = any("security-level" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_security_level if has_nameif else True, "details": "Security levels configured" if has_security_level else "Missing security-level configuration"}

    def check_asa_same_security_traffic(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check same-security-traffic configuration."""
        same_security_lines = self._find_lines(config_lines, pattern="same-security-traffic permit")

        if same_security_lines:
            line_nums = [ln for ln, _ in same_security_lines]
            contents = [content for _, content in same_security_lines]
            return self._create_finding(
                False,
                f"Same-security-traffic enabled on {len(line_nums)} line(s) - review if necessary",
                affected_lines=line_nums,
                line_content=contents
            )
        else:
            return self._create_finding(True, "Same-security-traffic disabled")

    def check_asa_object_groups(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check use of object groups."""
        has_object_groups = any("object-group" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_object_groups, "details": "Object groups configured" if has_object_groups else "No object groups found"}

    def check_asa_threat_detection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check threat detection enabled."""
        has_threat_detection = any("threat-detection" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_threat_detection, "details": "Threat detection enabled" if has_threat_detection else "Threat detection not configured"}

    def check_asa_inspection_policies(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check inspection policies configured."""
        has_inspect = any(re.search(r'inspect (dns|http|ftp|icmp)', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_inspect, "details": "Inspection policies configured" if has_inspect else "No inspection policies found"}

    def check_asa_connection_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check connection limits configured."""
        has_conn_limit = any("set connection conn-max" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_conn_limit, "details": "Connection limits configured" if has_conn_limit else "No connection limits found"}

    def check_asa_tcp_normalization(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check TCP normalization/map configured."""
        tcp_map_lines = self._find_lines(config_lines, pattern="tcp-map")
        return self._create_finding(
            len(tcp_map_lines) > 0,
            "TCP normalization configured" if tcp_map_lines else "TCP normalization not configured"
        )

    def check_asa_timeout_values(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check timeout values configured."""
        timeout_lines = self._find_lines(config_lines, condition=lambda c: re.search(r'timeout (xlate|conn)', c) is not None)
        return self._create_finding(
            len(timeout_lines) > 0,
            "Timeout values configured" if timeout_lines else "Default timeout values in use"
        )

    def check_asa_dns_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check DNS inspection enabled."""
        dns_inspect_lines = self._find_lines(config_lines, pattern="inspect dns")
        return self._create_finding(
            len(dns_inspect_lines) > 0,
            "DNS inspection enabled" if dns_inspect_lines else "DNS inspection not enabled"
        )

    def check_asa_http_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check HTTP inspection enabled."""
        http_inspect_lines = self._find_lines(config_lines, pattern="inspect http")
        return self._create_finding(
            len(http_inspect_lines) > 0,
            "HTTP inspection enabled" if http_inspect_lines else "HTTP inspection not enabled"
        )

    def check_asa_ftp_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check FTP inspection enabled."""
        ftp_inspect_lines = self._find_lines(config_lines, pattern="inspect ftp")
        return self._create_finding(
            len(ftp_inspect_lines) > 0,
            "FTP inspection enabled" if ftp_inspect_lines else "FTP inspection not enabled"
        )

    def check_asa_ikev2_vpn(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check IKEv2 configured for VPN."""
        has_ikev2 = any("crypto ikev2" in self._safe_content(line) for line in config_lines)
        has_ikev1 = any("crypto isakmp" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ikev2 or not has_ikev1, "details": "IKEv2 configured" if has_ikev2 else ("No VPN configured" if not has_ikev1 else "Only IKEv1 configured")}

    def check_asa_ipsec_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check strong IPsec encryption (AES-256)."""
        crypto_lines = self._find_lines(config_lines, condition=lambda c: re.search(r'crypto ipsec', c) is not None)

        if not crypto_lines:
            return self._create_finding(True, "No IPsec configured")

        # Check for weak encryption
        weak_lines = self._find_lines(config_lines, condition=lambda c: re.search(r'(des|3des)\s', c) is not None)
        aes256_lines = self._find_lines(config_lines, pattern="aes-256")

        if weak_lines:
            line_nums = [ln for ln, _ in weak_lines]
            contents = [content for _, content in weak_lines]
            return self._create_finding(
                False,
                f"Weak encryption (DES/3DES) found on {len(line_nums)} line(s)",
                affected_lines=line_nums,
                line_content=contents
            )
        elif not aes256_lines:
            return self._create_finding(False, "No AES-256 encryption configured")
        else:
            return self._create_finding(True, "Strong encryption (AES-256) configured")

    def check_asa_vpn_pfs(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check VPN PFS configured."""
        has_crypto_map = any("crypto map" in self._safe_content(line) for line in config_lines)
        if not has_crypto_map:
            return {"compliant": True, "details": "No crypto map configured"}
        has_pfs = any("set pfs" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_pfs, "details": "PFS configured" if has_pfs else "PFS not configured"}

    def check_asa_anyconnect_auth(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check AnyConnect authentication configured."""
        has_anyconnect = any("anyconnect" in self._safe_content(line) or "webvpn" in self._safe_content(line) for line in config_lines)
        if not has_anyconnect:
            return {"compliant": True, "details": "AnyConnect not configured"}
        has_auth = any("authentication-server-group" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_auth, "details": "AnyConnect authentication configured" if has_auth else "AnyConnect lacks AAA authentication"}

    def check_asa_ssl_vpn_ciphers(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check SSL VPN cipher configuration."""
        has_ssl_cipher = any(re.search(r'ssl cipher', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_ssl_cipher, "details": "SSL ciphers configured" if has_ssl_cipher else "Default SSL ciphers in use"}

    def check_asa_no_weak_vpn(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check weak VPN protocols disabled."""
        has_vpdn = any("vpdn enable" in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines)
        return {"compliant": not has_vpdn, "details": "Weak VPN protocols disabled" if not has_vpdn else "VPDN (PPTP/L2TP) enabled"}

    def check_asa_twice_nat(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check network object NAT usage."""
        has_object_nat = any("object network" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_object_nat, "details": "Object NAT configured" if has_object_nat else "Traditional NAT in use"}

    def check_asa_outbound_acls(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check outbound ACLs configured."""
        has_outbound_acl = any(re.search(r'access-group.*out', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_outbound_acl, "details": "Outbound ACLs configured" if has_outbound_acl else "No outbound ACL filtering"}

    def check_asa_acl_logging(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check ACL logging configured."""
        has_acl = any("access-list" in self._safe_content(line) for line in config_lines)
        if not has_acl:
            return {"compliant": True, "details": "No ACLs configured"}
        has_log = any("access-list" in self._safe_content(line) and "log" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_log, "details": "ACL logging configured" if has_log else "ACLs lack logging"}

    def check_asa_failover_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check failover encryption configured."""
        has_failover = any("failover" in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines)
        if not has_failover:
            return {"compliant": True, "details": "Failover not configured"}
        has_key = any("failover key" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_key, "details": "Failover encryption configured" if has_key else "Failover lacks encryption"}

    def check_asa_botnet_filter(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check Botnet Traffic Filter enabled."""
        has_botnet = any("dynamic-filter" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_botnet, "details": "Botnet Traffic Filter enabled" if has_botnet else "Botnet Traffic Filter not enabled"}

    def check_asa_vpn_accounting(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check VPN accounting configured."""
        has_vpn_acct = any("aaa accounting" in self._safe_content(line) and "vpn" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_vpn_acct, "details": "VPN accounting configured" if has_vpn_acct else "VPN accounting not configured"}

    def check_asa_unnecessary_services(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check unnecessary services disabled."""
        has_ftp = any("ftp mode" in self._safe_content(line) and not self._safe_content(line).startswith("no ") for line in config_lines)
        return {"compliant": not has_ftp, "details": "Unnecessary services disabled" if not has_ftp else "FTP service enabled"}

    def check_asa_ntp_timezone(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA: Check NTP and timezone configured."""
        has_ntp = any("ntp server" in self._safe_content(line) for line in config_lines)
        has_timezone = any("clock timezone" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ntp and has_timezone, "details": f"NTP: {has_ntp}, Timezone: {has_timezone}"}

    # ASA-Specific DISA STIG Check Functions (10 functions)

    def check_asa_stig_management_interface(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check management access restricted by interface."""
        http_lines = [line for line in config_lines if "http " in self._safe_content(line) and " " in self._safe_content(line).split("http ", 1)[1]]
        ssh_lines = [line for line in config_lines if "ssh " in self._safe_content(line) and " " in self._safe_content(line).split("ssh ", 1)[1]]

        # Check if management commands specify interface (not "any" or missing)
        http_has_interface = any(
            len(self._safe_content(line).split()) >= 4
            for line in http_lines
        )
        ssh_has_interface = any(
            len(self._safe_content(line).split()) >= 4
            for line in ssh_lines
        )

        compliant = (len(http_lines) == 0 or http_has_interface) and (len(ssh_lines) == 0 or ssh_has_interface)
        return {
            "compliant": compliant,
            "details": "Management access restricted by interface" if compliant else "Management access not restricted by interface"
        }

    def check_asa_stig_aaa_management(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check AAA configured for device management."""
        has_aaa_http = any(
            "aaa authentication http console" in self._safe_content(line)
            for line in config_lines
        )
        has_aaa_ssh = any(
            "aaa authentication ssh console" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_aaa_http or has_aaa_ssh
        return {
            "compliant": compliant,
            "details": "AAA configured for management" if compliant else "AAA not configured for management"
        }

    def check_asa_stig_session_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check session timeout does not exceed 10 minutes."""
        ssh_timeout = None
        http_timeout = None

        for line in config_lines:
            content = self._safe_content(line)
            if content.startswith("ssh timeout "):
                try:
                    ssh_timeout = int(content.split()[2])
                except (IndexError, ValueError):
                    pass
            elif content.startswith("http timeout "):
                try:
                    http_timeout = int(content.split()[2])
                except (IndexError, ValueError):
                    pass

        # STIG requires 10 minutes or less
        ssh_compliant = ssh_timeout is None or ssh_timeout <= 10
        http_compliant = http_timeout is None or http_timeout <= 10

        compliant = ssh_compliant and http_compliant
        return {
            "compliant": compliant,
            "details": f"SSH timeout: {ssh_timeout or 'not set'}, HTTP timeout: {http_timeout or 'not set'}" +
                      (" (exceeds 10 min)" if not compliant else "")
        }

    def check_asa_stig_acl_logging(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check access-lists log denied traffic."""
        acl_lines = [line for line in config_lines if "access-list " in self._safe_content(line) and " deny " in self._safe_content(line)]

        if not acl_lines:
            return {"compliant": True, "details": "No deny ACLs configured"}

        acls_with_logging = sum(1 for line in acl_lines if " log" in self._safe_content(line))
        compliant = acls_with_logging == len(acl_lines)

        return {
            "compliant": compliant,
            "details": f"{acls_with_logging}/{len(acl_lines)} deny ACLs have logging enabled"
        }

    def check_asa_stig_privilege_levels(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check privilege levels properly separated."""
        privilege_lines = [line for line in config_lines if "privilege " in self._safe_content(line) and " level " in self._safe_content(line)]

        # Check if custom privilege levels are defined (not just 0, 1, 15)
        custom_levels = set()
        for line in privilege_lines:
            content = self._safe_content(line)
            match = re.search(r'level\s+(\d+)', content)
            if match:
                level = int(match.group(1))
                if level not in [0, 1, 15]:
                    custom_levels.add(level)

        compliant = len(custom_levels) > 0
        return {
            "compliant": compliant,
            "details": f"{len(custom_levels)} custom privilege level(s) configured" if compliant else "No privilege level separation configured"
        }

    def check_asa_stig_connection_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check connection timeouts configured."""
        has_conn_timeout = any("timeout conn" in self._safe_content(line) for line in config_lines)
        has_xlate_timeout = any("timeout xlate" in self._safe_content(line) for line in config_lines)

        compliant = has_conn_timeout and has_xlate_timeout
        return {
            "compliant": compliant,
            "details": "Connection timeouts configured" if compliant else "Missing connection timeout configuration"
        }

    def check_asa_stig_snmp_default_community(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check no default SNMP community strings."""
        has_public = any(
            "snmp-server community public" in self._safe_content(line)
            for line in config_lines
        )
        has_private = any(
            "snmp-server community private" in self._safe_content(line)
            for line in config_lines
        )

        compliant = not has_public and not has_private
        return {
            "compliant": compliant,
            "details": "No default SNMP communities" if compliant else "Default SNMP community strings detected (public/private)"
        }

    def check_asa_stig_encrypted_management(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check management uses encrypted protocols only."""
        has_ssh = any("ssh " in self._safe_content(line) and "ssh " == self._safe_content(line)[:4] for line in config_lines)
        has_https = any("http server enable" in self._safe_content(line) for line in config_lines)
        has_telnet = any("telnet " in self._safe_content(line) and "telnet " == self._safe_content(line)[:7] for line in config_lines)

        # Compliant if SSH or HTTPS enabled, and no telnet
        compliant = (has_ssh or has_https) and not has_telnet
        return {
            "compliant": compliant,
            "details": f"SSH: {has_ssh}, HTTPS: {has_https}, Telnet: {has_telnet}" +
                      (" - Uses encrypted management" if compliant else " - Insecure protocols detected or no encrypted management")
        }

    def check_asa_stig_context_admin(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check security context admin restricted."""
        has_mode_multiple = any("mode multiple" in self._safe_content(line) for line in config_lines)

        if not has_mode_multiple:
            return {"compliant": True, "details": "Not in multiple context mode"}

        # In multiple context mode, check for admin context restrictions
        has_admin_context = any("context admin" in self._safe_content(line) for line in config_lines)
        has_allocate_interface = any("allocate-interface" in self._safe_content(line) for line in config_lines)

        compliant = has_admin_context and has_allocate_interface
        return {
            "compliant": compliant,
            "details": "Admin context restricted" if compliant else "Admin context not properly restricted"
        }

    def check_asa_stig_traffic_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """ASA STIG: Check traffic inspection configured."""
        has_policy_map = any("policy-map" in self._safe_content(line) for line in config_lines)
        has_inspect = any("inspect " in self._safe_content(line) for line in config_lines)

        # Check for common inspection protocols
        inspect_protocols = ["inspect http", "inspect ftp", "inspect dns"]
        protocols_configured = sum(
            1 for protocol in inspect_protocols
            if any(protocol in self._safe_content(line) for line in config_lines)
        )

        compliant = has_policy_map and has_inspect and protocols_configured >= 2
        return {
            "compliant": compliant,
            "details": f"Traffic inspection: {protocols_configured} protocol(s) configured" if compliant else "Insufficient traffic inspection configured"
        }

    # New NXOS Check Functions (25 functions)

    def check_nxos_vdc_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VDC resource limits configured."""
        has_vdc = any(re.match(r'^vdc\s+', self._safe_content(line)) for line in config_lines)
        if not has_vdc:
            return {"compliant": True, "details": "VDC not in use"}
        has_limits = any("limit-resource" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_limits, "details": "VDC resource limits configured" if has_limits else "VDC lacks resource limits"}

    def check_nxos_vdc_separation(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VDC separation configured."""
        vdc_count = len([line for line in config_lines if re.match(r'^vdc\s+', self._safe_content(line))])
        return {"compliant": vdc_count > 1 or vdc_count == 0, "details": f"{vdc_count} VDCs configured" if vdc_count > 0 else "VDC not in use"}

    def check_nxos_vdc_ha(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VDC HA policy configured."""
        has_vdc = any(re.match(r'^vdc\s+', self._safe_content(line)) for line in config_lines)
        if not has_vdc:
            return {"compliant": True, "details": "VDC not in use"}
        has_ha_policy = any("ha-policy" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ha_policy, "details": "VDC HA policy configured" if has_ha_policy else "VDC lacks HA policy"}

    def check_nxos_vpc_keepalive(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC peer-keepalive configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_keepalive = any("peer-keepalive" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_keepalive, "details": "vPC peer-keepalive configured" if has_keepalive else "vPC lacks peer-keepalive"}

    def check_nxos_vpc_peerlink(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC peer-link configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_peerlink = any("vpc peer-link" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_peerlink, "details": "vPC peer-link configured" if has_peerlink else "vPC lacks peer-link"}

    def check_nxos_vpc_autorecovery(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC auto-recovery configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_autorecovery = any("auto-recovery" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_autorecovery, "details": "vPC auto-recovery configured" if has_autorecovery else "vPC lacks auto-recovery"}

    def check_nxos_vpc_priority(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check vPC role priority configured."""
        has_vpc = any("vpc domain" in self._safe_content(line) for line in config_lines)
        if not has_vpc:
            return {"compliant": True, "details": "vPC not configured"}
        has_priority = any("role priority" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_priority, "details": "vPC role priority configured" if has_priority else "vPC using default priority"}

    def check_nxos_fex_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check FEX authentication configured."""
        has_fex = any(re.match(r'^fex\s+', self._safe_content(line)) for line in config_lines)
        if not has_fex:
            return {"compliant": True, "details": "FEX not configured"}
        has_pinning = any("pinning" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_pinning, "details": "FEX pinning configured" if has_pinning else "FEX lacks pinning/authentication"}

    def check_nxos_fex_maxlinks(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check FEX max-links configured."""
        has_fex = any(re.match(r'^fex\s+', self._safe_content(line)) for line in config_lines)
        if not has_fex:
            return {"compliant": True, "details": "FEX not configured"}
        has_maxlinks = any("max-links" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_maxlinks, "details": "FEX max-links configured" if has_maxlinks else "FEX using default max-links"}

    def check_nxos_custom_roles(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check custom RBAC roles configured."""
        custom_roles = [line for line in config_lines if re.match(r'^role name\s+(?!network-admin|network-operator)', self._safe_content(line))]
        return {"compliant": len(custom_roles) > 0, "details": f"{len(custom_roles)} custom roles configured" if custom_roles else "No custom roles configured"}

    def check_nxos_session_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check session limits configured."""
        has_session_limit = any("limit-max-sessions" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_session_limit, "details": "Session limits configured" if has_session_limit else "No session limits configured"}

    def check_nxos_command_authorization(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check command authorization enabled."""
        has_cmd_authz = any("aaa authorization commands" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_cmd_authz, "details": "Command authorization configured" if has_cmd_authz else "Command authorization not configured"}

    def check_nxos_admin_role_count(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check network-admin role usage."""
        admin_users = [line for line in config_lines if "role network-admin" in self._safe_content(line)]
        return {"compliant": len(admin_users) <= 3, "details": f"{len(admin_users)} users with network-admin role" if admin_users else "No network-admin users found"}

    def check_nxos_ra_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 RA Guard configured."""
        has_ra_guard = any("ipv6 nd raguard" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ra_guard, "details": "IPv6 RA Guard configured" if has_ra_guard else "IPv6 RA Guard not configured"}

    def check_nxos_nd_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 ND Inspection configured."""
        has_nd_inspection = any("ipv6 nd inspection" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_nd_inspection, "details": "IPv6 ND Inspection configured" if has_nd_inspection else "IPv6 ND Inspection not configured"}

    def check_nxos_dhcpv6_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 DHCP Guard configured."""
        has_dhcpv6_guard = any("ipv6 dhcp guard" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_dhcpv6_guard, "details": "IPv6 DHCP Guard configured" if has_dhcpv6_guard else "IPv6 DHCP Guard not configured"}

    def check_nxos_ipv6_source_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check IPv6 Source Guard configured."""
        has_ipv6_sg = any("ipv6 source-guard" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_ipv6_sg, "details": "IPv6 Source Guard configured" if has_ipv6_sg else "IPv6 Source Guard not configured"}

    def check_nxos_bfd(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check BFD configured."""
        has_bfd = any("feature bfd" in self._safe_content(line) or "bfd interval" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_bfd, "details": "BFD configured" if has_bfd else "BFD not configured"}

    def check_nxos_graceful_restart(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check graceful restart configured."""
        has_gr = any("graceful-restart" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_gr, "details": "Graceful restart configured" if has_gr else "Graceful restart not configured"}

    def check_nxos_cfs_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check CFS authentication enabled."""
        has_cfs = any("cfs distribute" in self._safe_content(line) for line in config_lines)
        if not has_cfs:
            return {"compliant": True, "details": "CFS not enabled"}
        has_auth = any("enable-authentication" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_auth, "details": "CFS authentication enabled" if has_auth else "CFS lacks authentication"}

    def check_nxos_vxlan_security(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check VXLAN security configured."""
        has_vxlan = any("feature nv overlay" in self._safe_content(line) for line in config_lines)
        if not has_vxlan:
            return {"compliant": True, "details": "VXLAN not configured"}
        has_evpn = any("evpn" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_evpn, "details": "VXLAN with EVPN configured" if has_evpn else "VXLAN without EVPN"}

    def check_nxos_port_tracking(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check port tracking configured."""
        has_tracking = any(re.match(r'^track\s+', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_tracking, "details": "Port tracking configured" if has_tracking else "Port tracking not configured"}

    def check_nxos_qos_policies(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check QoS policies configured."""
        has_qos = any("class-map type qos" in self._safe_content(line) or "policy-map type qos" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_qos, "details": "QoS policies configured" if has_qos else "QoS policies not configured"}

    def check_nxos_snmpv3_only(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check SNMPv3 only configured."""
        has_snmpv3 = any("snmp-server user" in self._safe_content(line) for line in config_lines)
        has_community = any(re.search(r'snmp-server community\s+\w+', self._safe_content(line)) for line in config_lines)
        return {"compliant": has_snmpv3 and not has_community, "details": "SNMPv3 only configured" if (has_snmpv3 and not has_community) else "SNMPv1/v2c or no SNMP configured"}

    def check_nxos_checkpoint_auto(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS: Check automatic checkpoint configured."""
        has_checkpoint_auto = any("checkpoint auto" in self._safe_content(line) for line in config_lines)
        return {"compliant": has_checkpoint_auto, "details": "Automatic checkpoint configured" if has_checkpoint_auto else "Automatic checkpoint not configured"}

    # NXOS-Specific DISA STIG Check Functions (10 functions)

    def check_nxos_stig_password_complexity(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check password complexity enforced."""
        has_strength_check = any(
            "password strength-check" in self._safe_content(line)
            for line in config_lines
        )

        # Check if default strength-check is disabled (good - means custom rules)
        has_no_default = any(
            "no password strength-check default" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_strength_check
        return {
            "compliant": compliant,
            "details": "Password strength checking enabled" + (" with custom rules" if has_no_default else "") if compliant else "Password strength checking not enabled"
        }

    def check_nxos_stig_aaa_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check AAA authentication configured."""
        has_aaa_console = any(
            "aaa authentication login console" in self._safe_content(line)
            for line in config_lines
        )
        has_aaa_default = any(
            "aaa authentication login default" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_aaa_console or has_aaa_default
        return {
            "compliant": compliant,
            "details": "AAA authentication configured" if compliant else "AAA authentication not configured"
        }

    def check_nxos_stig_session_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check session timeout does not exceed 10 minutes."""
        timeout_values = []

        for line in config_lines:
            content = self._safe_content(line)
            if "exec-timeout" in content:
                # Parse timeout value (format: exec-timeout <minutes>)
                match = re.search(r'exec-timeout\s+(\d+)', content)
                if match:
                    timeout_values.append(int(match.group(1)))

        if not timeout_values:
            return {"compliant": False, "details": "No exec-timeout configured"}

        # Check all timeouts are 10 minutes or less
        max_timeout = max(timeout_values)
        compliant = max_timeout <= 10

        return {
            "compliant": compliant,
            "details": f"Max timeout: {max_timeout} minutes" + (" - compliant" if compliant else " - exceeds 10 minutes")
        }

    def check_nxos_stig_fips_mode(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check FIPS mode enabled."""
        
        fips_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "fips mode enable" in self._safe_content(line)
        ]

        if fips_lines:
            line_nums = [ln for ln, _ in fips_lines]
            contents = [content for _, content in fips_lines]
            return self._create_finding(
                True,
                f"FIPS mode enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "FIPS mode not enabled - Best practice: Configure appropriate setting"
            )

    def check_nxos_stig_command_accounting(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check command accounting configured."""
        
        accounting_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa accounting default" in self._safe_content(line)
        ]

        if accounting_lines:
            line_nums = [ln for ln, _ in accounting_lines]
            contents = [content for _, content in accounting_lines]
            return self._create_finding(
                True,
                f"AAA accounting configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA accounting not configured - Best practice: Configure appropriate setting"
            )

    def check_nxos_stig_tcp_limits(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check TCP protection configured."""
        has_tcp_mtu = any(
            "ip tcp path-mtu-discovery" in self._safe_content(line)
            for line in config_lines
        )

        # Additional TCP hardening checks
        has_tcp_synwait = any(
            "ip tcp synwait-time" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_tcp_mtu or has_tcp_synwait
        return {
            "compliant": compliant,
            "details": "TCP protection configured" if compliant else "TCP protection not configured"
        }

    def check_nxos_stig_snmp_default_community(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check no default SNMP community strings."""
        has_public = any(
            "snmp-server community public" in self._safe_content(line)
            for line in config_lines
        )
        has_private = any(
            "snmp-server community private" in self._safe_content(line)
            for line in config_lines
        )

        compliant = not has_public and not has_private
        return {
            "compliant": compliant,
            "details": "No default SNMP communities" if compliant else "Default SNMP community strings detected (public/private)"
        }

    def check_nxos_stig_snmpv3_security(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check SNMPv3 with auth and priv configured."""
        snmpv3_users = []

        for line in config_lines:
            content = self._safe_content(line)
            if "snmp-server user" in content:
                # Check if it has auth and priv
                if " auth " in content and " priv " in content:
                    snmpv3_users.append(content)

        compliant = len(snmpv3_users) > 0
        return {
            "compliant": compliant,
            "details": f"SNMPv3 with auth and priv: {len(snmpv3_users)} user(s)" if compliant else "No SNMPv3 users with auth and priv"
        }

    def check_nxos_stig_management_acl(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check management interface ACL configured."""
        has_mgmt_interface = any(
            "interface mgmt" in self._safe_content(line)
            for line in config_lines
        )

        if not has_mgmt_interface:
            return {"compliant": True, "details": "No mgmt interface configured"}

        # Check for ACL on management interface
        in_mgmt_interface = False
        has_acl = False

        for line in config_lines:
            content = self._safe_content(line)
            if "interface mgmt" in content:
                in_mgmt_interface = True
            elif in_mgmt_interface and content.startswith("interface "):
                in_mgmt_interface = False
            elif in_mgmt_interface and "ip access-group" in content:
                has_acl = True
                break

        return {
            "compliant": has_acl,
            "details": "Management ACL configured" if has_acl else "No ACL on management interface"
        }

    def check_nxos_stig_management_vlan(self, config_lines: List, parsed_config: Dict) -> Dict:
        """NXOS STIG: Check management traffic segregation."""
        has_mgmt_interface = any(
            "interface mgmt" in self._safe_content(line)
            for line in config_lines
        )
        has_mgmt_ip = False

        in_mgmt_interface = False
        for line in config_lines:
            content = self._safe_content(line)
            if "interface mgmt" in content:
                in_mgmt_interface = True
            elif in_mgmt_interface and content.startswith("interface "):
                in_mgmt_interface = False
            elif in_mgmt_interface and "ip address" in content:
                has_mgmt_ip = True
                break

        compliant = has_mgmt_interface and has_mgmt_ip
        return {
            "compliant": compliant,
            "details": "Dedicated management interface configured" if compliant else "No dedicated management interface"
        }

    # New IOS Check Functions - Interface Security

    def check_dtp_disabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that DTP is disabled on access ports."""
        dtp_issues = []
        in_interface = False
        current_interface = None
        is_access_port = False
        has_nonegotiate = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'interface\s+(gigabitethernet|fastethernet|ethernet)', content, re.I):
                # Save previous interface state
                if in_interface and is_access_port and not has_nonegotiate:
                    dtp_issues.append(current_interface)

                in_interface = True
                current_interface = content
                is_access_port = False
                has_nonegotiate = False
            elif in_interface and content.startswith("interface "):
                in_interface = False
            elif in_interface:
                if "switchport mode access" in content:
                    is_access_port = True
                if "switchport nonegotiate" in content:
                    has_nonegotiate = True

        # Check last interface
        if in_interface and is_access_port and not has_nonegotiate:
            dtp_issues.append(current_interface)

        return {
            "compliant": len(dtp_issues) == 0,
            "details": f"DTP not disabled on: {', '.join(dtp_issues) if dtp_issues else 'All access ports compliant'}"
        }

    def check_unused_interfaces_shutdown(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that unused interfaces are shutdown."""
        # This is a best-effort check - we look for interfaces without IP or VLAN config that aren't shutdown
        unshutdown_unused = []
        in_interface = False
        current_interface = None
        has_config = False
        is_shutdown = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'interface\s+', content, re.I):
                if in_interface and not has_config and not is_shutdown:
                    unshutdown_unused.append(current_interface)

                in_interface = True
                current_interface = content
                has_config = False
                is_shutdown = False
            elif in_interface and content.startswith("interface "):
                in_interface = False
            elif in_interface:
                if re.search(r'(ip address|switchport|description|channel-group)', content, re.I):
                    has_config = True
                if content == "shutdown":
                    is_shutdown = True

        return {
            "compliant": len(unshutdown_unused) == 0,
            "details": f"Unused interfaces not shutdown: {len(unshutdown_unused)}" if unshutdown_unused else "Check passed"
        }

    def check_native_vlan_trunk(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that native VLAN is configured on trunk ports."""
        trunk_without_native_vlan = []
        in_interface = False
        current_interface = None
        is_trunk = False
        has_native_vlan = False

        for line in config_lines:
            content = self._safe_content(line)

            if re.match(r'interface\s+', content, re.I):
                if in_interface and is_trunk and not has_native_vlan:
                    trunk_without_native_vlan.append(current_interface)

                in_interface = True
                current_interface = content
                is_trunk = False
                has_native_vlan = False
            elif in_interface and content.startswith("interface "):
                in_interface = False
            elif in_interface:
                if "switchport mode trunk" in content:
                    is_trunk = True
                if "switchport trunk native vlan" in content:
                    has_native_vlan = True

        return {
            "compliant": len(trunk_without_native_vlan) == 0,
            "details": f"Trunks without native VLAN: {len(trunk_without_native_vlan)}" if trunk_without_native_vlan else "All trunks have native VLAN configured"
        }

    def check_port_security(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that port security is enabled on access ports."""
        
        port_security_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "switchport port-security" in self._safe_content(line)
        ]

        if port_security_lines:
            line_nums = [ln for ln, _ in port_security_lines]
            contents = [content for _, content in port_security_lines]
            return self._create_finding(
                True,
                f"Port security configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No port security found - Best practice: Configure appropriate setting"
            )

    def check_storm_control(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that storm control is configured."""
        
        storm_control_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "storm-control" in self._safe_content(line)
        ]

        if storm_control_lines:
            line_nums = [ln for ln, _ in storm_control_lines]
            contents = [content for _, content in storm_control_lines]
            return self._create_finding(
                True,
                f"Storm control configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "No storm control found - Best practice: Configure appropriate setting"
            )

    def check_dhcp_snooping(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that DHCP snooping is enabled."""
        
        dhcp_snooping_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip dhcp snooping" in self._safe_content(line)
        ]

        if dhcp_snooping_lines:
            line_nums = [ln for ln, _ in dhcp_snooping_lines]
            contents = [content for _, content in dhcp_snooping_lines]
            return self._create_finding(
                True,
                f"DHCP snooping enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "DHCP snooping not configured - Best practice: Configure appropriate setting"
            )

    def check_dynamic_arp_inspection(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Dynamic ARP Inspection is enabled."""
        
        dai_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip arp inspection" in self._safe_content(line)
        ]

        if dai_lines:
            line_nums = [ln for ln, _ in dai_lines]
            contents = [content for _, content in dai_lines]
            return self._create_finding(
                True,
                f"Dynamic ARP Inspection enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "DAI not configured - Best practice: Configure appropriate setting"
            )

    def check_ip_source_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that IP Source Guard is enabled."""
        
        ipsg_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip verify source" in self._safe_content(line)
        ]

        if ipsg_lines:
            line_nums = [ln for ln, _ in ipsg_lines]
            contents = [content for _, content in ipsg_lines]
            return self._create_finding(
                True,
                f"IP Source Guard enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "IP Source Guard not configured - Best practice: Configure appropriate setting"
            )

    def check_bpdu_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that BPDU Guard is enabled."""
        
        bpdu_guard_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'spanning-tree (bpduguard|portfast bpduguard)', self._safe_content(line))
        ]

        if bpdu_guard_lines:
            line_nums = [ln for ln, _ in bpdu_guard_lines]
            contents = [content for _, content in bpdu_guard_lines]
            return self._create_finding(
                True,
                f"BPDU Guard enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "BPDU Guard not configured - Best practice: Configure appropriate setting"
            )

    def check_root_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Root Guard is enabled."""
        
        root_guard_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "spanning-tree guard root" in self._safe_content(line)
        ]

        if root_guard_lines:
            line_nums = [ln for ln, _ in root_guard_lines]
            contents = [content for _, content in root_guard_lines]
            return self._create_finding(
                True,
                f"Root Guard enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Root Guard not configured - Best practice: Configure appropriate setting"
            )

    # New IOS Check Functions - Advanced AAA

    def check_aaa_authorization_exec(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA authorization for exec."""
        
        aaa_authz_exec_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa authorization exec" in self._safe_content(line)
        ]

        if aaa_authz_exec_lines:
            line_nums = [ln for ln, _ in aaa_authz_exec_lines]
            contents = [content for _, content in aaa_authz_exec_lines]
            return self._create_finding(
                True,
                f"AAA authorization exec configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA authorization exec not configured - Best practice: Configure appropriate setting"
            )

    def check_aaa_authorization_commands(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA authorization for commands."""
        
        aaa_authz_commands_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa authorization commands" in self._safe_content(line)
        ]

        if aaa_authz_commands_lines:
            line_nums = [ln for ln, _ in aaa_authz_commands_lines]
            contents = [content for _, content in aaa_authz_commands_lines]
            return self._create_finding(
                True,
                f"AAA authorization commands configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA authorization commands not configured - Best practice: Configure appropriate setting"
            )

    def check_aaa_accounting_exec(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA accounting for exec sessions."""
        
        aaa_acct_exec_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa accounting exec" in self._safe_content(line)
        ]

        if aaa_acct_exec_lines:
            line_nums = [ln for ln, _ in aaa_acct_exec_lines]
            contents = [content for _, content in aaa_acct_exec_lines]
            return self._create_finding(
                True,
                f"AAA accounting exec configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA accounting exec not configured - Best practice: Configure appropriate setting"
            )

    def check_aaa_accounting_commands(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check AAA accounting for commands."""
        
        aaa_acct_commands_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "aaa accounting commands" in self._safe_content(line)
        ]

        if aaa_acct_commands_lines:
            line_nums = [ln for ln, _ in aaa_acct_commands_lines]
            contents = [content for _, content in aaa_acct_commands_lines]
            return self._create_finding(
                True,
                f"AAA accounting commands configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "AAA accounting commands not configured - Best practice: Configure appropriate setting"
            )

    def check_login_block_for(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check login failure rate limiting."""
        
        login_block_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "login block-for" in self._safe_content(line)
        ]

        if login_block_lines:
            line_nums = [ln for ln, _ in login_block_lines]
            contents = [content for _, content in login_block_lines]
            return self._create_finding(
                True,
                f"Login failure rate limiting configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Login block-for not configured - Best practice: Configure appropriate setting"
            )

    def check_password_complexity(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check password complexity requirements."""
        
        complexity_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "password strength-check" in self._safe_content(line)
        ]

        if complexity_lines:
            line_nums = [ln for ln, _ in complexity_lines]
            contents = [content for _, content in complexity_lines]
            return self._create_finding(
                True,
                f"Password complexity enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Password strength-check not configured - Best practice: Configure appropriate setting"
            )

    def check_no_type7_passwords(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for weak Type 7 passwords in configuration."""
        type7_found = []

        for line in config_lines:
            content = self._safe_content(line)
            # Type 7 passwords start with "password 7" or "username X password 7"
            if re.search(r'password\s+7\s+\w+', content, re.I):
                type7_found.append(content)

        return {
            "compliant": len(type7_found) == 0,
            "details": f"Type 7 passwords found: {len(type7_found)}" if type7_found else "No Type 7 passwords detected"
        }

    # New IOS Check Functions - Routing Security

    def check_bgp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check BGP neighbor authentication."""
        has_bgp = any(
            "router bgp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_bgp:
            return {"compliant": True, "details": "BGP not configured"}

        has_bgp_password = any(
            re.search(r'neighbor\s+\S+\s+password', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_bgp_password,
            "details": "BGP authentication configured" if has_bgp_password else "BGP neighbors lack authentication"
        }

    def check_bgp_prefix_filtering(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check BGP prefix filtering."""
        has_bgp = any(
            "router bgp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_bgp:
            return {"compliant": True, "details": "BGP not configured"}

        has_prefix_filtering = any(
            re.search(r'neighbor\s+\S+\s+(prefix-list|route-map|filter-list)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_prefix_filtering,
            "details": "BGP prefix filtering configured" if has_prefix_filtering else "BGP lacks prefix filtering"
        }

    def check_bgp_max_prefix(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check BGP maximum-prefix limits."""
        has_bgp = any(
            "router bgp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_bgp:
            return {"compliant": True, "details": "BGP not configured"}

        has_max_prefix = any(
            "neighbor" in self._safe_content(line) and "maximum-prefix" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_max_prefix,
            "details": "BGP maximum-prefix configured" if has_max_prefix else "BGP lacks maximum-prefix limits"
        }

    def check_ospf_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check OSPF authentication."""
        has_ospf = any(
            "router ospf" in self._safe_content(line)
            for line in config_lines
        )

        if not has_ospf:
            return {"compliant": True, "details": "OSPF not configured"}

        has_ospf_auth = any(
            re.search(r'ip ospf (authentication|message-digest)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_ospf_auth,
            "details": "OSPF authentication configured" if has_ospf_auth else "OSPF lacks authentication"
        }

    def check_ospf_passive_interface(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check OSPF passive interface configuration."""
        has_ospf = any(
            "router ospf" in self._safe_content(line)
            for line in config_lines
        )

        if not has_ospf:
            return {"compliant": True, "details": "OSPF not configured"}

        has_passive = any(
            "passive-interface" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": has_passive,
            "details": "OSPF passive-interface configured" if has_passive else "OSPF lacks passive-interface configuration"
        }

    def check_eigrp_authentication(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check EIGRP authentication."""
        has_eigrp = any(
            "router eigrp" in self._safe_content(line)
            for line in config_lines
        )

        if not has_eigrp:
            return {"compliant": True, "details": "EIGRP not configured"}

        has_eigrp_auth = any(
            re.search(r'ip authentication (mode eigrp|key-chain eigrp)', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_eigrp_auth,
            "details": "EIGRP authentication configured" if has_eigrp_auth else "EIGRP lacks authentication"
        }

    # New IOS Check Functions - Advanced Cryptography

    def check_strong_rsa_keys(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for strong RSA keys (2048-bit minimum)."""
        rsa_key_lines = [line for line in config_lines if "crypto key generate rsa" in self._safe_content(line)]

        if not rsa_key_lines:
            return {"compliant": False, "details": "No RSA key generation found"}

        has_strong_keys = any(
            re.search(r'modulus (2048|4096)', self._safe_content(line))
            for line in rsa_key_lines
        )

        return {
            "compliant": has_strong_keys,
            "details": "Strong RSA keys (2048-bit+) configured" if has_strong_keys else "Weak RSA keys detected"
        }

    def check_ssh_strong_algorithms(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for strong SSH algorithms."""
        
        ssh_algo_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip ssh server algorithm" in self._safe_content(line)
        ]

        if ssh_algo_lines:
            line_nums = [ln for ln, _ in ssh_algo_lines]
            contents = [content for _, content in ssh_algo_lines]
            return self._create_finding(
                True,
                f"SSH algorithm restrictions configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "SSH algorithms not restricted - Best practice: Configure appropriate setting"
            )

    def check_no_weak_ipsec_encryption(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for weak IPsec encryption (DES, 3DES)."""
        weak_ipsec = []

        for line in config_lines:
            content = self._safe_content(line)
            if re.search(r'(esp-des|esp-3des)', content, re.I):
                weak_ipsec.append(content)

        return {
            "compliant": len(weak_ipsec) == 0,
            "details": f"Weak IPsec encryption found: {len(weak_ipsec)}" if weak_ipsec else "No weak IPsec encryption detected"
        }

    def check_ikev2_preferred(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that IKEv2 is preferred over IKEv1."""
        has_ikev2 = any(
            "crypto ikev2" in self._safe_content(line)
            for line in config_lines
        )

        has_isakmp = any(
            "crypto isakmp" in self._safe_content(line)
            for line in config_lines
        )

        # If IPsec is configured, prefer IKEv2
        if has_isakmp and not has_ikev2:
            return {"compliant": False, "details": "IKEv1 configured without IKEv2"}

        return {
            "compliant": True,
            "details": "IKEv2 configured" if has_ikev2 else "No IKE configuration found"
        }

    def check_strong_dh_groups(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check for strong Diffie-Hellman groups (14+)."""
        dh_groups = []

        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'group\s+(\d+)', content)
            if match:
                group_num = int(match.group(1))
                if group_num < 14:
                    dh_groups.append(group_num)

        return {
            "compliant": len(dh_groups) == 0,
            "details": f"Weak DH groups found: {dh_groups}" if dh_groups else "Strong DH groups (14+) configured"
        }

    def check_ipsec_pfs(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Perfect Forward Secrecy is enabled for IPsec."""
        has_crypto_map = any(
            "crypto map" in self._safe_content(line)
            for line in config_lines
        )

        if not has_crypto_map:
            return {"compliant": True, "details": "No crypto map configured"}

        has_pfs = any(
            re.search(r'set pfs\s+group', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": has_pfs,
            "details": "IPsec PFS enabled" if has_pfs else "IPsec lacks PFS configuration"
        }

    # New IOS Check Functions - Management Plane Security

    def check_ssh_ciphersuite_restrictions(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check SSH ciphersuite restrictions."""
        
        ssh_cipher_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip ssh server algorithm encryption" in self._safe_content(line)
        ]

        if ssh_cipher_lines:
            line_nums = [ln for ln, _ in ssh_cipher_lines]
            contents = [content for _, content in ssh_cipher_lines]
            return self._create_finding(
                True,
                f"SSH cipher restrictions configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "SSH ciphers not restricted - Best practice: Configure appropriate setting"
            )

    def check_ssh_timeout(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check SSH authentication timeout."""
        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'ip ssh time-out (\d+)', content)
            if match:
                timeout = int(match.group(1))
                return {
                    "compliant": timeout <= 60,
                    "details": f"SSH timeout: {timeout} seconds"
                }

        return {
            "compliant": False,
            "details": "SSH timeout not configured"
        }

    def check_ssh_auth_retries(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check SSH authentication retries."""
        for line in config_lines:
            content = self._safe_content(line)
            match = re.search(r'ip ssh authentication-retries (\d+)', content)
            if match:
                retries = int(match.group(1))
                return {
                    "compliant": retries <= 3,
                    "details": f"SSH auth retries: {retries}"
                }

        return {
            "compliant": False,
            "details": "SSH authentication-retries not configured"
        }

    def check_no_telnet(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that Telnet is disabled."""
        has_telnet = any(
            "transport input telnet" in self._safe_content(line) or
            "transport input all" in self._safe_content(line)
            for line in config_lines
        )

        return {
            "compliant": not has_telnet,
            "details": "Telnet disabled" if not has_telnet else "Telnet is enabled on VTY lines"
        }

    def check_no_tftp_server(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that TFTP server is disabled."""
        has_tftp = any(
            re.match(r'tftp-server\s+', self._safe_content(line))
            for line in config_lines
        )

        return {
            "compliant": not has_tftp,
            "details": "TFTP server disabled" if not has_tftp else "TFTP server is enabled"
        }

    def check_scp_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that SCP server is enabled."""
        
        scp_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "ip scp server enable" in self._safe_content(line)
        ]

        if scp_lines:
            line_nums = [ln for ln, _ in scp_lines]
            contents = [content for _, content in scp_lines]
            return self._create_finding(
                True,
                f"SCP server enabled (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "SCP server not enabled - Best practice: Configure appropriate setting"
            )

    # New IOS Check Functions - Logging & Monitoring

    def check_logging_source_interface(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging source-interface configuration."""
        
        logging_source_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "logging source-interface" in self._safe_content(line)
        ]

        if logging_source_lines:
            line_nums = [ln for ln, _ in logging_source_lines]
            contents = [content for _, content in logging_source_lines]
            return self._create_finding(
                True,
                f"Logging source-interface configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging source-interface not configured - Best practice: Configure appropriate setting"
            )

    def check_logging_timestamps(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging timestamps with datetime."""
        
        timestamps_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if re.search(r'service timestamps log datetime', self._safe_content(line))
        ]

        if timestamps_lines:
            line_nums = [ln for ln, _ in timestamps_lines]
            contents = [content for _, content in timestamps_lines]
            return self._create_finding(
                True,
                f"Logging timestamps with datetime configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging timestamps not properly configured - Best practice: Configure appropriate setting"
            )

    def check_logging_facility(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging facility configuration."""
        
        facility_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "logging facility" in self._safe_content(line)
        ]

        if facility_lines:
            line_nums = [ln for ln, _ in facility_lines]
            contents = [content for _, content in facility_lines]
            return self._create_finding(
                True,
                f"Logging facility configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging facility not configured - Best practice: Configure appropriate setting"
            )

    def check_logging_synchronous(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check logging synchronous on lines."""
        
        logging_sync_lines = [
            (self._get_line_number(line), self._safe_content(line))
            for line in config_lines
            if "logging synchronous" in self._safe_content(line)
        ]

        if logging_sync_lines:
            line_nums = [ln for ln, _ in logging_sync_lines]
            contents = [content for _, content in logging_sync_lines]
            return self._create_finding(
                True,
                f"Logging synchronous configured (line {line_nums[0]})",
                line_nums,
                contents
            )
        else:
            return self._create_finding(
                False,
                "Logging synchronous not configured - Best practice: Configure appropriate setting"
            )

    # Additional CIS Controls (56-61) - Final 6 check functions for 100% coverage

    def check_tcp_sequence_randomization(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check TCP sequence number randomization (TCP keepalives)."""
        has_tcp_keepalive_in = any(
            "service tcp-keepalives-in" in self._safe_content(line)
            for line in config_lines
        )
        has_tcp_keepalive_out = any(
            "service tcp-keepalives-out" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_tcp_keepalive_in and has_tcp_keepalive_out
        return {
            "compliant": compliant,
            "details": "TCP keepalives enabled for both directions" if compliant else "TCP keepalives not fully configured"
        }

    def check_interface_descriptions(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check that all active interfaces have descriptions."""
        interfaces_without_desc = []
        current_interface = None
        interface_has_description = False
        interface_is_shutdown = False

        for line in config_lines:
            content = self._safe_content(line)

            # New interface found
            if content.startswith("interface "):
                # Save previous interface if it was missing description
                if current_interface and not interface_has_description and not interface_is_shutdown:
                    interfaces_without_desc.append(current_interface)

                current_interface = content.replace("interface ", "").strip()
                interface_has_description = False
                interface_is_shutdown = False

            # Check for description
            elif current_interface and content.startswith("description "):
                interface_has_description = True

            # Check if interface is shutdown
            elif current_interface and content.strip() == "shutdown":
                interface_is_shutdown = True

        # Check last interface
        if current_interface and not interface_has_description and not interface_is_shutdown:
            interfaces_without_desc.append(current_interface)

        compliant = len(interfaces_without_desc) == 0
        return {
            "compliant": compliant,
            "details": "All active interfaces have descriptions" if compliant else f"{len(interfaces_without_desc)} active interface(s) lack descriptions: {', '.join(interfaces_without_desc[:5])}"
        }

    def check_switchport_mode_explicit(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check switchport mode explicitly set without negotiation."""
        interfaces_with_auto_negotiation = []
        current_interface = None
        has_switchport_mode = False
        has_nonegotiate = False

        for line in config_lines:
            content = self._safe_content(line)

            # New interface found
            if content.startswith("interface "):
                # Check previous interface
                if current_interface and has_switchport_mode and not has_nonegotiate:
                    if "GigabitEthernet" in current_interface or "FastEthernet" in current_interface or "Ethernet" in current_interface:
                        interfaces_with_auto_negotiation.append(current_interface)

                current_interface = content.replace("interface ", "").strip()
                has_switchport_mode = False
                has_nonegotiate = False

            # Check for switchport mode
            elif current_interface and "switchport mode" in content:
                has_switchport_mode = True

            # Check for nonegotiate
            elif current_interface and "switchport nonegotiate" in content:
                has_nonegotiate = True

        # Check last interface
        if current_interface and has_switchport_mode and not has_nonegotiate:
            if "GigabitEthernet" in current_interface or "FastEthernet" in current_interface or "Ethernet" in current_interface:
                interfaces_with_auto_negotiation.append(current_interface)

        compliant = len(interfaces_with_auto_negotiation) == 0
        return {
            "compliant": compliant,
            "details": "All switchports have nonegotiate configured" if compliant else f"{len(interfaces_with_auto_negotiation)} switchport(s) allow DTP negotiation: {', '.join(interfaces_with_auto_negotiation[:5])}"
        }

    def check_loop_guard(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check Loop Guard enabled globally or on trunk ports."""
        has_global_loopguard = any(
            "spanning-tree loopguard default" in self._safe_content(line)
            for line in config_lines
        )

        # Check for per-interface loop guard on trunks
        trunk_interfaces = []
        trunk_with_loopguard = []
        current_interface = None
        is_trunk = False
        has_loopguard = False

        for line in config_lines:
            content = self._safe_content(line)

            if content.startswith("interface "):
                # Process previous interface
                if current_interface and is_trunk:
                    trunk_interfaces.append(current_interface)
                    if has_loopguard:
                        trunk_with_loopguard.append(current_interface)

                current_interface = content.replace("interface ", "").strip()
                is_trunk = False
                has_loopguard = False

            elif current_interface and "switchport mode trunk" in content:
                is_trunk = True

            elif current_interface and "spanning-tree guard loop" in content:
                has_loopguard = True

        # Check last interface
        if current_interface and is_trunk:
            trunk_interfaces.append(current_interface)
            if has_loopguard:
                trunk_with_loopguard.append(current_interface)

        # Compliant if global loopguard OR all trunks have it configured
        compliant = has_global_loopguard or (len(trunk_interfaces) > 0 and len(trunk_interfaces) == len(trunk_with_loopguard))

        if has_global_loopguard:
            detail = "Loop Guard enabled globally"
        elif len(trunk_interfaces) == 0:
            detail = "No trunk interfaces configured"
            compliant = True
        elif compliant:
            detail = f"All {len(trunk_interfaces)} trunk interface(s) have Loop Guard"
        else:
            detail = f"Loop Guard missing on {len(trunk_interfaces) - len(trunk_with_loopguard)} trunk interface(s)"

        return {
            "compliant": compliant,
            "details": detail
        }

    def check_netflow_enabled(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check NetFlow or sFlow enabled for traffic monitoring."""
        has_netflow_export = any(
            "ip flow-export" in self._safe_content(line) or "flow exporter" in self._safe_content(line)
            for line in config_lines
        )

        has_sflow = any(
            "sflow" in self._safe_content(line)
            for line in config_lines
        )

        has_flexible_netflow = any(
            "flow monitor" in self._safe_content(line) or "flow record" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_netflow_export or has_sflow or has_flexible_netflow

        if has_flexible_netflow:
            detail = "Flexible NetFlow configured"
        elif has_netflow_export:
            detail = "NetFlow export configured"
        elif has_sflow:
            detail = "sFlow configured"
        else:
            detail = "No flow monitoring configured"

        return {
            "compliant": compliant,
            "details": detail
        }

    def check_config_change_notifications(self, config_lines: List, parsed_config: Dict) -> Dict:
        """Check configuration change notifications enabled."""
        has_archive = any("archive" in self._safe_content(line) for line in config_lines)
        has_log_config = any("log config" in self._safe_content(line) for line in config_lines)
        has_logging_enable = any(
            "logging enable" in self._safe_content(line)
            for line in config_lines
        )
        has_notify = any(
            "notify syslog" in self._safe_content(line)
            for line in config_lines
        )

        compliant = has_archive and has_log_config and (has_logging_enable or has_notify)

        if compliant:
            detail = "Configuration change notifications enabled"
        elif not has_archive:
            detail = "Archive not configured"
        elif not has_log_config:
            detail = "Log config not enabled in archive"
        else:
            detail = "Configuration change logging/notification not fully enabled"

        return {
            "compliant": compliant,
            "details": detail
        }

    # Helper methods

    def _safe_content(self, line) -> str:
        """Safely extract content from line object or string."""
        if hasattr(line, 'content'):
            return line.content.strip()
        return str(line).strip()

    def _get_line_number(self, line) -> Optional[int]:
        """Safely extract line number from line object."""
        if hasattr(line, 'line_number'):
            return line.line_number
        return None

    def _create_finding(self, compliant: bool, message: str,
                       affected_lines: Optional[List[int]] = None,
                       line_content: Optional[List[str]] = None) -> Dict:
        """
        Create standardized finding with line number tracking.

        Args:
            compliant: Whether the check passed
            message: Human-readable message
            affected_lines: List of line numbers where issues found
            line_content: Content of affected lines

        Returns:
            Dictionary with compliant status, details, and line tracking
        """
        result = {
            "compliant": compliant,
            "details": message
        }

        if not compliant and affected_lines:
            result["affected_lines"] = affected_lines
            result["line_content"] = line_content or []
            result["evidence_type"] = "misconfiguration"
        elif not compliant:
            result["evidence_type"] = "missing_configuration"

        return result

    def _find_lines(self, config_lines: List, pattern=None, condition=None) -> List[tuple]:
        """
        Find lines matching pattern or condition and return with line numbers.

        This is a simplified helper that automatically tracks line numbers.

        Args:
            config_lines: List of config lines to search
            pattern: String to search for in line content (simple string match)
            condition: Callable that takes line content and returns bool

        Returns:
            List of (line_number, content) tuples
        """
        results = []
        for line in config_lines:
            content = self._safe_content(line)
            line_num = self._get_line_number(line)

            match = False
            if pattern and pattern in content:
                match = True
            elif condition and condition(content):
                match = True

            if match:
                results.append((line_num, content))

        return results

    def _wrap_finding(self, compliant: bool, base_message: str,
                     found_lines: List[tuple] = None) -> Dict:
        """
        Automatically wrap finding with line numbers - SIMPLIFIED APPROACH.

        This method makes it easy to add line tracking without modifying each function.

        Args:
            compliant: Whether check passed
            base_message: Base message (will be enhanced with line info)
            found_lines: List of (line_number, content) tuples from _find_lines

        Returns:
            Finding dict with automatic line tracking
        """
        if found_lines:
            line_nums = [ln for ln, _ in found_lines if ln is not None]
            contents = [content for _, content in found_lines]

            if compliant:
                # Config found as expected - show where it was found
                if line_nums:
                    message = f"{base_message} (line {line_nums[0]})"
                else:
                    message = base_message
            else:
                # Misconfiguration found - show all problem lines
                if len(line_nums) == 1:
                    message = f"{base_message} - Misconfiguration found on line {line_nums[0]}"
                elif len(line_nums) > 1:
                    line_list = ", ".join(str(ln) for ln in line_nums[:5])
                    if len(line_nums) > 5:
                        line_list += f" (and {len(line_nums) - 5} more)"
                    message = f"{base_message} - Misconfiguration found on lines: {line_list}"
                else:
                    message = base_message

            return self._create_finding(compliant, message, line_nums, contents)
        else:
            # Nothing found
            if not compliant:
                # This is a missing configuration - recommend best practice
                message = f"{base_message} - Best practice: Configuration not found"
            else:
                # Compliant because nothing bad was found
                message = base_message
            return self._create_finding(compliant, message)
