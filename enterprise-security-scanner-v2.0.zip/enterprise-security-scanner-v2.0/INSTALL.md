# Installation Guide - Enterprise Network Security Scanner

## Prerequisites

### System Requirements

- **Operating System:** Linux, macOS, or Windows
- **Python Version:** 3.7 or higher
- **Disk Space:** ~50 MB
- **Memory:** 512 MB minimum (recommended: 1 GB for large configs)

### Checking Python Version

```bash
python3 --version
# Should output: Python 3.7.0 or higher
```

If Python 3 is not installed:

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3 python3-pip
```

**RHEL/CentOS:**
```bash
sudo yum install python3
```

**macOS:**
```bash
brew install python3
```

**Windows:**
Download from https://www.python.org/downloads/

## Installation Methods

### Method 1: Simple Extraction (Recommended)

The scanner requires no external dependencies and can run immediately after extraction.

```bash
# Extract the package
unzip enterprise-security-scanner-v2.0.zip
cd enterprise-security-scanner

# Verify installation
python3 config-parser/enterprise_security_parser.py --help

# Test with a sample config (if provided)
python3 config-parser/enterprise_security_parser.py examples/sample-cisco-ios.txt --output test-report.html
```

### Method 2: System-Wide Installation

For easier access from any directory:

```bash
# Extract to /opt (recommended for Linux/macOS)
sudo unzip enterprise-security-scanner-v2.0.zip -d /opt/
cd /opt/enterprise-security-scanner

# Create a symbolic link
sudo ln -s /opt/enterprise-security-scanner/config-parser/enterprise_security_parser.py /usr/local/bin/network-security-scan

# Now you can run from anywhere
network-security-scan /path/to/config.txt --output report.html
```

### Method 3: User Installation (No Admin Rights)

```bash
# Extract to your home directory
cd ~
unzip enterprise-security-scanner-v2.0.zip
cd enterprise-security-scanner

# Add to PATH (add to ~/.bashrc or ~/.zshrc)
export PATH="$HOME/enterprise-security-scanner/config-parser:$PATH"

# Create an alias (add to ~/.bashrc or ~/.zshrc)
alias network-scan='python3 $HOME/enterprise-security-scanner/config-parser/enterprise_security_parser.py'

# Reload shell
source ~/.bashrc  # or source ~/.zshrc

# Use the alias
network-scan config.txt --output report.html
```

## Optional Dependencies

The scanner works without any external dependencies. However, for enhanced parsing capabilities:

### Genie Parser (Optional)

Cisco's Genie parser provides more accurate parsing for complex configurations.

```bash
pip3 install 'pyats[library]'
```

**Note:** Genie is **not required**. The scanner will automatically fall back to regex-based parsing if Genie is not available.

## Directory Structure

After installation, your directory should look like this:

```
enterprise-security-scanner/
├── PACKAGE_README.md              # Main documentation
├── INSTALL.md                     # This file
├── USAGE_GUIDE.md                 # Usage examples
├── config-parser/                 # Main CLI tool
│   ├── enterprise_security_parser.py  ← Main script
│   ├── benchmark_validator.py
│   ├── benchmark_rules.py
│   ├── genie_integration.py
│   ├── cva_mapping.json
│   └── docs/
├── rule-engines/                  # Analysis engines
│   └── scanner/
│       ├── core.py
│       ├── engines/
│       ├── rules/
│       └── vendors/
└── examples/                      # Sample files (if included)
    ├── sample-cisco-ios.txt
    ├── sample-cisco-asa.txt
    └── sample-report.html
```

## Verification

### 1. Test Basic Functionality

```bash
cd enterprise-security-scanner

# Check help
python3 config-parser/enterprise_security_parser.py --help
```

Expected output:
```
usage: enterprise_security_parser.py [-h] --output OUTPUT
                                     [--format {html,json}]
                                     [--vendor {cisco_ios,cisco_asa,...}]
                                     [--pretty] [--no-security]
                                     config_file
```

### 2. Test with Sample Config

Create a simple test config:

```bash
cat > test-config.txt << 'EOF'
hostname test-router
!
interface GigabitEthernet0/0
 ip address 192.168.1.1 255.255.255.0
!
line vty 0 4
 transport input ssh
!
end
EOF
```

Run the scanner:

```bash
python3 config-parser/enterprise_security_parser.py test-config.txt --output test-report.html
```

Expected output:
```
Parsing configuration...
✓ Parsed X lines
✓ Detected vendor: cisco_ios
Running security analysis...
✓ Found X security issues
✓ HTML report written to: test-report.html
```

### 3. Verify Report Generation

Open the HTML report:

```bash
# Linux
xdg-open test-report.html

# macOS
open test-report.html

# Windows
start test-report.html
```

## Troubleshooting

### Issue: "python3: command not found"

**Solution:** Install Python 3 or use `python` instead of `python3`:
```bash
python config-parser/enterprise_security_parser.py --help
```

### Issue: "No module named 'scanner'"

**Cause:** Running from wrong directory

**Solution:** Make sure `rule-engines/` directory is in the same parent as `config-parser/`:
```bash
# Check structure
ls -la
# Should show both config-parser/ and rule-engines/

# If not, navigate to the correct directory
cd /path/to/enterprise-security-scanner
```

### Issue: "Permission denied"

**Solution:** Make the script executable:
```bash
chmod +x config-parser/enterprise_security_parser.py
```

### Issue: "Warning: Genie parser not installed"

This is **normal** and not an error. The scanner will work fine without Genie.

To remove the warning (optional):
```bash
pip3 install 'pyats[library]'
```

### Issue: Large configs are slow

**Solution:** This is normal for configs with 5000+ lines. The scanner analyzes every line.

For very large configs (10,000+ lines):
```bash
# Increase timeout if needed (the scanner doesn't have a timeout, but if you're piping output)
python3 config-parser/enterprise_security_parser.py large-config.txt --output report.html 2>&1 | tee scan.log
```

### Issue: Unicode errors on Windows

**Solution:** Use UTF-8 encoding:
```bash
python3 config-parser/enterprise_security_parser.py config.txt --output report.html
# Or explicitly set encoding in Windows PowerShell
$env:PYTHONIOENCODING="utf-8"
python3 config-parser/enterprise_security_parser.py config.txt --output report.html
```

## Updating

### From v1.0 to v2.0

If you have v1.0 installed:

1. Backup any custom modifications
2. Remove old installation
3. Extract new version
4. Restore custom modifications (if any)

```bash
# Backup (if you made changes)
cp config-parser/cva_mapping.json ~/cva_mapping.json.backup

# Remove old version
rm -rf enterprise-security-scanner

# Install new version
unzip enterprise-security-scanner-v2.0.zip

# Restore custom mappings (if needed)
cp ~/cva_mapping.json.backup enterprise-security-scanner/config-parser/cva_mapping.json
```

## Uninstallation

```bash
# If installed in /opt
sudo rm -rf /opt/enterprise-security-scanner
sudo rm /usr/local/bin/network-security-scan  # if you created the symlink

# If installed in home directory
rm -rf ~/enterprise-security-scanner

# Remove from PATH (edit ~/.bashrc or ~/.zshrc)
# Delete the lines you added during installation
```

## Advanced Configuration

### Custom CVA Mappings

Edit `config-parser/cva_mapping.json` to add custom CVA IDs:

```json
{
  "mappings": {
    "cdp": "CVA 2203",
    "http": "CVA 0001",
    "custom_rule_id": "CVA XXXX"
  }
}
```

### Running in Automation

For CI/CD pipelines or scheduled scans:

```bash
#!/bin/bash
# scan-configs.sh

SCANNER="/opt/enterprise-security-scanner/config-parser/enterprise_security_parser.py"
CONFIG_DIR="/network/configs"
OUTPUT_DIR="/reports"

for config in "$CONFIG_DIR"/*.txt; do
    filename=$(basename "$config" .txt)
    python3 "$SCANNER" "$config" \
        --output "$OUTPUT_DIR/${filename}-$(date +%Y%m%d).html" \
        --format html
done
```

### Docker Container (Advanced)

Create a Dockerfile:

```dockerfile
FROM python:3.9-slim

WORKDIR /scanner
COPY enterprise-security-scanner/ /scanner/

ENTRYPOINT ["python3", "/scanner/config-parser/enterprise_security_parser.py"]
```

Build and run:

```bash
docker build -t network-scanner .
docker run -v $(pwd):/configs network-scanner /configs/router.txt --output /configs/report.html
```

## Getting Help

1. Check `USAGE_GUIDE.md` for usage examples
2. Check `PACKAGE_README.md` for feature documentation
3. Review `config-parser/LINE_TRACKING_GUIDE.md` for understanding findings
4. Contact your system administrator for technical support

## Next Steps

After installation:
1. Read `USAGE_GUIDE.md` for usage examples
2. Try scanning a sample configuration
3. Review the HTML report to understand the output
4. Integrate into your security workflow

---

**Installation complete! Ready to scan network configurations.**
