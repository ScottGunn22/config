"""Plain text report generator."""

from typing import List
from ..core import ScanResults, Finding, Severity


class TextReporter:
    """Generate plain text format reports."""
    
    def generate_report(self, results: ScanResults) -> str:
        """Generate plain text report."""
        lines = []
        
        # Header
        lines.append("=" * 80)
        lines.append("NETWORK SECURITY SCANNER REPORT")
        lines.append("=" * 80)
        lines.append("")
        
        # Summary
        lines.append("SCAN SUMMARY")
        lines.append("-" * 40)
        lines.append(f"Target Device: {results.device_hostname}")
        lines.append(f"Vendor: {results.vendor.value}")
        lines.append(f"Scan Time: {results.scan_timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Config Lines: {results.config_lines_total}")
        lines.append(f"Scan Duration: {results.scan_duration_ms}ms")
        lines.append("")
        
        # Severity breakdown
        summary = results.get_summary()
        lines.append("FINDINGS SUMMARY")
        lines.append("-" * 40)
        lines.append(f"Total Findings: {summary['total_findings']}")
        
        for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            count = summary['severity_breakdown'].get(severity, 0)
            if count > 0:
                lines.append(f"  {severity}: {count}")
        
        lines.append(f"Highest CVSS Score: {summary['highest_cvss']}")
        lines.append("")
        
        # Detailed findings
        if results.findings:
            lines.append("DETAILED FINDINGS")
            lines.append("=" * 80)
            lines.append("")
            
            # Group findings by severity
            findings_by_severity = self._group_findings_by_severity(results.findings)
            
            for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
                findings = findings_by_severity.get(severity, [])
                if not findings:
                    continue
                
                lines.append(f"{severity.value} SEVERITY FINDINGS")
                lines.append("-" * 40)
                lines.append("")
                
                for i, finding in enumerate(findings, 1):
                    lines.extend(self._format_finding(finding, i))
                    lines.append("")
        
        # Footer
        lines.append("=" * 80)
        lines.append("End of Report")
        lines.append("=" * 80)
        
        return "\\n".join(lines)
    
    def _group_findings_by_severity(self, findings: List[Finding]) -> dict:
        """Group findings by severity level."""
        grouped = {}
        for finding in findings:
            if finding.severity not in grouped:
                grouped[finding.severity] = []
            grouped[finding.severity].append(finding)
        return grouped
    
    def _format_finding(self, finding: Finding, index: int) -> List[str]:
        """Format a single finding for text output."""
        lines = []
        
        # Header
        lines.append(f"[{index}] {finding.title}")
        lines.append(f"Rule ID: {finding.rule_id}")
        lines.append(f"Category: {finding.category}")
        lines.append(f"CVSS Score: {finding.cvss_score} ({finding.cvss_vector.to_vector_string()})")
        lines.append("")
        
        # Description
        lines.append("Description:")
        lines.append(f"  {finding.description}")
        lines.append("")
        
        # Configuration context
        if finding.config_line:
            lines.append("Current Configuration:")
            lines.append(f"  Line {finding.config_line.line_number}: {finding.config_line.content}")
            if finding.config_line.section:
                lines.append(f"  Section: {finding.config_line.section}")
            lines.append("")
        
        # Recommendation
        if finding.recommendation:
            lines.append("Recommendation:")
            lines.append(f"  {finding.recommendation}")
            lines.append("")
        
        # Fix commands
        if finding.fix_commands:
            lines.append("Fix Commands:")
            for cmd in finding.fix_commands:
                lines.append(f"  {cmd}")
            lines.append("")
        
        # Compliance
        if finding.nist_controls:
            lines.append(f"NIST Controls: {', '.join(finding.nist_controls)}")
        if finding.cis_controls:
            lines.append(f"CIS Controls: {', '.join(finding.cis_controls)}")
        
        return lines