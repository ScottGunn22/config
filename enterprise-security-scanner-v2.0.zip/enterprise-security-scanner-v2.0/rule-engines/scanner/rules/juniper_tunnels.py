"""Tunnel security rules for Juniper JunOS.

Detects insecure VPN and tunnel configurations including:
- IPsec tunnels without proper encryption
- IKE with weak cryptographic algorithms
- Missing or weak authentication
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class JuniperTunnelRules(BaseRuleEngine):
    """Tunnel and VPN security rules for Juniper JunOS."""

    def __init__(self):
        super().__init__()
        self.category = "Tunnel & VPN Security"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check tunnel security rules."""
        findings = []

        if vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._check_juniper_tunnels(parsed_config))

        return findings

    def _check_juniper_tunnels(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Juniper VPN and tunnel security configuration."""
        findings = []

        # Check IPsec/IKE configuration
        security_config = config.get('security', {})

        # Check IKE policies
        ike_config = security_config.get('ike', {})
        ike_policies = ike_config.get('policies', {})

        for policy_name, policy_config in ike_policies.items():
            # Check IKE mode
            mode = policy_config.get('mode')
            if mode == 'aggressive':
                findings.append(self.create_finding(
                    rule_id="JUNOS-IKE-001",
                    title=f"IKE Policy '{policy_name}' Using Aggressive Mode",
                    description=f"IKE policy '{policy_name}' is configured to use aggressive mode. Aggressive mode "
                              f"transmits identity information in cleartext and is vulnerable to offline dictionary "
                              f"attacks against the pre-shared key. Main mode provides better security by protecting "
                              f"identity information.",
                    severity="HIGH",
                    recommendation=f"Change IKE policy '{policy_name}' to use main mode",
                    fix_commands=[
                        f"set security ike policy {policy_name} mode main"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="L",
                        availability="N"
                    ),
                    nist_controls=["SC-8", "SC-13", "IA-5"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

        # Check IKE gateways
        ike_gateways = ike_config.get('gateways', {})
        for gateway_name, gateway_config in ike_gateways.items():
            # This would be expanded with actual gateway checks
            # For now, basic structure is in place
            pass

        # Check IPsec policies
        ipsec_config = security_config.get('ipsec', {})
        ipsec_policies = ipsec_config.get('policies', {})

        if not ipsec_policies and not ike_policies:
            # No VPN configuration - not necessarily an issue
            return findings

        # Check IPsec VPNs
        ipsec_vpns = ipsec_config.get('vpns', {})
        for vpn_name, vpn_config in ipsec_vpns.items():
            # Check if VPN has proper IKE gateway and IPsec policy
            if not vpn_config.get('ike_gateway'):
                findings.append(self.create_finding(
                    rule_id="JUNOS-IPSEC-001",
                    title=f"IPsec VPN '{vpn_name}' Missing IKE Gateway",
                    description=f"IPsec VPN '{vpn_name}' does not have an IKE gateway configured. Without an IKE "
                              f"gateway, the VPN tunnel cannot establish key exchange and will not function. This "
                              f"may indicate an incomplete or misconfigured VPN setup.",
                    severity="HIGH",
                    recommendation=f"Configure IKE gateway for IPsec VPN '{vpn_name}'",
                    fix_commands=[
                        f"set security ipsec vpn {vpn_name} ike gateway <gateway_name>"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="N",
                        integrity="N",
                        availability="H"
                    ),
                    nist_controls=["SC-7", "SC-8"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

            if not vpn_config.get('ipsec_policy'):
                findings.append(self.create_finding(
                    rule_id="JUNOS-IPSEC-002",
                    title=f"IPsec VPN '{vpn_name}' Missing IPsec Policy",
                    description=f"IPsec VPN '{vpn_name}' does not have an IPsec policy configured. Without an IPsec "
                              f"policy, the VPN tunnel has no encryption or authentication parameters defined. This "
                              f"may result in weak encryption or non-functional VPN.",
                    severity="HIGH",
                    recommendation=f"Configure IPsec policy for VPN '{vpn_name}'",
                    fix_commands=[
                        f"set security ipsec vpn {vpn_name} ipsec-policy <policy_name>"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="L"
                    ),
                    nist_controls=["SC-8", "SC-13"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

        # Check for interfaces in security zones (SRX specific)
        zones = security_config.get('zones', {})
        if zones:
            # Check if VPN zones are properly configured
            vpn_zone_found = False
            for zone_name, zone_config in zones.items():
                if 'vpn' in zone_name.lower():
                    vpn_zone_found = True
                    interfaces = zone_config.get('interfaces', [])
                    if not interfaces:
                        findings.append(self.create_finding(
                            rule_id="JUNOS-ZONE-001",
                            title=f"VPN Security Zone '{zone_name}' Has No Interfaces",
                            description=f"Security zone '{zone_name}' appears to be for VPN use but has no "
                                      f"interfaces assigned. VPN tunnels must be assigned to security zones to "
                                      f"apply security policies. Without proper zone assignment, VPN traffic may "
                                      f"be blocked or bypass security controls.",
                            severity="MEDIUM",
                            recommendation=f"Assign VPN interfaces to security zone '{zone_name}'",
                            fix_commands=[
                                f"set security zones security-zone {zone_name} interfaces st0.<unit>"
                            ],
                            cvss_vector=CVSSVector(
                                attack_vector="N",
                                attack_complexity="L",
                                privileges_required="N",
                                confidentiality="L",
                                integrity="L",
                                availability="H"
                            ),
                            nist_controls=["SC-7", "AC-4"],
                            vendor=VendorType.JUNIPER_JUNOS
                        ))

        return findings
