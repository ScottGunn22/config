"""Authentication and access control rules for Juniper JunOS.

Detects weak or missing authentication configurations including:
- Root authentication
- User accounts and privilege levels
- AAA configuration
- Password policies
"""

from typing import List, Dict, Any
from .base import BaseRuleEngine
from ..core import Finding, VendorType, CVSSVector


class JuniperAuthenticationRules(BaseRuleEngine):
    """Authentication security rules for Juniper JunOS."""

    def __init__(self):
        super().__init__()
        self.category = "Authentication & Access Control"

    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check authentication security rules."""
        findings = []

        if vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._check_juniper_auth(parsed_config))

        return findings

    def _check_juniper_auth(self, config: Dict[str, Any]) -> List[Finding]:
        """Check Juniper authentication configuration."""
        findings = []

        # Get system configuration
        system = config.get('system', {})
        auth_config = system.get('authentication', {})
        login_config = system.get('login', {})

        # Check for root authentication
        root_auth = auth_config.get('root', {})
        if not root_auth.get('configured'):
            findings.append(self.create_finding(
                rule_id="JUNOS-AUTH-001",
                title="Root Authentication Not Configured",
                description="The root account does not have authentication configured. This allows unrestricted "
                          "access to the device with the default or no password. An attacker with physical or "
                          "network access could gain full administrative control of the device.",
                severity="CRITICAL",
                recommendation="Configure root authentication with encrypted password",
                fix_commands=[
                    "set system root-authentication encrypted-password \"<encrypted_password>\"",
                    "# Or use SSH key-based authentication:",
                    "set system root-authentication ssh-rsa \"<ssh_public_key>\""
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-2", "IA-5", "AC-2"],
                vendor=VendorType.JUNIPER_JUNOS
            ))
        elif root_auth.get('method') == 'plain-text-password':
            findings.append(self.create_finding(
                rule_id="JUNOS-AUTH-002",
                title="Root Using Plain-Text Password",
                description="The root account is configured with a plain-text password instead of an encrypted "
                          "password. Plain-text passwords are visible in the configuration and can be easily "
                          "compromised. This violates security best practices and compliance requirements.",
                severity="HIGH",
                recommendation="Replace plain-text password with encrypted password",
                fix_commands=[
                    "delete system root-authentication plain-text-password",
                    "set system root-authentication encrypted-password \"<encrypted_password>\""
                ],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="L",
                    privileges_required="L",
                    confidentiality="H",
                    integrity="H",
                    availability="H"
                ),
                nist_controls=["IA-5(1)", "SC-28"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check user accounts
        users = login_config.get('users', {})
        if not users:
            findings.append(self.create_finding(
                rule_id="JUNOS-AUTH-003",
                title="No User Accounts Configured",
                description="No user accounts are configured on the device. Relying solely on the root account "
                          "does not provide accountability or role-based access control. All administrative "
                          "actions will be attributed to root, making audit trails ineffective.",
                severity="HIGH",
                recommendation="Configure individual user accounts with appropriate privilege classes",
                fix_commands=[
                    "set system login user <username> class <super-user|operator|read-only>",
                    "set system login user <username> authentication encrypted-password \"<password>\""
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="L",
                    availability="L"
                ),
                nist_controls=["AC-2", "AU-2", "IA-2"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        # Check for users with weak authentication
        for username, user_config in users.items():
            auth = user_config.get('authentication', {})

            if 'plain-text-password' in auth:
                findings.append(self.create_finding(
                    rule_id="JUNOS-AUTH-004",
                    title=f"User '{username}' Using Plain-Text Password",
                    description=f"User account '{username}' is configured with a plain-text password. "
                              "Plain-text passwords are visible in the configuration and violate security "
                              "best practices.",
                    severity="HIGH",
                    recommendation=f"Replace plain-text password with encrypted password for user '{username}'",
                    fix_commands=[
                        f"delete system login user {username} authentication plain-text-password",
                        f"set system login user {username} authentication encrypted-password \"<password>\""
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="L",
                        attack_complexity="L",
                        privileges_required="L",
                        confidentiality="H",
                        integrity="H",
                        availability="H"
                    ),
                    nist_controls=["IA-5(1)", "SC-28"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

            # Check user privilege class
            user_class = user_config.get('class')
            if not user_class:
                findings.append(self.create_finding(
                    rule_id="JUNOS-AUTH-005",
                    title=f"User '{username}' Missing Privilege Class",
                    description=f"User account '{username}' does not have a privilege class assigned. Without "
                              "a defined class, the user's access level is undefined and may grant unintended "
                              "privileges or deny necessary access.",
                    severity="MEDIUM",
                    recommendation=f"Assign appropriate privilege class to user '{username}'",
                    fix_commands=[
                        f"set system login user {username} class <super-user|operator|read-only|custom-class>"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="L",
                        attack_complexity="L",
                        privileges_required="L",
                        confidentiality="L",
                        integrity="L",
                        availability="N"
                    ),
                    nist_controls=["AC-2", "AC-6"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

        # Check for SSH configuration
        services = system.get('services', {})
        ssh_config = services.get('ssh', {})

        if not ssh_config:
            findings.append(self.create_finding(
                rule_id="JUNOS-AUTH-006",
                title="SSH Service Not Enabled",
                description="SSH service is not enabled on the device. Without SSH, secure remote management "
                          "is not possible, and administrators may resort to insecure protocols like Telnet. "
                          "This exposes credentials and session data to interception.",
                severity="HIGH",
                recommendation="Enable SSH service with secure protocol version",
                fix_commands=[
                    "set system services ssh protocol-version v2",
                    "set system services ssh root-login deny"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["SC-8", "IA-2(8)", "AC-17"],
                vendor=VendorType.JUNIPER_JUNOS
            ))
        else:
            # Check SSH protocol version
            protocol_version = ssh_config.get('protocol_version')
            if not protocol_version or protocol_version != 'v2':
                findings.append(self.create_finding(
                    rule_id="JUNOS-AUTH-007",
                    title="SSH Not Restricted to Protocol Version 2",
                    description="SSH is not explicitly configured to use only protocol version 2. SSHv1 has "
                              "known cryptographic weaknesses and should never be used. Allowing SSHv1 exposes "
                              "the device to man-in-the-middle attacks and session hijacking.",
                    severity="HIGH",
                    recommendation="Configure SSH to use only protocol version 2",
                    fix_commands=[
                        "set system services ssh protocol-version v2"
                    ],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="L"
                    ),
                    nist_controls=["SC-8", "IA-2(8)"],
                    vendor=VendorType.JUNIPER_JUNOS
                ))

        # Check for Telnet service
        if 'telnet' in services:
            findings.append(self.create_finding(
                rule_id="JUNOS-AUTH-008",
                title="Insecure Telnet Service Enabled",
                description="Telnet service is enabled on the device. Telnet transmits all data, including "
                          "usernames and passwords, in cleartext. An attacker with network access can intercept "
                          "credentials and session data using packet sniffing tools.",
                severity="CRITICAL",
                recommendation="Disable Telnet service and use SSH instead",
                fix_commands=[
                    "delete system services telnet"
                ],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="L"
                ),
                nist_controls=["SC-8", "AC-17", "IA-2(8)"],
                vendor=VendorType.JUNIPER_JUNOS
            ))

        return findings
