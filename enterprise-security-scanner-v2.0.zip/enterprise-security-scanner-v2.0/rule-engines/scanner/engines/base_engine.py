"""Base engine for modular security analysis."""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from enum import Enum
from ..core import Finding, VendorType


class EngineCategory(Enum):
    """Categories of security analysis engines."""
    AUTHENTICATION = "authentication"
    ROUTING = "routing" 
    SWITCHING = "switching"
    SECURITY = "security"
    COMPLIANCE = "compliance"
    NETWORK_SERVICES = "network_services"
    MANAGEMENT = "management"


class EnginePriority(Enum):
    """Engine execution priority levels."""
    CRITICAL = 1    # Core security (auth, access control)
    HIGH = 2        # Protocol security (routing, switching)
    MEDIUM = 3      # Advanced features (QoS, multicast)
    LOW = 4         # Optional enhancements (monitoring)


class BaseSecurityEngine(ABC):
    """Abstract base class for all security analysis engines."""
    
    def __init__(self):
        self.engine_name = self.__class__.__name__
        self.category = self.get_category()
        self.priority = self.get_priority()
        self.supported_vendors = self.get_supported_vendors()
        self.rule_count = 0
        self.findings_generated = 0
    
    @abstractmethod
    def get_category(self) -> EngineCategory:
        """Return the engine category."""
        pass
    
    @abstractmethod 
    def get_priority(self) -> EnginePriority:
        """Return the engine priority."""
        pass
    
    @abstractmethod
    def get_supported_vendors(self) -> List[VendorType]:
        """Return list of supported vendor types."""
        pass
    
    @abstractmethod
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """
        Analyze configuration and return security findings.
        
        Args:
            parsed_config: Parsed configuration data
            vendor: Device vendor type
            
        Returns:
            List of security findings
        """
        pass
    
    def is_vendor_supported(self, vendor: VendorType) -> bool:
        """Check if vendor is supported by this engine."""
        return vendor in self.supported_vendors
    
    def get_engine_info(self) -> Dict[str, Any]:
        """Get engine metadata and statistics."""
        return {
            "name": self.engine_name,
            "category": self.category.value,
            "priority": self.priority.value,
            "supported_vendors": [v.value for v in self.supported_vendors],
            "rule_count": self.rule_count,
            "findings_generated": self.findings_generated
        }
    
    def create_finding(self, **kwargs) -> Finding:
        """Helper method to create findings with engine context."""
        finding = Finding(**kwargs)
        finding.engine_name = self.engine_name
        finding.engine_category = self.category.value
        self.findings_generated += 1
        return finding


class ProtocolSecurityEngine(BaseSecurityEngine):
    """Base class for routing protocol security engines."""
    
    def get_category(self) -> EngineCategory:
        return EngineCategory.ROUTING
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.HIGH
    
    @abstractmethod
    def check_authentication(self, protocol_config: Dict) -> List[Finding]:
        """Check protocol authentication configuration."""
        pass
    
    @abstractmethod  
    def check_filtering(self, protocol_config: Dict) -> List[Finding]:
        """Check route/update filtering configuration."""
        pass
    
    @abstractmethod
    def check_hardening(self, protocol_config: Dict) -> List[Finding]:
        """Check protocol-specific hardening measures."""
        pass


class SwitchingSecurityEngine(BaseSecurityEngine):
    """Base class for Layer 2 security engines."""
    
    def get_category(self) -> EngineCategory:
        return EngineCategory.SWITCHING
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.HIGH
    
    @abstractmethod
    def check_port_security(self, switching_config: Dict) -> List[Finding]:
        """Check port-level security configuration.""" 
        pass
    
    @abstractmethod
    def check_vlan_security(self, switching_config: Dict) -> List[Finding]:
        """Check VLAN security configuration."""
        pass
    
    @abstractmethod
    def check_spanning_tree_security(self, switching_config: Dict) -> List[Finding]:
        """Check spanning tree security features."""
        pass


class ComplianceEngine(BaseSecurityEngine):
    """Base class for compliance framework engines."""
    
    def get_category(self) -> EngineCategory:
        return EngineCategory.COMPLIANCE
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.MEDIUM
    
    @abstractmethod
    def get_framework_name(self) -> str:
        """Return compliance framework name."""
        pass
    
    @abstractmethod
    def get_framework_version(self) -> str:
        """Return compliance framework version."""
        pass
    
    @abstractmethod
    def check_compliance_requirements(self, config: Dict) -> List[Finding]:
        """Check configuration against compliance requirements."""
        pass
    
    def generate_compliance_report(self, findings: List[Finding]) -> Dict[str, Any]:
        """Generate compliance-specific report."""
        framework_findings = [
            f for f in findings 
            if f.engine_category == self.category.value and 
               f.engine_name == self.engine_name
        ]
        
        return {
            "framework": self.get_framework_name(),
            "version": self.get_framework_version(),
            "total_checks": len(framework_findings),
            "passed": len([f for f in framework_findings if f.severity.value in ["INFO", "LOW"]]),
            "failed": len([f for f in framework_findings if f.severity.value in ["CRITICAL", "HIGH", "MEDIUM"]]),
            "compliance_score": self.calculate_compliance_score(framework_findings)
        }
    
    def calculate_compliance_score(self, findings: List[Finding]) -> float:
        """Calculate compliance score (0-100)."""
        if not findings:
            return 100.0
        
        # Weight findings by severity
        severity_weights = {"CRITICAL": 10, "HIGH": 5, "MEDIUM": 2, "LOW": 1, "INFO": 0}
        total_weight = sum(severity_weights[f.severity.value] for f in findings)
        max_possible_weight = len(findings) * severity_weights["CRITICAL"]
        
        if max_possible_weight == 0:
            return 100.0
        
        # Higher weight = lower score
        score = max(0, 100 - (total_weight / max_possible_weight) * 100)
        return round(score, 1)


class EngineRegistry:
    """Registry for managing security analysis engines."""
    
    def __init__(self):
        self.engines: Dict[str, BaseSecurityEngine] = {}
        self.engines_by_category: Dict[EngineCategory, List[BaseSecurityEngine]] = {}
        self.engines_by_priority: Dict[EnginePriority, List[BaseSecurityEngine]] = {}
    
    def register_engine(self, engine: BaseSecurityEngine) -> None:
        """Register a security analysis engine."""
        engine_name = engine.engine_name
        
        if engine_name in self.engines:
            raise ValueError(f"Engine '{engine_name}' is already registered")
        
        self.engines[engine_name] = engine
        
        # Add to category mapping
        category = engine.category
        if category not in self.engines_by_category:
            self.engines_by_category[category] = []
        self.engines_by_category[category].append(engine)
        
        # Add to priority mapping  
        priority = engine.priority
        if priority not in self.engines_by_priority:
            self.engines_by_priority[priority] = []
        self.engines_by_priority[priority].append(engine)
    
    def get_engine(self, engine_name: str) -> Optional[BaseSecurityEngine]:
        """Get engine by name."""
        return self.engines.get(engine_name)
    
    def get_engines_by_category(self, category: EngineCategory) -> List[BaseSecurityEngine]:
        """Get all engines in a category."""
        return self.engines_by_category.get(category, [])
    
    def get_engines_by_vendor(self, vendor: VendorType) -> List[BaseSecurityEngine]:
        """Get all engines that support a vendor."""
        return [engine for engine in self.engines.values() 
                if engine.is_vendor_supported(vendor)]
    
    def get_engines_by_priority(self, priority: EnginePriority) -> List[BaseSecurityEngine]:
        """Get all engines with specific priority."""
        return self.engines_by_priority.get(priority, [])
    
    def get_execution_order(self, vendor: VendorType) -> List[BaseSecurityEngine]:
        """Get engines in execution order (by priority) for a vendor."""
        supported_engines = self.get_engines_by_vendor(vendor)
        
        # Sort by priority (CRITICAL=1, HIGH=2, etc.)
        return sorted(supported_engines, key=lambda e: e.priority.value)
    
    def get_registry_info(self) -> Dict[str, Any]:
        """Get registry statistics and information."""
        return {
            "total_engines": len(self.engines),
            "categories": {cat.value: len(engines) for cat, engines in self.engines_by_category.items()},
            "priorities": {pri.value: len(engines) for pri, engines in self.engines_by_priority.items()},
            "engines": [engine.get_engine_info() for engine in self.engines.values()]
        }


# Global registry instance
engine_registry = EngineRegistry()