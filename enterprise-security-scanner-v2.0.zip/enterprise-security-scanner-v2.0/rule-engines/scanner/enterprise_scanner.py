"""Enterprise Security Scanner with Modular Engine Framework."""

import time
from datetime import datetime
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from .core import SecurityScanner, ScanResults, VendorType
from .engines.base_engine import engine_registry, BaseSecurityEngine, EnginePriority
from .engines.routing.bgp_engine import BGPSecurityEngine
from .engines.routing.ospf_engine import OSPFSecurityEngine
from .engines.switching.stp_engine import STPSecurityEngine
from .engines.security.acl_engine import ACLSecurityEngine
from .engines.security.snmp_engine import SNMPSecurityEngine
from .engines.security.crypto_engine import CryptographySecurityEngine
from .engines.compliance.pci_dss_engine import PCIDSSComplianceEngine


class EnterpriseSecurityScanner(SecurityScanner):
    """Enhanced security scanner with modular engine framework."""
    
    def __init__(self):
        super().__init__()
        self._initialize_enterprise_engines()
        self.parallel_execution = True
        self.max_workers = 4
    
    def _initialize_enterprise_engines(self):
        """Initialize and register enterprise security engines."""
        # Register new modular engines
        try:
            bgp_engine = BGPSecurityEngine()
            engine_registry.register_engine(bgp_engine)
            
            ospf_engine = OSPFSecurityEngine()
            engine_registry.register_engine(ospf_engine)
            
            stp_engine = STPSecurityEngine() 
            engine_registry.register_engine(stp_engine)
            
            acl_engine = ACLSecurityEngine()
            engine_registry.register_engine(acl_engine)
            
            snmp_engine = SNMPSecurityEngine()
            engine_registry.register_engine(snmp_engine)
            
            crypto_engine = CryptographySecurityEngine()
            engine_registry.register_engine(crypto_engine)
            
            pci_engine = PCIDSSComplianceEngine()
            engine_registry.register_engine(pci_engine)
            
            print(f"✅ Registered {len(engine_registry.engines)} security engines")
        except Exception as e:
            print(f"⚠️  Warning: Failed to register some engines: {e}")
    
    def scan_config(self, config_content: str, vendor: Optional[VendorType] = None) -> ScanResults:
        """Enhanced configuration scanning with modular engines."""
        start_time = datetime.now()
        
        # Parse configuration
        if vendor is None:
            vendor = self._detect_vendor(config_content)
        
        parser = self.vendor_parsers.get(vendor)
        if not parser:
            raise ValueError(f"Unsupported vendor: {vendor}")
        
        parsed_config = parser.parse_config(config_content)
        
        # Get engines for this vendor in execution order
        engines = engine_registry.get_execution_order(vendor)
        
        # Add legacy rule engines for compatibility
        legacy_engines = list(self.rule_engines.values())
        
        # Run security analysis
        if self.parallel_execution:
            findings = self._run_parallel_analysis(parsed_config, vendor, engines, legacy_engines)
        else:
            findings = self._run_sequential_analysis(parsed_config, vendor, engines, legacy_engines)
        
        # Calculate scan duration
        end_time = datetime.now()
        duration_ms = int((end_time - start_time).total_seconds() * 1000)
        
        # Create enhanced results
        results = ScanResults(
            findings=findings,
            vendor=vendor,
            device_hostname=parsed_config.get("hostname", "Unknown"),
            scan_timestamp=start_time,
            config_lines_total=len(parsed_config.get("config_lines", [])),
            rules_executed=len(engines) + len(legacy_engines),
            scan_duration_ms=duration_ms
        )
        
        return results
    
    def _run_parallel_analysis(self, parsed_config: Dict, vendor: VendorType, 
                             engines: List[BaseSecurityEngine], legacy_engines: List) -> List:
        """Run security analysis in parallel for better performance."""
        all_findings = []
        
        # Execute engines in parallel by priority group
        priority_groups = {
            EnginePriority.CRITICAL: [],
            EnginePriority.HIGH: [], 
            EnginePriority.MEDIUM: [],
            EnginePriority.LOW: []
        }
        
        # Group engines by priority
        for engine in engines:
            priority_groups[engine.priority].append(engine)
        
        # Execute each priority group in sequence, engines within group in parallel
        for priority in [EnginePriority.CRITICAL, EnginePriority.HIGH, 
                        EnginePriority.MEDIUM, EnginePriority.LOW]:
            
            priority_engines = priority_groups[priority]
            if not priority_engines:
                continue
            
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                # Submit engine tasks
                future_to_engine = {
                    executor.submit(engine.analyze_configuration, parsed_config, vendor): engine
                    for engine in priority_engines
                }
                
                # Collect results
                for future in as_completed(future_to_engine):
                    engine = future_to_engine[future]
                    try:
                        engine_findings = future.result(timeout=30)  # 30 second timeout
                        all_findings.extend(engine_findings)
                    except Exception as e:
                        print(f"⚠️  Engine {engine.engine_name} failed: {e}")
        
        # Run legacy engines (for backward compatibility)
        for engine in legacy_engines:
            try:
                engine_findings = engine.check_config(parsed_config, vendor)
                all_findings.extend(engine_findings)
            except Exception as e:
                print(f"⚠️  Legacy engine failed: {e}")
        
        return all_findings
    
    def _run_sequential_analysis(self, parsed_config: Dict, vendor: VendorType,
                               engines: List[BaseSecurityEngine], legacy_engines: List) -> List:
        """Run security analysis sequentially."""
        all_findings = []
        
        # Execute modular engines
        for engine in engines:
            try:
                engine_findings = engine.analyze_configuration(parsed_config, vendor)
                all_findings.extend(engine_findings)
            except Exception as e:
                print(f"⚠️  Engine {engine.engine_name} failed: {e}")
        
        # Execute legacy engines
        for engine in legacy_engines:
            try:
                engine_findings = engine.check_config(parsed_config, vendor)
                all_findings.extend(engine_findings)
            except Exception as e:
                print(f"⚠️  Legacy engine failed: {e}")
        
        return all_findings
    
    def get_engine_statistics(self) -> Dict[str, Any]:
        """Get detailed engine statistics and performance metrics."""
        registry_info = engine_registry.get_registry_info()
        
        return {
            "modular_engines": registry_info,
            "legacy_engines": {
                "count": len(self.rule_engines),
                "engines": list(self.rule_engines.keys())
            },
            "total_engines": registry_info["total_engines"] + len(self.rule_engines),
            "execution_mode": "parallel" if self.parallel_execution else "sequential",
            "max_workers": self.max_workers
        }
    
    def scan_device_fleet(self, device_configs: List[Dict[str, Any]]) -> List[ScanResults]:
        """Scan multiple device configurations in parallel."""
        if not device_configs:
            return []
        
        results = []
        
        with ThreadPoolExecutor(max_workers=min(len(device_configs), self.max_workers)) as executor:
            # Submit scan tasks
            future_to_config = {
                executor.submit(
                    self.scan_config, 
                    config["content"], 
                    config.get("vendor")
                ): config
                for config in device_configs
            }
            
            # Collect results
            for future in as_completed(future_to_config):
                config = future_to_config[future]
                try:
                    scan_result = future.result(timeout=60)  # 60 second timeout per device
                    scan_result.device_hostname = config.get("hostname", scan_result.device_hostname)
                    results.append(scan_result)
                except Exception as e:
                    print(f"⚠️  Failed to scan device {config.get('hostname', 'Unknown')}: {e}")
        
        return results
    
    def generate_fleet_summary(self, fleet_results: List[ScanResults]) -> Dict[str, Any]:
        """Generate summary statistics for fleet scan results."""
        if not fleet_results:
            return {}
        
        total_devices = len(fleet_results)
        total_findings = sum(len(result.findings) for result in fleet_results)
        total_config_lines = sum(result.config_lines_total for result in fleet_results)
        
        # Severity breakdown across fleet
        fleet_severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
        for result in fleet_results:
            for finding in result.findings:
                fleet_severity_counts[finding.severity.value] += 1
        
        # Vendor breakdown
        vendor_counts = {}
        for result in fleet_results:
            vendor = result.vendor.value
            vendor_counts[vendor] = vendor_counts.get(vendor, 0) + 1
        
        # Top issues across fleet
        issue_counts = {}
        for result in fleet_results:
            for finding in result.findings:
                title = finding.title
                issue_counts[title] = issue_counts.get(title, 0) + 1
        
        top_issues = sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "fleet_summary": {
                "total_devices": total_devices,
                "total_findings": total_findings,
                "total_config_lines": total_config_lines,
                "average_findings_per_device": round(total_findings / total_devices, 1),
                "severity_breakdown": fleet_severity_counts,
                "vendor_breakdown": vendor_counts
            },
            "top_issues": [
                {"issue": issue, "device_count": count, "percentage": round((count/total_devices)*100, 1)}
                for issue, count in top_issues
            ],
            "risk_assessment": self._calculate_fleet_risk(fleet_results),
            "scan_performance": {
                "total_scan_time": sum(r.scan_duration_ms for r in fleet_results),
                "average_scan_time": round(sum(r.scan_duration_ms for r in fleet_results) / total_devices, 1)
            }
        }
    
    def _calculate_fleet_risk(self, fleet_results: List[ScanResults]) -> Dict[str, Any]:
        """Calculate overall fleet risk assessment."""
        if not fleet_results:
            return {"level": "UNKNOWN", "score": 0}
        
        # Risk scoring algorithm
        risk_score = 0
        total_possible_score = 0
        
        for result in fleet_results:
            device_score = 0
            device_max_score = 100  # Max score per device
            
            for finding in result.findings:
                if finding.severity.value == "CRITICAL":
                    device_score += 25
                elif finding.severity.value == "HIGH": 
                    device_score += 15
                elif finding.severity.value == "MEDIUM":
                    device_score += 5
                elif finding.severity.value == "LOW":
                    device_score += 1
            
            risk_score += min(device_score, device_max_score)
            total_possible_score += device_max_score
        
        if total_possible_score == 0:
            risk_percentage = 0
        else:
            risk_percentage = (risk_score / total_possible_score) * 100
        
        # Determine risk level
        if risk_percentage >= 75:
            risk_level = "CRITICAL"
        elif risk_percentage >= 50:
            risk_level = "HIGH"
        elif risk_percentage >= 25:
            risk_level = "MEDIUM"
        elif risk_percentage > 0:
            risk_level = "LOW"
        else:
            risk_level = "MINIMAL"
        
        return {
            "level": risk_level,
            "score": round(risk_percentage, 1),
            "critical_devices": len([r for r in fleet_results if any(f.severity.value == "CRITICAL" for f in r.findings)]),
            "compliant_devices": len([r for r in fleet_results if len(r.findings) == 0])
        }