#!/usr/bin/env python3
"""Enterprise Security Parser - CLI interface using Network Security Scanner engines.

This script provides 1:1 parity with the web application by using the exact same
security analysis engines from the Network Security Scanner.
"""

import sys
import os
import argparse
import json
import re
from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

# Add the rule engines to Python path (relative to this script)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RULE_ENGINE_PATH = os.path.join(os.path.dirname(SCRIPT_DIR), 'rule-engines')
sys.path.insert(0, RULE_ENGINE_PATH)

from scanner.core import SecurityScanner, VendorType, Severity, Finding, ConfigLine
from scanner.engines.security.acl_engine import ACLSecurityEngine
from scanner.engines.security.crypto_engine import CryptographySecurityEngine
from scanner.engines.security.snmp_engine import SNMPSecurityEngine
from scanner.engines.routing.bgp_engine import BGPSecurityEngine
from scanner.engines.routing.ospf_engine import OSPFSecurityEngine
from scanner.engines.switching.stp_engine import STPSecurityEngine
from scanner.engines.compliance.pci_dss_engine import PCIDSSComplianceEngine
from scanner.rules.authentication import AuthenticationRules
from scanner.rules.network_services import NetworkServicesRules
from scanner.rules.comprehensive_security import ComprehensiveSecurityRules
from scanner.rules.logging import LoggingRules
from scanner.rules.fhrp_security import FHRPSecurityRules
from scanner.rules.tunnel_security import TunnelSecurityRules
from scanner.rules.juniper_authentication import JuniperAuthenticationRules
from scanner.rules.juniper_services import JuniperServicesRules
from scanner.rules.juniper_comprehensive import JuniperComprehensiveRules
from scanner.rules.juniper_tunnels import JuniperTunnelRules
from scanner.rules.paloalto_security import PaloAltoSecurityRules

# Add benchmark validation
from benchmark_validator import BenchmarkValidator

# Add Genie integration
from genie_integration import create_parser as create_genie_parser


@dataclass
class ParsedConfig:
    """Container for parsed configuration data."""
    config_lines: List[ConfigLine]
    vendor: VendorType
    hostname: Optional[str] = None
    total_lines: int = 0


class EnterpriseSecurityParser:
    """CLI parser using Network Security Scanner engines for 1:1 parity."""

    def __init__(self):
        """Initialize with all available security engines and rule engines."""
        # Security analysis engines
        self.engines = [
            ACLSecurityEngine(),
            CryptographySecurityEngine(),
            SNMPSecurityEngine(),
            BGPSecurityEngine(),
            OSPFSecurityEngine(),
            STPSecurityEngine(),
            PCIDSSComplianceEngine()
        ]

        # Rule-based engines
        self.rule_engines = [
            # Cisco IOS rules
            AuthenticationRules(),
            NetworkServicesRules(),
            ComprehensiveSecurityRules(),
            LoggingRules(),
            FHRPSecurityRules(),
            TunnelSecurityRules(),
            # Juniper JunOS rules
            JuniperAuthenticationRules(),
            JuniperServicesRules(),
            JuniperComprehensiveRules(),
            JuniperTunnelRules(),
            # Palo Alto PAN-OS rules
            PaloAltoSecurityRules()
        ]

        # Benchmark validator for CIS, STIG, and vendor hardening guides
        self.benchmark_validator = BenchmarkValidator()

        # Load CVA mapping
        self.cva_mapping = self._load_cva_mapping()

    def _load_cva_mapping(self) -> Dict[str, str]:
        """Load CVA ID mapping from JSON file."""
        mapping_file = Path(__file__).parent / "cva_mapping.json"
        if mapping_file.exists():
            try:
                with open(mapping_file, 'r') as f:
                    data = json.load(f)
                    return data.get("mappings", {})
            except Exception as e:
                print(f"⚠ Warning: Could not load CVA mapping: {e}", file=sys.stderr)
                return {}
        return {}

    def _apply_cva_mapping(self, finding: Finding) -> Optional[str]:
        """Apply CVA ID to a finding based on rule ID or category."""
        if not self.cva_mapping:
            return None

        # Try exact rule ID match first
        if finding.rule_id in self.cva_mapping:
            return self.cva_mapping[finding.rule_id]

        # Try matching each rule ID if comma-separated (merged findings)
        for rule_id in finding.rule_id.split(", "):
            if rule_id.strip() in self.cva_mapping:
                return self.cva_mapping[rule_id.strip()]

        # Try partial matches based on keywords in title
        title_lower = finding.title.lower()
        description_lower = finding.description.lower() if finding.description else ""

        keyword_matches = {
            "cdp": "cdp",
            "http": "http",
            "bootp": "bootp",
            "redirect": "redirect",
            "domain lookup": "domain_lookup",
            "ssh": "ssh",
            "enable secret": "enable_secret",
            "type 7 password": "type7_password",
            "plain text password": "type7_password",
            "password encryption": "type7_password",
            "proxy arp": "proxy_arp",
            "source route": "source_route",
            "aaa": "aaa",
            "exec-timeout": "exec_timeout",
            "session timeout": "exec_timeout",
            "console": "console_auth",
            "trunk": "trunk_guard",
            "root guard": "trunk_guard",
            "small servers": "small_servers",
            "transport input": "transport_input",
            "snmp": "snmp_rw",
            "urpf": "proxy_arp",
            "ntp": "ntp_disable",
            "default password": "default_password",
            "weak password": "default_password",
            "weak ipsec": "weak_encryption",
            "weak encryption": "weak_encryption",
            "weak cryptographic": "weak_encryption",
            "weak algorithm": "weak_encryption",
            "3des": "weak_encryption",
            "des": "weak_encryption"
        }

        for keyword, mapping_key in keyword_matches.items():
            if (keyword in title_lower or keyword in description_lower) and mapping_key in self.cva_mapping:
                return self.cva_mapping[mapping_key]

        # Special check for default passwords - look in config line
        if hasattr(finding, 'config_line') and finding.config_line:
            config_content = finding.config_line.content.lower() if hasattr(finding.config_line, 'content') else str(finding.config_line).lower()
            # Common default passwords in Cisco configs
            default_passwords = ['cisco', 'cisco123', 'password', 'admin', '12345']
            if 'enable password' in config_content:
                for default_pwd in default_passwords:
                    if default_pwd in config_content:
                        if "default_password" in self.cva_mapping:
                            return self.cva_mapping["default_password"]

        return None

    def detect_vendor(self, content: str) -> VendorType:
        """Auto-detect vendor from configuration content with comprehensive pattern matching."""
        content_lower = content.lower()

        # Cisco IOS patterns
        ios_patterns = [
            r'^\s*interface\s+(gigabitethernet|fastethernet|ethernet)',
            r'^\s*router\s+(bgp|ospf|eigrp)',
            r'^\s*ip\s+route\s+',
            r'^\s*access-list\s+\d+',
            r'^\s*line\s+(con|vty|aux)',
            r'^\s*enable\s+(password|secret)',
            r'^\s*ip\s+access-group',
            r'^\s*service\s+timestamps',
            r'^\s*spanning-tree\s+mode',
        ]

        # Juniper JunOS patterns
        junos_patterns = [
            r'^\s*set\s+system',
            r'^\s*set\s+interfaces',
            r'^\s*set\s+protocols',
            r'^\s*set\s+security',
            r'^\s*set\s+routing-options',
            r'^\s*set\s+policy-options',
            r'version\s+\d+\.\d+',
        ]

        # Fortinet FortiOS patterns
        fortios_patterns = [
            r'^\s*config\s+system',
            r'^\s*config\s+firewall',
            r'^\s*set\s+vdom',
            r'^\s*config\s+router',
            r'^\s*edit\s+\d+',
            r'^\s*next\s*$',
            r'^\s*end\s*$',
        ]

        # Palo Alto PAN-OS patterns
        panos_patterns = [
            r'^\s*set\s+deviceconfig',
            r'^\s*set\s+network\s+interface',
            r'^\s*set\s+zone',
            r'^\s*set\s+rulebase',
            r'^\s*set\s+application',
            r'^\s*set\s+address',
        ]

        # Calculate scores for each vendor
        ios_score = sum(1 for pattern in ios_patterns
                       if re.search(pattern, content_lower, re.MULTILINE))
        junos_score = sum(1 for pattern in junos_patterns
                         if re.search(pattern, content_lower, re.MULTILINE))
        fortios_score = sum(1 for pattern in fortios_patterns
                           if re.search(pattern, content_lower, re.MULTILINE))
        panos_score = sum(1 for pattern in panos_patterns
                         if re.search(pattern, content_lower, re.MULTILINE))

        # Determine vendor based on highest score with minimum threshold
        scores = {
            VendorType.CISCO_IOS: ios_score,
            VendorType.JUNIPER_JUNOS: junos_score,
            VendorType.FORTINET_FORTIOS: fortios_score,
            VendorType.PALOALTO_PANOS: panos_score,
        }

        max_score = max(scores.values())
        if max_score >= 2:
            return max(scores, key=scores.get)

        return VendorType.UNKNOWN
    
    def parse_config(self, content: str, vendor: Optional[VendorType] = None) -> ParsedConfig:
        """Parse configuration content into structured format."""
        if vendor is None:
            vendor = self.detect_vendor(content)
        
        lines = content.split('\n')
        config_lines = []
        hostname = None
        
        for line_num, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith('!'):
                continue
            
            # Extract hostname
            if stripped.startswith('hostname '):
                hostname = stripped.split()[1]
            
            # Create ConfigLine object matching the web app format
            config_line = ConfigLine(
                line_number=line_num,
                content=stripped,
                section=self._determine_section(stripped),
                indentation=len(line) - len(line.lstrip())
            )
            config_lines.append(config_line)
        
        return ParsedConfig(
            config_lines=config_lines,
            vendor=vendor,
            hostname=hostname,
            total_lines=len(config_lines)
        )
    
    def _determine_section(self, content: str) -> str:
        """Determine configuration section for context."""
        content_lower = content.lower()
        
        if content_lower.startswith('interface '):
            return "interface"
        elif content_lower.startswith('router '):
            return "routing"
        elif content_lower.startswith('line '):
            return "line"
        elif content_lower.startswith('access-list'):
            return "acl"
        elif content_lower.startswith('crypto'):
            return "crypto"
        elif content_lower.startswith('snmp'):
            return "snmp"
        
        return "global"
    
    def analyze_security(self, parsed_config: ParsedConfig, raw_config_text: str = "") -> List[Finding]:
        """Run comprehensive security analysis using all engines."""
        all_findings = []

        # Use Genie parser to extract structured data
        genie_parser = create_genie_parser(parsed_config.vendor)
        analysis_config = genie_parser.parse_config(raw_config_text, parsed_config.config_lines)

        # Ensure vendor and hostname are set
        analysis_config["vendor"] = parsed_config.vendor
        analysis_config["hostname"] = parsed_config.hostname

        # Run security analysis engines
        for engine in self.engines:
            if parsed_config.vendor in engine.get_supported_vendors():
                try:
                    findings = engine.analyze_configuration(analysis_config, parsed_config.vendor)
                    all_findings.extend(findings)
                    print(f"✓ {engine.__class__.__name__}: {len(findings)} findings", file=sys.stderr)
                except Exception as e:
                    print(f"⚠ {engine.__class__.__name__}: Error - {str(e)}", file=sys.stderr)

        # Run rule-based engines
        for rule_engine in self.rule_engines:
            try:
                findings = rule_engine.check_config(analysis_config, parsed_config.vendor)
                all_findings.extend(findings)
                print(f"✓ {rule_engine.__class__.__name__}: {len(findings)} findings", file=sys.stderr)
            except Exception as e:
                print(f"⚠ {rule_engine.__class__.__name__}: Error - {str(e)}", file=sys.stderr)

        # Run benchmark validation (CIS, STIG, Vendor Hardening)
        try:
            if parsed_config.vendor == VendorType.CISCO_IOS:
                benchmark_findings = self.benchmark_validator.validate_cisco_ios(analysis_config)
                # Convert benchmark findings to Finding objects
                for bf in benchmark_findings:
                    finding = Finding(
                        rule_id=bf["rule_id"],
                        title=bf["title"],
                        description=f"{bf['description']}\n\nBenchmark: {bf['benchmark_name']} ({bf['benchmark_id']})",
                        severity=Severity(bf["severity"].upper()),
                        category=bf["category"],
                        recommendation=bf["recommendation"],
                        fix_commands=bf["fix_commands"],
                        nist_controls=bf["nist_controls"],
                        vendor=parsed_config.vendor
                    )
                    all_findings.append(finding)
                print(f"✓ BenchmarkValidator: {len(benchmark_findings)} findings", file=sys.stderr)
        except Exception as e:
            print(f"⚠ BenchmarkValidator: Error - {str(e)}", file=sys.stderr)

        # Deduplicate findings while preserving all rule information
        deduplicated_findings = self._deduplicate_findings(all_findings)

        # Apply CVA mapping to all findings
        for finding in deduplicated_findings:
            cva_id = self._apply_cva_mapping(finding)
            if cva_id:
                finding.cva_id = cva_id

        # Sort by severity (same as web app)
        severity_order = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
            Severity.INFO: 4
        }
        deduplicated_findings.sort(key=lambda f: severity_order.get(f.severity, 99))

        return deduplicated_findings

    def _deduplicate_findings(self, findings: List[Finding]) -> List[Finding]:
        """Deduplicate findings while preserving all detection information."""
        if not findings:
            return []

        # Group findings by normalized title (case-insensitive, remove special chars)
        groups = {}

        for finding in findings:
            # Create a normalized key based on the core issue
            normalized_title = re.sub(r'[^a-z0-9\s]', '', finding.title.lower())
            normalized_title = re.sub(r'\s+', ' ', normalized_title).strip()

            if normalized_title not in groups:
                groups[normalized_title] = []
            groups[normalized_title].append(finding)

        deduplicated = []

        for normalized_title, group in groups.items():
            if len(group) == 1:
                # No duplicates, keep as-is
                deduplicated.append(group[0])
            else:
                # Merge duplicates
                merged = self._merge_findings(group)
                deduplicated.append(merged)

        return deduplicated

    def _merge_findings(self, findings: List[Finding]) -> Finding:
        """Merge multiple findings into one, preserving all detection sources."""
        # Use the highest severity
        severity_order = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
            Severity.INFO: 4
        }
        primary = min(findings, key=lambda f: severity_order.get(f.severity, 99))

        # Collect all rule IDs and sources
        rule_ids = []
        detection_sources = []
        all_nist_controls = set()
        all_fix_commands = []
        benchmark_info = []

        for finding in findings:
            rule_ids.append(finding.rule_id)

            # Extract benchmark info from description if present
            if "Benchmark:" in finding.description:
                desc_parts = finding.description.split("Benchmark:")
                benchmark_info.append(desc_parts[1].strip())
                base_desc = desc_parts[0].strip()
            else:
                base_desc = finding.description

            # Build detection source info
            source_info = f"{finding.rule_id}"
            if benchmark_info and benchmark_info[-1]:
                source_info += f" ({benchmark_info[-1]})"
            detection_sources.append(source_info)

            # Collect NIST controls
            if hasattr(finding, 'nist_controls') and finding.nist_controls:
                all_nist_controls.update(finding.nist_controls)

            # Collect fix commands (deduplicate)
            if hasattr(finding, 'fix_commands') and finding.fix_commands:
                for cmd in finding.fix_commands:
                    if cmd not in all_fix_commands:
                        all_fix_commands.append(cmd)

        # Create merged description
        base_description = primary.description.split("Benchmark:")[0].strip() if "Benchmark:" in primary.description else primary.description

        merged_description = f"{base_description}\n\n**Detected by multiple rules:**\n"
        for i, source in enumerate(detection_sources, 1):
            merged_description += f"{i}. {source}\n"

        # Create merged finding
        merged = Finding(
            rule_id=", ".join(rule_ids),
            title=primary.title,
            description=merged_description,
            severity=primary.severity,
            category=primary.category,
            recommendation=primary.recommendation,
            fix_commands=all_fix_commands,
            nist_controls=sorted(list(all_nist_controls)),
            vendor=primary.vendor
        )

        # Preserve config_line if present
        if hasattr(primary, 'config_line'):
            merged.config_line = primary.config_line

        # Preserve CVSS if present
        if hasattr(primary, 'cvss_vector'):
            merged.cvss_vector = primary.cvss_vector
        if hasattr(primary, 'cvss_score'):
            merged.cvss_score = primary.cvss_score

        return merged

    def generate_summary(self, findings: List[Finding]) -> Dict[str, int]:
        """Generate security summary statistics."""
        summary = {
            "total_findings": len(findings),
            "critical": len([f for f in findings if f.severity == Severity.CRITICAL]),
            "high": len([f for f in findings if f.severity == Severity.HIGH]),
            "medium": len([f for f in findings if f.severity == Severity.MEDIUM]),
            "low": len([f for f in findings if f.severity == Severity.LOW]),
            "info": len([f for f in findings if f.severity == Severity.INFO])
        }
        return summary
    
    def format_findings_for_output(self, findings: List[Finding]) -> List[Dict[str, Any]]:
        """Format findings for JSON output (matching web app format)."""
        formatted_findings = []

        for finding in findings:
            finding_dict = {
                "rule_id": finding.rule_id,
                "title": finding.title,
                "description": finding.description,
                "severity": finding.severity.value,
                "category": finding.category,
                "recommendation": finding.recommendation,
                "nist_controls": getattr(finding, 'nist_controls', []),
                "fix_commands": getattr(finding, 'fix_commands', [])
            }

            # Add CVA ID if available
            if hasattr(finding, 'cva_id') and finding.cva_id:
                finding_dict["cva_id"] = finding.cva_id

            # Add config line context if available
            if hasattr(finding, 'config_line') and finding.config_line:
                if hasattr(finding.config_line, 'content'):
                    finding_dict["config_line"] = finding.config_line.content
                    finding_dict["line_number"] = finding.config_line.line_number
                else:
                    finding_dict["config_line"] = str(finding.config_line)
                    finding_dict["line_number"] = 0

            # Add CVSS score if available
            if hasattr(finding, 'cvss_vector') and finding.cvss_vector:
                finding_dict["cvss_score"] = getattr(finding, 'cvss_score', 0.0)

            formatted_findings.append(finding_dict)

        return formatted_findings


def generate_html_report(data: Dict[str, Any], output_file: Path):
    """Generate HTML report matching web app format."""
    html_template = f"""<!DOCTYPE html>
<html>
<head>
    <title>Enterprise Security Analysis Report</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .severity-critical {{ background-color: #dc3545; color: white; }}
        .severity-high {{ background-color: #fd7e14; color: white; }}
        .severity-medium {{ background-color: #ffc107; color: dark; }}
        .severity-low {{ background-color: #28a745; color: white; }}
        .severity-info {{ background-color: #17a2b8; color: white; }}
        .section-header {{ background-color: #2c3e50; color: white; margin-bottom: 20px; }}
        .detection-sources {{ background-color: #f8f9fa; border-left: 4px solid #0d6efd; padding: 10px; margin: 10px 0; }}
        .detection-sources strong {{ color: #0d6efd; }}
    </style>
</head>
<body>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <div class="section-header p-3 rounded">
                    <h1>Enterprise Security Analysis Report</h1>
                    <p class="mb-0">Generated using Network Security Scanner Engines</p>
                </div>
            </div>
        </div>
        
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Configuration Summary</div>
                    <div class="card-body">
                        <p><strong>Vendor:</strong> {data['vendor']}</p>
                        <p><strong>Hostname:</strong> {data.get('hostname', 'Unknown')}</p>
                        <p><strong>Total Lines:</strong> {data['total_lines']}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Security Summary</div>
                    <div class="card-body">
                        <p><strong>Total Findings:</strong> {data['security_summary']['total_findings']}</p>
                        <div class="row">
                            <div class="col-sm-6">
                                <span class="badge severity-critical me-1">Critical: {data['security_summary']['critical']}</span><br>
                                <span class="badge severity-high me-1 mt-1">High: {data['security_summary']['high']}</span><br>
                                <span class="badge severity-medium me-1 mt-1">Medium: {data['security_summary']['medium']}</span>
                            </div>
                            <div class="col-sm-6">
                                <span class="badge severity-low me-1">Low: {data['security_summary']['low']}</span><br>
                                <span class="badge severity-info me-1 mt-1">Info: {data['security_summary']['info']}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">Security Findings</div>
                    <div class="card-body">"""
    
    for i, finding in enumerate(data['security_findings'], 1):
        severity_class = f"severity-{finding['severity'].lower()}"

        # Format description to highlight detection sources
        description = finding['description']
        if '**Detected by multiple rules:**' in description:
            parts = description.split('**Detected by multiple rules:**')
            description_html = f"{parts[0]}<div class='detection-sources'><strong>Detected by multiple rules:</strong><br>{parts[1]}</div>"
        else:
            description_html = description

        # Add CVA ID badge if present
        cva_badge = ""
        if finding.get('cva_id'):
            cva_badge = f'<span class="badge bg-info me-2">{finding["cva_id"]}</span>'

        html_template += f"""
                        <div class="card mb-3">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span><strong>#{i}: {finding['title']}</strong></span>
                                <div>
                                    {cva_badge}
                                    <span class="badge {severity_class}">{finding['severity']}</span>
                                </div>
                            </div>
                            <div class="card-body">
                                <p><strong>Rule ID:</strong> {finding['rule_id']}</p>
                                <p><strong>Category:</strong> {finding['category']}</p>"""

        # Add CVA ID in body if present
        if finding.get('cva_id'):
            html_template += f"""
                                <p><strong>CVA ID:</strong> <span class="badge bg-info">{finding['cva_id']}</span></p>"""

        html_template += f"""
                                <p><strong>Description:</strong> {description_html}</p>"""
        
        if finding.get('config_line'):
            html_template += f"""
                                <p><strong>Configuration Line:</strong> <code>{finding['config_line']}</code> (Line {finding.get('line_number', 'N/A')})</p>"""
        
        html_template += f"""
                                <p><strong>Recommendation:</strong> {finding['recommendation']}</p>"""
        
        if finding.get('fix_commands'):
            html_template += f"""
                                <p><strong>Fix Commands:</strong></p>
                                <pre><code>{'<br>'.join(finding['fix_commands'])}</code></pre>"""
        
        if finding.get('nist_controls'):
            html_template += f"""
                                <p><strong>NIST Controls:</strong> {', '.join(finding['nist_controls'])}</p>"""
        
        html_template += """
                            </div>
                        </div>"""
    
    html_template += """
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""
    
    with open(output_file, 'w') as f:
        f.write(html_template)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Enterprise Security Parser - 1:1 parity with Network Security Scanner',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 enterprise_security_parser.py config.txt --output report.html
  python3 enterprise_security_parser.py config.txt --output findings.json --format json --pretty
  python3 enterprise_security_parser.py config.txt --output report.html --vendor cisco_ios
        """
    )
    
    parser.add_argument('config_file', help='Path to configuration file')
    parser.add_argument('--output', '-o', required=True, help='Output file path')
    parser.add_argument('--format', '-f', choices=['html', 'json'], default='html',
                       help='Output format (default: html)')
    parser.add_argument('--vendor', '-v', 
                       choices=['cisco_ios', 'juniper_junos', 'fortinet_fortios', 'paloalto_panos', 'unknown'],
                       help='Specify vendor type (auto-detect if not specified)')
    parser.add_argument('--pretty', '-p', action='store_true',
                       help='Pretty print JSON output')
    parser.add_argument('--no-security', '-n', action='store_true',
                       help='Skip security analysis')
    
    args = parser.parse_args()
    
    # Validate input file
    config_path = Path(args.config_file)
    if not config_path.exists():
        print(f"Error: Configuration file '{config_path}' not found", file=sys.stderr)
        sys.exit(1)
    
    # Read configuration file
    try:
        with open(config_path, 'r') as f:
            content = f.read()
    except Exception as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Initialize parser
    enterprise_parser = EnterpriseSecurityParser()
    
    # Parse vendor type
    vendor = None
    if args.vendor:
        vendor = VendorType(args.vendor)
    
    # Parse configuration
    print("Parsing configuration...", file=sys.stderr)
    parsed_config = enterprise_parser.parse_config(content, vendor)
    print(f"✓ Parsed {parsed_config.total_lines} lines", file=sys.stderr)
    print(f"✓ Detected vendor: {parsed_config.vendor.value}", file=sys.stderr)
    
    # Run security analysis
    security_findings = []
    if not args.no_security:
        print("Running security analysis...", file=sys.stderr)
        security_findings = enterprise_parser.analyze_security(parsed_config, content)
        print(f"✓ Found {len(security_findings)} security issues", file=sys.stderr)
    
    # Generate output
    output_data = {
        'vendor': parsed_config.vendor.value,
        'hostname': parsed_config.hostname,
        'total_lines': parsed_config.total_lines,
        'security_findings': enterprise_parser.format_findings_for_output(security_findings),
        'security_summary': enterprise_parser.generate_summary(security_findings)
    }
    
    # Write output
    output_path = Path(args.output)
    
    if args.format == 'json':
        indent = 2 if args.pretty else None
        with open(output_path, 'w') as f:
            json.dump(output_data, f, indent=indent, default=str)
        print(f"✓ JSON output written to: {output_path}")
    else:  # HTML
        generate_html_report(output_data, output_path)
        print(f"✓ HTML report written to: {output_path}")
    
    # Print summary
    summary = output_data['security_summary']
    print(f"\nParsing Summary:")
    print(f"  Vendor: {output_data['vendor']}")
    print(f"  Hostname: {output_data['hostname'] or 'Unknown'}")
    print(f"  Total Lines: {output_data['total_lines']}")
    
    if not args.no_security:
        print(f"\nSecurity Analysis:")
        print(f"  Total Findings: {summary['total_findings']}")
        print(f"  Critical: {summary['critical']}")
        print(f"  High: {summary['high']}")
        print(f"  Medium: {summary['medium']}")
        print(f"  Low: {summary['low']}")
        print(f"  Info: {summary['info']}")


if __name__ == '__main__':
    main()