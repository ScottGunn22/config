"""Cryptography and Encryption Security Analysis Engine."""

import re
from typing import List, Dict, Any, Optional
from ..base_engine import BaseSecurityEngine, EngineCategory, EnginePriority
from ...core import Finding, VendorType, Severity, CVSSVector
from ..utils import safe_get_content, create_mock_config_line


class CryptographySecurityEngine(BaseSecurityEngine):
    """Comprehensive cryptography and encryption security analysis engine."""
    
    def __init__(self):
        super().__init__()
        self.rule_count = 18
    
    def get_category(self) -> EngineCategory:
        return EngineCategory.SECURITY
    
    def get_priority(self) -> EnginePriority:
        return EnginePriority.HIGH
    
    def get_supported_vendors(self) -> List[VendorType]:
        return [VendorType.CISCO_IOS, VendorType.JUNIPER_JUNOS]
    
    def analyze_configuration(self, parsed_config: Dict[str, Any], 
                            vendor: VendorType) -> List[Finding]:
        """Analyze cryptographic configuration for security issues."""
        findings = []
        
        if vendor == VendorType.CISCO_IOS:
            findings.extend(self._analyze_cisco_crypto(parsed_config))
        elif vendor == VendorType.JUNIPER_JUNOS:
            findings.extend(self._analyze_juniper_crypto(parsed_config))
        
        return findings
    
    def _analyze_cisco_crypto(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Cisco cryptographic configuration."""
        findings = []
        config_lines = config.get("config_lines", [])
        
        # Extract crypto configuration
        crypto_config = self._extract_crypto_config(config_lines)
        
        # Run crypto security checks
        findings.extend(self._check_ssh_configuration(crypto_config))
        findings.extend(self._check_ssl_tls_configuration(crypto_config))
        findings.extend(self._check_ipsec_configuration(crypto_config))
        findings.extend(self._check_certificate_configuration(crypto_config))
        findings.extend(self._check_key_management(crypto_config))
        findings.extend(self._check_weak_ciphers(crypto_config))
        
        return findings
    
    def _extract_crypto_config(self, config_lines: List) -> Dict[str, Any]:
        """Extract cryptographic configuration from config lines."""
        crypto_config = {
            "ssh_version": None,
            "ssh_timeout": None,
            "ssh_retries": None,
            "ssl_proposals": [],
            "ipsec_transforms": [],
            "ipsec_policies": [],
            "certificates": [],
            "key_chains": [],
            "crypto_maps": [],
            "weak_ciphers": []
        }
        
        for line in config_lines:
            content = safe_get_content(line)
            if not hasattr(line, 'content'):
                line = create_mock_config_line(content)
            
            # SSH configuration
            if content.startswith("ip ssh"):
                if "version" in content:
                    crypto_config["ssh_version"] = {
                        "config_line": line,
                        "command": content
                    }
                elif "timeout" in content or "time-out" in content:
                    crypto_config["ssh_timeout"] = {
                        "config_line": line,
                        "command": content
                    }
                elif "authentication-retries" in content:
                    crypto_config["ssh_retries"] = {
                        "config_line": line,
                        "command": content
                    }
            
            # SSL/TLS configuration
            elif "ip http" in content and ("ssl" in content or "tls" in content):
                crypto_config["ssl_proposals"].append({
                    "config_line": line,
                    "command": content
                })
            
            # IPSec configuration
            elif content.startswith("crypto ipsec transform-set"):
                crypto_config["ipsec_transforms"].append({
                    "config_line": line,
                    "command": content
                })
            
            elif content.startswith("crypto ipsec policy"):
                crypto_config["ipsec_policies"].append({
                    "config_line": line,
                    "command": content
                })
            
            elif content.startswith("crypto map"):
                crypto_config["crypto_maps"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Certificate configuration
            elif "crypto pki" in content:
                crypto_config["certificates"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Key chain configuration
            elif content.startswith("key chain"):
                crypto_config["key_chains"].append({
                    "config_line": line,
                    "command": content
                })
            
            # Check for weak ciphers in cryptographic contexts only
            self._check_weak_ciphers_in_line(content, line, crypto_config)
        
        return crypto_config
    
    def _check_weak_ciphers_in_line(self, content: str, line, crypto_config: Dict):
        """Check for weak ciphers in appropriate cryptographic contexts only."""
        content_lower = content.lower()
        
        # Define cryptographic contexts where cipher checking makes sense
        crypto_contexts = [
            "crypto", "ssh", "ssl", "tls", "ipsec", "isakmp", "transform-set",
            "encryption", "cipher", "algorithm", "pki", "certificate", "key"
        ]
        
        # Only check for weak ciphers if we're in a cryptographic context
        in_crypto_context = any(context in content_lower for context in crypto_contexts)
        
        if not in_crypto_context:
            return
        
        # Weak cipher patterns with word boundaries to avoid false positives
        weak_cipher_checks = [
            # DES - but not in words like "description", "destination", "design"
            ("des", r'\bdes\b|des-cbc|des-40|des-56'),
            # 3DES 
            ("3des", r'\b3des\b|3des-cbc|triple-des'),
            # RC4
            ("rc4", r'\brc4\b|rc4-128|rc4-40'),
            # MD5 in crypto contexts
            ("md5", r'\bmd5\b|md5-hmac|hmac-md5'),
            # SHA1 in crypto contexts  
            ("sha1", r'\bsha1\b|sha-1|hmac-sha1')
        ]
        
        for cipher_name, pattern in weak_cipher_checks:
            if re.search(pattern, content_lower):
                # Additional exclusions for legitimate non-crypto uses
                exclusions = ["no ", "disable", "remove", "description", "destination"]
                if not any(exclusion in content_lower for exclusion in exclusions):
                    crypto_config["weak_ciphers"].append({
                        "cipher": cipher_name,
                        "config_line": line,
                        "command": content
                    })
    
    def _check_ssh_configuration(self, crypto_config: Dict) -> List[Finding]:
        """Check SSH configuration security."""
        findings = []
        
        ssh_version = crypto_config.get("ssh_version")
        
        # Check SSH version
        if not ssh_version:
            findings.append(self.create_finding(
                rule_id="CRYPTO-001",
                title="SSH Version Not Explicitly Configured",
                description="SSH version not explicitly set. May default to less secure version 1.",
                severity=Severity.HIGH,
                category="Cryptography",
                recommendation="Configure SSH version 2 explicitly",
                fix_commands=["ip ssh version 2"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="N"
                ),
                nist_controls=["SC-8", "SC-13"],
                vendor=VendorType.CISCO_IOS
            ))
        elif "version 1" in ssh_version["command"]:
            findings.append(self.create_finding(
                rule_id="CRYPTO-002",
                title="SSH Version 1 Enabled",
                description="SSH version 1 is enabled. This version has known cryptographic vulnerabilities.",
                severity=Severity.CRITICAL,
                category="Cryptography",
                config_line=ssh_version["config_line"],
                recommendation="Use SSH version 2 only",
                fix_commands=["ip ssh version 2"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="L",
                    privileges_required="N",
                    confidentiality="H",
                    integrity="H",
                    availability="N"
                ),
                nist_controls=["SC-8", "SC-13"],
                vendor=VendorType.CISCO_IOS
            ))
        
        # Check SSH timeout
        ssh_timeout = crypto_config.get("ssh_timeout")
        if ssh_timeout:
            timeout_match = re.search(r'(\d+)', ssh_timeout["command"])
            if timeout_match:
                timeout_value = int(timeout_match.group(1))
                if timeout_value > 300:  # More than 5 minutes
                    findings.append(self.create_finding(
                        rule_id="CRYPTO-003",
                        title="SSH Timeout Too Long",
                        description=f"SSH timeout set to {timeout_value} seconds. Long timeouts increase exposure to attacks.",
                        severity=Severity.LOW,
                        category="Cryptography",
                        config_line=ssh_timeout["config_line"],
                        recommendation="Set SSH timeout to 120-300 seconds",
                        fix_commands=["ip ssh timeout 120"],
                        cvss_vector=CVSSVector(
                            attack_vector="N",
                            attack_complexity="H",
                            privileges_required="L",
                            confidentiality="L",
                            integrity="N",
                            availability="N"
                        ),
                        nist_controls=["AC-12"],
                        vendor=VendorType.CISCO_IOS
                    ))
        
        return findings
    
    def _check_ssl_tls_configuration(self, crypto_config: Dict) -> List[Finding]:
        """Check SSL/TLS configuration."""
        findings = []
        
        ssl_configs = crypto_config.get("ssl_proposals", [])
        
        for ssl_config in ssl_configs:
            # Check for insecure SSL/TLS versions
            if any(version in ssl_config["command"].lower() for version in ["sslv2", "sslv3", "tlsv1.0"]):
                findings.append(self.create_finding(
                    rule_id="CRYPTO-004",
                    title="Insecure SSL/TLS Version Enabled",
                    description="Insecure SSL/TLS version detected. SSLv2, SSLv3, and TLSv1.0 have known vulnerabilities.",
                    severity=Severity.HIGH,
                    category="Cryptography",
                    config_line=ssl_config["config_line"],
                    recommendation="Use TLS 1.2 or higher only",
                    fix_commands=["ip http secure-server ssl-version tlsv1.2"],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="N"
                    ),
                    nist_controls=["SC-8", "SC-13"],
                    vendor=VendorType.CISCO_IOS
                ))
        
        return findings
    
    def _check_ipsec_configuration(self, crypto_config: Dict) -> List[Finding]:
        """Check IPSec configuration."""
        findings = []
        
        transforms = crypto_config.get("ipsec_transforms", [])
        
        for transform in transforms:
            # Check for weak IPSec transforms
            if any(weak in transform["command"].lower() for weak in ["des", "3des", "md5"]):
                findings.append(self.create_finding(
                    rule_id="CRYPTO-005",
                    title="Weak IPSec Transform Set",
                    description="Weak IPSec encryption or authentication algorithm detected (DES, 3DES, or MD5).",
                    severity=Severity.HIGH,
                    category="Cryptography",
                    config_line=transform["config_line"],
                    recommendation="Use AES with SHA-256 or stronger",
                    fix_commands=["crypto ipsec transform-set STRONG esp-aes esp-sha256-hmac"],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L",
                        privileges_required="N",
                        confidentiality="H",
                        integrity="H",
                        availability="N"
                    ),
                    nist_controls=["SC-8", "SC-13"],
                    vendor=VendorType.CISCO_IOS
                ))
        
        return findings
    
    def _check_certificate_configuration(self, crypto_config: Dict) -> List[Finding]:
        """Check certificate configuration."""
        findings = []
        
        certificates = crypto_config.get("certificates", [])
        
        # Basic check for certificate configuration
        if not certificates:
            findings.append(self.create_finding(
                rule_id="CRYPTO-006",
                title="No PKI/Certificate Configuration Found",
                description="No PKI or certificate configuration detected. May impact secure communication capabilities.",
                severity=Severity.INFO,
                category="Cryptography",
                recommendation="Consider implementing PKI for certificate-based authentication",
                fix_commands=["crypto pki trustpoint <NAME>"],
                cvss_vector=CVSSVector(
                    attack_vector="L",
                    attack_complexity="H",
                    privileges_required="H",
                    confidentiality="N",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-17"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_key_management(self, crypto_config: Dict) -> List[Finding]:
        """Check key management configuration."""
        findings = []
        
        key_chains = crypto_config.get("key_chains", [])
        
        # This is a basic implementation - would need more detailed parsing
        if not key_chains and crypto_config.get("ipsec_transforms"):
            findings.append(self.create_finding(
                rule_id="CRYPTO-007",
                title="IPSec Without Proper Key Management",
                description="IPSec configuration detected without evident key management setup.",
                severity=Severity.MEDIUM,
                category="Cryptography",
                recommendation="Implement proper key management (IKE/ISAKMP policies)",
                fix_commands=["crypto isakmp policy 10"],
                cvss_vector=CVSSVector(
                    attack_vector="N",
                    attack_complexity="H",
                    privileges_required="H",
                    confidentiality="L",
                    integrity="L",
                    availability="N"
                ),
                nist_controls=["SC-12", "SC-13"],
                vendor=VendorType.CISCO_IOS
            ))
        
        return findings
    
    def _check_weak_ciphers(self, crypto_config: Dict) -> List[Finding]:
        """Check for weak cipher usage."""
        findings = []
        
        weak_ciphers = crypto_config.get("weak_ciphers", [])
        
        if weak_ciphers:
            # Group by cipher type
            cipher_groups = {}
            for cipher_info in weak_ciphers:
                cipher = cipher_info["cipher"]
                if cipher not in cipher_groups:
                    cipher_groups[cipher] = []
                cipher_groups[cipher].append(cipher_info)
            
            for cipher, instances in cipher_groups.items():
                severity = Severity.HIGH if cipher in ["des", "rc4"] else Severity.MEDIUM
                
                findings.append(self.create_finding(
                    rule_id=f"CRYPTO-008",
                    title=f"Weak Cryptographic Algorithm: {cipher.upper()}",
                    description=f"Weak cryptographic algorithm {cipher.upper()} detected in {len(instances)} configuration(s). "
                               f"This algorithm has known vulnerabilities.",
                    severity=severity,
                    category="Cryptography",
                    config_line=instances[0]["config_line"],
                    recommendation=f"Replace {cipher.upper()} with stronger alternatives (AES, SHA-256)",
                    fix_commands=[f"# Review and replace {cipher.upper()} usage"],
                    cvss_vector=CVSSVector(
                        attack_vector="N",
                        attack_complexity="L" if cipher in ["des", "rc4"] else "H",
                        privileges_required="N",
                        confidentiality="H" if cipher in ["des", "rc4"] else "L",
                        integrity="H" if cipher in ["des", "rc4"] else "L",
                        availability="N"
                    ),
                    nist_controls=["SC-13"],
                    vendor=VendorType.CISCO_IOS
                ))
        
        return findings
    
    def _analyze_juniper_crypto(self, config: Dict[str, Any]) -> List[Finding]:
        """Analyze Juniper cryptographic configuration (placeholder)."""
        # TODO: Implement Juniper crypto analysis
        return []