"""Rule coverage validation and gap analysis."""

import re
from typing import Dict, List, Set, Tuple
from ..core import VendorType


class CoverageValidator:
    """Validates rule coverage against known security standards and benchmarks."""
    
    def __init__(self):
        self.cisco_security_checklist = self._load_cisco_security_checklist()
        self.nist_mappings = self._load_nist_mappings()
        self.cis_benchmarks = self._load_cis_benchmarks()
    
    def _load_cisco_security_checklist(self) -> Dict[str, Dict]:
        """Load comprehensive Cisco security checklist."""
        return {
            "authentication": {
                "enable_secret": {
                    "description": "Strong enable secret password",
                    "pattern": r"enable secret",
                    "severity": "CRITICAL",
                    "nist": ["IA-5", "AC-3"]
                },
                "aaa_new_model": {
                    "description": "AAA new-model enabled",
                    "pattern": r"aaa new-model",
                    "severity": "HIGH",
                    "nist": ["IA-2", "AC-3"]
                },
                "no_type7_passwords": {
                    "description": "No Type 7 passwords",
                    "pattern": r"password 7",
                    "check_type": "forbidden",
                    "severity": "HIGH",
                    "nist": ["IA-5"]
                },
                "password_encryption": {
                    "description": "Password encryption service",
                    "pattern": r"service password-encryption",
                    "severity": "MEDIUM",
                    "nist": ["IA-5"]
                }
            },
            "access_control": {
                "vty_ssh_only": {
                    "description": "VTY lines restricted to SSH",
                    "pattern": r"transport input ssh",
                    "severity": "HIGH",
                    "nist": ["SC-8", "AC-17"]
                },
                "vty_acl": {
                    "description": "VTY access control lists",
                    "pattern": r"access-class.*in",
                    "severity": "HIGH",
                    "nist": ["AC-4"]
                },
                "exec_timeout": {
                    "description": "Appropriate exec timeout",
                    "pattern": r"exec-timeout [0-9]+ 0",
                    "severity": "MEDIUM",
                    "nist": ["AC-12"]
                },
                "login_banner": {
                    "description": "Warning login banner",
                    "pattern": r"banner login",
                    "severity": "LOW",
                    "nist": ["AC-8"]
                }
            },
            "network_services": {
                "no_http": {
                    "description": "HTTP server disabled",
                    "pattern": r"no ip http server",
                    "severity": "MEDIUM",
                    "nist": ["SC-8", "CM-7"]
                },
                "no_finger": {
                    "description": "Finger service disabled",
                    "pattern": r"no service finger",
                    "severity": "LOW",
                    "nist": ["CM-7"]
                },
                "no_small_servers": {
                    "description": "Small servers disabled",
                    "pattern": r"no service (tcp|udp)-small-servers",
                    "severity": "MEDIUM",
                    "nist": ["CM-7"]
                },
                "no_bootp": {
                    "description": "BOOTP server disabled",
                    "pattern": r"no ip bootp server",
                    "severity": "MEDIUM",
                    "nist": ["CM-7"]
                },
                "no_source_route": {
                    "description": "IP source routing disabled",
                    "pattern": r"no ip source-route",
                    "severity": "MEDIUM",
                    "nist": ["SC-7"]
                },
                "no_domain_lookup": {
                    "description": "Domain lookups disabled",
                    "pattern": r"no ip domain-lookup",
                    "severity": "MEDIUM",
                    "nist": ["CM-7"]
                },
                "no_classless": {
                    "description": "Classless routing disabled",
                    "pattern": r"no ip classless",
                    "severity": "MEDIUM",
                    "nist": ["SC-7"]
                },
                "no_cdp": {
                    "description": "CDP disabled globally",
                    "pattern": r"no cdp run",
                    "severity": "LOW",
                    "nist": ["SC-7"]
                }
            },
            "interface_security": {
                "urpf": {
                    "description": "uRPF enabled on interfaces",
                    "pattern": r"ip verify unicast source reachable-via",
                    "severity": "HIGH",
                    "nist": ["SC-7"]
                },
                "no_proxy_arp": {
                    "description": "Proxy ARP disabled",
                    "pattern": r"no ip proxy-arp",
                    "severity": "LOW",
                    "nist": ["SC-7"]
                },
                "no_redirects": {
                    "description": "IP redirects disabled",
                    "pattern": r"no ip redirects",
                    "severity": "MEDIUM",
                    "nist": ["SC-7"]
                },
                "no_directed_broadcast": {
                    "description": "Directed broadcast disabled",
                    "pattern": r"no ip directed-broadcast",
                    "severity": "MEDIUM",
                    "nist": ["SC-7"]
                }
            },
            "snmp_security": {
                "snmp_acl": {
                    "description": "SNMP community ACLs",
                    "pattern": r"snmp-server community \S+ RO \d+",
                    "severity": "HIGH",
                    "nist": ["AC-3"]
                },
                "no_snmp_rw": {
                    "description": "No SNMP RW communities",
                    "pattern": r"snmp-server community \S+ RW",
                    "check_type": "forbidden",
                    "severity": "HIGH",
                    "nist": ["AC-3"]
                },
                "snmp_traps": {
                    "description": "SNMP trap configuration",
                    "pattern": r"snmp-server enable traps",
                    "severity": "LOW",
                    "nist": ["AU-3"]
                }
            },
            "logging": {
                "logging_host": {
                    "description": "Centralized logging configured",
                    "pattern": r"logging \d+\.\d+\.\d+\.\d+",
                    "severity": "MEDIUM",
                    "nist": ["AU-3", "AU-6"]
                },
                "logging_trap": {
                    "description": "Appropriate logging level",
                    "pattern": r"logging trap (informational|notifications|warnings|errors)",
                    "severity": "LOW",
                    "nist": ["AU-3"]
                }
            },
            "ntp_security": {
                "ntp_auth": {
                    "description": "NTP authentication enabled",
                    "pattern": r"ntp authenticate",
                    "severity": "LOW",
                    "nist": ["SC-45"]
                }
            }
        }
    
    def _load_nist_mappings(self) -> Dict[str, List[str]]:
        """Load NIST control mappings."""
        return {
            "IA-2": "Identification and Authentication (Organizational Users)",
            "IA-5": "Authenticator Management", 
            "AC-3": "Access Enforcement",
            "AC-4": "Information Flow Enforcement",
            "AC-8": "System Use Notification",
            "AC-12": "Session Termination",
            "AC-17": "Remote Access",
            "SC-7": "Boundary Protection",
            "SC-8": "Transmission Confidentiality and Integrity",
            "SC-45": "System Time Synchronization",
            "CM-7": "Least Functionality",
            "AU-3": "Content of Audit Records",
            "AU-6": "Audit Review, Analysis, and Reporting"
        }
    
    def _load_cis_benchmarks(self) -> Dict[str, Dict]:
        """Load CIS benchmark mappings."""
        return {
            "1.1.1": "Ensure 'service password-encryption' is enabled",
            "1.1.2": "Ensure 'enable secret' is configured",
            "1.1.3": "Ensure 'username secret' is configured for all users",
            "2.1.1": "Ensure 'no ip source-route' is configured",
            "2.1.2": "Ensure 'no ip proxy-arp' is configured on all interfaces",
            "2.1.3": "Ensure 'no ip redirects' is configured on all interfaces",
            "2.2.1": "Ensure 'no cdp run' is configured",
            "2.2.2": "Ensure 'no service tcp-small-servers' is configured",
            "2.2.3": "Ensure 'no service udp-small-servers' is configured",
            "3.1.1": "Ensure 'transport input ssh' is configured on VTY lines",
            "3.1.2": "Ensure 'exec-timeout' is configured on all lines",
            "3.2.1": "Ensure 'access-class' is configured for VTY lines"
        }
    
    def analyze_coverage_gaps(self, config_lines: List, current_findings: List) -> Dict[str, List]:
        """Analyze gaps in rule coverage against security standards."""
        gaps = {
            "missing_checks": [],
            "weak_coverage": [],
            "unchecked_patterns": [],
            "missing_nist_controls": []
        }
        
        # Check against Cisco security checklist
        for category, checks in self.cisco_security_checklist.items():
            for check_id, check_info in checks.items():
                pattern = check_info["pattern"]
                check_type = check_info.get("check_type", "required")
                
                # Check if we have a rule covering this pattern
                covered = any(
                    finding.rule_id.lower().replace("-", "_").replace("_", "") in check_id.lower().replace("_", "")
                    for finding in current_findings
                )
                
                if not covered:
                    # Check if the pattern exists in config
                    if check_type == "required":
                        has_pattern = any(re.search(pattern, line.content, re.I) for line in config_lines)
                        if not has_pattern:
                            gaps["missing_checks"].append({
                                "category": category,
                                "check": check_id,
                                "description": check_info["description"],
                                "severity": check_info["severity"],
                                "nist": check_info.get("nist", [])
                            })
                    elif check_type == "forbidden":
                        has_pattern = any(re.search(pattern, line.content, re.I) for line in config_lines)
                        if has_pattern:
                            gaps["missing_checks"].append({
                                "category": category,
                                "check": check_id,
                                "description": f"Forbidden pattern detected: {check_info['description']}",
                                "severity": check_info["severity"],
                                "nist": check_info.get("nist", [])
                            })
        
        return gaps
    
    def generate_coverage_report(self, config_lines: List, current_findings: List) -> str:
        """Generate a comprehensive coverage report."""
        gaps = self.analyze_coverage_gaps(config_lines, current_findings)
        
        report = ["SECURITY RULE COVERAGE ANALYSIS", "=" * 50, ""]
        
        # Current coverage
        report.append(f"Current Findings: {len(current_findings)}")
        report.append(f"Security Categories Covered: {len(set(f.category for f in current_findings))}")
        report.append("")
        
        # Missing checks
        if gaps["missing_checks"]:
            report.append("MISSING SECURITY CHECKS")
            report.append("-" * 30)
            
            by_severity = {}
            for gap in gaps["missing_checks"]:
                severity = gap["severity"]
                if severity not in by_severity:
                    by_severity[severity] = []
                by_severity[severity].append(gap)
            
            for severity in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
                if severity in by_severity:
                    report.append(f"\\n{severity} Priority:")
                    for gap in by_severity[severity]:
                        report.append(f"  ❌ {gap['check']}: {gap['description']}")
                        report.append(f"     Category: {gap['category']}")
                        report.append(f"     NIST: {', '.join(gap['nist'])}")
                        report.append("")
        
        # Coverage summary
        total_possible = sum(len(checks) for checks in self.cisco_security_checklist.values())
        covered = total_possible - len(gaps["missing_checks"])
        coverage_pct = (covered / total_possible) * 100
        
        report.append("COVERAGE SUMMARY")
        report.append("-" * 20)
        report.append(f"Coverage: {covered}/{total_possible} checks ({coverage_pct:.1f}%)")
        report.append(f"Missing: {len(gaps['missing_checks'])} critical security checks")
        
        if coverage_pct < 80:
            report.append("\\n⚠️  WARNING: Security coverage below 80%!")
            report.append("   Consider implementing missing checks for comprehensive protection.")
        elif coverage_pct >= 95:
            report.append("\\n✅ Excellent security coverage!")
        else:
            report.append("\\n👍 Good security coverage, room for improvement.")
        
        return "\\n".join(report)
    
    def suggest_missing_rules(self, gaps: Dict) -> List[Dict]:
        """Suggest specific rules to implement for missing checks."""
        suggestions = []
        
        for gap in gaps["missing_checks"]:
            if gap["severity"] in ["CRITICAL", "HIGH"]:
                suggestions.append({
                    "rule_id": f"MISSING-{gap['check'].upper()}",
                    "title": gap["description"],
                    "category": gap["category"].title(),
                    "severity": gap["severity"],
                    "implementation": f"Check for pattern: {self.cisco_security_checklist[gap['category']][gap['check']]['pattern']}",
                    "nist_controls": gap["nist"]
                })
        
        return suggestions