"""Base security rule engine."""

from abc import ABC, abstractmethod
from typing import List, Dict, Any
from ..core import Finding, VendorType


class BaseRuleEngine(ABC):
    """Base class for security rule engines."""
    
    def __init__(self):
        self.category = "General"
        self.rules = []
    
    @abstractmethod
    def check_config(self, parsed_config: Dict[str, Any], vendor: VendorType) -> List[Finding]:
        """Check configuration against security rules."""
        pass
    
    def create_finding(
        self,
        rule_id: str,
        title: str,
        description: str,
        severity: str,
        config_line=None,
        recommendation: str = "",
        fix_commands: List[str] = None,
        cvss_vector=None,
        nist_controls: List[str] = None,
        vendor: VendorType = VendorType.UNKNOWN
    ) -> Finding:
        """Helper method to create a standardized finding."""
        from ..core import Finding, Severity, CVSSVector
        
        # Convert severity string to enum
        severity_map = {
            "CRITICAL": Severity.CRITICAL,
            "HIGH": Severity.HIGH,
            "MEDIUM": Severity.MEDIUM,
            "LOW": Severity.LOW,
            "INFO": Severity.INFO
        }
        
        finding = Finding(
            title=title,
            description=description,
            category=self.category,
            severity=severity_map.get(severity.upper(), Severity.INFO),
            config_line=config_line,
            recommendation=recommendation,
            fix_commands=fix_commands or [],
            nist_controls=nist_controls or [],
            vendor=vendor,
            rule_id=rule_id
        )
        
        if cvss_vector:
            finding.cvss_vector = cvss_vector
            finding.cvss_score = cvss_vector.calculate_score()
        
        return finding