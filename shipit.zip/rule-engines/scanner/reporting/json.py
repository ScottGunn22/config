"""JSON report generator."""

import json
from typing import Dict, Any
from ..core import ScanResults


class JSONReporter:
    """Generate JSON format reports."""
    
    def generate_report(self, results: ScanResults) -> str:
        """Generate JSON report."""
        report_data = {
            "metadata": {
                "tool": "Network Security Scanner",
                "version": "1.0.0",
                "timestamp": results.scan_timestamp.isoformat(),
                "scan_duration_ms": results.scan_duration_ms
            },
            "target": {
                "vendor": results.vendor.value,
                "hostname": results.device_hostname,
                "config_lines_total": results.config_lines_total
            },
            "summary": results.get_summary(),
            "findings": [finding.to_dict() for finding in results.findings]
        }
        
        return json.dumps(report_data, indent=2, default=str)